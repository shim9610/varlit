fn main() {
    println!("cargo:rustc-link-search=native=/workspace/scratch/format-practicality-20261104/lib");
}
