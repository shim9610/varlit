from pathlib import Path
import shutil,subprocess,os,json,tempfile,time
R=Path(__file__).resolve().parent
assert 'FINISHED 105' in (R/'driver.log').read_text(),'Do not build during primary timings'
old=R/'original-harness';old.mkdir();shutil.copy2(R/'src/main.rs',old/'main.rs');shutil.copy2(R/'build.rs',old/'build.rs')
p=R/'src/main.rs';s=p.read_text();s=s.replace('    fn sqlite3_close(d: *mut Db) -> c_int;','    fn sqlite3_close(d: *mut Db) -> c_int;\n    fn sqlite3_busy_timeout(d: *mut Db, ms:c_int)->c_int;\n    fn sqlite3_clear_bindings(s:*mut Statement)->c_int;')
s=s.replace('            let mut x = Self {','            assert_eq!(sqlite3_busy_timeout(db,5000),0);\n            let mut x = Self {',1)
a=s.index('    fn put(&mut self, id: usize, b: &[u8]) {',s.index('struct Sql'));b=s.index('    fn get(',a)
part=s[a:b];needle='            assert_eq!(sqlite3_reset(self.stmt), 0);';assert needle in part
part=part.replace(needle,needle+'\n            assert_eq!(sqlite3_clear_bindings(self.stmt),0);');s=s[:a]+part+s[b:]
assert 'sqlite3_busy_timeout(db,5000)'in s and 'sqlite3_clear_bindings(self.stmt)'in s;p.write_text(s)
env=os.environ.copy();env.update(CARGO_HOME='/workspace/tooling/cargo',RUSTUP_HOME='/workspace/tooling/rustup',CARGO_TARGET_DIR='/workspace/varlit/target',CARGO_BUILD_JOBS='4');env['PATH']='/workspace/tooling/cargo/bin:'+env['PATH']
with (R/'build-sqlite-correction.log').open('w')as f:
 subprocess.run(['cargo','fmt','--manifest-path',str(R/'Cargo.toml')],env=env,stdout=f,stderr=f,check=True)
 subprocess.run(['cargo','build','--release','--offline','--manifest-path',str(R/'Cargo.toml')],env=env,stdout=f,stderr=f,check=True)
shutil.copy2('/workspace/varlit/target/release/format-practicality',R/'bench-sqlite')
smoke=[]
for n in [128,4096,65536,1<<20,4<<20]:
 with tempfile.TemporaryDirectory(dir=R/'data')as d:
  p=subprocess.run([str(R/'bench-sqlite'),'sqlite',d,str(16<<20),str(n),'8',str(4<<20)],capture_output=True,text=True,timeout=120)
  smoke.append(dict(payload=n,exit=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stderr
(R/'smoke-sqlite-corrected.json').write_text(json.dumps(smoke,indent=2))
# Do not import run.py: its benchmark loop is intentionally top-level.
plan=json.loads((R/'plan.json').read_text());plan['modes']=['sqlite'];plan['sqlite_busy_timeout_ms']=5000;plan['sqlite_static_binding_lifetime']='clear_bindings after reset while input bytes remain alive';plan['replaces']='All original SQLite timing observations, including successful ones; those attempts remain retained.'
import hashlib
plan['sha256']={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [R/'bench-sqlite',R/'src/main.rs',R/'Cargo.lock',R/'measure']};(R/'sqlite-plan.json').write_text(json.dumps(plan,indent=2))
os.sched_setaffinity(0,plan['affinity']);O=R/'sqlite-timings';O.mkdir();rows=[]
for c in plan['cases']:
 for g in range(3):
  stem=f"{c['name']}-g{g}-sqlite";row=dict(case=c['name'],group=g,mode='sqlite');t=time.monotonic()
  with tempfile.TemporaryDirectory(prefix=stem+'-',dir=R/'data')as d:
   cmd=[str(R/'measure'),str(O/(stem+'.usage.json')),str(O/(stem+'.pid')),str(R/'bench-sqlite'),'sqlite',d,str(c['total']),str(c['payload']),'8',str(plan['query_bytes'])]
   with (O/(stem+'.stdout')).open('w')as o,(O/(stem+'.stderr')).open('w')as e:
    p=subprocess.run(cmd,stdout=o,stderr=e,env={**os.environ,'TMPDIR':d},timeout=600)
   row['exit']=p.returncode;row['command']=cmd
   if p.returncode:row['error']=f'exit {p.returncode}'
   else:
    row['result']=json.loads((O/(stem+'.stdout')).read_text());row['usage']=json.loads((O/(stem+'.usage.json')).read_text());assert row['result']['verified'] and row['result']['count']==c['total']//c['payload']
  row['wall_seconds']=time.monotonic()-t;rows.append(row)
  with (R/'sqlite-samples.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
  print(stem,round(row['wall_seconds'],2),row.get('error','OK'),flush=True)
assert len(rows)==15 and not any('error'in r for r in rows)
print('FINISHED SQLITE',len(rows),flush=True)
