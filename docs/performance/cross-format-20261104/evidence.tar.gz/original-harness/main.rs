//! Linux-only comparative diagnostic, not product code. All successful bytes are validated.
use std::{
    ffi::{CString, c_char, c_int, c_uint, c_void},
    fs::{File, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    time::Instant,
};
use varlit::*;
type R<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;
#[derive(Clone, VarlitBlock)]
#[varlit(id = 1, version = 1, kind = "variable", key = "key")]
struct Blob {
    key: u64,
    payload: Vec<u8>,
}
#[derive(Clone, VarlitBlock)]
#[varlit(id = 1, version = 1, kind = "variable")]
struct StreamBlob {
    key: u64,
    payload: Vec<u8>,
}
static BLOCKS: &[BlockDescriptor] = &[BlockDescriptor {
    id: 1,
    name: "Blob",
    version: 1,
    kind: BlockKind::Variable,
    fields: &[],
}];
static INDEXED: &[DiskIndexedBlock] = &[DiskIndexedBlock::of::<Blob>()];
fn ispec() -> FormatSpec {
    FormatSpec::new(
        b"XCROSS01",
        1,
        Endian::Little,
        0,
        IndexPolicy::KeyedOffsetChain,
        IntegrityPolicy::Crc32,
        RecoveryPolicy::Strict,
        ManifestPolicy::None,
        BLOCKS,
    )
    .with_block_identities(&[Blob::IDENTITY])
}
fn spec() -> FormatSpec {
    FormatSpec::new(
        b"XCROSS01",
        1,
        Endian::Little,
        0,
        IndexPolicy::BlockOffsetChain,
        IntegrityPolicy::Crc32,
        RecoveryPolicy::Strict,
        ManifestPolicy::None,
        BLOCKS,
    )
    .with_block_identities(&[StreamBlob::IDENTITY])
}
fn nspec() -> FormatSpec {
    spec().with_commit_policy(CommitPolicy::TransactionMarker(
        TransactionMarkerMode::Explicit,
    ))
}
fn stream_blob(id: usize, n: usize) -> StreamBlob {
    let b = make(id, n);
    StreamBlob {
        key: b.key,
        payload: b.payload,
    }
}
fn options() -> DiskIndexOptions {
    DiskIndexOptions {
        cache_bytes: 8 << 20,
        ..Default::default()
    }
}
fn soptions() -> StreamOptions {
    StreamOptions {
        state: options(),
        ..Default::default()
    }
}
fn plan() -> DiskIndexPlan {
    DiskIndexPlan::canonical(ispec(), INDEXED).unwrap()
}
fn make(id: usize, n: usize) -> Blob {
    let mut payload = vec![(id % 251) as u8; n];
    payload[..8].copy_from_slice(&(id as u64).to_le_bytes());
    Blob {
        key: id as u64,
        payload,
    }
}
#[inline(never)]
fn check(id: usize, b: &[u8], n: usize) {
    assert_eq!(b.len(), n);
    assert_eq!(&b[..8], &(id as u64).to_le_bytes());
    assert!(b[8..].iter().all(|&x| x == (id % 251) as u8));
    std::hint::black_box(b);
}
#[link(name = "hdf5_serial")]
unsafe extern "C" {
    static H5T_NATIVE_UCHAR_g: i64;
    static H5P_CLS_DATASET_CREATE_ID_g: i64;
    static H5P_CLS_DATASET_ACCESS_ID_g: i64;
    fn H5open() -> c_int;
    fn H5get_libversion(a: *mut c_uint, b: *mut c_uint, c: *mut c_uint) -> c_int;
    fn H5is_library_threadsafe(x: *mut bool) -> c_int;
    fn H5Fcreate(n: *const c_char, f: c_uint, c: i64, a: i64) -> i64;
    fn H5Fopen(n: *const c_char, f: c_uint, a: i64) -> i64;
    fn H5Fclose(f: i64) -> c_int;
    fn H5Fflush(f: i64, s: c_int) -> c_int;
    fn H5Pcreate(c: i64) -> i64;
    fn H5Pclose(p: i64) -> c_int;
    fn H5Pset_chunk(p: i64, n: c_int, d: *const u64) -> c_int;
    fn H5Pset_fletcher32(p: i64) -> c_int;
    fn H5Pset_chunk_cache(p: i64, slots: usize, bytes: usize, w: f64) -> c_int;
    fn H5Screate_simple(r: c_int, d: *const u64, m: *const u64) -> i64;
    fn H5Sclose(s: i64) -> c_int;
    fn H5Sselect_hyperslab(
        s: i64,
        op: c_int,
        start: *const u64,
        stride: *const u64,
        count: *const u64,
        block: *const u64,
    ) -> c_int;
    fn H5Dcreate2(l: i64, n: *const c_char, t: i64, s: i64, lc: i64, dc: i64, da: i64) -> i64;
    fn H5Dopen2(l: i64, n: *const c_char, a: i64) -> i64;
    fn H5Dclose(d: i64) -> c_int;
    fn H5Dget_space(d: i64) -> i64;
    fn H5Dset_extent(d: i64, s: *const u64) -> c_int;
    fn H5Dwrite(d: i64, t: i64, m: i64, s: i64, p: i64, b: *const c_void) -> c_int;
    fn H5Dread(d: i64, t: i64, m: i64, s: i64, p: i64, b: *mut c_void) -> c_int;
}
fn hid(x: i64) -> i64 {
    assert!(x >= 0, "HDF5 ID error");
    x
}
fn hok(x: c_int) {
    assert!(x >= 0, "HDF5 operation error")
}
struct Hdf {
    file: i64,
    data: i64,
    memory: i64,
    space: i64,
    n: usize,
    rows: usize,
}
impl Hdf {
    fn create(path: &Path, n: usize, crc: bool) -> Self {
        unsafe {
            hok(H5open());
            let name = CString::new(path.to_str().unwrap()).unwrap();
            let file = hid(H5Fcreate(name.as_ptr(), 2, 0, 0));
            let s = hid(H5Screate_simple(
                2,
                [0, n as u64].as_ptr(),
                [u64::MAX, n as u64].as_ptr(),
            ));
            let p = hid(H5Pcreate(H5P_CLS_DATASET_CREATE_ID_g));
            hok(H5Pset_chunk(p, 2, [1, n as u64].as_ptr()));
            if crc {
                hok(H5Pset_fletcher32(p));
            }
            let a = hid(H5Pcreate(H5P_CLS_DATASET_ACCESS_ID_g));
            hok(H5Pset_chunk_cache(a, 521, 8 << 20, 0.75));
            let data = hid(H5Dcreate2(
                file,
                c"payload".as_ptr(),
                H5T_NATIVE_UCHAR_g,
                s,
                0,
                p,
                a,
            ));
            hok(H5Pclose(a));
            hok(H5Pclose(p));
            hok(H5Sclose(s));
            let memory = hid(H5Screate_simple(
                2,
                [1, n as u64].as_ptr(),
                std::ptr::null(),
            ));
            Self {
                file,
                data,
                memory,
                space: -1,
                n,
                rows: 0,
            }
        }
    }
    fn open(path: &Path, n: usize) -> Self {
        unsafe {
            hok(H5open());
            let name = CString::new(path.to_str().unwrap()).unwrap();
            let file = hid(H5Fopen(name.as_ptr(), 0, 0));
            let a = hid(H5Pcreate(H5P_CLS_DATASET_ACCESS_ID_g));
            hok(H5Pset_chunk_cache(a, 521, 8 << 20, 0.75));
            let data = hid(H5Dopen2(file, c"payload".as_ptr(), a));
            hok(H5Pclose(a));
            let space = hid(H5Dget_space(data));
            let memory = hid(H5Screate_simple(
                2,
                [1, n as u64].as_ptr(),
                std::ptr::null(),
            ));
            Self {
                file,
                data,
                memory,
                space,
                n,
                rows: 0,
            }
        }
    }
    fn extend(&mut self, rows: usize) {
        unsafe {
            if self.space >= 0 {
                hok(H5Sclose(self.space));
            }
            hok(H5Dset_extent(
                self.data,
                [rows as u64, self.n as u64].as_ptr(),
            ));
            self.space = hid(H5Dget_space(self.data));
            self.rows = rows;
        }
    }
    fn select(&self, id: usize) {
        unsafe {
            hok(H5Sselect_hyperslab(
                self.space,
                0,
                [id as u64, 0].as_ptr(),
                std::ptr::null(),
                [1, self.n as u64].as_ptr(),
                std::ptr::null(),
            ));
        }
    }
    fn put(&mut self, id: usize, b: &[u8]) {
        self.select(id);
        unsafe {
            hok(H5Dwrite(
                self.data,
                H5T_NATIVE_UCHAR_g,
                self.memory,
                self.space,
                0,
                b.as_ptr().cast(),
            ));
        }
    }
    fn get(&mut self, id: usize, b: &mut [u8]) {
        self.select(id);
        unsafe {
            hok(H5Dread(
                self.data,
                H5T_NATIVE_UCHAR_g,
                self.memory,
                self.space,
                0,
                b.as_mut_ptr().cast(),
            ));
        }
    }
    fn flush(&self) {
        unsafe {
            hok(H5Fflush(self.file, 1));
        }
    }
}
impl Drop for Hdf {
    fn drop(&mut self) {
        unsafe {
            if self.space >= 0 {
                hok(H5Sclose(self.space));
            }
            hok(H5Sclose(self.memory));
            hok(H5Dclose(self.data));
            hok(H5Fclose(self.file));
        }
    }
}
enum Db {}
enum Statement {}
#[link(name = "sqlite3")]
unsafe extern "C" {
    fn sqlite3_libversion() -> *const c_char;
    fn sqlite3_open(p: *const c_char, d: *mut *mut Db) -> c_int;
    fn sqlite3_close(d: *mut Db) -> c_int;
    fn sqlite3_exec(
        d: *mut Db,
        q: *const c_char,
        cb: *mut c_void,
        arg: *mut c_void,
        err: *mut *mut c_char,
    ) -> c_int;
    fn sqlite3_prepare_v2(
        d: *mut Db,
        q: *const c_char,
        n: c_int,
        s: *mut *mut Statement,
        t: *mut *const c_char,
    ) -> c_int;
    fn sqlite3_bind_int64(s: *mut Statement, i: c_int, v: i64) -> c_int;
    fn sqlite3_bind_blob64(
        s: *mut Statement,
        i: c_int,
        b: *const c_void,
        n: u64,
        de: Option<unsafe extern "C" fn(*mut c_void)>,
    ) -> c_int;
    fn sqlite3_step(s: *mut Statement) -> c_int;
    fn sqlite3_reset(s: *mut Statement) -> c_int;
    fn sqlite3_finalize(s: *mut Statement) -> c_int;
    fn sqlite3_column_blob(s: *mut Statement, i: c_int) -> *const c_void;
    fn sqlite3_column_bytes(s: *mut Statement, i: c_int) -> c_int;
    fn sqlite3_column_int64(s: *mut Statement, i: c_int) -> i64;
}
struct Sql {
    db: *mut Db,
    stmt: *mut Statement,
}
impl Sql {
    fn open(p: &Path, write: bool) -> Self {
        unsafe {
            let mut db = std::ptr::null_mut();
            let name = CString::new(p.to_str().unwrap()).unwrap();
            assert_eq!(sqlite3_open(name.as_ptr(), &mut db), 0);
            let mut x = Self {
                db,
                stmt: std::ptr::null_mut(),
            };
            x.exec("PRAGMA cache_size=-8192;");
            if write {
                x.exec("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; CREATE TABLE payload(id INTEGER PRIMARY KEY, bytes BLOB NOT NULL);");
                x.prepare("INSERT INTO payload VALUES(?1,?2)");
            } else {
                x.prepare("SELECT bytes FROM payload WHERE id=?1");
            }
            x
        }
    }
    fn exec(&self, q: &str) {
        unsafe {
            let q = CString::new(q).unwrap();
            assert_eq!(
                sqlite3_exec(
                    self.db,
                    q.as_ptr(),
                    std::ptr::null_mut(),
                    std::ptr::null_mut(),
                    std::ptr::null_mut()
                ),
                0,
                "SQLite exec {q:?}"
            );
        }
    }
    fn prepare(&mut self, q: &str) {
        unsafe {
            if !self.stmt.is_null() {
                assert_eq!(sqlite3_finalize(self.stmt), 0);
            }
            let q = CString::new(q).unwrap();
            assert_eq!(
                sqlite3_prepare_v2(
                    self.db,
                    q.as_ptr(),
                    -1,
                    &mut self.stmt,
                    std::ptr::null_mut()
                ),
                0
            );
        }
    }
    fn put(&mut self, id: usize, b: &[u8]) {
        unsafe {
            assert_eq!(sqlite3_bind_int64(self.stmt, 1, id as i64), 0);
            assert_eq!(
                sqlite3_bind_blob64(self.stmt, 2, b.as_ptr().cast(), b.len() as u64, None),
                0
            );
            assert_eq!(sqlite3_step(self.stmt), 101);
            assert_eq!(sqlite3_reset(self.stmt), 0);
        }
    }
    fn get(&mut self, id: usize, n: usize) {
        unsafe {
            assert_eq!(sqlite3_bind_int64(self.stmt, 1, id as i64), 0);
            assert_eq!(sqlite3_step(self.stmt), 100);
            let len = sqlite3_column_bytes(self.stmt, 0) as usize;
            let b = std::slice::from_raw_parts(sqlite3_column_blob(self.stmt, 0).cast::<u8>(), len);
            check(id, b, n);
            assert_eq!(sqlite3_reset(self.stmt), 0);
        }
    }
    fn scan(&mut self, n: usize, count: usize) {
        self.prepare("SELECT id,bytes FROM payload ORDER BY id");
        let mut id = 0;
        unsafe {
            loop {
                let rc = sqlite3_step(self.stmt);
                if rc == 101 {
                    break;
                }
                assert_eq!(rc, 100);
                assert_eq!(sqlite3_column_int64(self.stmt, 0), id as i64);
                let len = sqlite3_column_bytes(self.stmt, 1) as usize;
                let b =
                    std::slice::from_raw_parts(sqlite3_column_blob(self.stmt, 1).cast::<u8>(), len);
                check(id, b, n);
                id += 1;
            }
        }
        assert_eq!(id, count);
        self.prepare("SELECT bytes FROM payload WHERE id=?1");
    }
}
impl Drop for Sql {
    fn drop(&mut self) {
        unsafe {
            assert_eq!(sqlite3_finalize(self.stmt), 0);
            assert_eq!(sqlite3_close(self.db), 0);
        }
    }
}
fn write(mode: &str, p: &Path, total: usize, n: usize) -> R<()> {
    let count = total / n;
    let per = (16 << 20) / n;
    let batch = BatchOptions::default();
    match mode {
        "raw" => {
            let mut f = OpenOptions::new().write(true).create_new(true).open(p)?;
            let mut buf = Vec::with_capacity(4 << 20);
            for start in (0..count).step_by(per) {
                for id in start..start + per {
                    buf.extend_from_slice(&make(id, n).payload);
                    if buf.len() >= 4 << 20 {
                        f.write_all(&buf)?;
                        buf.clear();
                    }
                }
                if !buf.is_empty() {
                    f.write_all(&buf)?;
                    buf.clear();
                }
                f.sync_all()?;
            }
        }
        "hdf5" | "hdf5-fletcher" => {
            let mut h = Hdf::create(p, n, mode == "hdf5-fletcher");
            let file = File::open(p)?;
            for start in (0..count).step_by(per) {
                h.extend(start + per);
                for id in start..start + per {
                    h.put(id, &make(id, n).payload);
                }
                h.flush();
                file.sync_all()?;
            }
            drop(h);
            file.sync_all()?;
        }
        "sqlite" => {
            let mut s = Sql::open(p, true);
            for start in (0..count).step_by(per) {
                s.exec("BEGIN IMMEDIATE");
                for id in start..start + per {
                    s.put(id, &make(id, n).payload);
                }
                s.exec("COMMIT");
            }
            s.exec("PRAGMA wal_checkpoint(TRUNCATE)");
        }
        "varlit-native" => {
            let mut f = nspec().create(p)?;
            for start in (0..count).step_by(per) {
                for id in start..start + per {
                    f.push_info(&stream_blob(id, n))?;
                }
                f.commit_durable()?;
            }
        }
        "varlit-stream" => {
            let mut f = VarlitStreamWriter::create(spec(), p, soptions())?;
            for start in (0..count).step_by(per) {
                f.push_iter((start..start + per).map(|id| stream_blob(id, n)), batch)?;
                f.sync()?;
            }
        }
        "varlit-indexed" => {
            let mut f = VarlitIndexedWriter::create(ispec(), p, options(), plan())?;
            for start in (0..count).step_by(per) {
                f.push_iter((start..start + per).map(|id| make(id, n)), batch)?;
                f.sync()?;
            }
        }
        _ => panic!("mode"),
    }
    Ok(())
}
enum Reader {
    Raw(File),
    Hdf(Hdf),
    Sql(Sql),
    Native(VarlitFile, Vec<RecordIndexEntry>),
    Stream(VarlitStreamReader),
    Index(VarlitIndexedReader),
}
impl Reader {
    fn open(mode: &str, p: &Path, n: usize) -> R<Self> {
        Ok(match mode {
            "raw" => Self::Raw(File::open(p)?),
            "hdf5" | "hdf5-fletcher" => Self::Hdf(Hdf::open(p, n)),
            "sqlite" => Self::Sql(Sql::open(p, false)),
            "varlit-native" => {
                let f = VarlitFile::open_readonly(nspec(), p)?;
                let mut entries = Vec::new();
                f.block_entries_into::<StreamBlob>(&mut entries)?;
                Self::Native(f, entries)
            }
            "varlit-stream" => Self::Stream(VarlitStreamReader::open(spec(), p, soptions())?),
            "varlit-indexed" => {
                Self::Index(VarlitIndexedReader::open(ispec(), p, options(), plan())?)
            }
            _ => panic!("mode"),
        })
    }
    fn get(&mut self, id: usize, b: &mut Vec<u8>, n: usize) -> R<()> {
        match self {
            Self::Raw(f) => {
                f.seek(SeekFrom::Start((id * n) as u64))?;
                f.read_exact(b)?;
                check(id, b, n);
            }
            Self::Hdf(h) => {
                h.get(id, b);
                check(id, b, n);
            }
            Self::Sql(s) => s.get(id, n),
            Self::Native(f, entries) => {
                let row: StreamBlob = f.decode_block_into(&entries[id], b)?;
                assert_eq!(row.key, id as u64);
                check(id, &row.payload, n);
            }
            Self::Index(f) => {
                let row: Blob = f.get(&(id as u64))?.expect("present");
                assert_eq!(row.key, id as u64);
                check(id, &row.payload, n);
            }
            Self::Stream(_) => panic!("stream has no key point API"),
        }
        Ok(())
    }
    fn scan(&mut self, n: usize, count: usize) -> R<()> {
        let mut b = vec![0; n];
        match self {
            Self::Stream(f) => {
                let mut id = 0;
                for row in f.blocks::<StreamBlob>()? {
                    let row = row?;
                    assert_eq!(row.key, id as u64);
                    check(id, &row.payload, n);
                    id += 1;
                }
                assert_eq!(id, count);
            }
            Self::Index(f) => {
                let mut id = 0;
                for row in f.blocks::<Blob>()? {
                    let row = row?;
                    assert_eq!(row.key, id as u64);
                    check(id, &row.payload, n);
                    id += 1;
                }
                assert_eq!(id, count);
            }
            Self::Sql(s) => s.scan(n, count),
            _ => {
                for id in 0..count {
                    self.get(id, &mut b, n)?;
                }
            }
        }
        Ok(())
    }
}
fn storage(p: &Path) -> R<(u64, u64)> {
    use std::os::unix::fs::MetadataExt;
    let mut bytes = 0;
    let mut allocated = 0;
    for x in std::fs::read_dir(p)? {
        let x = x?;
        if x.file_type()?.is_file() {
            let m = x.metadata()?;
            bytes += m.len();
            allocated += m.blocks() * 512;
        }
    }
    Ok((bytes, allocated))
}
fn random(s: &mut u64) -> u64 {
    *s = s
        .wrapping_mul(6364136223846793005)
        .wrapping_add(1442695040888963407);
    *s
}
#[repr(C)]
struct Timespec {
    sec: std::ffi::c_long,
    nsec: std::ffi::c_long,
}
unsafe extern "C" {
    fn clock_gettime(id: c_int, t: *mut Timespec) -> c_int;
}
fn cpu() -> f64 {
    let mut t = Timespec { sec: 0, nsec: 0 };
    assert_eq!(unsafe { clock_gettime(2, &mut t) }, 0);
    t.sec as f64 + t.nsec as f64 / 1e9
}
fn main() -> R<()> {
    let a: Vec<_> = std::env::args().collect();
    if a.get(1).is_some_and(|s| s == "versions") {
        unsafe {
            hok(H5open());
            let (mut x, mut y, mut z) = (0, 0, 0);
            H5get_libversion(&mut x, &mut y, &mut z);
            let mut ts = false;
            H5is_library_threadsafe(&mut ts);
            println!(
                "{}",
                serde_json::json!({"hdf5":format!("{x}.{y}.{z}"),"hdf5_threadsafe":ts,"sqlite":std::ffi::CStr::from_ptr(sqlite3_libversion()).to_str()?})
            );
        }
        return Ok(());
    }
    let mode = &a[1];
    let dir = PathBuf::from(&a[2]);
    let total: usize = a[3].parse()?;
    let n: usize = a[4].parse()?;
    let readers: usize = a[5].parse()?;
    let query_bytes: usize = a[6].parse()?;
    assert!(
        total >= 16 << 20
            && total.is_multiple_of(16 << 20)
            && (16usize << 20).is_multiple_of(n)
            && n >= 8
            && readers > 0
    );
    let path = dir.join("data.bin");
    let count = total / n;
    let c = cpu();
    let start = Instant::now();
    write(mode, &path, total, n)?;
    let write_seconds = start.elapsed().as_secs_f64();
    let write_cpu = cpu() - c;
    let (logical_bytes, allocated_bytes) = storage(&dir)?;
    let c = cpu();
    let start = Instant::now();
    let mut r = Reader::open(mode, &path, n)?;
    let open_seconds = start.elapsed().as_secs_f64();
    let open_cpu = cpu() - c;
    let c = cpu();
    let start = Instant::now();
    r.scan(n, count)?;
    let scan_seconds = start.elapsed().as_secs_f64();
    let scan_cpu = cpu() - c;
    let queries = (query_bytes / n).max(16);
    let c = cpu();
    let random_seconds = if mode == "varlit-stream" {
        None
    } else {
        let mut seed = 961004;
        let mut b = vec![0; n];
        let start = Instant::now();
        for _ in 0..queries {
            let id = (random(&mut seed) % (count as u64)) as usize;
            r.get(id, &mut b, n)?;
        }
        Some(start.elapsed().as_secs_f64())
    };
    let random_cpu = if random_seconds.is_some() {
        Some(cpu() - c)
    } else {
        None
    };
    drop(r);
    let c = cpu();
    let start = Instant::now();
    std::thread::scope(|scope| -> R<()> {
        let mut workers = Vec::new();
        for _ in 0..readers {
            let path = &path;
            workers.push(scope.spawn(move || -> R<()> {
                let mut r = Reader::open(mode, path, n)?;
                r.scan(n, count)
            }));
        }
        for w in workers {
            w.join().expect("reader panicked")?;
        }
        Ok(())
    })?;
    let parallel_seconds = start.elapsed().as_secs_f64();
    let parallel_cpu = cpu() - c;
    println!(
        "{}",
        serde_json::json!({"mode":mode,"payload_bytes":n,"total_bytes":total,"count":count,"epoch_bytes":16<<20,"queries":queries,"query_bytes":queries*n,"readers":readers,"parallel_read_bytes":total*readers,"write_seconds":write_seconds,"write_cpu":write_cpu,"open_cpu":open_cpu,"scan_cpu":scan_cpu,"random_cpu":random_cpu,"parallel_cpu":parallel_cpu,"open_seconds":open_seconds,"scan_seconds":scan_seconds,"random_seconds":random_seconds,"parallel_seconds":parallel_seconds,"logical_bytes":logical_bytes,"allocated_bytes":allocated_bytes,"verified":true})
    );
    Ok(())
}
