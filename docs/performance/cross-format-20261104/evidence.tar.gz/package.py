from pathlib import Path
import hashlib,json,tarfile,re,subprocess
R=Path(__file__).resolve().parent;O=Path('/workspace/varlit/docs/performance/cross-format-20261104')
plan=json.loads((R/'plan.json').read_text());fixed=json.loads((R/'sqlite-plan.json').read_text())
assert hashlib.sha256((R/'original-harness/main.rs').read_bytes()).hexdigest()==plan['sha256']['src/main.rs']
assert hashlib.sha256((R/'src/main.rs').read_bytes()).hexdigest()==fixed['sha256']['src/main.rs']
for p,sha in [(R/'bench',plan['sha256']['bench']),(R/'bench-sqlite',fixed['sha256']['bench-sqlite'])]:assert hashlib.sha256(p.read_bytes()).hexdigest()==sha
manifest=[];files=[];allowed={'.json','.jsonl','.log','.py','.rs','.c','.toml','.lock','.stdout','.stderr','.txt'}
for p in sorted(R.rglob('*')):
 if not p.is_file()or p.is_symlink()or any(x in ['data','lib','target','__pycache__']for x in p.relative_to(R).parts)or p.suffix not in allowed:continue
 b=p.read_bytes();assert not re.search(rb'github_pat_[A-Za-z0-9_]{30,}|ghp_[A-Za-z0-9]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',b)
 files.append(p);manifest.append(dict(path=str(p.relative_to(R)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(O/'evidence.tar.gz','w:gz')as t:
 for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
with tarfile.open(O/'evidence.tar.gz','r:gz')as t:
 for x in manifest:
  b=t.extractfile(x['path']).read();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256']
(O/'evidence.sha256').write_text(hashlib.sha256((O/'evidence.tar.gz').read_bytes()).hexdigest()+'  evidence.tar.gz\n')
print('VERIFIED',len(files),'files;',sum(x['bytes']for x in manifest),'raw bytes;', (O/'evidence.tar.gz').stat().st_size,'archive bytes')
