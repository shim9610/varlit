"""Separate observer-affected resource diagnostics; never pool their times."""
from pathlib import Path
import subprocess,json,os,tempfile,time,stat
R=Path(__file__).resolve().parent;O=R/'probes';O.mkdir(exist_ok=True);D=R/'data'
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
MODES=['raw','hdf5','hdf5-fletcher','sqlite','varlit-native','varlit-stream','varlit-indexed']
CASES=[('1g-64k',1<<30,65536,m) for m in MODES]+[('4g-4m',4<<30,4<<20,m) for m in ['sqlite','varlit-indexed','hdf5-fletcher']]
rows=[]
for name,total,n,mode in CASES:
 stem=name+'-'+mode;peaks=dict(visible_allocated_bytes=0,deleted_allocated_bytes=0,total_allocated_bytes=0,cgroup_bytes=0);samples=0;errors={};native=None
 with tempfile.TemporaryDirectory(prefix=stem+'-',dir=D) as directory:
  data=Path(directory);usage=O/(stem+'.usage.json');pid=O/(stem+'.pid')
  cmd=[str(R/'measure'),str(usage),str(pid),str(R/('bench-sqlite' if mode=='sqlite' else 'bench')),mode,directory,str(total),str(n),'8',str(64<<20)]
  with (O/(stem+'.stdout')).open('w') as o,(O/(stem+'.stderr')).open('w') as e:
   child=subprocess.Popen(cmd,stdout=o,stderr=e,env={**os.environ,'TMPDIR':directory});start=time.monotonic()
   while child.poll() is None:
    assert time.monotonic()-start<600,'probe timeout'
    if native is None:
     try:native=int(pid.read_text())
     except (OSError,ValueError):time.sleep(.001);continue
    visible=set();deleted=set();v=d=0
    for f in data.iterdir():
     try:
      m=f.stat()
      if stat.S_ISREG(m.st_mode):visible.add((m.st_dev,m.st_ino));v+=m.st_blocks*512
     except OSError:pass
    try:
     for fd in Path(f'/proc/{native}/fd').iterdir():
      if fd.name in ['0','1','2']:continue
      try:
       m=fd.stat();k=(m.st_dev,m.st_ino)
       if stat.S_ISREG(m.st_mode) and k not in visible and k not in deleted and os.readlink(fd).endswith(' (deleted)'):deleted.add(k);d+=m.st_blocks*512
      except OSError:pass
    except OSError:pass
    for k,val in [('visible_allocated_bytes',v),('deleted_allocated_bytes',d),('total_allocated_bytes',v+d),('cgroup_bytes',int(Path('/sys/fs/cgroup/memory.current').read_text()))]:peaks[k]=max(peaks[k],val)
    samples+=1;time.sleep(.005)
  row=dict(case=name,mode=mode,command=cmd,exit=child.returncode,peaks=peaks,samples=samples,usage=json.loads(usage.read_text()),result=json.loads((O/(stem+'.stdout')).read_text()),interval_seconds=.005,time_scope='observer-affected; not benchmark timing')
 rows.append(row);(R/'probes.json').write_text(json.dumps(rows,indent=2));print(stem,child.returncode,samples,peaks,flush=True)
 assert child.returncode==0 and row['result']['verified'] and samples>0
print('FINISHED PROBES',len(rows),flush=True)
