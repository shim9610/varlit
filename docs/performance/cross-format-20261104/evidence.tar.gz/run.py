from pathlib import Path
import os,json,subprocess,tempfile,time,hashlib,statistics,platform,resource
R=Path(__file__).resolve().parent;O=R/'timings';O.mkdir(exist_ok=True);D=R/'data'
MODES=['raw','hdf5','hdf5-fletcher','sqlite','varlit-native','varlit-stream','varlit-indexed']
CASES=[dict(name='bulk-1g-64k',total=1<<30,payload=65536),dict(name='bulk-1g-1m',total=1<<30,payload=1<<20),dict(name='bulk-4g-4m',total=4<<30,payload=4<<20),dict(name='small-64m-4k',total=64<<20,payload=4096),dict(name='tiny-16m-128',total=16<<20,payload=128)]
CPUS=sorted(os.sched_getaffinity(0))[:4];os.sched_setaffinity(0,CPUS)
plan=dict(runtime_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/varlit',text=True).strip(),cases=CASES,modes=MODES,groups=3,readers=8,query_bytes=64<<20,epoch_bytes=16<<20,batch_bytes=4<<20,engine_cache_bytes=8<<20,affinity=CPUS,cpu_quota=Path('/sys/fs/cgroup/cpu.max').read_text().strip(),memory_limit=Path('/sys/fs/cgroup/memory.max').read_text().strip(),disk_bytes=32<<30,platform=platform.platform(),versions=json.loads(subprocess.check_output([str(R/'bench'),'versions'],text=True)),sha256={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'bench',R/'src/main.rs',R/'Cargo.lock',R/'measure']},method='Diagnostic cross-format comparison, 3 fixed repetitions in rotated/reversed order, not a 5-percent regression qualification. Same bytes, same 16 MiB durable epochs; native CRC32, HDF5 none/Fletcher32, SQLite FULL WAL, raw lower bound; semantics differ. All bytes validated by identical Rust function; no compression. Cached reads, not cold-device throughput. Separate process/phase CPU; process RSS and IO from native-child wait4. No concurrent builds or observers during timings.')
(R/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(R/'memory-events-before.txt').write_text(Path('/sys/fs/cgroup/memory.events').read_text())
rows=[];started=time.monotonic()
for ci,c in enumerate(CASES):
 for g in range(3):
  order=MODES[(ci+g*2)%7:]+MODES[:(ci+g*2)%7]
  if g%2:order=list(reversed(order))
  for mode in order:
   stem=f"{c['name']}-g{g}-{mode}";row=dict(case=c['name'],group=g,mode=mode)
   with tempfile.TemporaryDirectory(prefix=stem+'-',dir=D) as d:
    cmd=[str(R/'measure'),str(O/(stem+'.usage.json')),str(O/(stem+'.pid')),str(R/'bench'),mode,d,str(c['total']),str(c['payload']),'8',str(64<<20)]
    t=time.monotonic()
    with (O/(stem+'.stdout')).open('w') as o,(O/(stem+'.stderr')).open('w') as e:
     try:
      result=subprocess.run(cmd,stdout=o,stderr=e,timeout=600,env={**os.environ,'TMPDIR':d});row['exit']=result.returncode
      if result.returncode:raise RuntimeError(f'exit {result.returncode}')
      event=json.loads((O/(stem+'.stdout')).read_text());assert event['verified'] and event['count']==c['total']//c['payload'] and event['parallel_read_bytes']==8*c['total']
      row.update(result=event,usage=json.loads((O/(stem+'.usage.json')).read_text()))
     except Exception as error:row['error']=str(error)
    row['command']=cmd;row['wall_seconds']=time.monotonic()-t
   rows.append(row)
   with (R/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(len(rows),'/105',stem,round(row['wall_seconds'],2),row.get('error','OK'),flush=True)
(R/'memory-events-after.txt').write_text(Path('/sys/fs/cgroup/memory.events').read_text())
print('FINISHED',len(rows),'errors',sum('error'in r for r in rows),'elapsed',time.monotonic()-started,flush=True)
