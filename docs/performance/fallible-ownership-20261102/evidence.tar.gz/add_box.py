from pathlib import Path
root=Path('/workspace/varlit/crates/varlit-core/src')
p=root/'fallible.rs';s=p.read_text();s+='''
/// Allocate one owned value, reporting refusal instead of invoking the OOM handler.
/// The value is dropped normally on refusal. User-defined destructors are outside
/// the allocator contract. Zero-sized values need no allocation.
pub fn try_box<T>(value: T) -> Result<Box<T>> {
    let layout = std::alloc::Layout::new::<T>();
    let pointer = if layout.size() == 0 {
        std::ptr::NonNull::<T>::dangling().as_ptr()
    } else {
        // SAFETY: Layout::new supplies the nonzero size and alignment of T.
        let pointer = unsafe { std::alloc::alloc(layout) }.cast::<T>();
        if pointer.is_null() { return Err(allocation("boxed value", layout.size())); }
        pointer
    };
    // SAFETY: the pointer is uniquely owned and aligned; either the allocation
    // has exactly T's layout, or T is zero-sized and the pointer is dangling.
    // write moves value without dropping uninitialized storage. from_raw adopts
    // that single initialized T with the same global allocator/layout. There is
    // no fallible operation or user callback between allocation and adoption.
    unsafe { pointer.write(value); Ok(Box::from_raw(pointer)) }
}
impl<T: TryClone> TryClone for Box<T> {
    fn try_clone(&self) -> Result<Self> { try_box((**self).try_clone()?) }
}

pub(crate) fn boxed_error(source: Error, fallback: Error, build: impl FnOnce(Box<Error>) -> Error) -> Error {
    match try_box(source) { Ok(source) => build(source), Err(_) => fallback }
}

pub(crate) fn context_failure(operation: &'static str, sequence: Option<u64>, event: Option<crate::MatrixCommitEvent>, publication: Option<bool>, parent_sync_pending: bool) -> Error {
    Error::ErrorContextAllocationFailed { operation, sequence, event, publication, parent_sync_pending }
}

pub(crate) fn matrix_error(operation: &'static str, event: crate::MatrixCommitEvent, source: Error) -> Error {
    // MatrixCommitEvent contains only integers and a static string. Its Clone
    // performs no allocation; retain it inline if either box cannot be made.
    let fallback = context_failure(operation, None, Some(event.clone()), if operation == "matrix publication uncertain" { None } else { Some(true) }, false);
    let Ok(event) = try_box(event) else { return fallback; };
    boxed_error(source, fallback, |source| match operation {
        "matrix durability" => Error::MatrixCommittedButDurabilityUnproven { event, source },
        "matrix publication uncertain" => Error::MatrixPublicationUncertain { event, source },
        "matrix hook" => Error::MatrixCommittedButHookFailed { event, source },
        _ => unreachable!("private matrix error operation"),
    })
}
''';p.write_text(s)
p=root/'lib.rs';s=p.read_text().replace('pub use fallible::TryClone;', 'pub use fallible::{TryClone, try_box};');p.write_text(s)
p=root/'error.rs';s=p.read_text();s=s.replace('pub enum Error {','''pub enum Error {
    /// An operation failed, and allocating its detailed error context also failed.
    /// `publication`: Some(true) means the operation already appended/published;
    /// None means its publication outcome is uncertain; Some(false) means it did
    /// not publish. Do not blindly repeat an operation with a true/unknown result.
    /// `event` retains matrix notification geometry without allocating. Detailed
    /// source errors/path text may be lost; parent-sync uncertainty is retained.
    #[error("error context allocation failed after {operation}; publication={publication:?}, sequence={sequence:?}, parent_sync_pending={parent_sync_pending}")]
    ErrorContextAllocationFailed {
        operation: &'static str,
        sequence: Option<u64>,
        event: Option<crate::MatrixCommitEvent>,
        publication: Option<bool>,
        parent_sync_pending: bool,
    },
''',1)
s=s.replace('''            } => Error::PublishedButRebindFailed {
                sequence,
                source,
                parent_sync: Some(Box::new(parent_sync)),
            },''','''            } => match crate::fallible::try_box(parent_sync) {
                Ok(parent_sync) => Error::PublishedButRebindFailed { sequence, source, parent_sync: Some(parent_sync) },
                Err(_) => crate::fallible::context_failure("replacement rebind", Some(sequence), None, Some(true), true),
            },
            Error::ErrorContextAllocationFailed { operation, sequence, event, publication, .. } => {
                crate::fallible::context_failure(operation, sequence, event, publication, true)
            },''')
p.write_text(s)
p=root/'diagnostics.rs';s=p.read_text().replace('| Error::AllocationFailed { .. }','| Error::AllocationFailed { .. }\n        | Error::ErrorContextAllocationFailed { .. }');p.write_text(s)
# Rewrite error construction expressions, leaving pattern matches and tests alone.
variants={'AppendedButImmediateFailed':('append immediate','Some(true)'), 'PublishedButIndexStale':('published index','Some(true)'), 'PublishedButRebindFailed':('replacement rebind','Some(true)'), 'CommittedButDurabilityUnproven':('commit durability','Some(true)'), 'PublishedButParentSyncPending':('replacement parent sync','Some(true)')}
def closing(s,start,opening='(',closing=')'):
 depth=0;quoted=False;escape=False
 for i in range(start,len(s)):
  c=s[i]
  if quoted:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':quoted=False
  elif c=='"':quoted=True
  elif c==opening:depth+=1
  elif c==closing:
   depth-=1
   if depth==0:return i
 raise ValueError('unbalanced')
for name in ['immediate.rs','stream.rs','indexed.rs','file.rs','matrix_generation.rs','experimental_matrix.rs','disk_index.rs']:
 p=root/name;s=p.read_text()
 for variant,(operation,publication) in variants.items():
  pos=0
  while True:
   start=s.find('Error::'+variant+' {',pos)
   if start<0:break
   brace=s.index('{',start);end=closing(s,brace,'{','}');body=s[brace+1:end]
   needle='source: Box::new('
   if needle not in body:pos=end+1;continue
   b=body.index(needle);op=body.index('(',b);ep=closing(body,op);value=body[op+1:ep]
   import re
   sequence=re.search(r'(?:^|,)\s*sequence\s*(?::\s*([^,]+))?\s*,',body)
   seq='Some('+ (sequence.group(1).strip() if sequence and sequence.group(1) else 'sequence')+')' if sequence else 'None'
   modified=body[:b]+'source'+body[ep+1:]
   fallback=f'crate::fallible::context_failure("{operation}", {seq}, None, {publication}, '+('true' if variant=='PublishedButParentSyncPending' else 'false')+')'
   # Fully-qualified crate::Error also occurs; replace its preceding prefix too.
   actual=start-7 if s[max(0,start-7):start]=='crate::' else start
   replacement=f'crate::fallible::boxed_error({value}, {fallback}, |source| Error::{variant} {{{modified}}})'
   s=s[:actual]+replacement+s[end+1:];pos=actual+len(replacement)
 for variant,operation in [('MatrixCommittedButDurabilityUnproven','matrix durability'),('MatrixPublicationUncertain','matrix publication uncertain'),('MatrixCommittedButHookFailed','matrix hook')]:
  pos=0
  while True:
   start=s.find('Error::'+variant+' {',pos)
   if start<0:break
   brace=s.index('{',start);end=closing(s,brace,'{','}');body=s[brace+1:end]
   if 'event: Box::new(event)' not in body:pos=end+1;continue
   replacement=f'crate::fallible::matrix_error("{operation}", event, source)'
   s=s[:start]+replacement+s[end+1:];pos=start+len(replacement)
 p.write_text(s)
# Ordinary boxes, whose callers already return Result. Box::default is also an allocation.
for name in ['matrix.rs','matrix_directory.rs','experimental_matrix.rs']:
 p=root/name;s=p.read_text();pos=0
 while True:
  start=s.find('Box::new(',pos)
  if start<0:break
  # Existing test/example boxes are outside production scope.
  if name=='matrix.rs' and s[:start].count('\n')>8000:pos=start+9;continue
  end=closing(s,start+8)
  s=s[:start]+'crate::fallible::try_box('+s[start+9:end]+')?'+s[end+1:];pos=end+25
 p.write_text(s)
p=root/'matrix_generation.rs';s=p.read_text().replace('writer.as_ref().map(|_| Box::default())','writer.as_ref().map(|_| crate::fallible::try_box(Working::default())).transpose()?').replace('let next_working = Box::default();','let next_working = crate::fallible::try_box(Working::default())?;');p.write_text(s)
p=root/'disk_index.rs';s=p.read_text().replace('error => Error::DiskIndex(Box::new(error)),','error => match crate::fallible::try_box(error) { Ok(error) => Error::DiskIndex(error), Err(error) => error },');p.write_text(s)
