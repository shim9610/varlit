from pathlib import Path
p=Path('/workspace/varlit/crates/varlit/tests/validation_coverage.rs');s=p.read_text()
fixture='''
varlit::varlit_format! {
    struct OwnershipHeader {
        magic: b"OWHD"; version: 1; preset: none;
        layout {
            file_header Header { bytes magic = b"OWHD"; u16 kind; }
            segment Data repeat until_eof {
                lead_in Lead { bytes magic = b"DATA"; u16 kind;
                    i64 next = finalize(target = segment_end, relative_to = after_lead_in);
                    i64 raw = finalize(target = raw_region_start, relative_to = after_lead_in);
                }
                metadata Meta; raw_region Raw;
            }
        }
    }
}
varlit::varlit_format! {
    struct OwnershipIndex {
        magic: b"OWIX"; version: 1; index: keyed_offset_chain;
        blocks { variable OwnedEntry(id = 71, key = [id], key_index = disk) { id: u64, value: u64, } }
    }
}
'''
s=s.replace('fn probe(\n',fixture+'\nfn probe(\n',1)
rows=[]
rows.append('''    contract!("core/scan_control.rs::scan_control::ScanCancellationToken::fn:try_new@d8624e1b9e8ccf6f",
        valid { let token = varlit::ScanCancellationToken::try_new()?; assert!(!token.is_cancelled()); token.cancel(); assert!(token.is_cancelled()); Ok(()) },
        invalid { let result = refusing_allocations(varlit::ScanCancellationToken::try_new); assert!(matches!(result, Err(varlit::Error::Io(e)) if e.kind() == std::io::ErrorKind::OutOfMemory)); Ok(()) }
    ),''')
rows.append('''    contract!("macros/modules/format_emit.rs::format_emit::generator:high_cardinality_api_tokens@61f1678165055f69", generated "disk_index_plan",
        valid { let plan = OwnershipIndex::disk_index_plan()?; assert_eq!(plan.descriptors().len(), 1); assert!(plan.validate(OwnershipIndex::spec()).is_ok()); Ok(()) },
        invalid { let result = refusing_allocations(OwnershipHeader::disk_index_plan); assert!(matches!(result, Err(varlit::Error::AllocationFailed { .. }))); assert!(matches!(OwnershipHeader::disk_index_plan(), Err(varlit::Error::DiskIndex(e)) if matches!(*e, varlit::DiskIndexError::PlanEmpty))); Ok(()) }
    ),''')
for name,h in [('layout_field_struct_tokens','1b03f39d4b518018'),('layout_field_to_value_tokens','5525b6594eca5be7')]:
 rows.append(f'''    contract!("macros/modules/format_emit.rs::format_emit::generator:{name}@{h}", generated "__varlit_layout_values",
        valid {{ let fields = OwnershipHeaderHeaderLayoutFields {{ kind: 42 }}.__varlit_layout_values()?; assert_eq!(fields.len(), 1); assert_eq!(fields[0].value.to_u16("kind")?, 42); Ok(()) }},
        invalid {{ let fields = OwnershipHeaderHeaderLayoutFields {{ kind: 42 }}; let result = refusing_allocations(|| fields.__varlit_layout_values()); assert!(matches!(result, Err(varlit::Error::AllocationFailed {{ .. }}))); assert_eq!(fields.kind, 42); Ok(()) }}
    ),''')
rows.append('''    contract!("macros/modules/format_emit.rs::format_emit::generator:layout_header_typed_tokens@095075385290c05c", generated "create_layout_writer_with_typed_header",
        valid { let dir = tempfile::tempdir()?; let path = dir.path().join("header"); let mut writer = OwnershipHeader::create_layout_writer_with_typed_header(&path, OwnershipHeaderHeaderLayoutFields { kind: 42 })?; writer.flush()?; assert_eq!(&std::fs::read(path)?[..6], b"OWHD\\x2a\\x00"); Ok(()) },
        invalid { let dir = tempfile::tempdir()?; let path = dir.path().join("header"); let result = refusing_allocations(|| OwnershipHeader::create_layout_writer_with_typed_header(&path, OwnershipHeaderHeaderLayoutFields { kind: 42 })); assert!(matches!(result, Err(varlit::Error::AllocationFailed { .. }))); assert!(!path.exists()); Ok(()) }
    ),''')
rows.append('''    contract!("macros/modules/format_emit.rs::format_emit::generator:layout_writer_segment_method_tokens@6d7f0cdfe27d767e", generated "write_data",
        valid { let dir = tempfile::tempdir()?; let path = dir.path().join("segment"); let mut writer = OwnershipHeader::create_layout_writer_with_typed_header(&path, OwnershipHeaderHeaderLayoutFields { kind: 42 })?; let info = writer.write_data(OwnershipHeaderDataLayoutWrite { fields: OwnershipHeaderDataLayoutFields { kind: 7 }, footer_fields: OwnershipHeaderDataLayoutFooterFields, metadata: b"", raw: b"data" })?; assert_eq!(info.kind()?, 7); Ok(()) },
        invalid { let dir = tempfile::tempdir()?; let path = dir.path().join("segment"); let mut writer = OwnershipHeader::create_layout_writer_with_typed_header(&path, OwnershipHeaderHeaderLayoutFields { kind: 42 })?; writer.flush()?; let before = std::fs::read(&path)?; let result = refusing_allocations(|| writer.write_data(OwnershipHeaderDataLayoutWrite { fields: OwnershipHeaderDataLayoutFields { kind: 7 }, footer_fields: OwnershipHeaderDataLayoutFooterFields, metadata: b"", raw: b"data" })); assert!(matches!(result, Err(varlit::Error::AllocationFailed { .. }))); writer.flush()?; assert_eq!(std::fs::read(path)?, before); Ok(()) }
    ),''')
s=s.replace('const CONTRACTS: &[Contract] = &[','const CONTRACTS: &[Contract] = &[\n'+'\n'.join(rows),1)
p.write_text(s)
