set -e
source /workspace/tooling/varlit/env.sh
python3 - <<'PY'
from pathlib import Path
import time
p=Path('/workspace/scratch/fallible-ownership/stage1-performance.log')
while not p.exists() or not p.read_text().endswith('DONE\n'):
 time.sleep(2)
PY
cargo fmt --all
cargo check --workspace --all-features > /workspace/scratch/fallible-ownership/stage2-check.log 2>&1
cargo test -p varlit-core --all-features --test fallible_ownership -- --nocapture > /workspace/scratch/fallible-ownership/stage2-refusal.log 2>&1
cargo test -p varlit --all-features --test fallible_publication -- --nocapture > /workspace/scratch/fallible-ownership/stage2-publication.log 2>&1
cargo test -p varlit --all-features --test validation_coverage > /workspace/scratch/fallible-ownership/stage2-api.log 2>&1
