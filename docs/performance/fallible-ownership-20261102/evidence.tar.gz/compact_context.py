from pathlib import Path
r=Path('/workspace/varlit/crates/varlit-core/src')
p=r/'error.rs';s=p.read_text();start=s.index('    /// An operation failed,');end=s.index('    #[error("{resource} buffer',start)
s=s[:start]+'''    /// Detailed error allocation failed. This inline context preserves whether
    /// an append/publication happened or is uncertain; do not blindly retry it.
    #[error("could not allocate detailed error after {context:?}")]
    ErrorContextAllocationFailed { context: AllocationFailureContext },

'''+s[end:]
start=s.index('            Error::ErrorContextAllocationFailed {');end=s.index('            other => other,',start)
s=s[:start]+'''            Error::ErrorContextAllocationFailed {
                context: AllocationFailureContext::PublishedRebind { sequence, .. },
            } => crate::fallible::context_failure("replacement rebind", Some(sequence), None, Some(true), true),
'''+s[end:]
s+='''
/// Allocation-free operation facts retained when a detailed error cannot be boxed.
/// Each variant states a completed append/publication or an explicitly uncertain
/// outcome. Detailed source errors and path text may be unavailable.
#[derive(Clone, Debug, PartialEq, Eq)]
#[non_exhaustive]
pub enum AllocationFailureContext {
    /// The append happened; its requested Immediate boundary failed.
    Appended { sequence: u64 },
    /// The record was published; the derived index needs repair.
    PublishedIndex { sequence: u64 },
    /// The replacement was published; this handle could not rebind to it.
    PublishedRebind { sequence: u64, parent_sync_pending: bool },
    /// The commit marker was written; durability remains unconfirmed.
    Committed { sequence: u64 },
    /// The replacement was published; parent-directory sync remains pending.
    ParentSyncPending,
    /// The matrix generation was published; its final sync failed.
    MatrixDurability { event: crate::MatrixCommitEvent },
    /// Reopen and inspect the confirmed matrix generation before deciding to retry.
    MatrixPublicationUncertain { event: crate::MatrixCommitEvent },
    /// The cell is durable; only the post-publication notification failed.
    MatrixHook { event: crate::MatrixCommitEvent },
    /// The experimental generation is durable; cleanup failed.
    ReusePublished { generation: u64 },
    /// The experimental generation may have been published; inspect before retry.
    ReusePublicationUncertain { generation: u64 },
}
''';p.write_text(s)
p=r/'lib.rs';s=p.read_text().replace('pub use error::{Error, Result};','pub use error::{AllocationFailureContext, Error, Result};');p.write_text(s)
p=r/'fallible.rs';s=p.read_text();start=s.index('pub(crate) fn context_failure(');end=s.index('\npub(crate) fn matrix_error',start)
s=s[:start]+'''pub(crate) fn context_failure(operation: &'static str, sequence: Option<u64>, event: Option<crate::MatrixCommitEvent>, _publication: Option<bool>, parent_sync_pending: bool) -> Error {
    use crate::AllocationFailureContext as C;
    let context = match operation {
        "append immediate" => C::Appended { sequence: sequence.expect("append sequence") },
        "published index" => C::PublishedIndex { sequence: sequence.expect("published sequence") },
        "replacement rebind" => C::PublishedRebind { sequence: sequence.expect("replacement sequence"), parent_sync_pending },
        "commit durability" => C::Committed { sequence: sequence.expect("commit sequence") },
        "replacement parent sync" => C::ParentSyncPending,
        "matrix durability" => C::MatrixDurability { event: event.expect("matrix event") },
        "matrix publication uncertain" => C::MatrixPublicationUncertain { event: event.expect("matrix event") },
        "matrix hook" => C::MatrixHook { event: event.expect("matrix event") },
        "matrix reuse published" => C::ReusePublished { generation: sequence.expect("reuse generation") },
        "matrix reuse publication uncertain" => C::ReusePublicationUncertain { generation: sequence.expect("reuse generation") },
        _ => unreachable!("private error context operation"),
    };
    Error::ErrorContextAllocationFailed { context }
}
'''+s[end:];p.write_text(s)
p=Path('/workspace/varlit/crates/varlit/tests/fallible_publication.rs');s=p.read_text();start=s.index('Err(Error::ErrorContextAllocationFailed {');end=s.index(' => {',start);s=s[:start]+'''Err(Error::ErrorContextAllocationFailed { context: AllocationFailureContext::MatrixHook { event } })'''+s[end:];p.write_text(s)
p=Path('/workspace/varlit/crates/varlit/tests/validation_coverage.rs');s=p.read_text();start=s.index('    contract!("core/error.rs::error::Error::variant:ErrorContextAllocationFailed');end=s.index('    contract!("core/chunks.rs',start);s=s[:start]+s[end:];p.write_text(s)
