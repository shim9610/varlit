set -e
source /workspace/tooling/varlit/env.sh
cargo clippy --workspace --all-targets --all-features -- -D warnings > /workspace/scratch/fallible-ownership/stage1-clippy.log 2>&1
bash /workspace/scratch/fallible-ownership/build.sh before > /workspace/scratch/fallible-ownership/before-build.log 2>&1
bash /workspace/scratch/fallible-ownership/build.sh stage1 > /workspace/scratch/fallible-ownership/stage1-build.log 2>&1
git diff --binary > /workspace/scratch/fallible-ownership/stage1.patch
cp crates/varlit-core/src/fallible.rs /workspace/scratch/fallible-ownership/stage1-fallible.rs
python3 /workspace/scratch/fallible-ownership/bench_stage.py stage1 before > /workspace/scratch/fallible-ownership/stage1-performance.log 2>&1
