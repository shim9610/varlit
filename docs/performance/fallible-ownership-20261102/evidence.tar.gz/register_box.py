from pathlib import Path
p=Path('/workspace/varlit/crates/varlit/tests/validation_coverage.rs');s=p.read_text();s+='''
// Dedicated current-thread refusal; other concurrently running contracts are untouched.
struct ContractAllocator;
thread_local! { static REFUSE_CONTRACT: std::cell::Cell<bool> = const { std::cell::Cell::new(false) }; }
fn contract_refuses() -> bool { REFUSE_CONTRACT.try_with(std::cell::Cell::get).unwrap_or(false) }
// SAFETY: forwarding preserves System's layout/ownership; refusal returns null.
unsafe impl std::alloc::GlobalAlloc for ContractAllocator {
    unsafe fn alloc(&self, layout: std::alloc::Layout) -> *mut u8 {
        if contract_refuses() { std::ptr::null_mut() } else { unsafe { std::alloc::GlobalAlloc::alloc(&std::alloc::System, layout) } }
    }
    unsafe fn alloc_zeroed(&self, layout: std::alloc::Layout) -> *mut u8 {
        if contract_refuses() { std::ptr::null_mut() } else { unsafe { std::alloc::GlobalAlloc::alloc_zeroed(&std::alloc::System, layout) } }
    }
    unsafe fn realloc(&self, pointer: *mut u8, layout: std::alloc::Layout, size: usize) -> *mut u8 {
        if contract_refuses() { std::ptr::null_mut() } else { unsafe { std::alloc::GlobalAlloc::realloc(&std::alloc::System, pointer, layout, size) } }
    }
    unsafe fn dealloc(&self, pointer: *mut u8, layout: std::alloc::Layout) {
        unsafe { std::alloc::GlobalAlloc::dealloc(&std::alloc::System, pointer, layout) }
    }
}
#[global_allocator]
static CONTRACT_ALLOCATOR: ContractAllocator = ContractAllocator;
fn refusing_allocations<T>(body: impl FnOnce() -> T) -> T {
    struct Reset;
    impl Drop for Reset { fn drop(&mut self) { REFUSE_CONTRACT.with(|state| state.set(false)); } }
    REFUSE_CONTRACT.with(|state| state.set(true));
    let _reset = Reset;
    body()
}
'''
blocks=''
for symbol in ['core/fallible.rs::fallible::fn:try_box@36a82d3283743b0b','core/lib.rs::::export:try_box@2b506e7fd8ea20d1']:
 blocks+='''    contract!("'''+symbol+'''",
        valid { let value = varlit::try_box(7u64)?; assert_eq!(*value, 7); Ok(()) },
        invalid {
            let result = refusing_allocations(|| varlit::try_box(7u64));
            assert!(matches!(result, Err(varlit::Error::AllocationFailed { resource: "boxed value", requested: 8 })));
            Ok(())
        }
    ),
'''
blocks+='''    contract!("core/error.rs::error::Error::variant:ErrorContextAllocationFailed@73b34d7b29b8dc9a",
        valid {
            let error = varlit::Error::ErrorContextAllocationFailed { operation: "append immediate", sequence: Some(17), event: None, publication: Some(true), parent_sync_pending: false };
            assert!(matches!(error, varlit::Error::ErrorContextAllocationFailed { sequence: Some(17), publication: Some(true), .. }));
            Ok(())
        },
        invalid {
            let error = refusing_allocations(|| varlit::try_box(7u64)).unwrap_err();
            assert!(!matches!(error, varlit::Error::ErrorContextAllocationFailed { .. }));
            assert!(matches!(error, varlit::Error::AllocationFailed { .. }));
            Ok(())
        }
    ),
'''
s=s.replace('    contract!("core/chunks.rs::chunks::ChunkedBytes::fn:decoded_len',blocks+'    contract!("core/chunks.rs::chunks::ChunkedBytes::fn:decoded_len',1);p.write_text(s)
