from pathlib import Path
p=Path('/workspace/varlit/crates/varlit/tests/validation_coverage.rs');s=p.read_text();syms=['core/fallible.rs::fallible::TryClone::fn:try_clone@4c103a12486804c7','core/fallible.rs::fallible::TryClone::fn:try_clone_slice@d5101c54b8f22ed5','core/fallible.rs::fallible::macro:copy_clone@98ecf16d6ba68408','core/fallible.rs::fallible::macro:copy_clone@e451f0eff70d84c4','core/fallible.rs::fallible::trait:TryClone@cbf29ce484222325','core/lib.rs::::export:TryClone@4aefc82d5057d594'];blocks=''
for sym in syms:
 generated=' generated "try_clone_slice",' if '::macro:' in sym else ''
 blocks+='''    contract!("'''+sym+'",'+generated+'''
        valid {
            use varlit::TryClone;
            let value = vec![Some(String::from("fallible"))];
            assert_eq!(value.try_clone()?, value);
            assert_eq!(u64::try_clone_slice(&[1, 2, 3])?, [1, 2, 3]);
            Ok(())
        },
        invalid {
            use varlit::TryClone;
            struct Refuses;
            impl TryClone for Refuses {
                fn try_clone(&self) -> varlit::Result<Self> {
                    Err(varlit::Error::AllocationFailed { resource: "contract clone", requested: 1 })
                }
            }
            assert!(matches!(vec![Refuses].try_clone(), Err(varlit::Error::AllocationFailed { .. })));
            assert!(Refuses::try_clone_slice(&[Refuses]).is_err());
            Ok(())
        }
    ),
'''
s=s.replace('    contract!("core/chunks.rs::chunks::ChunkedBytes::fn:decoded_len',blocks+'    contract!("core/chunks.rs::chunks::ChunkedBytes::fn:decoded_len',1);p.write_text(s)
