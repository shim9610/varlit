//! Explicit allocation-failure propagation for owned values.
use crate::{Error, Result};
use std::collections::{HashMap, VecDeque};
use std::hash::Hash;
use std::path::PathBuf;

/// Clone a value without aborting when a requested allocation is refused.
///
/// Implementations must use fallible allocation for every newly owned field and
/// release partially constructed output on error. The source stays unchanged.
/// A successful result has the same value/ownership semantics as `Clone`.
/// Custom implementations, hash/equality callbacks and destructors must uphold
/// this contract themselves. This is not an OS OOM-kill guarantee.
///
/// There is deliberately no blanket `T: Clone` implementation: wrapping
/// `clone()` in `Ok` would still permit an allocation abort. Existing `Clone`
/// implementations remain available for source compatibility, outside this
/// contract. BTreeMap has no implementation until its allocations are fallible.
pub trait TryClone: Sized {
    fn try_clone(&self) -> Result<Self>;
}

fn allocation(resource: &'static str, requested: usize) -> Error {
    Error::AllocationFailed {
        resource,
        requested: requested as u64,
    }
}
macro_rules! copy_clone {
    ($($ty:ty),* $(,)?) => {$(impl TryClone for $ty {
        #[inline]
        fn try_clone(&self) -> Result<Self> { Ok(*self) }
    })*};
}
copy_clone!(
    (),
    bool,
    char,
    u8,
    u16,
    u32,
    u64,
    u128,
    usize,
    i8,
    i16,
    i32,
    i64,
    i128,
    isize,
    f32,
    f64
);
impl<T: ?Sized> TryClone for &T {
    fn try_clone(&self) -> Result<Self> {
        Ok(*self)
    }
}
impl<T: Copy, const N: usize> TryClone for [T; N] {
    fn try_clone(&self) -> Result<Self> {
        Ok(*self)
    }
}
impl<T: TryClone> TryClone for Option<T> {
    fn try_clone(&self) -> Result<Self> {
        self.as_ref().map(TryClone::try_clone).transpose()
    }
}
impl<A: TryClone, B: TryClone> TryClone for (A, B) {
    fn try_clone(&self) -> Result<Self> {
        Ok((self.0.try_clone()?, self.1.try_clone()?))
    }
}
impl<T: TryClone> TryClone for Vec<T> {
    fn try_clone(&self) -> Result<Self> {
        let mut output = Vec::new();
        output
            .try_reserve_exact(self.len())
            .map_err(|_| allocation("vector clone", self.len().saturating_mul(size_of::<T>())))?;
        for value in self {
            output.push(value.try_clone()?);
        }
        Ok(output)
    }
}
impl TryClone for String {
    fn try_clone(&self) -> Result<Self> {
        let mut output = String::new();
        output
            .try_reserve_exact(self.len())
            .map_err(|_| allocation("string clone", self.len()))?;
        output.push_str(self);
        Ok(output)
    }
}
impl TryClone for PathBuf {
    fn try_clone(&self) -> Result<Self> {
        let mut output = std::ffi::OsString::new();
        output
            .try_reserve_exact(self.as_os_str().len())
            .map_err(|_| allocation("path clone", self.as_os_str().len()))?;
        output.push(self.as_os_str());
        Ok(output.into())
    }
}
impl<T: TryClone> TryClone for VecDeque<T> {
    fn try_clone(&self) -> Result<Self> {
        let mut output = VecDeque::new();
        output
            .try_reserve_exact(self.len())
            .map_err(|_| allocation("deque clone", self.len().saturating_mul(size_of::<T>())))?;
        for value in self {
            output.push_back(value.try_clone()?);
        }
        Ok(output)
    }
}
impl<K: Eq + Hash + TryClone, V: TryClone> TryClone for HashMap<K, V> {
    fn try_clone(&self) -> Result<Self> {
        // RandomState::clone copies the seed; it does not allocate.
        let mut output = HashMap::with_hasher(self.hasher().clone());
        output
            .try_reserve(self.len())
            .map_err(|_| allocation("map clone", self.len().saturating_mul(size_of::<(K, V)>())))?;
        for (key, value) in self {
            output.insert(key.try_clone()?, value.try_clone()?);
        }
        Ok(output)
    }
}
impl<T: ?Sized> TryClone for std::sync::Arc<T> {
    fn try_clone(&self) -> Result<Self> {
        Ok(std::sync::Arc::clone(self))
    }
}
