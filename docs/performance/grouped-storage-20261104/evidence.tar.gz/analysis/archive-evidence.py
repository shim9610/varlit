from pathlib import Path
import hashlib
import json
import os
import platform
import subprocess
import tarfile

base=Path('/workspace/scratch/storage-bench-grouped-20261104')
repo=Path('/workspace/varlit')
out=repo/'docs/performance/grouped-storage-20261104'

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while b:=f.read(1<<20):h.update(b)
    return h.hexdigest()

environment=dict(kernel=platform.release(),architecture=platform.machine(),
    cpu_model=next(x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),
    cpu_max=Path('/sys/fs/cgroup/cpu.max').read_text().strip(),
    memory_max=Path('/sys/fs/cgroup/memory.max').read_text().strip(),
    filesystem_total_bytes=os.statvfs(base).f_blocks*os.statvfs(base).f_frsize,
    rustc=subprocess.check_output(['/workspace/tooling/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc','-Vv'],text=True),
    runtime_base='1e770ce3a73d2f317e32f34d250bc44cd9c4a421',production_rust_modified=False,
    memory_events_at_export=Path('/sys/fs/cgroup/memory.events').read_text(),
    native_libraries={str(p):sha(p) for p in [Path('/lib/x86_64-linux-gnu/libsqlite3.so.0'),Path('/lib/x86_64-linux-gnu/libhdf5_serial.so.310')]})
(out/'environment.json').write_text(json.dumps(environment,indent=2)+'\n')
entries={}
cohorts=['smoke-v1','legacy-regression','tuning-v1','full-v1','followup-v1','control-v1',
         'control-serial-v1','smoke-final','smoke-v2','tuning-v2','full-v2','control-v2','control-v3','legacy-final','grouped-final']
for cohort in cohorts:
    folder=base/cohort
    for p in folder.rglob('*'):
        if not p.is_file():continue
        parts=p.relative_to(folder).parts
        if any(x.endswith(('.work','.tmp')) or x in ['__pycache__','target'] for x in parts):continue
        assert p.stat().st_size < 64<<20, p
        entries['runs/'+str(p.relative_to(base))]=p
for p in (repo/'tools/storage-bench').rglob('*'):
    if p.is_file() and not any(x in ['target','__pycache__'] for x in p.relative_to(repo/'tools/storage-bench').parts):
        entries['tool/'+str(p.relative_to(repo/'tools/storage-bench'))]=p
for name in ['write-report.py','archive-evidence.py','resource-interruption.json','cache-reclamation.json',
             'control-interference.json','hdf-control-geometry.json','binary-reconstruction.json','ci-helper-tests.log','ci-helper-tests-final.log','ci117-evidence.json']:
    p=base/name
    if p.exists():entries['analysis/'+name]=p
for name in ['README.md','comparison.json','all-results.md','metrics.csv','environment.json','validation.json']:
    entries['report/'+name]=out/name
manifest=dict(selected_configurations=47,successful_selected_timing_observations=141,
    qualified_resource_probes=47,primary_cohorts=['full-v2','control-v2','control-v3','legacy-final','grouped-final'],
    superseded_cohorts=['full-v1','followup-v1','control-v1','control-serial-v1','control-v2'],
    superseded_reason='Scattered group-key / 1 MiB publication candidate, budget refusals, incomplete resource sample and interfered control are retained; never pooled into final ordered-key 16 MiB publication comparison.',
    failed_database_payloads='Locally retained, losslessly compressed with hashes in original attempt metadata; omitted from Git archive.',
    resource_limits_unchanged=True,
    files=[dict(path=k,bytes=p.stat().st_size,sha256=sha(p)) for k,p in sorted(entries.items())])
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
entries['evidence-manifest.json']=out/'evidence-manifest.json'
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=6) as tar:
    for name,p in sorted(entries.items()):
        info=tar.gettarinfo(str(p),arcname=name)
        info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
        with p.open('rb') as f:tar.addfile(info,f)
(out/'SHA256SUMS').write_text(''.join(f'{sha(out/name)}  {name}\n' for name in [
    'README.md','comparison.json','all-results.md','metrics.csv','environment.json','validation.json','evidence-manifest.json','evidence.tar.gz']))
print('Archived',len(entries),'files;',round((out/'evidence.tar.gz').stat().st_size/2**20,2),'MiB')
