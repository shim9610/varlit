from pathlib import Path
import json

repo = Path('/workspace/varlit')
out = repo / 'docs/performance/grouped-storage-20261104'
ps = json.loads((out/'comparison.json').read_text())['profiles']

def row(name, label):
    p=ps[name]; m=p['metrics']; v=p['probe']
    return f"| {label} | {m['write']:.3f} | {m['read_active']:.3f} | {m['completion']:.3f} | {m['cpu']:.3f} | {m['final_mib']:.3f} | {v['pss_sum']/2**20:.2f} |"

lines = ['# Grouped logical items: Varlit / SQLite / HDF5', '',
'''The grouped layout with packed items and ordered block keys reduces Varlit's individually
framed storage/time cost. This is a layout comparison on the same production
runtime, not a production-code optimization. The requested universal **at least
2× SQLite performance is still not established**; grouped SQLite is also fast.

The prior million-item fixture already batched 1,000 records per publication,
but retained one physical Frame and general-index key per item. Its result
must not be used as representative grouped-item performance. We retain those
observations and add equal-publication individually framed controls here.

[All results](all-results.md) · [Metrics CSV](metrics.csv) · [JSON](comparison.json)
· [Harness/contracts](../../../tools/storage-bench/README.md)
· [Grouping manual](../../scalable-io.md#choose-the-physical-block-before-choosing-the-batch-size)

## Logical items, physical records and publication

Each logical item has an immutable dense u64 ID and 128 caller-visible bytes,
including that ID. Routing is declared: divide the ID by items-per-block to
find its block, then take the remainder for its slot. A physical Frame contains
512 or 8,192 items. Its encoded block key is indexed in Varlit/SQLite; HDF5
persists a dense group-to-payload-extent directory. This is not a replacement
for a general arbitrary-key routing index, nor a million schema/block types.

| Logical payload | Logical items | Items/block | Physical blocks | Publications |
|---|---:|---:|---:|---:|
| 128 MiB | 1,048,576 | 512 | 2,048 | 8 |
| 128 MiB | 1,048,576 | 8,192 | 128 | 8 |
| 1 GiB | 8,388,608 | 512 | 16,384 | 64 |
| 1 GiB | 8,388,608 | 8,192 | 1,024 | 64 |

Primary publications contain 131,072 logical items / 16 MiB, independently of block
size. Mixed Metadata and application Head records remain included. Logical
values, publication sizes and required operations match across engines.
Changing the number of physical records is the experiment, not missing work.
General block keys remain unrestricted to support growing capture logs; the
finite-key enum policy is not used as an implicit cap on future block count.

The 42 grouped configurations cover both sizes and block widths, one/four
producers and eight readers, plus 128 MiB one-reader controls. Six 1 GiB
four-producer/eight-reader configurations additionally compare follow-only
stream/BLOB/HDF5 layouts. Five 128 MiB individually framed controls use the
same 131,072-item publication boundary, one producer and eight readers.
Six further keyed profiles hold the 1 GiB block layout fixed and compare
1 MiB publications with the primary 16 MiB publications.

## Required read work and concurrency

Each reader consumes the full published workload, validates every item byte,
missing/duplicate block ID, metadata and writer-derived order. Keyed profiles
then perform a **separate backend block lookup**, and copy/check every logical
item in reverse slot order through a caller-owned 128-byte buffer. The fetched
block is retained only for that item-query batch. The scan payload is not used
as the point result. This is group-local batched item lookup, not unrelated
cold random queries or one storage syscall per logical item.

Varlit uses indexed block Frames, SQLite uses a keyed BLOB table and native
prepared statements/WAL/FULL, and HDF5 uses sealed payload chunks, persisted
group directory and an application SWMR publication prefix. Follow-only layouts
omit unneeded point indexes. These integrity/recovery contracts differ; no
SQL ACID equivalence is asserted. No live backing file is memory-mapped.

Varlit/HDF5 have one writer receiving transactions through MPSC capacity two.
One/four producers retain their own staging in addition to the queued and active
transactions. SQLite producers own independent FULLMUTEX connections; SQLite
still permits only one active write transaction per database. Every reader has
an independent process/handle/cache. Writers do not wait for reader acknowledgments.

## Before/after layout controls

The following all process 1,048,576 logical items / 128 MiB with one producer,
eight readers and eight publications. Keyed cases include all group-local item
queries; the individual control executes a backend point query per item.

| Layout | Full write s | Reader-active s | Complete s | CPU s | Final MiB | Aggregate PSS MiB |
|---|---:|---:|---:|---:|---:|---:|''']
for engine in ['varlit-indexed','sqlite']:
    lines.append(row(f'individual-n1048576-t131072-q1-{engine}',f'{engine}: individual Frames'))
    for group in [512,8192]:
        lines.append(row(f'grouped-n1048576-g{group}-t131072-w1-r8-{engine}',f'{engine}: {group} items/block'))
lines += ['', '''Grouping changes the number of physical lookups by making the application
block route and locality explicit. It does not demonstrate the same speedup
for arbitrary scattered keys. The individual Frame control retains its earlier scattered composite-key encoding;
grouped block keys retain natural group-ID order. The layout comparison therefore
changes framing, index granularity and key locality together. Publication size
is fixed here; the separate publication contrast holds those layout choices fixed.
The individual SQL control uses recorded default
page/mmap settings; grouped SQL uses its separate tuning winner. Compare the
Varlit layout controls as layout changes, not a claim of globally optimal SQL.

## Large concurrent workload

Each of eight readers processes the entire 1 GiB workload; there are four
producers feeding one active writer. All rows below include grouped item queries.

| Layout | Full write s | Reader-active s | Complete s | CPU s | Final MiB | Aggregate PSS MiB |
|---|---:|---:|---:|---:|---:|---:|''']
for group in [512,8192]:
    for engine in ['varlit-indexed','sqlite','hdf5']:
        lines.append(row(f'grouped-n8388608-g{group}-t131072-w4-r8-{engine}',f'{engine}, {group}/block'))
lines += ['', '''Full write includes initialization, ingest, maintenance and final close/checkpoint.
Reader-active is the maximum reader's consume+refresh work, excluding idle
sleep but including tail work after the writer stops. Complete includes reader
startup/drain. These counters overlap and must not be added. CPU is kernel
wait4 user+system including waited-for child readers.

## Reads completed while writing

Both endpoints of a consume interval must fall inside the common-clock
writer-active window to count as entirely concurrent. Intervals crossing the
window edge are excluded, not proportionally assigned. This is a strict lower
bound: an excluded crossing interval may have performed much of its work while
the writer was active. During-write % below
uses the least-advanced reader; its MiB/s divides those bytes by the full
writer window, including waits. Each consume interval includes its item-query
batch. Throughput normalizes progress by one logical payload pass, not all
physical reads or the extra point-result copies. This separates observed
concurrent progress from final drain.

Publication occurs inside a backend write call. The p99 delay to completion of the benchmark consume helper
uses call return/start as lower/upper bounds, respectively. SQLite
lock waits can widen the upper bound. It is not an exact commit timestamp,
first-byte latency, an individual item API latency or a fixed-rate real-time guarantee.

| 1 GiB, four producers/eight readers | During-write % | Minimum reader MiB/s | Final drain s | p99 delay bounds ms |
|---|---:|---:|---:|---:|''']
for group in [512,8192]:
    for engine in ['varlit-indexed','sqlite','hdf5']:
        m=ps[f'grouped-n8388608-g{group}-t131072-w4-r8-{engine}']['metrics']
        lines.append(f"| {engine}, {group}/block | {100*m['min_reader_during_fraction']:.2f} | {m['min_reader_during_mib_s']:.2f} | {m['drain']:.4f} | {m['delay_p99_lower_ms']:.2f}–{m['delay_p99_upper_ms']:.2f} |")
lines += ['', '## Publication size with the physical layout held fixed', '',
          'The same 1 GiB, four-producer/eight-reader group layout is measured with',
          '1 MiB and 16 MiB publications. This isolates publication amortization from',
          'block packing and key order. Larger publications also retain more producer',
          'staging and delay visibility; memory and completion remain charged.', '',
          '| Engine | Items/block | Publication MiB | Full write s | Complete s | CPU s | Aggregate PSS MiB |',
          '|---|---:|---:|---:|---:|---:|---:|']
for group in [512,8192]:
    for engine in ['varlit-indexed','sqlite','hdf5']:
        for pub in [8192,131072]:
            p=ps[f'grouped-n8388608-g{group}-t{pub}-w4-r8-{engine}'];m=p['metrics']
            lines.append(f"| {engine} | {group} | {pub*128//2**20} | {m['write']:.3f} | {m['completion']:.3f} | {m['cpu']:.3f} | {p['probe']['pss_sum']/2**20:.2f} |")
lines += ['', '''## Resource accounting and qualification

The existing 4 CPU / 16 GiB / 32 GiB limits were not raised. Aggregate PSS/RSS
are sampled across writer, wrapper and all readers; producer threads are part
of writer memory. A complete process-tree coverage check is required. Samples
can miss shorter memory peaks. Unmapped OS file cache is not process PSS;
cgroup file/anonymous memory and pre-run baselines are retained, but include
the rest of this shared environment.

Final MiB is filesystem-allocated storage across primary and companions after
readers and writer close. Per-file logical/allocated sizes are retained in JSON.
Peak visible storage, temporary/WAL bytes and deleted-open generations are in
metrics.csv and raw probes. Temporary bytes are a subset of visible bytes;
independent maxima must not be summed as a simultaneous peak.

There are **141 selected successful timing observations and 47 qualified separate
resource probes**, three timings and one probe per configuration. Min/max values
are retained. Three repetitions are observational medians, not a 5% performance
qualification. SQLite tuning is 12 complete configurations × three observations
at 128 MiB/one producer/eight readers; each block width's complete winner is
frozen before the main run. Transfer to other sizes/concurrency is not a global
optimality claim. All queried values are immutable and known published IDs.

Two SQLite 1 GiB timing attempts were stopped by the existing free-space guard.
Their data/log/hash evidence is retained; after reclaiming only rebuildable old
build caches, both were retried successfully at the same limits and frozen
binary identity. This is not a larger storage budget. A periodic resource
sample also fell short of a child's final file allocation; its incomplete
observation is retained. A final quiescent file observation was added and all
36 earlier grouped resource profiles repeated with the same frozen binaries. Two
earlier successful resource samples are superseded, not pooled. One individual
control overlapped CI helper tests; it is retained/excluded and replaced by a
serial control observation. These earlier cohorts use scattered group keys and 1 MiB publications. They are retained as superseded evidence and are not pooled into final v2 results. The final grouped-v2/control-v3 selection uses naturally ordered group keys and includes a controlled 1 MiB versus 16 MiB publication comparison. The initial 16 MiB individual HDF5 control used 4 MiB header chunks exceeding its roughly 1.3 MiB dataset cache and was stopped after preserving the completed 66.886-second observation and partial attempts. Header chunks were capped at a transaction-dividing 4,096 rows (128 KiB for Frame headers), without increasing cache budgets; the complete controls were rerun. Grouped profiles have at most 256 physical Frames per transaction, so their geometry is unchanged.

The grouped unpublished-prefix gates, original-adapter regression campaign,
workload/telemetry helper tests and runnable manual example were executed.
This benchmark changes no production Rust, public API or existing file format.
It does not replace PR #18's safety checks or main-versus-PR regression study.
OOM/kill counters remained at their pre-existing six/three values through
the retained campaigns. This is not an OOM-impossibility proof.
No merge or release is performed.

See [local validation](validation.json), [environment](environment.json),
[evidence manifest](evidence-manifest.json),
[retained evidence archive](evidence.tar.gz) and [checksums](SHA256SUMS).
Full database payloads are omitted from Git; retained failed payload compression
identities are recorded in the original attempt metadata.''']
(out/'README.md').write_text('\n'.join(lines)+'\n')
print('Wrote',out/'README.md')
