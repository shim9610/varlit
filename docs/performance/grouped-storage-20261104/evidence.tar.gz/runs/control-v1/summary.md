# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| individual-n1048576-q1-varlit-indexed | 3 | 37.465576 | 37.709784 | 131.422183 | 37.12 | 397.09 |
| individual-n1048576-q1-sqlite | 3 | 4.947878 | 5.084556 | 19.301902 | 22.33 | 180.41 |
| individual-n1048576-q0-varlit-stream | 3 | 3.690841 | 9.120935 | 35.629552 | 15.59 | 280.25 |
| individual-n1048576-q0-sqlite | 3 | 1.716994 | 1.757000 | 5.269518 | 22.14 | 157.96 |
| individual-n1048576-q0-hdf5 | 3 | 0.906124 | 0.966803 | 3.638605 | 22.62 | 160.03 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
