# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| individual-n1048576-t131072-q1-varlit-indexed | 2 | 27.126526 | 28.935970 | 111.421573 | 130.54 | 363.77 |
| individual-n1048576-t131072-q1-sqlite | 2 | 4.791611 | 5.466686 | 20.090618 | 108.80 | 180.41 |
| individual-n1048576-t131072-q0-varlit-stream | 3 | 2.670156 | 8.748342 | 33.416553 | 107.83 | 280.08 |
| individual-n1048576-t131072-q0-sqlite | 3 | 1.931654 | 2.074792 | 6.103719 | 108.11 | 157.96 |
| individual-n1048576-t131072-q0-hdf5 | 2 | 0.794694 | 66.021457 | 262.912700 | 144.01 | 160.02 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
