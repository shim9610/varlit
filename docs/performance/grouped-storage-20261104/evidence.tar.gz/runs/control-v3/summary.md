# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| individual-n1048576-t131072-q1-varlit-indexed | 3 | 25.655546 | 27.817773 | 107.943155 | 130.70 | 363.77 |
| individual-n1048576-t131072-q1-sqlite | 3 | 4.330890 | 4.821897 | 17.809455 | 108.73 | 180.41 |
| individual-n1048576-t131072-q0-varlit-stream | 3 | 2.862210 | 8.740857 | 33.985768 | 107.83 | 280.08 |
| individual-n1048576-t131072-q0-sqlite | 3 | 2.060016 | 2.195549 | 6.137293 | 108.16 | 157.96 |
| individual-n1048576-t131072-q0-hdf5 | 3 | 0.673788 | 0.884194 | 3.273411 | 137.20 | 160.02 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
