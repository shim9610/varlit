# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| grouped-n1048576-g512-w1-r1-varlit-indexed | 3 | 0.472898 | 0.508215 | 0.511191 | 13.68 | 144.39 |
| grouped-n1048576-g512-w1-r1-sqlite | 3 | 0.445553 | 0.466557 | 0.499178 | 19.54 | 146.75 |
| grouped-n1048576-g512-w1-r1-hdf5 | 3 | 0.331419 | 0.357940 | 0.596151 | 18.66 | 128.22 |
| grouped-n1048576-g8192-w1-r1-varlit-indexed | 3 | 0.406719 | 0.430393 | 0.456112 | 15.82 | 130.20 |
| grouped-n1048576-g8192-w1-r1-sqlite | 3 | 0.370222 | 0.405783 | 0.477888 | 21.41 | 129.63 |
| grouped-n1048576-g8192-w1-r1-hdf5 | 3 | 0.318525 | 0.356465 | 0.580252 | 18.45 | 128.05 |
| grouped-n1048576-g512-w1-r8-varlit-indexed | 3 | 0.924149 | 0.961718 | 2.987649 | 13.47 | 144.39 |
| grouped-n1048576-g512-w1-r8-sqlite | 3 | 0.623013 | 0.738832 | 2.423493 | 19.43 | 146.75 |
| grouped-n1048576-g512-w1-r8-hdf5 | 3 | 0.721667 | 0.929270 | 3.520055 | 19.56 | 128.22 |
| grouped-n1048576-g8192-w1-r8-varlit-indexed | 3 | 1.080339 | 1.111698 | 3.498213 | 15.82 | 130.20 |
| grouped-n1048576-g8192-w1-r8-sqlite | 3 | 0.667551 | 0.767395 | 2.504256 | 21.39 | 129.63 |
| grouped-n1048576-g8192-w1-r8-hdf5 | 3 | 0.717971 | 0.890159 | 3.346751 | 19.54 | 128.05 |
| grouped-n1048576-g512-w4-r8-varlit-indexed | 3 | 0.844966 | 0.874955 | 2.717743 | 18.72 | 145.57 |
| grouped-n1048576-g512-w4-r8-sqlite | 3 | 0.766969 | 0.814771 | 2.503099 | 26.03 | 146.75 |
| grouped-n1048576-g512-w4-r8-hdf5 | 3 | 0.745625 | 0.923053 | 3.425561 | 26.89 | 128.22 |
| grouped-n1048576-g8192-w4-r8-varlit-indexed | 3 | 0.945156 | 0.986216 | 3.271372 | 20.83 | 130.23 |
| grouped-n1048576-g8192-w4-r8-sqlite | 3 | 0.902881 | 0.948408 | 2.959251 | 23.08 | 129.63 |
| grouped-n1048576-g8192-w4-r8-hdf5 | 3 | 0.824901 | 0.918302 | 3.474543 | 24.62 | 128.05 |
| grouped-n8388608-g512-w1-r8-varlit-indexed | 3 | 7.522062 | 7.555931 | 22.739091 | 17.01 | 1296.57 |
| grouped-n8388608-g512-w1-r8-sqlite | 3 | 5.193976 | 5.311981 | 18.445887 | 19.90 | 1171.08 |
| grouped-n8388608-g512-w1-r8-hdf5 | 3 | 5.991370 | 6.764222 | 25.762943 | 20.68 | 1025.70 |
| grouped-n8388608-g8192-w1-r8-varlit-indexed | 3 | 8.125892 | 8.191339 | 26.468952 | 16.70 | 1048.45 |
| grouped-n8388608-g8192-w1-r8-sqlite | 3 | 4.770285 | 5.112899 | 17.373701 | 21.52 | 1033.64 |
| grouped-n8388608-g8192-w1-r8-hdf5 | 3 | 6.567530 | 6.960055 | 26.551458 | 20.55 | 1024.29 |
| grouped-n8388608-g512-w4-r8-varlit-indexed | 3 | 7.473765 | 7.511063 | 22.612266 | 20.00 | 1329.26 |
| grouped-n8388608-g512-w4-r8-sqlite | 2 | 5.300743 | 5.372122 | 17.941272 | 29.37 | 1171.11 |
| grouped-n8388608-g512-w4-r8-hdf5 | 3 | 6.440181 | 6.826597 | 26.347738 | 28.98 | 1025.70 |
| grouped-n8388608-g8192-w4-r8-varlit-indexed | 3 | 7.646885 | 7.682672 | 25.226761 | 23.71 | 1049.19 |
| grouped-n8388608-g8192-w4-r8-sqlite | 3 | 5.221857 | 5.313428 | 18.573088 | 34.32 | 1033.64 |
| grouped-n8388608-g8192-w4-r8-hdf5 | 3 | 6.565625 | 6.878269 | 26.387585 | 27.61 | 1024.29 |
| grouped-follow-n8388608-g512-w4-r8-varlit-stream | 3 | 4.035749 | 4.075494 | 8.527046 | 20.02 | 1028.15 |
| grouped-follow-n8388608-g512-w4-r8-sqlite | 2 | 4.128348 | 4.172142 | 8.925217 | 30.44 | 1170.70 |
| grouped-follow-n8388608-g512-w4-r8-hdf5 | 3 | 4.547618 | 4.600180 | 17.187716 | 27.83 | 1024.68 |
| grouped-follow-n8388608-g8192-w4-r8-varlit-stream | 3 | 5.559971 | 5.603347 | 11.611840 | 21.29 | 1025.93 |
| grouped-follow-n8388608-g8192-w4-r8-sqlite | 3 | 4.173388 | 4.212937 | 9.229675 | 30.82 | 1033.57 |
| grouped-follow-n8388608-g8192-w4-r8-hdf5 | 3 | 4.536994 | 4.574000 | 17.102740 | 26.59 | 1024.20 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
