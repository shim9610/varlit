# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| grouped-n32768-g512-t8192-w1-r2-varlit-indexed | 1 | 0.016911 | 0.041211 | 0.052246 | 13.30 | 4.12 |
| grouped-n32768-g512-t8192-w1-r2-sqlite | 1 | 0.026036 | 0.046487 | 0.059982 | 15.89 | 4.06 |
| grouped-n32768-g512-t8192-w1-r2-hdf5 | 1 | 0.019056 | 0.045422 | 0.078344 | 17.66 | 4.01 |
| grouped-n32768-g8192-t8192-w1-r2-varlit-indexed | 1 | 0.026265 | 0.051050 | 0.067764 | 14.55 | 4.07 |
| grouped-n32768-g8192-t8192-w1-r2-sqlite | 1 | 0.032135 | 0.055963 | 0.077697 | 13.90 | 4.04 |
| grouped-n32768-g8192-t8192-w1-r2-hdf5 | 1 | 0.017940 | 0.042961 | 0.072895 | 17.30 | 4.01 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
