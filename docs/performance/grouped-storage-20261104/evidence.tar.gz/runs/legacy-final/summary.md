# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r2-varlit-stream | 1 | 0.016803 | 0.041576 | 0.044615 | 10.42 | 1.52 |
| mixed-p65536-r2-varlit-indexed | 1 | 0.016595 | 0.036310 | 0.040215 | 10.49 | 1.58 |
| mixed-p65536-r2-sqlite | 1 | 0.016040 | 0.036540 | 0.038664 | 11.04 | 1.52 |
| mixed-p65536-r2-hdf5 | 1 | 0.013510 | 0.035133 | 0.051682 | 13.70 | 2.01 |
| objects-follow-varlit-stream | 1 | 0.025927 | 0.044959 | 0.038847 | 9.09 | 0.08 |
| objects-follow-varlit-indexed | 1 | 0.028990 | 0.047398 | 0.043976 | 9.09 | 0.40 |
| objects-follow-sqlite | 1 | 0.011141 | 0.030111 | 0.032411 | 8.82 | 0.04 |
| objects-follow-hdf5 | 1 | 0.009290 | 0.034145 | 0.046659 | 9.48 | 0.04 |
| objects-keyed-varlit-indexed | 1 | 0.028176 | 0.045586 | 0.043697 | 9.08 | 0.40 |
| objects-keyed-sqlite | 1 | 0.019224 | 0.044787 | 0.042334 | 8.76 | 0.05 |
| table-w4-varlit-indexed | 1 | 0.096116 | 0.118429 | 0.101854 | 9.16 | 1.39 |
| table-w4-varlit-matrix | 1 | 0.049191 | 0.069242 | 0.062547 | 9.61 | 1.22 |
| table-w4-sqlite | 1 | 0.049115 | 0.068274 | 0.048395 | 9.47 | 0.09 |
| table-w4-hdf5 | 1 | 0.027285 | 0.052706 | 0.070892 | 9.82 | 0.08 |
| array-n16777216-g1048576-native-view | 1 | 0.028252 | 0.056514 | 0.046254 | 25.11 | 16.00 |
| array-n16777216-g1048576-stream | 1 | 0.022651 | 0.043232 | 0.033486 | 30.27 | 16.03 |
| array-n16777216-g1048576-indexed | 1 | 0.022691 | 0.054406 | 0.043801 | 30.39 | 16.04 |
| array-n16777216-g1048576-matrix-mmap | 1 | 0.040764 | 0.082242 | 0.074385 | 27.85 | 16.16 |
| array-n16777216-g1048576-matrix-owned | 1 | 0.045829 | 0.100438 | 0.089050 | 23.61 | 16.16 |
| array-n16777216-g1048576-sql-columns | 1 | 0.222899 | 0.343135 | 0.319355 | 31.60 | 19.75 |
| array-n16777216-g1048576-sql-chunks | 1 | 0.069994 | 0.106668 | 0.088033 | 32.49 | 16.03 |
| array-n16777216-g1048576-hdf-contiguous-bulk | 1 | 0.026363 | 0.049841 | 0.041477 | 40.72 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-bulk | 1 | 0.028133 | 0.056942 | 0.047646 | 49.97 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-fletcher-bulk | 1 | 0.037946 | 0.093314 | 0.085549 | 51.06 | 16.00 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
