# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r2-varlit-stream | 1 | 0.019690 | 0.040389 | 0.043658 | 10.56 | 1.52 |
| mixed-p65536-r2-varlit-indexed | 1 | 0.015710 | 0.035024 | 0.040844 | 10.48 | 1.58 |
| mixed-p65536-r2-sqlite | 1 | 0.015340 | 0.047099 | 0.054396 | 11.07 | 1.52 |
| mixed-p65536-r2-hdf5 | 1 | 0.013144 | 0.035966 | 0.052044 | 13.55 | 2.01 |
| objects-follow-varlit-stream | 1 | 0.019649 | 0.038166 | 0.036258 | 9.20 | 0.08 |
| objects-follow-varlit-indexed | 1 | 0.021545 | 0.043516 | 0.045139 | 9.12 | 0.40 |
| objects-follow-sqlite | 1 | 0.009896 | 0.028793 | 0.030712 | 8.83 | 0.04 |
| objects-follow-hdf5 | 1 | 0.011028 | 0.031623 | 0.043770 | 9.48 | 0.04 |
| objects-keyed-varlit-indexed | 1 | 0.038390 | 0.058086 | 0.054168 | 9.20 | 0.40 |
| objects-keyed-sqlite | 1 | 0.010214 | 0.037889 | 0.046061 | 8.76 | 0.05 |
| table-w4-varlit-indexed | 1 | 0.076563 | 0.097454 | 0.093153 | 9.19 | 1.38 |
| table-w4-varlit-matrix | 1 | 0.042881 | 0.061799 | 0.062176 | 10.07 | 1.22 |
| table-w4-sqlite | 1 | 0.048763 | 0.068902 | 0.048071 | 9.75 | 0.09 |
| table-w4-hdf5 | 1 | 0.020095 | 0.041590 | 0.060911 | 9.80 | 0.08 |
| array-n16777216-g1048576-native-view | 1 | 0.022129 | 0.047738 | 0.038220 | 25.11 | 16.00 |
| array-n16777216-g1048576-stream | 1 | 0.021660 | 0.042262 | 0.031536 | 30.28 | 16.03 |
| array-n16777216-g1048576-indexed | 1 | 0.027552 | 0.053914 | 0.036073 | 30.28 | 16.04 |
| array-n16777216-g1048576-matrix-mmap | 1 | 0.039423 | 0.080084 | 0.068877 | 29.24 | 16.16 |
| array-n16777216-g1048576-matrix-owned | 1 | 0.040182 | 0.090056 | 0.079769 | 23.61 | 16.16 |
| array-n16777216-g1048576-sql-columns | 1 | 0.230408 | 0.325825 | 0.308335 | 31.72 | 19.75 |
| array-n16777216-g1048576-sql-chunks | 1 | 0.067853 | 0.098776 | 0.082255 | 32.36 | 16.03 |
| array-n16777216-g1048576-hdf-contiguous-bulk | 1 | 0.020627 | 0.039617 | 0.032237 | 40.84 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-bulk | 1 | 0.157801 | 0.190175 | 0.179424 | 49.97 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-fletcher-bulk | 1 | 0.208480 | 0.253819 | 0.242962 | 50.94 | 16.00 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
