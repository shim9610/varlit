# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| grouped-n32768-g512-w1-r2-varlit-indexed | 1 | 0.041421 | 0.072077 | 0.085128 | 13.58 | 4.12 |
| grouped-n32768-g512-w1-r2-sqlite | 1 | 0.049321 | 0.078417 | 0.091098 | 15.77 | 4.06 |
| grouped-n32768-g512-w1-r2-hdf5 | 1 | 0.027159 | 0.065615 | 0.109584 | 17.75 | 4.01 |
| grouped-n32768-g8192-w1-r2-varlit-indexed | 1 | 0.040195 | 0.068695 | 0.099170 | 14.70 | 4.07 |
| grouped-n32768-g8192-w1-r2-sqlite | 1 | 0.041516 | 0.072268 | 0.096831 | 13.69 | 4.04 |
| grouped-n32768-g8192-w1-r2-hdf5 | 1 | 0.027110 | 0.056361 | 0.097994 | 17.42 | 4.01 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
