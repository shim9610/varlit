# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| grouped-n32768-g512-w1-r2-varlit-indexed | 1 | 0.029449 | 0.051372 | 0.072265 | 13.34 | 4.12 |
| grouped-n32768-g512-w1-r2-sqlite | 1 | 0.026706 | 0.050049 | 0.066092 | 15.89 | 4.06 |
| grouped-n32768-g512-w1-r2-hdf5 | 1 | 0.025185 | 0.058206 | 0.091501 | 17.75 | 4.01 |
| grouped-n32768-g8192-w1-r2-varlit-indexed | 1 | 0.026307 | 0.047899 | 0.068347 | 14.70 | 4.07 |
| grouped-n32768-g8192-w1-r2-sqlite | 1 | 0.035684 | 0.056957 | 0.078264 | 13.79 | 4.04 |
| grouped-n32768-g8192-w1-r2-hdf5 | 1 | 0.022171 | 0.050368 | 0.088338 | 17.37 | 4.01 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
