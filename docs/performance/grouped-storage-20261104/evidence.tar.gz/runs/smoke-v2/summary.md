# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| grouped-n32768-g512-t8192-w1-r2-varlit-indexed | 1 | 0.018774 | 0.039109 | 0.055607 | 13.34 | 4.12 |
| grouped-n32768-g512-t8192-w1-r2-sqlite | 1 | 0.025908 | 0.048108 | 0.069908 | 15.77 | 4.06 |
| grouped-n32768-g512-t8192-w1-r2-hdf5 | 1 | 0.015696 | 0.044428 | 0.077832 | 17.64 | 4.01 |
| grouped-n32768-g8192-t8192-w1-r2-varlit-indexed | 1 | 0.024652 | 0.043723 | 0.054927 | 14.64 | 4.07 |
| grouped-n32768-g8192-t8192-w1-r2-sqlite | 1 | 0.026660 | 0.048658 | 0.068206 | 13.81 | 4.04 |
| grouped-n32768-g8192-t8192-w1-r2-hdf5 | 1 | 0.028978 | 0.060135 | 0.090522 | 17.34 | 4.01 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
