# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| grouped-n1048576-g512-w1-r8-sqlite-p4096-m0 | 3 | 0.806572 | 0.851767 | 2.541406 | 20.04 | 129.07 |
| grouped-n1048576-g512-w1-r8-sqlite-p4096-m1073741824 | 3 | 0.803171 | 0.848446 | 2.578993 | 20.36 | 129.07 |
| grouped-n1048576-g512-w1-r8-sqlite-p16384-m0 | 3 | 0.766992 | 0.810023 | 2.475352 | 19.65 | 132.16 |
| grouped-n1048576-g512-w1-r8-sqlite-p16384-m1073741824 | 3 | 0.734132 | 0.777355 | 2.449500 | 19.66 | 132.16 |
| grouped-n1048576-g512-w1-r8-sqlite-p65536-m0 | 3 | 0.640876 | 0.731892 | 2.328965 | 19.48 | 146.75 |
| grouped-n1048576-g512-w1-r8-sqlite-p65536-m1073741824 | 3 | 0.695999 | 0.771578 | 2.400545 | 19.53 | 146.75 |
| grouped-n1048576-g8192-w1-r8-sqlite-p4096-m0 | 3 | 0.842878 | 0.878236 | 2.862225 | 20.93 | 128.20 |
| grouped-n1048576-g8192-w1-r8-sqlite-p4096-m1073741824 | 3 | 0.874034 | 0.912680 | 2.881051 | 20.91 | 128.20 |
| grouped-n1048576-g8192-w1-r8-sqlite-p16384-m0 | 3 | 0.783864 | 0.845172 | 2.785919 | 21.83 | 128.36 |
| grouped-n1048576-g8192-w1-r8-sqlite-p16384-m1073741824 | 3 | 0.782775 | 0.859440 | 2.850690 | 21.47 | 128.36 |
| grouped-n1048576-g8192-w1-r8-sqlite-p65536-m0 | 3 | 0.672392 | 0.778948 | 2.636723 | 21.39 | 129.63 |
| grouped-n1048576-g8192-w1-r8-sqlite-p65536-m1073741824 | 3 | 0.628608 | 0.757952 | 2.541572 | 20.39 | 129.63 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
