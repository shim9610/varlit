# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| grouped-n1048576-g512-t131072-w1-r8-sqlite-p4096-m0 | 3 | 0.790394 | 0.861882 | 2.727633 | 80.18 | 129.05 |
| grouped-n1048576-g512-t131072-w1-r8-sqlite-p4096-m1073741824 | 3 | 0.824569 | 0.901478 | 2.837905 | 80.17 | 129.05 |
| grouped-n1048576-g512-t131072-w1-r8-sqlite-p16384-m0 | 3 | 0.639297 | 0.756290 | 2.359087 | 79.89 | 132.14 |
| grouped-n1048576-g512-t131072-w1-r8-sqlite-p16384-m1073741824 | 3 | 0.690059 | 0.768022 | 2.423427 | 79.81 | 132.14 |
| grouped-n1048576-g512-t131072-w1-r8-sqlite-p65536-m0 | 3 | 0.528085 | 0.668734 | 2.101272 | 79.68 | 146.75 |
| grouped-n1048576-g512-t131072-w1-r8-sqlite-p65536-m1073741824 | 3 | 0.523874 | 0.703131 | 2.191047 | 79.67 | 146.75 |
| grouped-n1048576-g8192-t131072-w1-r8-sqlite-p4096-m0 | 3 | 0.752130 | 0.831486 | 2.673485 | 82.00 | 128.20 |
| grouped-n1048576-g8192-t131072-w1-r8-sqlite-p4096-m1073741824 | 3 | 0.790197 | 0.873754 | 2.761781 | 81.98 | 128.20 |
| grouped-n1048576-g8192-t131072-w1-r8-sqlite-p16384-m0 | 3 | 0.659548 | 0.780944 | 2.340343 | 81.61 | 128.36 |
| grouped-n1048576-g8192-t131072-w1-r8-sqlite-p16384-m1073741824 | 3 | 0.674845 | 0.772893 | 2.486057 | 81.56 | 128.36 |
| grouped-n1048576-g8192-t131072-w1-r8-sqlite-p65536-m0 | 3 | 0.499889 | 0.689338 | 2.209660 | 81.46 | 129.63 |
| grouped-n1048576-g8192-t131072-w1-r8-sqlite-p65536-m1073741824 | 3 | 0.471166 | 0.689743 | 2.142567 | 82.47 | 129.63 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
