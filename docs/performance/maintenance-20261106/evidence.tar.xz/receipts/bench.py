from pathlib import Path
import importlib.util,json,hashlib,subprocess,random,os,statistics
ROOT=Path('/workspace/varlit');OUT=Path('/workspace/scratch/tidy-20261106/bench');OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('storage_bench',ROOT/'tools/storage-bench/run.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
assert int(Path('/sys/fs/cgroup/memory.max').read_text())==16*2**30
quota,period=map(int,Path('/sys/fs/cgroup/cpu.max').read_text().split());assert quota==4*period
subprocess.run(['cc','-O2',str(ROOT/'tools/storage-bench/measure.c'),'-o',str(OUT/'measure')],check=True)
selected=[]
for items,prod,readers,group in [(1<<20,1,1,8192),(1<<20,1,8,512),(8<<20,4,8,8192),(8<<20,4,8,512)]:
 selected.append(next(p for p in h.profiles('grouped') if p['name']==f'grouped-n{items}-g{group}-t131072-w{prod}-r{readers}-varlit-indexed'))
for mode in ['native-view','native-mmap']:
 selected.append(dict(name=f'array-n134217728-g65536-{mode}',kind='array',mode=mode,total=128<<20,group=65536,page=4096,mmap=0,points=4096,ranges=128,readers=0,warm_scan=True))
binaries={label:{kind:str(Path('/workspace/scratch/tidy-20261106/bin')/version/kind) for kind in ['mixed','arrays']} for label,version in [('referenceA','before'),('referenceB','before'),('candidate','after')]}
manifest=dict(baseline='9343ea1754947d3af8e03dfa525d6ba5af856008',profiles=selected,rounds=5,labels=binaries,sha256={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for group in binaries.values() for p in group.values()},cpu_max=Path('/sys/fs/cgroup/cpu.max').read_text().strip(),memory_max=Path('/sys/fs/cgroup/memory.max').read_text().strip(),disk_budget_gib=32,seed=619303)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');rng=random.Random(manifest['seed']);rows=[]
def invoke(p,label,index,probe=False,gate=False):
 p=dict(p,binary_override=binaries[label]['mixed' if p['kind']=='mixed' else 'arrays'])
 stem=f'{len(rows):03}-{label}-{index}'
 r=h.invoke(p,OUT,stem,probe=probe,gate=gate,timeout=300);r.update(label=label,round=index);rows.append(r)
 with (OUT/'results.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
 print(stem,p['name'],r.get('error','ok'),flush=True)
 if r.get('error'):raise RuntimeError(r['error'])
# Freeze all timing work before looking at results; reference A/B are identical binaries.
for round in range(5):
 order=selected[:];rng.shuffle(order)
 for p in order:
  labels=list(binaries);rng.shuffle(labels)
  for label in labels:invoke(p,label,round)
for p in selected:
 for label in binaries:invoke(p,label,5,probe=True)
for p in selected:
 if p['kind']=='mixed':
  for label in ['referenceA','candidate']:invoke(p,label,6,gate=True)
summary=[]
for p in selected:
 entry={'profile':p['name'],'timings':{},'resources':{}}
 for label in binaries:
  timing=[r for r in rows if r['profile']['name']==p['name'] and r['label']==label and not r['probe'] and not r['visibility_gate']]
  probe=next(r for r in rows if r['profile']['name']==p['name'] and r['label']==label and r['probe'])
  metrics={'wall':statistics.median(r['usage']['elapsed_seconds'] for r in timing),'cpu':statistics.median(r['usage']['cpu'] for r in timing),'file':statistics.median(r['result']['allocated_bytes'] for r in timing)}
  if p['kind']=='mixed':metrics['reader_active']=statistics.median(max(x['active_seconds'] for x in r['result']['readers']) for r in timing) if 'active_seconds' in timing[0]['result']['readers'][0] else None
  entry['timings'][label]=metrics
  entry['resources'][label]=probe['sampled_peaks']
 entry['candidate_change']={k:entry['timings']['candidate'][k]/entry['timings']['referenceA'][k]-1 for k in ['wall','cpu']}
 entry['identical_reference_change']={k:entry['timings']['referenceB'][k]/entry['timings']['referenceA'][k]-1 for k in ['wall','cpu']}
 summary.append(entry)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('QUALIFICATION COMPLETE',flush=True)
