from pathlib import Path
import tarfile,subprocess,hashlib,shutil,os
root=Path('/workspace/varlit');out=Path('/workspace/scratch/tidy-20261106')
paths=['crates/varlit-core/src','crates/varlit-macros/src','crates/varlit/src']
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for base in paths for p in (root/base).rglob('*') if p.is_file()}
backup=out/'current-source.tar'
with tarfile.open(backup,'w') as tar:
 for p in paths:tar.add(root/p,arcname=p)
env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_INCREMENTAL='0',CARGO_PROFILE_RELEASE_DEBUG='0',CARGO_TARGET_DIR=str(root/'target'))
command=['cargo','build','--locked','--release','--manifest-path','tools/storage-bench/Cargo.toml','--bins']
def build(label):
 for base in paths:
  for p in (root/base).rglob('*.rs'):os.utime(p,None)
 with (out/f'{label}-build.log').open('w') as f:subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 dest=out/'bin'/label;dest.mkdir(exist_ok=True)
 for name in ['mixed','arrays','writer','payload']:shutil.copy2(root/'target/release'/name,dest/name)
try:
 original=out/'baseline-source.tar'
 with original.open('wb') as f:subprocess.run(['git','archive','9343ea1',*paths],cwd=root,stdout=f,check=True)
 with tarfile.open(original) as tar:tar.extractall(root,filter='data')
 build('before-samepath')
finally:
 with tarfile.open(backup) as tar:tar.extractall(root,filter='data')
 current={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for base in paths for p in (root/base).rglob('*') if p.is_file()}
 assert current==files,'source restore mismatch'
 print('Current source restored and hashes verified.',flush=True)
build('after-samepath')
for label in ['before-samepath','after-samepath']:
 symbols=subprocess.check_output(['nm','-C',str(out/'bin'/label/'mixed')],text=True)
 moved='varlit_core::file::follow::<impl varlit_core::file::VarlitFile>::follow' in symbols
 assert moved == label.startswith('after'),f'wrong binary identity for {label}'
print('Both variants built at the identical workspace path with identical options; baseline/candidate symbol identities verified.',flush=True)
