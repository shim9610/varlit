#[kani::proof]
#[kani::unwind(10)]
#[kani::stub(std::alloc::alloc, model_alloc)]
#[kani::stub(std::alloc::alloc_zeroed, model_zeroed)]
#[kani::stub(std::alloc::realloc, model_realloc)]
#[kani::stub(std::alloc::dealloc, model_dealloc)]
fn shared_initializer_refusal_and_last_owner_drop() {
    let refuse: bool = kani::any();
    let init_error: bool = kani::any();
    let runs = Cell::new(0);
    let drops = Cell::new(0);
    refuse_from(if refuse {0} else {usize::MAX});
    let result = try_arc_with(|| {
        runs.set(runs.get()+1);
        if init_error { return Err(Error::InvalidMatrixLayout); }
        Ok(Counted {value: 17, drops: &drops})
    });
    assert_eq!(runs.get(), usize::from(!refuse), "shared initializer ran without reserved storage");
    assert_eq!(result.is_ok(), !refuse && !init_error);
    if let Ok(owner) = result {
        refuse_from(0);
        let copy = owner.try_clone().unwrap();
        assert!(Arc::ptr_eq(&owner, &copy));
        assert_eq!(calls(), 0, "shared clone attempted allocation");
        drop(owner); assert_eq!(drops.get(), 0);
        drop(copy); assert_eq!(drops.get(), 1);
    }
    assert_eq!(live(), 0, "shared owner storage leaked");
}

#[kani::proof]
#[kani::unwind(10)]
#[kani::stub(std::alloc::alloc, model_alloc)]
#[kani::stub(std::alloc::alloc_zeroed, model_zeroed)]
#[kani::stub(std::alloc::realloc, model_realloc)]
#[kani::stub(std::alloc::dealloc, model_dealloc)]
fn copy_on_write_refusal_preserves_shared_source() {
    let mut owner = try_arc(vec![1u8,2,3]).unwrap();
    let shared: bool = kani::any();
    let retained = shared.then(|| owner.clone());
    let baseline = live();
    let fail: usize = kani::any(); refuse_from(fail);
    let result = try_make_mut(&mut owner);
    assert_eq!(result.is_ok(), !shared || fail >= 2, "COW refusal outcome lost");
    match result {
        Ok(value) => value[0] = 9,
        Err(_) => {
            assert!(Arc::ptr_eq(&owner, retained.as_ref().unwrap()));
            assert_eq!(owner.as_slice(), &[1,2,3]);
            assert_eq!(live(), baseline, "failed COW leaked partial output");
        }
    }
    if let Some(old) = retained { assert_eq!(old.as_slice(), &[1,2,3]); }
    drop(owner); assert_eq!(live(), 0);
}
