
/workspace/scratch/ownership-contracts/arc-bin/ownership_boundary_load:     file format elf64-x86-64


Disassembly of section .text:

0000000000028220 <ownership_boundary_load::main>:
   28220:	55                   	push   %rbp
   28221:	41 57                	push   %r15
   28223:	41 56                	push   %r14
   28225:	41 55                	push   %r13
   28227:	41 54                	push   %r12
   28229:	53                   	push   %rbx
   2822a:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
   28231:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
   28236:	48 8d 9c 24 d8 00 00 	lea    0xd8(%rsp),%rbx
   2823d:	00 
   2823e:	48 89 df             	mov    %rbx,%rdi
   28241:	ff 15 39 d2 04 00    	call   *0x4d239(%rip)        # 75480 <_DYNAMIC+0x2e8>
   28247:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   2824e:	00 
   2824f:	48 89 de             	mov    %rbx,%rsi
   28252:	ff 15 30 d2 04 00    	call   *0x4d230(%rip)        # 75488 <_DYNAMIC+0x2f0>
   28258:	48 ba 7d 00 00 00 00 	movabs $0x800000000000007d,%rdx
   2825f:	00 00 80 
   28262:	4c 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%r14
   28269:	00 
   2826a:	48 8d 42 83          	lea    -0x7d(%rdx),%rax
   2826e:	48 be ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rsi
   28275:	aa aa aa 
   28278:	49 39 c6             	cmp    %rax,%r14
   2827b:	0f 84 f7 0b 00 00    	je     28e78 <ownership_boundary_load::main+0xc58>
   28281:	49 89 c5             	mov    %rax,%r13
   28284:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   2828b:	00 
   2828c:	48 89 04 24          	mov    %rax,(%rsp)
   28290:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
   28297:	00 
   28298:	48 2b 84 24 e0 00 00 	sub    0xe0(%rsp),%rax
   2829f:	00 
   282a0:	48 89 c1             	mov    %rax,%rcx
   282a3:	48 c1 e9 03          	shr    $0x3,%rcx
   282a7:	48 0f af ce          	imul   %rsi,%rcx
   282ab:	48 83 f9 04          	cmp    $0x4,%rcx
   282af:	bd 03 00 00 00       	mov    $0x3,%ebp
   282b4:	48 0f 43 e9          	cmovae %rcx,%rbp
   282b8:	48 8d 8a 63 ff ff ff 	lea    -0x9d(%rdx),%rcx
   282bf:	48 39 c8             	cmp    %rcx,%rax
   282c2:	76 14                	jbe    282d8 <ownership_boundary_load::main+0xb8>
   282c4:	45 31 e4             	xor    %r12d,%r12d
   282c7:	4c 89 e7             	mov    %r12,%rdi
   282ca:	4c 89 fe             	mov    %r15,%rsi
   282cd:	ff 15 bd d1 04 00    	call   *0x4d1bd(%rip)        # 75490 <_DYNAMIC+0x2f8>
   282d3:	e9 a0 0c 00 00       	jmp    28f78 <ownership_boundary_load::main+0xd58>
   282d8:	48 8d 04 ed 08 00 00 	lea    0x8(,%rbp,8),%rax
   282df:	00 
   282e0:	4c 8d 3c 40          	lea    (%rax,%rax,2),%r15
   282e4:	4d 85 ff             	test   %r15,%r15
   282e7:	74 27                	je     28310 <ownership_boundary_load::main+0xf0>
   282e9:	ff 15 a9 d1 04 00    	call   *0x4d1a9(%rip)        # 75498 <_DYNAMIC+0x300>
   282ef:	41 bc 08 00 00 00    	mov    $0x8,%r12d
   282f5:	be 08 00 00 00       	mov    $0x8,%esi
   282fa:	4c 89 ff             	mov    %r15,%rdi
   282fd:	ff 15 9d d1 04 00    	call   *0x4d19d(%rip)        # 754a0 <_DYNAMIC+0x308>
   28303:	48 85 c0             	test   %rax,%rax
   28306:	74 bf                	je     282c7 <ownership_boundary_load::main+0xa7>
   28308:	48 89 c3             	mov    %rax,%rbx
   2830b:	48 ff c5             	inc    %rbp
   2830e:	eb 07                	jmp    28317 <ownership_boundary_load::main+0xf7>
   28310:	bb 08 00 00 00       	mov    $0x8,%ebx
   28315:	31 ed                	xor    %ebp,%ebp
   28317:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
   2831e:	00 
   2831f:	48 89 43 10          	mov    %rax,0x10(%rbx)
   28323:	0f 10 84 24 b8 00 00 	movups 0xb8(%rsp),%xmm0
   2832a:	00 
   2832b:	0f 11 03             	movups %xmm0,(%rbx)
   2832e:	48 89 ac 24 98 00 00 	mov    %rbp,0x98(%rsp)
   28335:	00 
   28336:	48 89 9c 24 a0 00 00 	mov    %rbx,0xa0(%rsp)
   2833d:	00 
   2833e:	48 c7 84 24 a8 00 00 	movq   $0x1,0xa8(%rsp)
   28345:	00 01 00 00 00 
   2834a:	0f 10 84 24 d8 00 00 	movups 0xd8(%rsp),%xmm0
   28351:	00 
   28352:	66 0f 10 8c 24 e8 00 	movupd 0xe8(%rsp),%xmm1
   28359:	00 00 
   2835b:	66 0f 29 4c 24 50    	movapd %xmm1,0x50(%rsp)
   28361:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   28366:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   2836c:	41 be 18 00 00 00    	mov    $0x18,%r14d
   28372:	4c 8b 25 0f d1 04 00 	mov    0x4d10f(%rip),%r12        # 75488 <_DYNAMIC+0x2f0>
   28379:	eb 28                	jmp    283a3 <ownership_boundary_load::main+0x183>
   2837b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   28380:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   28385:	4a 89 44 33 10       	mov    %rax,0x10(%rbx,%r14,1)
   2838a:	0f 10 44 24 10       	movups 0x10(%rsp),%xmm0
   2838f:	42 0f 11 04 33       	movups %xmm0,(%rbx,%r14,1)
   28394:	49 ff c7             	inc    %r15
   28397:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
   2839e:	00 
   2839f:	49 83 c6 18          	add    $0x18,%r14
   283a3:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   283a8:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   283ad:	41 ff d4             	call   *%r12
   283b0:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
   283b5:	4c 39 ed             	cmp    %r13,%rbp
   283b8:	74 56                	je     28410 <ownership_boundary_load::main+0x1f0>
   283ba:	4c 3b bc 24 98 00 00 	cmp    0x98(%rsp),%r15
   283c1:	00 
   283c2:	75 bc                	jne    28380 <ownership_boundary_load::main+0x160>
   283c4:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
   283c9:	48 2b 54 24 48       	sub    0x48(%rsp),%rdx
   283ce:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   283d3:	48 c1 ea 03          	shr    $0x3,%rdx
   283d7:	48 b8 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   283de:	aa aa aa 
   283e1:	48 0f af d0          	imul   %rax,%rdx
   283e5:	48 ff c2             	inc    %rdx
   283e8:	b9 08 00 00 00       	mov    $0x8,%ecx
   283ed:	41 b8 18 00 00 00    	mov    $0x18,%r8d
   283f3:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   283fa:	00 
   283fb:	4c 89 fe             	mov    %r15,%rsi
   283fe:	e8 dd 55 00 00       	call   2d9e0 <alloc::raw_vec::RawVecInner<A>::reserve::do_reserve_and_handle>
   28403:	48 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%rbx
   2840a:	00 
   2840b:	e9 70 ff ff ff       	jmp    28380 <ownership_boundary_load::main+0x160>
   28410:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
   28415:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   2841a:	48 89 c8             	mov    %rcx,%rax
   2841d:	4c 29 f0             	sub    %r14,%rax
   28420:	48 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdx
   28427:	aa aa aa 
   2842a:	48 f7 e2             	mul    %rdx
   2842d:	4c 39 f1             	cmp    %r14,%rcx
   28430:	74 3d                	je     2846f <ownership_boundary_load::main+0x24f>
   28432:	48 89 d3             	mov    %rdx,%rbx
   28435:	48 c1 eb 04          	shr    $0x4,%rbx
   28439:	49 83 c6 08          	add    $0x8,%r14
   2843d:	4c 8b 3d 24 d0 04 00 	mov    0x4d024(%rip),%r15        # 75468 <_DYNAMIC+0x2d0>
   28444:	eb 13                	jmp    28459 <ownership_boundary_load::main+0x239>
   28446:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2844d:	00 00 00 
   28450:	49 83 c6 18          	add    $0x18,%r14
   28454:	48 ff cb             	dec    %rbx
   28457:	74 16                	je     2846f <ownership_boundary_load::main+0x24f>
   28459:	49 8b 76 f8          	mov    -0x8(%r14),%rsi
   2845d:	48 85 f6             	test   %rsi,%rsi
   28460:	74 ee                	je     28450 <ownership_boundary_load::main+0x230>
   28462:	49 8b 3e             	mov    (%r14),%rdi
   28465:	ba 01 00 00 00       	mov    $0x1,%edx
   2846a:	41 ff d7             	call   *%r15
   2846d:	eb e1                	jmp    28450 <ownership_boundary_load::main+0x230>
   2846f:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   28474:	48 85 c0             	test   %rax,%rax
   28477:	74 18                	je     28491 <ownership_boundary_load::main+0x271>
   28479:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
   2847e:	48 c1 e0 03          	shl    $0x3,%rax
   28482:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   28486:	ba 08 00 00 00       	mov    $0x8,%edx
   2848b:	ff 15 d7 cf 04 00    	call   *0x4cfd7(%rip)        # 75468 <_DYNAMIC+0x2d0>
   28491:	66 0f 10 84 24 98 00 	movupd 0x98(%rsp),%xmm0
   28498:	00 00 
   2849a:	66 0f 29 84 24 80 00 	movapd %xmm0,0x80(%rsp)
   284a1:	00 00 
   284a3:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
   284aa:	00 
   284ab:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
   284b2:	00 
   284b3:	48 83 fe 02          	cmp    $0x2,%rsi
   284b7:	0f 82 72 0a 00 00    	jb     28f2f <ownership_boundary_load::main+0xd0f>
   284bd:	4c 8b 8c 24 88 00 00 	mov    0x88(%rsp),%r9
   284c4:	00 
   284c5:	49 8d 41 18          	lea    0x18(%r9),%rax
   284c9:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
   284d0:	00 
   284d1:	48 83 fe 02          	cmp    $0x2,%rsi
   284d5:	0f 84 62 0a 00 00    	je     28f3d <ownership_boundary_load::main+0xd1d>
   284db:	49 8b 49 38          	mov    0x38(%r9),%rcx
   284df:	49 8b 71 40          	mov    0x40(%r9),%rsi
   284e3:	48 83 fe 01          	cmp    $0x1,%rsi
   284e7:	74 0e                	je     284f7 <ownership_boundary_load::main+0x2d7>
   284e9:	48 85 f6             	test   %rsi,%rsi
   284ec:	0f 84 88 0a 00 00    	je     28f7a <ownership_boundary_load::main+0xd5a>
   284f2:	0f b6 11             	movzbl (%rcx),%edx
   284f5:	eb 17                	jmp    2850e <ownership_boundary_load::main+0x2ee>
   284f7:	0f b6 11             	movzbl (%rcx),%edx
   284fa:	b0 01                	mov    $0x1,%al
   284fc:	83 fa 2b             	cmp    $0x2b,%edx
   284ff:	0f 84 0e 09 00 00    	je     28e13 <ownership_boundary_load::main+0xbf3>
   28505:	83 fa 2d             	cmp    $0x2d,%edx
   28508:	0f 84 05 09 00 00    	je     28e13 <ownership_boundary_load::main+0xbf3>
   2850e:	31 c0                	xor    %eax,%eax
   28510:	80 fa 2b             	cmp    $0x2b,%dl
   28513:	0f 94 c0             	sete   %al
   28516:	48 89 f2             	mov    %rsi,%rdx
   28519:	48 29 c2             	sub    %rax,%rdx
   2851c:	48 01 c1             	add    %rax,%rcx
   2851f:	48 f7 d8             	neg    %rax
   28522:	48 83 fa 11          	cmp    $0x11,%rdx
   28526:	73 3f                	jae    28567 <ownership_boundary_load::main+0x347>
   28528:	48 85 d2             	test   %rdx,%rdx
   2852b:	0f 84 88 00 00 00    	je     285b9 <ownership_boundary_load::main+0x399>
   28531:	48 01 c6             	add    %rax,%rsi
   28534:	48 f7 de             	neg    %rsi
   28537:	45 31 ff             	xor    %r15d,%r15d
   2853a:	31 c0                	xor    %eax,%eax
   2853c:	0f 1f 40 00          	nopl   0x0(%rax)
   28540:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
   28544:	83 c2 d0             	add    $0xffffffd0,%edx
   28547:	83 fa 09             	cmp    $0x9,%edx
   2854a:	0f 87 24 09 00 00    	ja     28e74 <ownership_boundary_load::main+0xc54>
   28550:	4b 8d 3c bf          	lea    (%r15,%r15,4),%rdi
   28554:	89 d2                	mov    %edx,%edx
   28556:	4c 8d 3c 7a          	lea    (%rdx,%rdi,2),%r15
   2855a:	48 ff c0             	inc    %rax
   2855d:	48 89 f2             	mov    %rsi,%rdx
   28560:	48 01 c2             	add    %rax,%rdx
   28563:	75 db                	jne    28540 <ownership_boundary_load::main+0x320>
   28565:	eb 55                	jmp    285bc <ownership_boundary_load::main+0x39c>
   28567:	48 01 c6             	add    %rax,%rsi
   2856a:	48 f7 de             	neg    %rsi
   2856d:	45 31 ff             	xor    %r15d,%r15d
   28570:	bf 0a 00 00 00       	mov    $0xa,%edi
   28575:	45 31 c0             	xor    %r8d,%r8d
   28578:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2857f:	00 
   28580:	48 89 f0             	mov    %rsi,%rax
   28583:	4c 01 c0             	add    %r8,%rax
   28586:	74 34                	je     285bc <ownership_boundary_load::main+0x39c>
   28588:	4c 89 f8             	mov    %r15,%rax
   2858b:	48 f7 e7             	mul    %rdi
   2858e:	42 0f b6 14 01       	movzbl (%rcx,%r8,1),%edx
   28593:	0f 80 70 08 00 00    	jo     28e09 <ownership_boundary_load::main+0xbe9>
   28599:	83 c2 d0             	add    $0xffffffd0,%edx
   2859c:	83 fa 0a             	cmp    $0xa,%edx
   2859f:	0f 83 cf 08 00 00    	jae    28e74 <ownership_boundary_load::main+0xc54>
   285a5:	49 89 c7             	mov    %rax,%r15
   285a8:	89 d0                	mov    %edx,%eax
   285aa:	49 ff c0             	inc    %r8
   285ad:	49 01 c7             	add    %rax,%r15
   285b0:	73 ce                	jae    28580 <ownership_boundary_load::main+0x360>
   285b2:	b0 02                	mov    $0x2,%al
   285b4:	e9 5a 08 00 00       	jmp    28e13 <ownership_boundary_load::main+0xbf3>
   285b9:	45 31 ff             	xor    %r15d,%r15d
   285bc:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
   285c3:	00 
   285c4:	4c 89 bc 24 00 01 00 	mov    %r15,0x100(%rsp)
   285cb:	00 
   285cc:	ff 15 c6 ce 04 00    	call   *0x4cec6(%rip)        # 75498 <_DYNAMIC+0x300>
   285d2:	bf 20 00 00 00       	mov    $0x20,%edi
   285d7:	be 01 00 00 00       	mov    $0x1,%esi
   285dc:	ff 15 be ce 04 00    	call   *0x4cebe(%rip)        # 754a0 <_DYNAMIC+0x308>
   285e2:	48 85 c0             	test   %rax,%rax
   285e5:	0f 84 6b 09 00 00    	je     28f56 <ownership_boundary_load::main+0xd36>
   285eb:	48 89 c3             	mov    %rax,%rbx
   285ee:	0f 10 05 23 e4 fd ff 	movups -0x21bdd(%rip),%xmm0        # 6a18 <__abi_tag+0x671c>
   285f5:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   285f9:	66 0f 10 05 07 e4 fd 	movupd -0x21bf9(%rip),%xmm0        # 6a08 <__abi_tag+0x670c>
   28600:	ff 
   28601:	66 0f 11 00          	movupd %xmm0,(%rax)
   28605:	ff 15 8d ce 04 00    	call   *0x4ce8d(%rip)        # 75498 <_DYNAMIC+0x300>
   2860b:	bf 00 60 00 00       	mov    $0x6000,%edi
   28610:	be 08 00 00 00       	mov    $0x8,%esi
   28615:	ff 15 85 ce 04 00    	call   *0x4ce85(%rip)        # 754a0 <_DYNAMIC+0x308>
   2861b:	48 85 c0             	test   %rax,%rax
   2861e:	0f 84 44 09 00 00    	je     28f68 <ownership_boundary_load::main+0xd48>
   28624:	49 89 c6             	mov    %rax,%r14
   28627:	48 c7 84 24 b8 00 00 	movq   $0x400,0xb8(%rsp)
   2862e:	00 00 04 00 00 
   28633:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   2863a:	00 
   2863b:	48 c7 44 24 10 20 00 	movq   $0x20,0x10(%rsp)
   28642:	00 00 
   28644:	48 89 1c 24          	mov    %rbx,(%rsp)
   28648:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   2864d:	48 c7 44 24 20 20 00 	movq   $0x20,0x20(%rsp)
   28654:	00 00 
   28656:	45 31 e4             	xor    %r12d,%r12d
   28659:	4c 8d 6c 24 40       	lea    0x40(%rsp),%r13
   2865e:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   28663:	48 8b 2d 3e ce 04 00 	mov    0x4ce3e(%rip),%rbp        # 754a8 <_DYNAMIC+0x310>
   2866a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   28670:	4c 89 ef             	mov    %r13,%rdi
   28673:	48 89 f3             	mov    %rsi,%rbx
   28676:	ff d5                	call   *%rbp
   28678:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   2867d:	49 89 46 10          	mov    %rax,0x10(%r14)
   28681:	66 0f 10 44 24 40    	movupd 0x40(%rsp),%xmm0
   28687:	66 41 0f 11 06       	movupd %xmm0,(%r14)
   2868c:	49 83 c6 18          	add    $0x18,%r14
   28690:	49 ff cc             	dec    %r12
   28693:	49 81 fc 01 fc ff ff 	cmp    $0xfffffffffffffc01,%r12
   2869a:	48 89 de             	mov    %rbx,%rsi
   2869d:	75 d1                	jne    28670 <ownership_boundary_load::main+0x450>
   2869f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   286a4:	49 89 46 10          	mov    %rax,0x10(%r14)
   286a8:	0f 10 44 24 10       	movups 0x10(%rsp),%xmm0
   286ad:	41 0f 11 06          	movups %xmm0,(%r14)
   286b1:	66 0f 10 84 24 b8 00 	movupd 0xb8(%rsp),%xmm0
   286b8:	00 00 
   286ba:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   286c0:	48 c7 44 24 50 00 04 	movq   $0x400,0x50(%rsp)
   286c7:	00 00 
   286c9:	ff 15 c9 cd 04 00    	call   *0x4cdc9(%rip)        # 75498 <_DYNAMIC+0x300>
   286cf:	bf 18 00 00 00       	mov    $0x18,%edi
   286d4:	be 08 00 00 00       	mov    $0x8,%esi
   286d9:	ff 15 c1 cd 04 00    	call   *0x4cdc1(%rip)        # 754a0 <_DYNAMIC+0x308>
   286df:	48 85 c0             	test   %rax,%rax
   286e2:	0f 84 77 07 00 00    	je     28e5f <ownership_boundary_load::main+0xc3f>
   286e8:	49 89 c4             	mov    %rax,%r12
   286eb:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   286f0:	49 89 44 24 10       	mov    %rax,0x10(%r12)
   286f5:	66 0f 28 44 24 40    	movapd 0x40(%rsp),%xmm0
   286fb:	66 41 0f 11 04 24    	movupd %xmm0,(%r12)
   28701:	ff 15 a9 cd 04 00    	call   *0x4cda9(%rip)        # 754b0 <_DYNAMIC+0x318>
   28707:	49 be 7d 00 00 00 00 	movabs $0x800000000000007d,%r14
   2870e:	00 00 80 
   28711:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   28718:	00 
   28719:	89 94 24 c0 00 00 00 	mov    %edx,0xc0(%rsp)
   28720:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
   28727:	00 00 00 00 00 
   2872c:	4d 85 ff             	test   %r15,%r15
   2872f:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
   28734:	4c 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%r13
   2873b:	00 
   2873c:	0f 84 42 03 00 00    	je     28a84 <ownership_boundary_load::main+0x864>
   28742:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   28749:	00 
   2874a:	31 ed                	xor    %ebp,%ebp
   2874c:	eb 19                	jmp    28767 <ownership_boundary_load::main+0x547>
   2874e:	66 90                	xchg   %ax,%ax
   28750:	4d 89 ee             	mov    %r13,%r14
   28753:	4c 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%r13
   2875a:	00 
   2875b:	48 ff c5             	inc    %rbp
   2875e:	4c 39 fd             	cmp    %r15,%rbp
   28761:	0f 84 1d 03 00 00    	je     28a84 <ownership_boundary_load::main+0x864>
   28767:	49 8b 45 20          	mov    0x20(%r13),%rax
   2876b:	49 8b 4d 28          	mov    0x28(%r13),%rcx
   2876f:	48 83 f9 03          	cmp    $0x3,%rcx
   28773:	0f 84 27 01 00 00    	je     288a0 <ownership_boundary_load::main+0x680>
   28779:	48 83 f9 0a          	cmp    $0xa,%rcx
   2877d:	0f 85 bd 01 00 00    	jne    28940 <ownership_boundary_load::main+0x720>
   28783:	48 8b 08             	mov    (%rax),%rcx
   28786:	48 ba 6e 65 73 74 65 	movabs $0x622d64657473656e,%rdx
   2878d:	64 2d 62 
   28790:	48 31 d1             	xor    %rdx,%rcx
   28793:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   28797:	48 35 6f 78 00 00    	xor    $0x786f,%rax
   2879d:	48 09 c8             	or     %rcx,%rax
   287a0:	0f 85 9b 06 00 00    	jne    28e41 <ownership_boundary_load::main+0xc21>
   287a6:	ff 15 ec cc 04 00    	call   *0x4ccec(%rip)        # 75498 <_DYNAMIC+0x300>
   287ac:	bf 18 00 00 00       	mov    $0x18,%edi
   287b1:	be 08 00 00 00       	mov    $0x8,%esi
   287b6:	ff 15 e4 cc 04 00    	call   *0x4cce4(%rip)        # 754a0 <_DYNAMIC+0x308>
   287bc:	48 85 c0             	test   %rax,%rax
   287bf:	0f 84 3e 04 00 00    	je     28c03 <ownership_boundary_load::main+0x9e3>
   287c5:	49 89 c5             	mov    %rax,%r13
   287c8:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   287cd:	4c 89 e6             	mov    %r12,%rsi
   287d0:	e8 db 0e 00 00       	call   296b0 <<alloc::vec::Vec<T> as varlit_core::fallible::TryClone>::try_clone>
   287d5:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   287da:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   287df:	4c 8b 64 24 50       	mov    0x50(%rsp),%r12
   287e4:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
   287e9:	48 b8 7d 00 00 00 00 	movabs $0x800000000000007d,%rax
   287f0:	00 00 80 
   287f3:	48 39 c2             	cmp    %rax,%rdx
   287f6:	0f 85 7b 04 00 00    	jne    28c77 <ownership_boundary_load::main+0xa57>
   287fc:	49 89 4d 00          	mov    %rcx,0x0(%r13)
   28800:	4d 89 65 08          	mov    %r12,0x8(%r13)
   28804:	4d 89 75 10          	mov    %r14,0x10(%r13)
   28808:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
   2880f:	00 
   28810:	48 8b 0c 24          	mov    (%rsp),%rcx
   28814:	4c 01 f1             	add    %r14,%rcx
   28817:	48 89 0c 24          	mov    %rcx,(%rsp)
   2881b:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
   28822:	00 
   28823:	48 8d 84 24 98 00 00 	lea    0x98(%rsp),%rax
   2882a:	00 
   2882b:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   28830:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
   28835:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
   2883c:	00 
   2883d:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   28842:	4c 8b 70 10          	mov    0x10(%rax),%r14
   28846:	4d 85 f6             	test   %r14,%r14
   28849:	4c 8b 2d 18 cc 04 00 	mov    0x4cc18(%rip),%r13        # 75468 <_DYNAMIC+0x2d0>
   28850:	0f 84 da 01 00 00    	je     28a30 <ownership_boundary_load::main+0x810>
   28856:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2885b:	4c 8b 60 08          	mov    0x8(%rax),%r12
   2885f:	49 83 c4 08          	add    $0x8,%r12
   28863:	eb 18                	jmp    2887d <ownership_boundary_load::main+0x65d>
   28865:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2886c:	00 00 00 00 
   28870:	49 83 c4 18          	add    $0x18,%r12
   28874:	49 ff ce             	dec    %r14
   28877:	0f 84 b3 01 00 00    	je     28a30 <ownership_boundary_load::main+0x810>
   2887d:	49 8b 74 24 f8       	mov    -0x8(%r12),%rsi
   28882:	48 85 f6             	test   %rsi,%rsi
   28885:	74 e9                	je     28870 <ownership_boundary_load::main+0x650>
   28887:	49 8b 3c 24          	mov    (%r12),%rdi
   2888b:	ba 01 00 00 00       	mov    $0x1,%edx
   28890:	41 ff d5             	call   *%r13
   28893:	eb db                	jmp    28870 <ownership_boundary_load::main+0x650>
   28895:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2889c:	00 00 00 00 
   288a0:	0f b7 08             	movzwl (%rax),%ecx
   288a3:	81 f1 62 6f 00 00    	xor    $0x6f62,%ecx
   288a9:	0f b6 40 02          	movzbl 0x2(%rax),%eax
   288ad:	83 f0 78             	xor    $0x78,%eax
   288b0:	66 09 c8             	or     %cx,%ax
   288b3:	0f 85 88 05 00 00    	jne    28e41 <ownership_boundary_load::main+0xc21>
   288b9:	ff 15 d9 cb 04 00    	call   *0x4cbd9(%rip)        # 75498 <_DYNAMIC+0x300>
   288bf:	bf 40 00 00 00       	mov    $0x40,%edi
   288c4:	be 08 00 00 00       	mov    $0x8,%esi
   288c9:	ff 15 d1 cb 04 00    	call   *0x4cbd1(%rip)        # 754a0 <_DYNAMIC+0x308>
   288cf:	48 85 c0             	test   %rax,%rax
   288d2:	0f 84 4a 03 00 00    	je     28c22 <ownership_boundary_load::main+0xa02>
   288d8:	48 89 28             	mov    %rbp,(%rax)
   288db:	48 89 68 08          	mov    %rbp,0x8(%rax)
   288df:	48 89 68 10          	mov    %rbp,0x10(%rax)
   288e3:	48 89 68 18          	mov    %rbp,0x18(%rax)
   288e7:	48 89 68 20          	mov    %rbp,0x20(%rax)
   288eb:	48 89 68 28          	mov    %rbp,0x28(%rax)
   288ef:	48 89 68 30          	mov    %rbp,0x30(%rax)
   288f3:	48 89 68 38          	mov    %rbp,0x38(%rax)
   288f7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   288fc:	48 8b 0c 24          	mov    (%rsp),%rcx
   28900:	48 01 e9             	add    %rbp,%rcx
   28903:	48 89 0c 24          	mov    %rcx,(%rsp)
   28907:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
   2890e:	00 
   2890f:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
   28914:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
   28919:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   2891e:	be 40 00 00 00       	mov    $0x40,%esi
   28923:	ba 08 00 00 00       	mov    $0x8,%edx
   28928:	ff 15 3a cb 04 00    	call   *0x4cb3a(%rip)        # 75468 <_DYNAMIC+0x2d0>
   2892e:	48 ff c5             	inc    %rbp
   28931:	4c 39 fd             	cmp    %r15,%rbp
   28934:	0f 85 2d fe ff ff    	jne    28767 <ownership_boundary_load::main+0x547>
   2893a:	e9 45 01 00 00       	jmp    28a84 <ownership_boundary_load::main+0x864>
   2893f:	90                   	nop
   28940:	48 83 f9 06          	cmp    $0x6,%rcx
   28944:	0f 85 f7 04 00 00    	jne    28e41 <ownership_boundary_load::main+0xc21>
   2894a:	8b 08                	mov    (%rax),%ecx
   2894c:	ba 73 68 61 72       	mov    $0x72616873,%edx
   28951:	31 d1                	xor    %edx,%ecx
   28953:	0f b7 40 04          	movzwl 0x4(%rax),%eax
   28957:	35 65 64 00 00       	xor    $0x6465,%eax
   2895c:	09 c8                	or     %ecx,%eax
   2895e:	0f 85 dd 04 00 00    	jne    28e41 <ownership_boundary_load::main+0xc21>
   28964:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   28969:	ff 15 49 cb 04 00    	call   *0x4cb49(%rip)        # 754b8 <_DYNAMIC+0x320>
   2896f:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   28974:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   28979:	4c 39 f0             	cmp    %r14,%rax
   2897c:	0f 85 cc 02 00 00    	jne    28c4e <ownership_boundary_load::main+0xa2e>
   28982:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
   28987:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
   2898e:	00 
   2898f:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   28994:	48 8d b4 24 98 00 00 	lea    0x98(%rsp),%rsi
   2899b:	00 
   2899c:	ff 15 1e cb 04 00    	call   *0x4cb1e(%rip)        # 754c0 <_DYNAMIC+0x328>
   289a2:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   289a7:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   289ac:	4c 39 f1             	cmp    %r14,%rcx
   289af:	0f 85 14 04 00 00    	jne    28dc9 <ownership_boundary_load::main+0xba9>
   289b5:	4d 89 f5             	mov    %r14,%r13
   289b8:	4d 89 e6             	mov    %r12,%r14
   289bb:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   289c0:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   289c7:	00 
   289c8:	ff 15 fa ca 04 00    	call   *0x4cafa(%rip)        # 754c8 <_DYNAMIC+0x330>
   289ce:	49 89 dc             	mov    %rbx,%r12
   289d1:	48 89 df             	mov    %rbx,%rdi
   289d4:	ff 15 f6 ca 04 00    	call   *0x4caf6(%rip)        # 754d0 <_DYNAMIC+0x338>
   289da:	0f b6 c0             	movzbl %al,%eax
   289dd:	48 8b 0c 24          	mov    (%rsp),%rcx
   289e1:	48 01 c1             	add    %rax,%rcx
   289e4:	48 89 0c 24          	mov    %rcx,(%rsp)
   289e8:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
   289ef:	00 
   289f0:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   289f5:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
   289fa:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   289ff:	f0 48 ff 0f          	lock decq (%rdi)
   28a03:	75 05                	jne    28a0a <ownership_boundary_load::main+0x7ea>
   28a05:	e8 06 51 00 00       	call   2db10 <triomphe::arc::Arc<T>::drop_slow>
   28a0a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   28a0f:	f0 48 ff 0f          	lock decq (%rdi)
   28a13:	4d 89 f4             	mov    %r14,%r12
   28a16:	0f 85 34 fd ff ff    	jne    28750 <ownership_boundary_load::main+0x530>
   28a1c:	e8 ef 50 00 00       	call   2db10 <triomphe::arc::Arc<T>::drop_slow>
   28a21:	e9 2a fd ff ff       	jmp    28750 <ownership_boundary_load::main+0x530>
   28a26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   28a2d:	00 00 00 
   28a30:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   28a35:	49 8b 06             	mov    (%r14),%rax
   28a38:	48 85 c0             	test   %rax,%rax
   28a3b:	74 14                	je     28a51 <ownership_boundary_load::main+0x831>
   28a3d:	49 8b 7e 08          	mov    0x8(%r14),%rdi
   28a41:	48 c1 e0 03          	shl    $0x3,%rax
   28a45:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   28a49:	ba 08 00 00 00       	mov    $0x8,%edx
   28a4e:	41 ff d5             	call   *%r13
   28a51:	be 18 00 00 00       	mov    $0x18,%esi
   28a56:	ba 08 00 00 00       	mov    $0x8,%edx
   28a5b:	4c 89 f7             	mov    %r14,%rdi
   28a5e:	41 ff d5             	call   *%r13
   28a61:	49 be 7d 00 00 00 00 	movabs $0x800000000000007d,%r14
   28a68:	00 00 80 
   28a6b:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
   28a70:	4c 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%r13
   28a77:	00 
   28a78:	48 ff c5             	inc    %rbp
   28a7b:	4c 39 fd             	cmp    %r15,%rbp
   28a7e:	0f 85 e3 fc ff ff    	jne    28767 <ownership_boundary_load::main+0x547>
   28a84:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   28a8b:	00 
   28a8c:	ff 15 46 ca 04 00    	call   *0x4ca46(%rip)        # 754d8 <_DYNAMIC+0x340>
   28a92:	66 48 0f 6e c0       	movq   %rax,%xmm0
   28a97:	66 0f 62 05 11 e1 fd 	punpckldq -0x21eef(%rip),%xmm0        # 6bb0 <__abi_tag+0x68b4>
   28a9e:	ff 
   28a9f:	66 0f 5c 05 b9 e0 fd 	subpd  -0x21f47(%rip),%xmm0        # 6b60 <__abi_tag+0x6864>
   28aa6:	ff 
   28aa7:	66 0f 28 c8          	movapd %xmm0,%xmm1
   28aab:	66 0f 15 c8          	unpckhpd %xmm0,%xmm1
   28aaf:	f2 0f 58 c8          	addsd  %xmm0,%xmm1
   28ab3:	0f 57 c0             	xorps  %xmm0,%xmm0
   28ab6:	f2 0f 2a c2          	cvtsi2sd %edx,%xmm0
   28aba:	f2 0f 5e 05 9e dd fd 	divsd  -0x22262(%rip),%xmm0        # 6860 <__abi_tag+0x6564>
   28ac1:	ff 
   28ac2:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   28ac6:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
   28acc:	48 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%rax
   28ad3:	00 
   28ad4:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   28ad9:	48 8d 05 e0 09 00 00 	lea    0x9e0(%rip),%rax        # 294c0 <<&T as core::fmt::Display>::fmt>
   28ae0:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   28ae5:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
   28aec:	00 
   28aed:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   28af2:	48 8b 05 17 c9 04 00 	mov    0x4c917(%rip),%rax        # 75410 <_DYNAMIC+0x278>
   28af9:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   28afe:	48 8d 8c 24 b0 00 00 	lea    0xb0(%rsp),%rcx
   28b05:	00 
   28b06:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   28b0b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   28b10:	48 89 5c 24 70       	mov    %rbx,0x70(%rsp)
   28b15:	48 8b 05 c4 c9 04 00 	mov    0x4c9c4(%rip),%rax        # 754e0 <_DYNAMIC+0x348>
   28b1c:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   28b21:	48 8d 3d 41 f7 fd ff 	lea    -0x208bf(%rip),%rdi        # 8269 <__abi_tag+0x7f6d>
   28b28:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   28b2d:	ff 15 b5 c9 04 00    	call   *0x4c9b5(%rip)        # 754e8 <_DYNAMIC+0x350>
   28b33:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   28b38:	4c 89 30             	mov    %r14,(%rax)
   28b3b:	49 8b 5c 24 08       	mov    0x8(%r12),%rbx
   28b40:	4d 8b 74 24 10       	mov    0x10(%r12),%r14
   28b45:	4d 85 f6             	test   %r14,%r14
   28b48:	74 35                	je     28b7f <ownership_boundary_load::main+0x95f>
   28b4a:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
   28b4e:	4c 8b 25 13 c9 04 00 	mov    0x4c913(%rip),%r12        # 75468 <_DYNAMIC+0x2d0>
   28b55:	eb 12                	jmp    28b69 <ownership_boundary_load::main+0x949>
   28b57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   28b5e:	00 00 
   28b60:	49 83 c7 18          	add    $0x18,%r15
   28b64:	49 ff ce             	dec    %r14
   28b67:	74 16                	je     28b7f <ownership_boundary_load::main+0x95f>
   28b69:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
   28b6d:	48 85 f6             	test   %rsi,%rsi
   28b70:	74 ee                	je     28b60 <ownership_boundary_load::main+0x940>
   28b72:	49 8b 3f             	mov    (%r15),%rdi
   28b75:	ba 01 00 00 00       	mov    $0x1,%edx
   28b7a:	41 ff d4             	call   *%r12
   28b7d:	eb e1                	jmp    28b60 <ownership_boundary_load::main+0x940>
   28b7f:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
   28b84:	49 8b 06             	mov    (%r14),%rax
   28b87:	48 85 c0             	test   %rax,%rax
   28b8a:	74 16                	je     28ba2 <ownership_boundary_load::main+0x982>
   28b8c:	48 c1 e0 03          	shl    $0x3,%rax
   28b90:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   28b94:	ba 08 00 00 00       	mov    $0x8,%edx
   28b99:	48 89 df             	mov    %rbx,%rdi
   28b9c:	ff 15 c6 c8 04 00    	call   *0x4c8c6(%rip)        # 75468 <_DYNAMIC+0x2d0>
   28ba2:	be 18 00 00 00       	mov    $0x18,%esi
   28ba7:	ba 08 00 00 00       	mov    $0x8,%edx
   28bac:	4c 89 f7             	mov    %r14,%rdi
   28baf:	ff 15 b3 c8 04 00    	call   *0x4c8b3(%rip)        # 75468 <_DYNAMIC+0x2d0>
   28bb5:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
   28bbc:	00 
   28bbd:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
   28bc4:	00 
   28bc5:	4d 85 f6             	test   %r14,%r14
   28bc8:	0f 84 c1 01 00 00    	je     28d8f <ownership_boundary_load::main+0xb6f>
   28bce:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
   28bd2:	4c 8b 25 8f c8 04 00 	mov    0x4c88f(%rip),%r12        # 75468 <_DYNAMIC+0x2d0>
   28bd9:	eb 12                	jmp    28bed <ownership_boundary_load::main+0x9cd>
   28bdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   28be0:	49 83 c7 18          	add    $0x18,%r15
   28be4:	49 ff ce             	dec    %r14
   28be7:	0f 84 a2 01 00 00    	je     28d8f <ownership_boundary_load::main+0xb6f>
   28bed:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
   28bf1:	48 85 f6             	test   %rsi,%rsi
   28bf4:	74 ea                	je     28be0 <ownership_boundary_load::main+0x9c0>
   28bf6:	49 8b 3f             	mov    (%r15),%rdi
   28bf9:	ba 01 00 00 00       	mov    $0x1,%edx
   28bfe:	41 ff d4             	call   *%r12
   28c01:	eb dd                	jmp    28be0 <ownership_boundary_load::main+0x9c0>
   28c03:	49 83 c6 99          	add    $0xffffffffffffff99,%r14
   28c07:	4d 89 f5             	mov    %r14,%r13
   28c0a:	41 be 18 00 00 00    	mov    $0x18,%r14d
   28c10:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
   28c16:	48 8d 15 6f 28 fe ff 	lea    -0x1d791(%rip),%rdx        # b48c <anon.2a50243cbdd70aae517223a5a1a25f04.1.llvm.16747617435240725101>
   28c1d:	e9 8a 00 00 00       	jmp    28cac <ownership_boundary_load::main+0xa8c>
   28c22:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   28c27:	48 c7 41 10 0b 00 00 	movq   $0xb,0x10(%rcx)
   28c2e:	00 
   28c2f:	48 c7 41 18 40 00 00 	movq   $0x40,0x18(%rcx)
   28c36:	00 
   28c37:	49 83 c6 99          	add    $0xffffffffffffff99,%r14
   28c3b:	4c 89 31             	mov    %r14,(%rcx)
   28c3e:	48 8d 05 47 28 fe ff 	lea    -0x1d7b9(%rip),%rax        # b48c <anon.2a50243cbdd70aae517223a5a1a25f04.1.llvm.16747617435240725101>
   28c45:	48 89 41 08          	mov    %rax,0x8(%rcx)
   28c49:	e9 89 00 00 00       	jmp    28cd7 <ownership_boundary_load::main+0xab7>
   28c4e:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
   28c53:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   28c58:	48 89 4a 30          	mov    %rcx,0x30(%rdx)
   28c5c:	0f 10 44 24 50       	movups 0x50(%rsp),%xmm0
   28c61:	0f 10 4c 24 60       	movups 0x60(%rsp),%xmm1
   28c66:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
   28c6a:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
   28c6e:	48 89 02             	mov    %rax,(%rdx)
   28c71:	48 89 72 08          	mov    %rsi,0x8(%rdx)
   28c75:	eb 60                	jmp    28cd7 <ownership_boundary_load::main+0xab7>
   28c77:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   28c7c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   28c81:	66 0f 10 44 24 60    	movupd 0x60(%rsp),%xmm0
   28c87:	66 0f 29 44 24 10    	movapd %xmm0,0x10(%rsp)
   28c8d:	49 89 d7             	mov    %rdx,%r15
   28c90:	be 18 00 00 00       	mov    $0x18,%esi
   28c95:	48 89 cb             	mov    %rcx,%rbx
   28c98:	ba 08 00 00 00       	mov    $0x8,%edx
   28c9d:	4c 89 ef             	mov    %r13,%rdi
   28ca0:	ff 15 c2 c7 04 00    	call   *0x4c7c2(%rip)        # 75468 <_DYNAMIC+0x2d0>
   28ca6:	4d 89 fd             	mov    %r15,%r13
   28ca9:	48 89 da             	mov    %rbx,%rdx
   28cac:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   28cb1:	4c 89 61 10          	mov    %r12,0x10(%rcx)
   28cb5:	4c 89 71 18          	mov    %r14,0x18(%rcx)
   28cb9:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   28cbe:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
   28cc2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   28cc7:	48 89 41 30          	mov    %rax,0x30(%rcx)
   28ccb:	4c 89 29             	mov    %r13,(%rcx)
   28cce:	48 89 51 08          	mov    %rdx,0x8(%rcx)
   28cd2:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
   28cd7:	4c 8b 2d 8a c7 04 00 	mov    0x4c78a(%rip),%r13        # 75468 <_DYNAMIC+0x2d0>
   28cde:	49 8b 5c 24 08       	mov    0x8(%r12),%rbx
   28ce3:	4d 8b 74 24 10       	mov    0x10(%r12),%r14
   28ce8:	4d 85 f6             	test   %r14,%r14
   28ceb:	74 32                	je     28d1f <ownership_boundary_load::main+0xaff>
   28ced:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
   28cf1:	eb 16                	jmp    28d09 <ownership_boundary_load::main+0xae9>
   28cf3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   28cfa:	84 00 00 00 00 00 
   28d00:	49 83 c7 18          	add    $0x18,%r15
   28d04:	49 ff ce             	dec    %r14
   28d07:	74 16                	je     28d1f <ownership_boundary_load::main+0xaff>
   28d09:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
   28d0d:	48 85 f6             	test   %rsi,%rsi
   28d10:	74 ee                	je     28d00 <ownership_boundary_load::main+0xae0>
   28d12:	49 8b 3f             	mov    (%r15),%rdi
   28d15:	ba 01 00 00 00       	mov    $0x1,%edx
   28d1a:	41 ff d5             	call   *%r13
   28d1d:	eb e1                	jmp    28d00 <ownership_boundary_load::main+0xae0>
   28d1f:	49 8b 04 24          	mov    (%r12),%rax
   28d23:	48 85 c0             	test   %rax,%rax
   28d26:	74 16                	je     28d3e <ownership_boundary_load::main+0xb1e>
   28d28:	48 c1 e0 03          	shl    $0x3,%rax
   28d2c:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   28d30:	ba 08 00 00 00       	mov    $0x8,%edx
   28d35:	48 89 df             	mov    %rbx,%rdi
   28d38:	ff 15 2a c7 04 00    	call   *0x4c72a(%rip)        # 75468 <_DYNAMIC+0x2d0>
   28d3e:	be 18 00 00 00       	mov    $0x18,%esi
   28d43:	ba 08 00 00 00       	mov    $0x8,%edx
   28d48:	4c 89 e7             	mov    %r12,%rdi
   28d4b:	ff 15 17 c7 04 00    	call   *0x4c717(%rip)        # 75468 <_DYNAMIC+0x2d0>
   28d51:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
   28d58:	00 
   28d59:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
   28d60:	00 
   28d61:	4d 85 f6             	test   %r14,%r14
   28d64:	74 29                	je     28d8f <ownership_boundary_load::main+0xb6f>
   28d66:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
   28d6a:	eb 0d                	jmp    28d79 <ownership_boundary_load::main+0xb59>
   28d6c:	0f 1f 40 00          	nopl   0x0(%rax)
   28d70:	49 83 c7 18          	add    $0x18,%r15
   28d74:	49 ff ce             	dec    %r14
   28d77:	74 16                	je     28d8f <ownership_boundary_load::main+0xb6f>
   28d79:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
   28d7d:	48 85 f6             	test   %rsi,%rsi
   28d80:	74 ee                	je     28d70 <ownership_boundary_load::main+0xb50>
   28d82:	49 8b 3f             	mov    (%r15),%rdi
   28d85:	ba 01 00 00 00       	mov    $0x1,%edx
   28d8a:	41 ff d5             	call   *%r13
   28d8d:	eb e1                	jmp    28d70 <ownership_boundary_load::main+0xb50>
   28d8f:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   28d96:	00 
   28d97:	48 85 c0             	test   %rax,%rax
   28d9a:	74 16                	je     28db2 <ownership_boundary_load::main+0xb92>
   28d9c:	48 c1 e0 03          	shl    $0x3,%rax
   28da0:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   28da4:	ba 08 00 00 00       	mov    $0x8,%edx
   28da9:	48 89 df             	mov    %rbx,%rdi
   28dac:	ff 15 b6 c6 04 00    	call   *0x4c6b6(%rip)        # 75468 <_DYNAMIC+0x2d0>
   28db2:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   28db7:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
   28dbe:	5b                   	pop    %rbx
   28dbf:	41 5c                	pop    %r12
   28dc1:	41 5d                	pop    %r13
   28dc3:	41 5e                	pop    %r14
   28dc5:	41 5f                	pop    %r15
   28dc7:	5d                   	pop    %rbp
   28dc8:	c3                   	ret
   28dc9:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
   28dce:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   28dd3:	48 89 56 30          	mov    %rdx,0x30(%rsi)
   28dd7:	0f 10 44 24 50       	movups 0x50(%rsp),%xmm0
   28ddc:	0f 10 4c 24 60       	movups 0x60(%rsp),%xmm1
   28de1:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
   28de5:	0f 11 46 10          	movups %xmm0,0x10(%rsi)
   28de9:	48 89 0e             	mov    %rcx,(%rsi)
   28dec:	48 89 46 08          	mov    %rax,0x8(%rsi)
   28df0:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   28df5:	f0 48 ff 0f          	lock decq (%rdi)
   28df9:	0f 85 d8 fe ff ff    	jne    28cd7 <ownership_boundary_load::main+0xab7>
   28dff:	e8 0c 4d 00 00       	call   2db10 <triomphe::arc::Arc<T>::drop_slow>
   28e04:	e9 ce fe ff ff       	jmp    28cd7 <ownership_boundary_load::main+0xab7>
   28e09:	80 c2 d0             	add    $0xd0,%dl
   28e0c:	31 c0                	xor    %eax,%eax
   28e0e:	80 fa 0a             	cmp    $0xa,%dl
   28e11:	14 01                	adc    $0x1,%al
   28e13:	88 44 24 40          	mov    %al,0x40(%rsp)
   28e17:	48 8d 3d 00 06 fe ff 	lea    -0x1fa00(%rip),%rdi        # 941e <anon.2361df452a3d74f765f7d2cf846dea24.227.llvm.8999845584199986377+0xc13>
   28e1e:	48 8d 0d f3 98 04 00 	lea    0x498f3(%rip),%rcx        # 72718 <__frame_dummy_init_array_entry+0x538>
   28e25:	4c 8d 05 8c 98 04 00 	lea    0x4988c(%rip),%r8        # 726b8 <__frame_dummy_init_array_entry+0x4d8>
   28e2c:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
   28e31:	be 2b 00 00 00       	mov    $0x2b,%esi
   28e36:	ff 15 b4 c6 04 00    	call   *0x4c6b4(%rip)        # 754f0 <_DYNAMIC+0x358>
   28e3c:	e9 37 01 00 00       	jmp    28f78 <ownership_boundary_load::main+0xd58>
   28e41:	48 8d 3d 08 e0 fd ff 	lea    -0x21ff8(%rip),%rdi        # 6e50 <__abi_tag+0x6b54>
   28e48:	48 8d 15 81 98 04 00 	lea    0x49881(%rip),%rdx        # 726d0 <__frame_dummy_init_array_entry+0x4f0>
   28e4f:	be 21 00 00 00       	mov    $0x21,%esi
   28e54:	ff 15 9e c6 04 00    	call   *0x4c69e(%rip)        # 754f8 <_DYNAMIC+0x360>
   28e5a:	e9 19 01 00 00       	jmp    28f78 <ownership_boundary_load::main+0xd58>
   28e5f:	bf 08 00 00 00       	mov    $0x8,%edi
   28e64:	be 18 00 00 00       	mov    $0x18,%esi
   28e69:	ff 15 91 c6 04 00    	call   *0x4c691(%rip)        # 75500 <_DYNAMIC+0x368>
   28e6f:	e9 04 01 00 00       	jmp    28f78 <ownership_boundary_load::main+0xd58>
   28e74:	b0 01                	mov    $0x1,%al
   28e76:	eb 9b                	jmp    28e13 <ownership_boundary_load::main+0xbf3>
   28e78:	4c 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%r14
   28e7f:	00 
   28e80:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
   28e87:	00 
   28e88:	48 89 c8             	mov    %rcx,%rax
   28e8b:	4c 29 f0             	sub    %r14,%rax
   28e8e:	48 f7 e6             	mul    %rsi
   28e91:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
   28e98:	00 00 00 00 00 
   28e9d:	48 c7 84 24 88 00 00 	movq   $0x8,0x88(%rsp)
   28ea4:	00 08 00 00 00 
   28ea9:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
   28eb0:	00 00 00 00 00 
   28eb5:	4c 39 f1             	cmp    %r14,%rcx
   28eb8:	75 38                	jne    28ef2 <ownership_boundary_load::main+0xcd2>
   28eba:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   28ec1:	00 
   28ec2:	48 85 c0             	test   %rax,%rax
   28ec5:	74 1b                	je     28ee2 <ownership_boundary_load::main+0xcc2>
   28ec7:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
   28ece:	00 
   28ecf:	48 c1 e0 03          	shl    $0x3,%rax
   28ed3:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   28ed7:	ba 08 00 00 00       	mov    $0x8,%edx
   28edc:	ff 15 86 c5 04 00    	call   *0x4c586(%rip)        # 75468 <_DYNAMIC+0x2d0>
   28ee2:	48 8d 15 9f 97 04 00 	lea    0x4979f(%rip),%rdx        # 72688 <__frame_dummy_init_array_entry+0x4a8>
   28ee9:	bf 01 00 00 00       	mov    $0x1,%edi
   28eee:	31 f6                	xor    %esi,%esi
   28ef0:	eb 5c                	jmp    28f4e <ownership_boundary_load::main+0xd2e>
   28ef2:	48 89 d3             	mov    %rdx,%rbx
   28ef5:	48 c1 eb 04          	shr    $0x4,%rbx
   28ef9:	49 83 c6 08          	add    $0x8,%r14
   28efd:	4c 8b 3d 64 c5 04 00 	mov    0x4c564(%rip),%r15        # 75468 <_DYNAMIC+0x2d0>
   28f04:	eb 13                	jmp    28f19 <ownership_boundary_load::main+0xcf9>
   28f06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   28f0d:	00 00 00 
   28f10:	49 83 c6 18          	add    $0x18,%r14
   28f14:	48 ff cb             	dec    %rbx
   28f17:	74 a1                	je     28eba <ownership_boundary_load::main+0xc9a>
   28f19:	49 8b 76 f8          	mov    -0x8(%r14),%rsi
   28f1d:	48 85 f6             	test   %rsi,%rsi
   28f20:	74 ee                	je     28f10 <ownership_boundary_load::main+0xcf0>
   28f22:	49 8b 3e             	mov    (%r14),%rdi
   28f25:	ba 01 00 00 00       	mov    $0x1,%edx
   28f2a:	41 ff d7             	call   *%r15
   28f2d:	eb e1                	jmp    28f10 <ownership_boundary_load::main+0xcf0>
   28f2f:	48 8d 15 52 97 04 00 	lea    0x49752(%rip),%rdx        # 72688 <__frame_dummy_init_array_entry+0x4a8>
   28f36:	bf 01 00 00 00       	mov    $0x1,%edi
   28f3b:	eb 11                	jmp    28f4e <ownership_boundary_load::main+0xd2e>
   28f3d:	48 8d 15 5c 97 04 00 	lea    0x4975c(%rip),%rdx        # 726a0 <__frame_dummy_init_array_entry+0x4c0>
   28f44:	be 02 00 00 00       	mov    $0x2,%esi
   28f49:	bf 02 00 00 00       	mov    $0x2,%edi
   28f4e:	ff 15 b4 c5 04 00    	call   *0x4c5b4(%rip)        # 75508 <_DYNAMIC+0x370>
   28f54:	eb 22                	jmp    28f78 <ownership_boundary_load::main+0xd58>
   28f56:	bf 01 00 00 00       	mov    $0x1,%edi
   28f5b:	be 20 00 00 00       	mov    $0x20,%esi
   28f60:	ff 15 2a c5 04 00    	call   *0x4c52a(%rip)        # 75490 <_DYNAMIC+0x2f8>
   28f66:	eb 10                	jmp    28f78 <ownership_boundary_load::main+0xd58>
   28f68:	bf 08 00 00 00       	mov    $0x8,%edi
   28f6d:	be 00 60 00 00       	mov    $0x6000,%esi
   28f72:	ff 15 18 c5 04 00    	call   *0x4c518(%rip)        # 75490 <_DYNAMIC+0x2f8>
   28f78:	0f 0b                	ud2
   28f7a:	31 c0                	xor    %eax,%eax
   28f7c:	e9 92 fe ff ff       	jmp    28e13 <ownership_boundary_load::main+0xbf3>
   28f81:	49 89 c7             	mov    %rax,%r15
   28f84:	be 20 00 00 00       	mov    $0x20,%esi
   28f89:	ba 01 00 00 00       	mov    $0x1,%edx
   28f8e:	48 89 df             	mov    %rbx,%rdi
   28f91:	ff 15 d1 c4 04 00    	call   *0x4c4d1(%rip)        # 75468 <_DYNAMIC+0x2d0>
   28f97:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   28f9e:	00 
   28f9f:	e8 ec 05 00 00       	call   29590 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::string::String>>>
   28fa4:	4c 89 ff             	mov    %r15,%rdi
   28fa7:	e8 f4 81 04 00       	call   711a0 <_Unwind_Resume@plt>
   28fac:	49 89 c7             	mov    %rax,%r15
   28faf:	e9 3f 01 00 00       	jmp    290f3 <ownership_boundary_load::main+0xed3>
   28fb4:	49 89 c7             	mov    %rax,%r15
   28fb7:	eb 38                	jmp    28ff1 <ownership_boundary_load::main+0xdd1>
   28fb9:	49 89 c7             	mov    %rax,%r15
   28fbc:	be 18 00 00 00       	mov    $0x18,%esi
   28fc1:	ba 08 00 00 00       	mov    $0x8,%edx
   28fc6:	4c 89 ef             	mov    %r13,%rdi
   28fc9:	ff 15 99 c4 04 00    	call   *0x4c499(%rip)        # 75468 <_DYNAMIC+0x2d0>
   28fcf:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
   28fd4:	e9 cb 00 00 00       	jmp    290a4 <ownership_boundary_load::main+0xe84>
   28fd9:	e9 c3 00 00 00       	jmp    290a1 <ownership_boundary_load::main+0xe81>
   28fde:	49 89 c7             	mov    %rax,%r15
   28fe1:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   28fe6:	f0 48 ff 0f          	lock decq (%rdi)
   28fea:	75 05                	jne    28ff1 <ownership_boundary_load::main+0xdd1>
   28fec:	e8 1f 4b 00 00       	call   2db10 <triomphe::arc::Arc<T>::drop_slow>
   28ff1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   28ff6:	f0 48 ff 08          	lock decq (%rax)
   28ffa:	75 0a                	jne    29006 <ownership_boundary_load::main+0xde6>
   28ffc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   29001:	e8 0a 4b 00 00       	call   2db10 <triomphe::arc::Arc<T>::drop_slow>
   29006:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
   2900b:	e9 94 00 00 00       	jmp    290a4 <ownership_boundary_load::main+0xe84>
   29010:	49 89 c7             	mov    %rax,%r15
   29013:	48 85 ed             	test   %rbp,%rbp
   29016:	74 42                	je     2905a <ownership_boundary_load::main+0xe3a>
   29018:	ba 01 00 00 00       	mov    $0x1,%edx
   2901d:	48 89 df             	mov    %rbx,%rdi
   29020:	48 89 ee             	mov    %rbp,%rsi
   29023:	ff 15 3f c4 04 00    	call   *0x4c43f(%rip)        # 75468 <_DYNAMIC+0x2d0>
   29029:	eb 2f                	jmp    2905a <ownership_boundary_load::main+0xe3a>
   2902b:	49 89 c7             	mov    %rax,%r15
   2902e:	49 f7 dc             	neg    %r12
   29031:	4c 89 a4 24 c8 00 00 	mov    %r12,0xc8(%rsp)
   29038:	00 
   29039:	be 20 00 00 00       	mov    $0x20,%esi
   2903e:	ba 01 00 00 00       	mov    $0x1,%edx
   29043:	48 8b 3c 24          	mov    (%rsp),%rdi
   29047:	ff 15 1b c4 04 00    	call   *0x4c41b(%rip)        # 75468 <_DYNAMIC+0x2d0>
   2904d:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   29054:	00 
   29055:	eb 30                	jmp    29087 <ownership_boundary_load::main+0xe67>
   29057:	49 89 c7             	mov    %rax,%r15
   2905a:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   2905f:	e8 0c 4a 00 00       	call   2da70 <<alloc::vec::into_iter::IntoIter<T,A> as core::ops::drop::Drop>::drop>
   29064:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   2906b:	00 
   2906c:	e8 1f 05 00 00       	call   29590 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::string::String>>>
   29071:	4c 89 ff             	mov    %r15,%rdi
   29074:	e8 27 81 04 00       	call   711a0 <_Unwind_Resume@plt>
   29079:	ff 15 f1 c3 04 00    	call   *0x4c3f1(%rip)        # 75470 <_DYNAMIC+0x2d8>
   2907f:	49 89 c7             	mov    %rax,%r15
   29082:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   29087:	e8 04 05 00 00       	call   29590 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::string::String>>>
   2908c:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   29093:	00 
   29094:	e8 f7 04 00 00       	call   29590 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::string::String>>>
   29099:	4c 89 ff             	mov    %r15,%rdi
   2909c:	e8 ff 80 04 00       	call   711a0 <_Unwind_Resume@plt>
   290a1:	49 89 c7             	mov    %rax,%r15
   290a4:	4c 89 e7             	mov    %r12,%rdi
   290a7:	e8 74 05 00 00       	call   29620 <core::ptr::drop_in_place<alloc::boxed::Box<alloc::vec::Vec<alloc::string::String>>>>
   290ac:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   290b3:	00 
   290b4:	e8 d7 04 00 00       	call   29590 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::string::String>>>
   290b9:	4c 89 ff             	mov    %r15,%rdi
   290bc:	e8 df 80 04 00       	call   711a0 <_Unwind_Resume@plt>
   290c1:	49 89 c7             	mov    %rax,%r15
   290c4:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   290cb:	00 
   290cc:	e8 bf 04 00 00       	call   29590 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::string::String>>>
   290d1:	4c 89 ff             	mov    %r15,%rdi
   290d4:	e8 c7 80 04 00       	call   711a0 <_Unwind_Resume@plt>
   290d9:	49 89 c7             	mov    %rax,%r15
   290dc:	4d 85 f6             	test   %r14,%r14
   290df:	74 12                	je     290f3 <ownership_boundary_load::main+0xed3>
   290e1:	ba 01 00 00 00       	mov    $0x1,%edx
   290e6:	48 8b 3c 24          	mov    (%rsp),%rdi
   290ea:	4c 89 f6             	mov    %r14,%rsi
   290ed:	ff 15 75 c3 04 00    	call   *0x4c375(%rip)        # 75468 <_DYNAMIC+0x2d0>
   290f3:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
   290fa:	00 
   290fb:	e8 70 49 00 00       	call   2da70 <<alloc::vec::into_iter::IntoIter<T,A> as core::ops::drop::Drop>::drop>
   29100:	4c 89 ff             	mov    %r15,%rdi
   29103:	e8 98 80 04 00       	call   711a0 <_Unwind_Resume@plt>
   29108:	ff 15 62 c3 04 00    	call   *0x4c362(%rip)        # 75470 <_DYNAMIC+0x2d8>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
