
/workspace/scratch/ownership-contracts/before-bin/ownership_boundary_load:     file format elf64-x86-64


Disassembly of section .text:

000000000002b060 <ownership_boundary_load::main>:
   2b060:	55                   	push   %rbp
   2b061:	41 57                	push   %r15
   2b063:	41 56                	push   %r14
   2b065:	41 55                	push   %r13
   2b067:	41 54                	push   %r12
   2b069:	53                   	push   %rbx
   2b06a:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
   2b071:	49 89 fe             	mov    %rdi,%r14
   2b074:	48 8d 9c 24 c8 00 00 	lea    0xc8(%rsp),%rbx
   2b07b:	00 
   2b07c:	48 89 df             	mov    %rbx,%rdi
   2b07f:	ff 15 73 a6 04 00    	call   *0x4a673(%rip)        # 756f8 <_DYNAMIC+0x360>
   2b085:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   2b08a:	48 89 de             	mov    %rbx,%rsi
   2b08d:	e8 de a8 ff ff       	call   25970 <<alloc::vec::Vec<T> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<T,I>>::from_iter>
   2b092:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   2b099:	00 
   2b09a:	48 83 fe 02          	cmp    $0x2,%rsi
   2b09e:	0f 82 85 08 00 00    	jb     2b929 <ownership_boundary_load::main+0x8c9>
   2b0a4:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
   2b0a9:	48 8d 43 18          	lea    0x18(%rbx),%rax
   2b0ad:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   2b0b4:	00 
   2b0b5:	48 83 fe 02          	cmp    $0x2,%rsi
   2b0b9:	0f 84 78 08 00 00    	je     2b937 <ownership_boundary_load::main+0x8d7>
   2b0bf:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
   2b0c3:	48 8b 73 40          	mov    0x40(%rbx),%rsi
   2b0c7:	48 83 fe 01          	cmp    $0x1,%rsi
   2b0cb:	74 0e                	je     2b0db <ownership_boundary_load::main+0x7b>
   2b0cd:	48 85 f6             	test   %rsi,%rsi
   2b0d0:	0f 84 87 08 00 00    	je     2b95d <ownership_boundary_load::main+0x8fd>
   2b0d6:	0f b6 11             	movzbl (%rcx),%edx
   2b0d9:	eb 17                	jmp    2b0f2 <ownership_boundary_load::main+0x92>
   2b0db:	0f b6 11             	movzbl (%rcx),%edx
   2b0de:	b0 01                	mov    $0x1,%al
   2b0e0:	83 fa 2b             	cmp    $0x2b,%edx
   2b0e3:	0f 84 e4 07 00 00    	je     2b8cd <ownership_boundary_load::main+0x86d>
   2b0e9:	83 fa 2d             	cmp    $0x2d,%edx
   2b0ec:	0f 84 db 07 00 00    	je     2b8cd <ownership_boundary_load::main+0x86d>
   2b0f2:	31 c0                	xor    %eax,%eax
   2b0f4:	80 fa 2b             	cmp    $0x2b,%dl
   2b0f7:	0f 94 c0             	sete   %al
   2b0fa:	48 89 f2             	mov    %rsi,%rdx
   2b0fd:	48 29 c2             	sub    %rax,%rdx
   2b100:	48 01 c1             	add    %rax,%rcx
   2b103:	48 f7 d8             	neg    %rax
   2b106:	48 83 fa 11          	cmp    $0x11,%rdx
   2b10a:	73 3b                	jae    2b147 <ownership_boundary_load::main+0xe7>
   2b10c:	48 85 d2             	test   %rdx,%rdx
   2b10f:	0f 84 84 00 00 00    	je     2b199 <ownership_boundary_load::main+0x139>
   2b115:	48 01 c6             	add    %rax,%rsi
   2b118:	48 f7 de             	neg    %rsi
   2b11b:	45 31 ff             	xor    %r15d,%r15d
   2b11e:	31 c0                	xor    %eax,%eax
   2b120:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
   2b124:	83 c2 d0             	add    $0xffffffd0,%edx
   2b127:	83 fa 09             	cmp    $0x9,%edx
   2b12a:	0f 87 f5 07 00 00    	ja     2b925 <ownership_boundary_load::main+0x8c5>
   2b130:	4b 8d 3c bf          	lea    (%r15,%r15,4),%rdi
   2b134:	89 d2                	mov    %edx,%edx
   2b136:	4c 8d 3c 7a          	lea    (%rdx,%rdi,2),%r15
   2b13a:	48 ff c0             	inc    %rax
   2b13d:	48 89 f2             	mov    %rsi,%rdx
   2b140:	48 01 c2             	add    %rax,%rdx
   2b143:	75 db                	jne    2b120 <ownership_boundary_load::main+0xc0>
   2b145:	eb 55                	jmp    2b19c <ownership_boundary_load::main+0x13c>
   2b147:	48 01 c6             	add    %rax,%rsi
   2b14a:	48 f7 de             	neg    %rsi
   2b14d:	45 31 ff             	xor    %r15d,%r15d
   2b150:	bf 0a 00 00 00       	mov    $0xa,%edi
   2b155:	45 31 c0             	xor    %r8d,%r8d
   2b158:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2b15f:	00 
   2b160:	48 89 f0             	mov    %rsi,%rax
   2b163:	4c 01 c0             	add    %r8,%rax
   2b166:	74 34                	je     2b19c <ownership_boundary_load::main+0x13c>
   2b168:	4c 89 f8             	mov    %r15,%rax
   2b16b:	48 f7 e7             	mul    %rdi
   2b16e:	42 0f b6 14 01       	movzbl (%rcx,%r8,1),%edx
   2b173:	0f 80 4a 07 00 00    	jo     2b8c3 <ownership_boundary_load::main+0x863>
   2b179:	83 c2 d0             	add    $0xffffffd0,%edx
   2b17c:	83 fa 0a             	cmp    $0xa,%edx
   2b17f:	0f 83 a0 07 00 00    	jae    2b925 <ownership_boundary_load::main+0x8c5>
   2b185:	49 89 c7             	mov    %rax,%r15
   2b188:	89 d0                	mov    %edx,%eax
   2b18a:	49 ff c0             	inc    %r8
   2b18d:	49 01 c7             	add    %rax,%r15
   2b190:	73 ce                	jae    2b160 <ownership_boundary_load::main+0x100>
   2b192:	b0 02                	mov    $0x2,%al
   2b194:	e9 34 07 00 00       	jmp    2b8cd <ownership_boundary_load::main+0x86d>
   2b199:	45 31 ff             	xor    %r15d,%r15d
   2b19c:	4c 89 bc 24 b8 00 00 	mov    %r15,0xb8(%rsp)
   2b1a3:	00 
   2b1a4:	ff 15 a6 a4 04 00    	call   *0x4a4a6(%rip)        # 75650 <_DYNAMIC+0x2b8>
   2b1aa:	bf 20 00 00 00       	mov    $0x20,%edi
   2b1af:	be 01 00 00 00       	mov    $0x1,%esi
   2b1b4:	ff 15 9e a4 04 00    	call   *0x4a49e(%rip)        # 75658 <_DYNAMIC+0x2c0>
   2b1ba:	48 85 c0             	test   %rax,%rax
   2b1bd:	0f 84 88 07 00 00    	je     2b94b <ownership_boundary_load::main+0x8eb>
   2b1c3:	0f 10 05 86 7b fe ff 	movups -0x1847a(%rip),%xmm0        # 12d50 <anon.c4814cb828c81191db59c5e81b199b19.6.llvm.8547334867598140981+0x1fc>
   2b1ca:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   2b1ce:	66 0f 10 05 6a 7b fe 	movupd -0x18496(%rip),%xmm0        # 12d40 <anon.c4814cb828c81191db59c5e81b199b19.6.llvm.8547334867598140981+0x1ec>
   2b1d5:	ff 
   2b1d6:	66 0f 11 00          	movupd %xmm0,(%rax)
   2b1da:	48 c7 44 24 30 20 00 	movq   $0x20,0x30(%rsp)
   2b1e1:	00 00 
   2b1e3:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   2b1e8:	48 c7 44 24 40 20 00 	movq   $0x20,0x40(%rsp)
   2b1ef:	00 00 
   2b1f1:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   2b1f8:	00 
   2b1f9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   2b1fe:	ba 00 04 00 00       	mov    $0x400,%edx
   2b203:	e8 a8 b5 ff ff       	call   267b0 <<T as alloc::vec::spec_from_elem::SpecFromElem>::from_elem>
   2b208:	ff 15 42 a4 04 00    	call   *0x4a442(%rip)        # 75650 <_DYNAMIC+0x2b8>
   2b20e:	bf 18 00 00 00       	mov    $0x18,%edi
   2b213:	be 08 00 00 00       	mov    $0x8,%esi
   2b218:	ff 15 3a a4 04 00    	call   *0x4a43a(%rip)        # 75658 <_DYNAMIC+0x2c0>
   2b21e:	48 85 c0             	test   %rax,%rax
   2b221:	0f 84 ec 06 00 00    	je     2b913 <ownership_boundary_load::main+0x8b3>
   2b227:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   2b22e:	00 
   2b22f:	48 89 48 10          	mov    %rcx,0x10(%rax)
   2b233:	66 0f 10 84 24 90 00 	movupd 0x90(%rsp),%xmm0
   2b23a:	00 00 
   2b23c:	66 0f 11 00          	movupd %xmm0,(%rax)
   2b240:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2b245:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   2b24c:	00 
   2b24d:	ff 15 ad a4 04 00    	call   *0x4a4ad(%rip)        # 75700 <_DYNAMIC+0x368>
   2b253:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
   2b258:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   2b25f:	00 
   2b260:	89 94 24 98 00 00 00 	mov    %edx,0x98(%rsp)
   2b267:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   2b26e:	00 00 
   2b270:	4d 85 ff             	test   %r15,%r15
   2b273:	0f 84 fe 02 00 00    	je     2b577 <ownership_boundary_load::main+0x517>
   2b279:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
   2b280:	00 00 
   2b282:	4c 8d 74 24 10       	lea    0x10(%rsp),%r14
   2b287:	48 8b 2d b2 a3 04 00 	mov    0x4a3b2(%rip),%rbp        # 75640 <_DYNAMIC+0x2a8>
   2b28e:	45 31 ed             	xor    %r13d,%r13d
   2b291:	48 89 9c 24 a8 00 00 	mov    %rbx,0xa8(%rsp)
   2b298:	00 
   2b299:	eb 18                	jmp    2b2b3 <ownership_boundary_load::main+0x253>
   2b29b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2b2a0:	48 8b 2d 99 a3 04 00 	mov    0x4a399(%rip),%rbp        # 75640 <_DYNAMIC+0x2a8>
   2b2a7:	49 ff c5             	inc    %r13
   2b2aa:	4d 39 fd             	cmp    %r15,%r13
   2b2ad:	0f 84 c4 02 00 00    	je     2b577 <ownership_boundary_load::main+0x517>
   2b2b3:	4d 89 f4             	mov    %r14,%r12
   2b2b6:	48 8b 43 20          	mov    0x20(%rbx),%rax
   2b2ba:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
   2b2be:	48 83 f9 03          	cmp    $0x3,%rcx
   2b2c2:	0f 84 d8 00 00 00    	je     2b3a0 <ownership_boundary_load::main+0x340>
   2b2c8:	48 83 f9 0a          	cmp    $0xa,%rcx
   2b2cc:	0f 85 6e 01 00 00    	jne    2b440 <ownership_boundary_load::main+0x3e0>
   2b2d2:	48 8b 08             	mov    (%rax),%rcx
   2b2d5:	48 ba 6e 65 73 74 65 	movabs $0x622d64657473656e,%rdx
   2b2dc:	64 2d 62 
   2b2df:	48 31 d1             	xor    %rdx,%rcx
   2b2e2:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2b2e6:	48 35 6f 78 00 00    	xor    $0x786f,%rax
   2b2ec:	48 09 c8             	or     %rcx,%rax
   2b2ef:	0f 85 03 06 00 00    	jne    2b8f8 <ownership_boundary_load::main+0x898>
   2b2f5:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   2b2fa:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
   2b301:	00 
   2b302:	e8 e9 fb ff ff       	call   2aef0 <<alloc::boxed::Box<T> as varlit_core::fallible::TryClone>::try_clone>
   2b307:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   2b30c:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   2b311:	48 ba 7d 00 00 00 00 	movabs $0x800000000000007d,%rdx
   2b318:	00 00 80 
   2b31b:	48 39 d1             	cmp    %rdx,%rcx
   2b31e:	0f 85 0f 04 00 00    	jne    2b733 <ownership_boundary_load::main+0x6d3>
   2b324:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   2b329:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2b32e:	48 03 48 10          	add    0x10(%rax),%rcx
   2b332:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   2b337:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
   2b33c:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
   2b341:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2b346:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
   2b34b:	48 8b 5d 10          	mov    0x10(%rbp),%rbx
   2b34f:	48 85 db             	test   %rbx,%rbx
   2b352:	0f 84 d8 01 00 00    	je     2b530 <ownership_boundary_load::main+0x4d0>
   2b358:	4c 8b 75 08          	mov    0x8(%rbp),%r14
   2b35c:	49 83 c6 08          	add    $0x8,%r14
   2b360:	eb 1b                	jmp    2b37d <ownership_boundary_load::main+0x31d>
   2b362:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2b369:	1f 84 00 00 00 00 00 
   2b370:	49 83 c6 18          	add    $0x18,%r14
   2b374:	48 ff cb             	dec    %rbx
   2b377:	0f 84 b3 01 00 00    	je     2b530 <ownership_boundary_load::main+0x4d0>
   2b37d:	49 8b 76 f8          	mov    -0x8(%r14),%rsi
   2b381:	48 85 f6             	test   %rsi,%rsi
   2b384:	74 ea                	je     2b370 <ownership_boundary_load::main+0x310>
   2b386:	49 8b 3e             	mov    (%r14),%rdi
   2b389:	ba 01 00 00 00       	mov    $0x1,%edx
   2b38e:	ff 15 ac a2 04 00    	call   *0x4a2ac(%rip)        # 75640 <_DYNAMIC+0x2a8>
   2b394:	eb da                	jmp    2b370 <ownership_boundary_load::main+0x310>
   2b396:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2b39d:	00 00 00 
   2b3a0:	0f b7 08             	movzwl (%rax),%ecx
   2b3a3:	81 f1 62 6f 00 00    	xor    $0x6f62,%ecx
   2b3a9:	0f b6 40 02          	movzbl 0x2(%rax),%eax
   2b3ad:	83 f0 78             	xor    $0x78,%eax
   2b3b0:	66 09 c8             	or     %cx,%ax
   2b3b3:	0f 85 3f 05 00 00    	jne    2b8f8 <ownership_boundary_load::main+0x898>
   2b3b9:	ff 15 91 a2 04 00    	call   *0x4a291(%rip)        # 75650 <_DYNAMIC+0x2b8>
   2b3bf:	bf 40 00 00 00       	mov    $0x40,%edi
   2b3c4:	be 08 00 00 00       	mov    $0x8,%esi
   2b3c9:	ff 15 89 a2 04 00    	call   *0x4a289(%rip)        # 75658 <_DYNAMIC+0x2c0>
   2b3cf:	48 85 c0             	test   %rax,%rax
   2b3d2:	0f 84 2b 03 00 00    	je     2b703 <ownership_boundary_load::main+0x6a3>
   2b3d8:	4c 89 28             	mov    %r13,(%rax)
   2b3db:	4c 89 68 08          	mov    %r13,0x8(%rax)
   2b3df:	4c 89 68 10          	mov    %r13,0x10(%rax)
   2b3e3:	4c 89 68 18          	mov    %r13,0x18(%rax)
   2b3e7:	4c 89 68 20          	mov    %r13,0x20(%rax)
   2b3eb:	4c 89 68 28          	mov    %r13,0x28(%rax)
   2b3ef:	4c 89 68 30          	mov    %r13,0x30(%rax)
   2b3f3:	4c 89 68 38          	mov    %r13,0x38(%rax)
   2b3f7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   2b3fc:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2b401:	4c 01 e9             	add    %r13,%rcx
   2b404:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   2b409:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
   2b40e:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
   2b413:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2b418:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   2b41d:	be 40 00 00 00       	mov    $0x40,%esi
   2b422:	ba 08 00 00 00       	mov    $0x8,%edx
   2b427:	ff d5                	call   *%rbp
   2b429:	4d 89 e6             	mov    %r12,%r14
   2b42c:	e9 76 fe ff ff       	jmp    2b2a7 <ownership_boundary_load::main+0x247>
   2b431:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2b438:	0f 1f 84 00 00 00 00 
   2b43f:	00 
   2b440:	48 83 f9 06          	cmp    $0x6,%rcx
   2b444:	0f 85 ae 04 00 00    	jne    2b8f8 <ownership_boundary_load::main+0x898>
   2b44a:	8b 08                	mov    (%rax),%ecx
   2b44c:	ba 73 68 61 72       	mov    $0x72616873,%edx
   2b451:	31 d1                	xor    %edx,%ecx
   2b453:	0f b7 40 04          	movzwl 0x4(%rax),%eax
   2b457:	35 65 64 00 00       	xor    $0x6465,%eax
   2b45c:	09 c8                	or     %ecx,%eax
   2b45e:	0f 85 94 04 00 00    	jne    2b8f8 <ownership_boundary_load::main+0x898>
   2b464:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   2b469:	ff 15 99 a2 04 00    	call   *0x4a299(%rip)        # 75708 <_DYNAMIC+0x370>
   2b46f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2b474:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
   2b479:	48 b9 7d 00 00 00 00 	movabs $0x800000000000007d,%rcx
   2b480:	00 00 80 
   2b483:	48 39 c8             	cmp    %rcx,%rax
   2b486:	0f 85 e4 02 00 00    	jne    2b770 <ownership_boundary_load::main+0x710>
   2b48c:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
   2b493:	00 
   2b494:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   2b499:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
   2b4a0:	00 
   2b4a1:	ff 15 69 a2 04 00    	call   *0x4a269(%rip)        # 75710 <_DYNAMIC+0x378>
   2b4a7:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   2b4ac:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   2b4b1:	48 ba 7d 00 00 00 00 	movabs $0x800000000000007d,%rdx
   2b4b8:	00 00 80 
   2b4bb:	48 39 d1             	cmp    %rdx,%rcx
   2b4be:	0f 85 d8 02 00 00    	jne    2b79c <ownership_boundary_load::main+0x73c>
   2b4c4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   2b4c9:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
   2b4d0:	00 
   2b4d1:	ff 15 41 a2 04 00    	call   *0x4a241(%rip)        # 75718 <_DYNAMIC+0x380>
   2b4d7:	4d 89 e6             	mov    %r12,%r14
   2b4da:	4c 89 e7             	mov    %r12,%rdi
   2b4dd:	ff 15 3d a2 04 00    	call   *0x4a23d(%rip)        # 75720 <_DYNAMIC+0x388>
   2b4e3:	0f b6 c0             	movzbl %al,%eax
   2b4e6:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2b4eb:	48 01 c1             	add    %rax,%rcx
   2b4ee:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   2b4f3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
   2b4f8:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   2b4fd:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2b502:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   2b507:	f0 48 ff 0f          	lock decq (%rdi)
   2b50b:	75 08                	jne    2b515 <ownership_boundary_load::main+0x4b5>
   2b50d:	e8 3e d0 ff ff       	call   28550 <triomphe::arc::Arc<T>::drop_slow>
   2b512:	4d 89 e6             	mov    %r12,%r14
   2b515:	f0 48 ff 4d 00       	lock decq 0x0(%rbp)
   2b51a:	0f 85 80 fd ff ff    	jne    2b2a0 <ownership_boundary_load::main+0x240>
   2b520:	48 89 ef             	mov    %rbp,%rdi
   2b523:	e8 28 d0 ff ff       	call   28550 <triomphe::arc::Arc<T>::drop_slow>
   2b528:	4d 89 e6             	mov    %r12,%r14
   2b52b:	e9 70 fd ff ff       	jmp    2b2a0 <ownership_boundary_load::main+0x240>
   2b530:	48 8b 45 00          	mov    0x0(%rbp),%rax
   2b534:	48 85 c0             	test   %rax,%rax
   2b537:	4c 8b 35 02 a1 04 00 	mov    0x4a102(%rip),%r14        # 75640 <_DYNAMIC+0x2a8>
   2b53e:	74 14                	je     2b554 <ownership_boundary_load::main+0x4f4>
   2b540:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
   2b544:	48 c1 e0 03          	shl    $0x3,%rax
   2b548:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   2b54c:	ba 08 00 00 00       	mov    $0x8,%edx
   2b551:	41 ff d6             	call   *%r14
   2b554:	be 18 00 00 00       	mov    $0x18,%esi
   2b559:	ba 08 00 00 00       	mov    $0x8,%edx
   2b55e:	48 89 ef             	mov    %rbp,%rdi
   2b561:	41 ff d6             	call   *%r14
   2b564:	48 8b 9c 24 a8 00 00 	mov    0xa8(%rsp),%rbx
   2b56b:	00 
   2b56c:	4c 89 f5             	mov    %r14,%rbp
   2b56f:	4d 89 e6             	mov    %r12,%r14
   2b572:	e9 30 fd ff ff       	jmp    2b2a7 <ownership_boundary_load::main+0x247>
   2b577:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   2b57e:	00 
   2b57f:	ff 15 a3 a1 04 00    	call   *0x4a1a3(%rip)        # 75728 <_DYNAMIC+0x390>
   2b585:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   2b58a:	66 48 0f 6e c0       	movq   %rax,%xmm0
   2b58f:	66 0f 62 05 59 79 fe 	punpckldq -0x186a7(%rip),%xmm0        # 12ef0 <anon.c4814cb828c81191db59c5e81b199b19.6.llvm.8547334867598140981+0x39c>
   2b596:	ff 
   2b597:	66 0f 5c 05 01 79 fe 	subpd  -0x186ff(%rip),%xmm0        # 12ea0 <anon.c4814cb828c81191db59c5e81b199b19.6.llvm.8547334867598140981+0x34c>
   2b59e:	ff 
   2b59f:	66 0f 28 c8          	movapd %xmm0,%xmm1
   2b5a3:	66 0f 15 c8          	unpckhpd %xmm0,%xmm1
   2b5a7:	f2 0f 2a d2          	cvtsi2sd %edx,%xmm2
   2b5ab:	f2 0f 58 c8          	addsd  %xmm0,%xmm1
   2b5af:	f2 0f 5e 15 e1 75 fe 	divsd  -0x18a1f(%rip),%xmm2        # 12b98 <anon.c4814cb828c81191db59c5e81b199b19.6.llvm.8547334867598140981+0x44>
   2b5b6:	ff 
   2b5b7:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   2b5bb:	f2 0f 11 54 24 10    	movsd  %xmm2,0x10(%rsp)
   2b5c1:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
   2b5c8:	00 
   2b5c9:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   2b5ce:	48 8d 05 cb ab ff ff 	lea    -0x5435(%rip),%rax        # 261a0 <<&T as core::fmt::Display>::fmt>
   2b5d5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   2b5da:	48 8d 84 24 b8 00 00 	lea    0xb8(%rsp),%rax
   2b5e1:	00 
   2b5e2:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   2b5e7:	48 8b 05 22 a0 04 00 	mov    0x4a022(%rip),%rax        # 75610 <_DYNAMIC+0x278>
   2b5ee:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   2b5f3:	48 8d 4c 24 28       	lea    0x28(%rsp),%rcx
   2b5f8:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   2b5fd:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   2b602:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
   2b607:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   2b60c:	48 8b 05 1d a1 04 00 	mov    0x4a11d(%rip),%rax        # 75730 <_DYNAMIC+0x398>
   2b613:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   2b618:	48 8d 3d 46 8b fe ff 	lea    -0x174ba(%rip),%rdi        # 14165 <anon.c4814cb828c81191db59c5e81b199b19.6.llvm.8547334867598140981+0x1611>
   2b61f:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   2b624:	ff 15 0e a1 04 00    	call   *0x4a10e(%rip)        # 75738 <_DYNAMIC+0x3a0>
   2b62a:	48 b8 7d 00 00 00 00 	movabs $0x800000000000007d,%rax
   2b631:	00 00 80 
   2b634:	49 89 45 00          	mov    %rax,0x0(%r13)
   2b638:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2b63d:	48 8b 58 10          	mov    0x10(%rax),%rbx
   2b641:	48 85 db             	test   %rbx,%rbx
   2b644:	74 39                	je     2b67f <ownership_boundary_load::main+0x61f>
   2b646:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2b64b:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2b64f:	49 83 c6 08          	add    $0x8,%r14
   2b653:	4c 8b 3d e6 9f 04 00 	mov    0x49fe6(%rip),%r15        # 75640 <_DYNAMIC+0x2a8>
   2b65a:	eb 0d                	jmp    2b669 <ownership_boundary_load::main+0x609>
   2b65c:	0f 1f 40 00          	nopl   0x0(%rax)
   2b660:	49 83 c6 18          	add    $0x18,%r14
   2b664:	48 ff cb             	dec    %rbx
   2b667:	74 16                	je     2b67f <ownership_boundary_load::main+0x61f>
   2b669:	49 8b 76 f8          	mov    -0x8(%r14),%rsi
   2b66d:	48 85 f6             	test   %rsi,%rsi
   2b670:	74 ee                	je     2b660 <ownership_boundary_load::main+0x600>
   2b672:	49 8b 3e             	mov    (%r14),%rdi
   2b675:	ba 01 00 00 00       	mov    $0x1,%edx
   2b67a:	41 ff d7             	call   *%r15
   2b67d:	eb e1                	jmp    2b660 <ownership_boundary_load::main+0x600>
   2b67f:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   2b684:	48 8b 03             	mov    (%rbx),%rax
   2b687:	48 85 c0             	test   %rax,%rax
   2b68a:	74 17                	je     2b6a3 <ownership_boundary_load::main+0x643>
   2b68c:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
   2b690:	48 c1 e0 03          	shl    $0x3,%rax
   2b694:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   2b698:	ba 08 00 00 00       	mov    $0x8,%edx
   2b69d:	ff 15 9d 9f 04 00    	call   *0x49f9d(%rip)        # 75640 <_DYNAMIC+0x2a8>
   2b6a3:	be 18 00 00 00       	mov    $0x18,%esi
   2b6a8:	ba 08 00 00 00       	mov    $0x8,%edx
   2b6ad:	48 89 df             	mov    %rbx,%rdi
   2b6b0:	ff 15 8a 9f 04 00    	call   *0x49f8a(%rip)        # 75640 <_DYNAMIC+0x2a8>
   2b6b6:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
   2b6bb:	4c 8b b4 24 80 00 00 	mov    0x80(%rsp),%r14
   2b6c2:	00 
   2b6c3:	4d 85 f6             	test   %r14,%r14
   2b6c6:	0f 84 c2 01 00 00    	je     2b88e <ownership_boundary_load::main+0x82e>
   2b6cc:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
   2b6d0:	4c 8b 25 69 9f 04 00 	mov    0x49f69(%rip),%r12        # 75640 <_DYNAMIC+0x2a8>
   2b6d7:	eb 14                	jmp    2b6ed <ownership_boundary_load::main+0x68d>
   2b6d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2b6e0:	49 83 c7 18          	add    $0x18,%r15
   2b6e4:	49 ff ce             	dec    %r14
   2b6e7:	0f 84 a1 01 00 00    	je     2b88e <ownership_boundary_load::main+0x82e>
   2b6ed:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
   2b6f1:	48 85 f6             	test   %rsi,%rsi
   2b6f4:	74 ea                	je     2b6e0 <ownership_boundary_load::main+0x680>
   2b6f6:	49 8b 3f             	mov    (%r15),%rdi
   2b6f9:	ba 01 00 00 00       	mov    $0x1,%edx
   2b6fe:	41 ff d4             	call   *%r12
   2b701:	eb dd                	jmp    2b6e0 <ownership_boundary_load::main+0x680>
   2b703:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   2b708:	49 c7 45 10 0b 00 00 	movq   $0xb,0x10(%r13)
   2b70f:	00 
   2b710:	49 c7 45 18 40 00 00 	movq   $0x40,0x18(%r13)
   2b717:	00 
   2b718:	48 b8 7d 00 00 00 00 	movabs $0x800000000000007d,%rax
   2b71f:	00 00 80 
   2b722:	48 83 c0 99          	add    $0xffffffffffffff99,%rax
   2b726:	49 89 45 00          	mov    %rax,0x0(%r13)
   2b72a:	48 8d 05 23 74 fe ff 	lea    -0x18bdd(%rip),%rax        # 12b54 <anon.c4814cb828c81191db59c5e81b199b19.6.llvm.8547334867598140981>
   2b731:	eb 26                	jmp    2b759 <ownership_boundary_load::main+0x6f9>
   2b733:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   2b738:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   2b73d:	49 89 55 30          	mov    %rdx,0x30(%r13)
   2b741:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
   2b746:	0f 10 4c 24 50       	movups 0x50(%rsp),%xmm1
   2b74b:	41 0f 11 4d 20       	movups %xmm1,0x20(%r13)
   2b750:	41 0f 11 45 10       	movups %xmm0,0x10(%r13)
   2b755:	49 89 4d 00          	mov    %rcx,0x0(%r13)
   2b759:	49 89 45 08          	mov    %rax,0x8(%r13)
   2b75d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2b762:	48 8b 58 10          	mov    0x10(%rax),%rbx
   2b766:	48 85 db             	test   %rbx,%rbx
   2b769:	75 7f                	jne    2b7ea <ownership_boundary_load::main+0x78a>
   2b76b:	e9 ae 00 00 00       	jmp    2b81e <ownership_boundary_load::main+0x7be>
   2b770:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   2b775:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   2b77a:	49 89 4d 30          	mov    %rcx,0x30(%r13)
   2b77e:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
   2b783:	0f 10 4c 24 50       	movups 0x50(%rsp),%xmm1
   2b788:	41 0f 11 4d 20       	movups %xmm1,0x20(%r13)
   2b78d:	41 0f 11 45 10       	movups %xmm0,0x10(%r13)
   2b792:	49 89 45 00          	mov    %rax,0x0(%r13)
   2b796:	49 89 6d 08          	mov    %rbp,0x8(%r13)
   2b79a:	eb 39                	jmp    2b7d5 <ownership_boundary_load::main+0x775>
   2b79c:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   2b7a1:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   2b7a6:	49 89 55 30          	mov    %rdx,0x30(%r13)
   2b7aa:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
   2b7af:	0f 10 4c 24 50       	movups 0x50(%rsp),%xmm1
   2b7b4:	41 0f 11 4d 20       	movups %xmm1,0x20(%r13)
   2b7b9:	41 0f 11 45 10       	movups %xmm0,0x10(%r13)
   2b7be:	49 89 4d 00          	mov    %rcx,0x0(%r13)
   2b7c2:	49 89 45 08          	mov    %rax,0x8(%r13)
   2b7c6:	f0 48 ff 4d 00       	lock decq 0x0(%rbp)
   2b7cb:	75 08                	jne    2b7d5 <ownership_boundary_load::main+0x775>
   2b7cd:	48 89 ef             	mov    %rbp,%rdi
   2b7d0:	e8 7b cd ff ff       	call   28550 <triomphe::arc::Arc<T>::drop_slow>
   2b7d5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2b7da:	48 8b 2d 5f 9e 04 00 	mov    0x49e5f(%rip),%rbp        # 75640 <_DYNAMIC+0x2a8>
   2b7e1:	48 8b 58 10          	mov    0x10(%rax),%rbx
   2b7e5:	48 85 db             	test   %rbx,%rbx
   2b7e8:	74 34                	je     2b81e <ownership_boundary_load::main+0x7be>
   2b7ea:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2b7ef:	4c 8b 78 08          	mov    0x8(%rax),%r15
   2b7f3:	49 83 c7 08          	add    $0x8,%r15
   2b7f7:	eb 10                	jmp    2b809 <ownership_boundary_load::main+0x7a9>
   2b7f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2b800:	49 83 c7 18          	add    $0x18,%r15
   2b804:	48 ff cb             	dec    %rbx
   2b807:	74 15                	je     2b81e <ownership_boundary_load::main+0x7be>
   2b809:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
   2b80d:	48 85 f6             	test   %rsi,%rsi
   2b810:	74 ee                	je     2b800 <ownership_boundary_load::main+0x7a0>
   2b812:	49 8b 3f             	mov    (%r15),%rdi
   2b815:	ba 01 00 00 00       	mov    $0x1,%edx
   2b81a:	ff d5                	call   *%rbp
   2b81c:	eb e2                	jmp    2b800 <ownership_boundary_load::main+0x7a0>
   2b81e:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   2b823:	48 8b 03             	mov    (%rbx),%rax
   2b826:	48 85 c0             	test   %rax,%rax
   2b829:	74 17                	je     2b842 <ownership_boundary_load::main+0x7e2>
   2b82b:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
   2b82f:	48 c1 e0 03          	shl    $0x3,%rax
   2b833:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   2b837:	ba 08 00 00 00       	mov    $0x8,%edx
   2b83c:	ff 15 fe 9d 04 00    	call   *0x49dfe(%rip)        # 75640 <_DYNAMIC+0x2a8>
   2b842:	be 18 00 00 00       	mov    $0x18,%esi
   2b847:	ba 08 00 00 00       	mov    $0x8,%edx
   2b84c:	48 89 df             	mov    %rbx,%rdi
   2b84f:	ff 15 eb 9d 04 00    	call   *0x49deb(%rip)        # 75640 <_DYNAMIC+0x2a8>
   2b855:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
   2b85a:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
   2b861:	00 
   2b862:	4d 85 ff             	test   %r15,%r15
   2b865:	74 27                	je     2b88e <ownership_boundary_load::main+0x82e>
   2b867:	4c 8d 73 08          	lea    0x8(%rbx),%r14
   2b86b:	eb 0c                	jmp    2b879 <ownership_boundary_load::main+0x819>
   2b86d:	0f 1f 00             	nopl   (%rax)
   2b870:	49 83 c6 18          	add    $0x18,%r14
   2b874:	49 ff cf             	dec    %r15
   2b877:	74 15                	je     2b88e <ownership_boundary_load::main+0x82e>
   2b879:	49 8b 76 f8          	mov    -0x8(%r14),%rsi
   2b87d:	48 85 f6             	test   %rsi,%rsi
   2b880:	74 ee                	je     2b870 <ownership_boundary_load::main+0x810>
   2b882:	49 8b 3e             	mov    (%r14),%rdi
   2b885:	ba 01 00 00 00       	mov    $0x1,%edx
   2b88a:	ff d5                	call   *%rbp
   2b88c:	eb e2                	jmp    2b870 <ownership_boundary_load::main+0x810>
   2b88e:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   2b893:	48 85 c0             	test   %rax,%rax
   2b896:	74 16                	je     2b8ae <ownership_boundary_load::main+0x84e>
   2b898:	48 c1 e0 03          	shl    $0x3,%rax
   2b89c:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   2b8a0:	ba 08 00 00 00       	mov    $0x8,%edx
   2b8a5:	48 89 df             	mov    %rbx,%rdi
   2b8a8:	ff 15 92 9d 04 00    	call   *0x49d92(%rip)        # 75640 <_DYNAMIC+0x2a8>
   2b8ae:	4c 89 e8             	mov    %r13,%rax
   2b8b1:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
   2b8b8:	5b                   	pop    %rbx
   2b8b9:	41 5c                	pop    %r12
   2b8bb:	41 5d                	pop    %r13
   2b8bd:	41 5e                	pop    %r14
   2b8bf:	41 5f                	pop    %r15
   2b8c1:	5d                   	pop    %rbp
   2b8c2:	c3                   	ret
   2b8c3:	80 c2 d0             	add    $0xd0,%dl
   2b8c6:	31 c0                	xor    %eax,%eax
   2b8c8:	80 fa 0a             	cmp    $0xa,%dl
   2b8cb:	14 01                	adc    $0x1,%al
   2b8cd:	88 44 24 30          	mov    %al,0x30(%rsp)
   2b8d1:	48 8d 3d 7d ae fe ff 	lea    -0x15183(%rip),%rdi        # 16755 <anon.c4814cb828c81191db59c5e81b199b19.6.llvm.8547334867598140981+0x3c01>
   2b8d8:	48 8d 0d 99 74 04 00 	lea    0x47499(%rip),%rcx        # 72d78 <anon.c4814cb828c81191db59c5e81b199b19.7.llvm.8547334867598140981+0x9e0>
   2b8df:	4c 8d 05 62 74 04 00 	lea    0x47462(%rip),%r8        # 72d48 <anon.c4814cb828c81191db59c5e81b199b19.7.llvm.8547334867598140981+0x9b0>
   2b8e6:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   2b8eb:	be 2b 00 00 00       	mov    $0x2b,%esi
   2b8f0:	ff 15 4a 9e 04 00    	call   *0x49e4a(%rip)        # 75740 <_DYNAMIC+0x3a8>
   2b8f6:	eb 63                	jmp    2b95b <ownership_boundary_load::main+0x8fb>
   2b8f8:	48 8d 3d 91 78 fe ff 	lea    -0x1876f(%rip),%rdi        # 13190 <anon.c4814cb828c81191db59c5e81b199b19.6.llvm.8547334867598140981+0x63c>
   2b8ff:	48 8d 15 5a 74 04 00 	lea    0x4745a(%rip),%rdx        # 72d60 <anon.c4814cb828c81191db59c5e81b199b19.7.llvm.8547334867598140981+0x9c8>
   2b906:	be 21 00 00 00       	mov    $0x21,%esi
   2b90b:	ff 15 37 9e 04 00    	call   *0x49e37(%rip)        # 75748 <_DYNAMIC+0x3b0>
   2b911:	eb 48                	jmp    2b95b <ownership_boundary_load::main+0x8fb>
   2b913:	bf 08 00 00 00       	mov    $0x8,%edi
   2b918:	be 18 00 00 00       	mov    $0x18,%esi
   2b91d:	ff 15 2d 9e 04 00    	call   *0x49e2d(%rip)        # 75750 <_DYNAMIC+0x3b8>
   2b923:	eb 36                	jmp    2b95b <ownership_boundary_load::main+0x8fb>
   2b925:	b0 01                	mov    $0x1,%al
   2b927:	eb a4                	jmp    2b8cd <ownership_boundary_load::main+0x86d>
   2b929:	48 8d 15 e8 73 04 00 	lea    0x473e8(%rip),%rdx        # 72d18 <anon.c4814cb828c81191db59c5e81b199b19.7.llvm.8547334867598140981+0x980>
   2b930:	bf 01 00 00 00       	mov    $0x1,%edi
   2b935:	eb 0c                	jmp    2b943 <ownership_boundary_load::main+0x8e3>
   2b937:	48 8d 15 f2 73 04 00 	lea    0x473f2(%rip),%rdx        # 72d30 <anon.c4814cb828c81191db59c5e81b199b19.7.llvm.8547334867598140981+0x998>
   2b93e:	bf 02 00 00 00       	mov    $0x2,%edi
   2b943:	ff 15 0f 9e 04 00    	call   *0x49e0f(%rip)        # 75758 <_DYNAMIC+0x3c0>
   2b949:	eb 10                	jmp    2b95b <ownership_boundary_load::main+0x8fb>
   2b94b:	bf 01 00 00 00       	mov    $0x1,%edi
   2b950:	be 20 00 00 00       	mov    $0x20,%esi
   2b955:	ff 15 ed 9c 04 00    	call   *0x49ced(%rip)        # 75648 <_DYNAMIC+0x2b0>
   2b95b:	0f 0b                	ud2
   2b95d:	31 c0                	xor    %eax,%eax
   2b95f:	e9 69 ff ff ff       	jmp    2b8cd <ownership_boundary_load::main+0x86d>
   2b964:	48 89 c3             	mov    %rax,%rbx
   2b967:	eb 13                	jmp    2b97c <ownership_boundary_load::main+0x91c>
   2b969:	48 89 c3             	mov    %rax,%rbx
   2b96c:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   2b971:	f0 48 ff 0f          	lock decq (%rdi)
   2b975:	75 05                	jne    2b97c <ownership_boundary_load::main+0x91c>
   2b977:	e8 d4 cb ff ff       	call   28550 <triomphe::arc::Arc<T>::drop_slow>
   2b97c:	f0 48 ff 4d 00       	lock decq 0x0(%rbp)
   2b981:	75 31                	jne    2b9b4 <ownership_boundary_load::main+0x954>
   2b983:	48 89 ef             	mov    %rbp,%rdi
   2b986:	e8 c5 cb ff ff       	call   28550 <triomphe::arc::Arc<T>::drop_slow>
   2b98b:	eb 27                	jmp    2b9b4 <ownership_boundary_load::main+0x954>
   2b98d:	eb 22                	jmp    2b9b1 <ownership_boundary_load::main+0x951>
   2b98f:	48 89 c3             	mov    %rax,%rbx
   2b992:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   2b999:	00 
   2b99a:	e8 51 00 00 00       	call   2b9f0 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::string::String>>>
   2b99f:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   2b9a4:	e8 47 00 00 00       	call   2b9f0 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::string::String>>>
   2b9a9:	48 89 df             	mov    %rbx,%rdi
   2b9ac:	e8 9f 59 04 00       	call   71350 <_Unwind_Resume@plt>
   2b9b1:	48 89 c3             	mov    %rax,%rbx
   2b9b4:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2b9b9:	e8 c2 00 00 00       	call   2ba80 <core::ptr::drop_in_place<alloc::boxed::Box<alloc::vec::Vec<alloc::string::String>>>>
   2b9be:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   2b9c3:	e8 28 00 00 00       	call   2b9f0 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::string::String>>>
   2b9c8:	48 89 df             	mov    %rbx,%rdi
   2b9cb:	e8 80 59 04 00       	call   71350 <_Unwind_Resume@plt>
   2b9d0:	48 89 c3             	mov    %rax,%rbx
   2b9d3:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   2b9d8:	e8 13 00 00 00       	call   2b9f0 <core::ptr::drop_in_place<alloc::vec::Vec<alloc::string::String>>>
   2b9dd:	48 89 df             	mov    %rbx,%rdi
   2b9e0:	e8 6b 59 04 00       	call   71350 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
