//! Actual owner/clone code under a refusing allocator model. Single-threaded.
use super::*;
use std::alloc::{GlobalAlloc, Layout, System};
use std::cell::Cell;

static mut CALLS: usize = 0;
static mut DENY_FROM: usize = usize::MAX;
static mut LIVE: isize = 0;

fn denied() -> bool {
    // Harnesses run in separate verifier executions, without threads.
    unsafe {
        let call = CALLS;
        CALLS += 1;
        call >= DENY_FROM
    }
}
fn refuse_from(position: usize) {
    unsafe {
        CALLS = 0;
        DENY_FROM = position;
    }
}
fn live() -> isize {
    unsafe { LIVE }
}
fn calls() -> usize {
    unsafe { CALLS }
}
unsafe fn model_alloc(layout: Layout) -> *mut u8 {
    if denied() {
        return std::ptr::null_mut();
    }
    let result = unsafe { System.alloc(layout) };
    if !result.is_null() {
        unsafe {
            LIVE += layout.size() as isize;
        }
    }
    result
}
unsafe fn model_zeroed(layout: Layout) -> *mut u8 {
    if denied() {
        return std::ptr::null_mut();
    }
    let result = unsafe { System.alloc_zeroed(layout) };
    if !result.is_null() {
        unsafe {
            LIVE += layout.size() as isize;
        }
    }
    result
}
unsafe fn model_realloc(ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
    if denied() {
        return std::ptr::null_mut();
    }
    let result = unsafe { System.realloc(ptr, layout, size) };
    if !result.is_null() {
        unsafe {
            LIVE += size as isize - layout.size() as isize;
        }
    }
    result
}
unsafe fn model_global_dealloc(_: &std::alloc::Global, ptr: std::ptr::NonNull<u8>, layout: Layout) {
    if layout.size() != 0 { unsafe { model_dealloc(ptr.as_ptr(), layout) } }
}
unsafe fn model_dealloc(ptr: *mut u8, layout: Layout) {
    unsafe {
        LIVE -= layout.size() as isize;
        System.dealloc(ptr, layout);
    }
}

// The contract ends at returning the error to the caller. All errors used
// here carry no heap resource; do not unfold the unrelated recursive Error
// drop graph in every harness. Payload owners are always actually dropped.
fn returned<T>(result: Result<T>) -> Option<T> {
    match result {
        Ok(value) => Some(value),
        Err(error) => {
            assert!(
                matches!(
                    &error,
                    Error::AllocationFailed { .. } | Error::InvalidMatrixLayout
                ) || matches!(&error, Error::Io(e) if e.kind() == std::io::ErrorKind::OutOfMemory)
            );
            std::mem::forget(error);
            None
        }
    }
}

struct Counted<'a> {
    value: u8,
    drops: &'a Cell<usize>,
}
impl Drop for Counted<'_> {
    fn drop(&mut self) {
        self.drops.set(self.drops.get() + 1);
    }
}

#[kani::proof]
#[kani::unwind(8)]
#[kani::stub(std::alloc::alloc, model_alloc)]
#[kani::stub(std::alloc::alloc_zeroed, model_zeroed)]
#[kani::stub(std::alloc::realloc, model_realloc)]
#[kani::stub(std::alloc::dealloc, model_dealloc)]
#[kani::stub(<std::alloc::Global as std::alloc::Allocator>::deallocate, model_global_dealloc)]
fn box_value_refusal_or_unique_ownership() {
    let drops = Cell::new(0);
    let value: u8 = kani::any();
    let refuse: bool = kani::any();
    refuse_from(if refuse { 0 } else { usize::MAX });
    let result = try_box(Counted {
        value,
        drops: &drops,
    });
    assert_eq!(result.is_ok(), !refuse, "box allocation refusal lost");
    if let Some(owner) = returned(result) {
        assert_eq!(owner.value, value);
        assert_eq!(drops.get(), 0);
        drop(owner);
    }
    assert_eq!(drops.get(), 1, "owned value was not dropped exactly once");
    assert_eq!(live(), 0, "box storage leaked");
}

#[kani::proof]
#[kani::unwind(8)]
#[kani::stub(std::alloc::alloc, model_alloc)]
#[kani::stub(std::alloc::alloc_zeroed, model_zeroed)]
#[kani::stub(std::alloc::realloc, model_realloc)]
#[kani::stub(std::alloc::dealloc, model_dealloc)]
#[kani::stub(<std::alloc::Global as std::alloc::Allocator>::deallocate, model_global_dealloc)]
fn box_initializer_runs_only_after_reservation() {
    let refuse: bool = kani::any();
    let init_error: bool = kani::any();
    let value: u8 = kani::any();
    let runs = Cell::new(0);
    let drops = Cell::new(0);
    refuse_from(if refuse { 0 } else { usize::MAX });
    let result = try_box_with(|| {
        runs.set(runs.get() + 1);
        if init_error {
            return Err(Error::InvalidMatrixLayout);
        }
        Ok(Counted {
            value,
            drops: &drops,
        })
    });
    assert_eq!(
        runs.get(),
        usize::from(!refuse),
        "initializer ran without reserved storage"
    );
    assert_eq!(
        result.is_ok(),
        !refuse && !init_error,
        "box initializer result lost"
    );
    if !refuse && init_error {
        assert!(matches!(result, Err(Error::InvalidMatrixLayout)));
    }
    drop(returned(result));
    assert_eq!(drops.get(), usize::from(!refuse && !init_error));
    assert_eq!(live(), 0, "failed initializer leaked storage");
}

#[kani::proof]
#[kani::unwind(8)]
#[kani::stub(std::alloc::alloc, model_alloc)]
#[kani::stub(std::alloc::alloc_zeroed, model_zeroed)]
#[kani::stub(std::alloc::realloc, model_realloc)]
#[kani::stub(std::alloc::dealloc, model_dealloc)]
#[kani::stub(<std::alloc::Global as std::alloc::Allocator>::deallocate, model_global_dealloc)]
fn uninitialized_box_alignment_and_zero_size() {
    #[repr(align(64))]
    struct Aligned([u8; 3]);
    #[repr(align(128))]
    struct Zero;
    let refuse: bool = kani::any();
    refuse_from(if refuse { 0 } else { usize::MAX });
    let result = try_box_uninit::<Aligned>();
    assert_eq!(result.is_ok(), !refuse);
    if let Some(storage) = returned(result) {
        assert_eq!((&*storage as *const _ as usize) % 64, 0);
        let owner = Box::write(storage, Aligned([7; 3]));
        assert_eq!(owner.0, [7; 3]);
    }
    assert_eq!(live(), 0);
    refuse_from(0);
    let zero = try_box_uninit::<Zero>().unwrap();
    assert_eq!((&*zero as *const _ as usize) % 128, 0);
    assert_eq!(calls(), 0, "zero-sized box attempted allocation");
    drop(zero);
}

#[kani::proof]
#[kani::unwind(5)]
#[kani::stub(std::alloc::alloc, model_alloc)]
#[kani::stub(std::alloc::alloc_zeroed, model_zeroed)]
#[kani::stub(std::alloc::realloc, model_realloc)]
#[kani::stub(std::alloc::dealloc, model_dealloc)]
#[kani::stub(<std::alloc::Global as std::alloc::Allocator>::deallocate, model_global_dealloc)]
fn byte_clone_preserves_source_on_every_refusal() {
    let data: [u8; 4] = kani::any();
    let len: usize = kani::any();
    kani::assume(len <= 4);
    let source = data[..len].to_vec();
    let baseline = live();
    let fail: usize = kani::any();
    refuse_from(fail);
    let result = source.try_clone();
    assert_eq!(
        result.is_ok(),
        len == 0 || fail > 0,
        "byte clone refusal lost"
    );
    if let Ok(copy) = &result {
        assert_eq!(copy.as_slice(), &data[..len]);
    }
    drop(returned(result));
    assert_eq!(source.as_slice(), &data[..len]);
    assert_eq!(live(), baseline, "byte clone leaked partial output");
    drop(source);
    assert_eq!(live(), 0);
}

#[kani::proof]
#[kani::unwind(5)]
#[kani::stub(std::alloc::alloc, model_alloc)]
#[kani::stub(std::alloc::alloc_zeroed, model_zeroed)]
#[kani::stub(std::alloc::realloc, model_realloc)]
#[kani::stub(std::alloc::dealloc, model_dealloc)]
#[kani::stub(<std::alloc::Global as std::alloc::Allocator>::deallocate, model_global_dealloc)]
fn nested_clone_releases_every_partial_owner() {
    struct Item<'a> {
        id: u8,
        fail_item: u8,
        cloned: bool,
        created: &'a Cell<usize>,
        destroyed: &'a Cell<usize>,
    }
    impl TryClone for Item<'_> {
        fn try_clone(&self) -> Result<Self> {
            if self.id == self.fail_item {
                return Err(Error::InvalidMatrixLayout);
            }
            self.created.set(self.created.get() + 1);
            Ok(Self {
                cloned: true,
                ..*self
            })
        }
    }
    impl Drop for Item<'_> {
        fn drop(&mut self) {
            if self.cloned {
                self.destroyed.set(self.destroyed.get() + 1);
            }
        }
    }
    let len: usize = kani::any();
    kani::assume(len <= 3);
    let fail_item: u8 = kani::any();
    let created = Cell::new(0);
    let destroyed = Cell::new(0);
    let mut source = Vec::new();
    for id in 0..len {
        source.push(Box::new(Item {
            id: id as u8,
            fail_item,
            cloned: false,
            created: &created,
            destroyed: &destroyed,
        }));
    }
    let baseline = live();
    let fail: usize = kani::any();
    refuse_from(fail);
    let result = source.try_clone();
    assert_eq!(
        result.is_ok(),
        (len == 0 || fail > len) && usize::from(fail_item) >= len,
        "nested clone success/refusal contract lost"
    );
    if let Some(copy) = returned(result) {
        assert_eq!(copy.len(), len);
        for (i, item) in copy.iter().enumerate() {
            assert_eq!(item.id, i as u8);
        }
        drop(copy);
    }
    assert_eq!(
        created.get(),
        destroyed.get(),
        "partial clone payload leaked"
    );
    assert_eq!(live(), baseline, "partial clone storage leaked");
    for (i, item) in source.iter().enumerate() {
        assert_eq!(item.id, i as u8);
        assert!(!item.cloned);
    }
    drop(source);
    assert_eq!(live(), 0);
}
