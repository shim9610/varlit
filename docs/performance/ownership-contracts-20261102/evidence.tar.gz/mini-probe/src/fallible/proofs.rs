//! Actual owner/clone code under a refusing allocator model. Single-threaded.
use super::*;
use std::alloc::{GlobalAlloc, Layout, System};
use std::cell::Cell;

static mut CALLS: usize = 0;
static mut DENY_FROM: usize = usize::MAX;
static mut LIVE: isize = 0;

fn denied() -> bool {
    // Harnesses run in separate verifier executions, without threads.
    unsafe {
        let call = CALLS;
        CALLS += 1;
        call >= DENY_FROM
    }
}
fn refuse_from(position: usize) {
    unsafe {
        CALLS = 0;
        DENY_FROM = position;
    }
}
fn live() -> isize {
    unsafe { LIVE }
}
fn calls() -> usize {
    unsafe { CALLS }
}
unsafe fn model_alloc(layout: Layout) -> *mut u8 {
    if denied() {
        return std::ptr::null_mut();
    }
    let result = unsafe { System.alloc(layout) };
    if !result.is_null() {
        unsafe {
            LIVE += layout.size() as isize;
        }
    }
    result
}
unsafe fn model_zeroed(layout: Layout) -> *mut u8 {
    if denied() {
        return std::ptr::null_mut();
    }
    let result = unsafe { System.alloc_zeroed(layout) };
    if !result.is_null() {
        unsafe {
            LIVE += layout.size() as isize;
        }
    }
    result
}
unsafe fn model_realloc(ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
    if denied() {
        return std::ptr::null_mut();
    }
    let result = unsafe { System.realloc(ptr, layout, size) };
    if !result.is_null() {
        unsafe {
            LIVE += size as isize - layout.size() as isize;
        }
    }
    result
}
unsafe fn model_global_grow(
    _: &std::alloc::Global, ptr: std::ptr::NonNull<u8>, old: Layout, new: Layout,
) -> std::result::Result<std::ptr::NonNull<[u8]>, std::alloc::AllocError> {
    assert_eq!(old.align(), new.align());
    let raw = if old.size() == 0 { unsafe { model_alloc(new) } }
        else { unsafe { model_realloc(ptr.as_ptr(), old, new.size()) } };
    let pointer = std::ptr::NonNull::new(raw).ok_or(std::alloc::AllocError)?;
    Ok(std::ptr::NonNull::slice_from_raw_parts(pointer, new.size()))
}
unsafe fn model_global_dealloc(_: &std::alloc::Global, ptr: std::ptr::NonNull<u8>, layout: Layout) {
    if layout.size() != 0 {
        unsafe { model_dealloc(ptr.as_ptr(), layout) }
    }
}
unsafe fn model_dealloc(ptr: *mut u8, layout: Layout) {
    unsafe {
        LIVE -= layout.size() as isize;
        System.dealloc(ptr, layout);
    }
}

// The contract ends at returning the error to the caller. All errors used
// here carry no heap resource; do not unfold the unrelated recursive Error
// drop graph in every harness. Payload owners are always actually dropped.
fn returned<T>(result: Result<T>) -> Option<T> {
    match result {
        Ok(value) => Some(value),
        Err(error) => {
            assert!(
                matches!(
                    &error,
                    Error::AllocationFailed { .. } | Error::InvalidMatrixLayout
                ) || matches!(&error, Error::Io(e) if e.kind() == std::io::ErrorKind::OutOfMemory)
            );
            std::mem::forget(error);
            None
        }
    }
}

struct Counted<'a> {
    value: u8,
    drops: &'a Cell<usize>,
}
impl Drop for Counted<'_> {
    fn drop(&mut self) {
        self.drops.set(self.drops.get() + 1);
    }
}

#[kani::proof]
#[kani::unwind(5)]
#[kani::stub(std::alloc::alloc, model_alloc)]
fn probe_cow_only_allocation_stub() {
    let mut value = try_arc(vec![1u8,2,3]).unwrap();
    let other = value.clone();
    let fail: usize = kani::any(); refuse_from(fail);
    let result = try_make_mut(&mut value);
    assert_eq!(result.is_ok(), fail >= 2, "allocation-only COW outcome");
    if let Some(v) = returned(result) { v[0] = 9; }
    assert_eq!(other.as_slice(), &[1,2,3]);
}
