#![cfg_attr(kani, feature(allocator_api))]
#[derive(Debug)] pub enum Error { AllocationFailed { resource: &'static str, requested: u64 }, InvalidMatrixLayout, Io(std::io::Error) }
impl From<std::io::Error> for Error { fn from(e: std::io::Error) -> Self { Self::Io(e) } }
pub type Result<T> = std::result::Result<T, Error>;
mod fallible;
