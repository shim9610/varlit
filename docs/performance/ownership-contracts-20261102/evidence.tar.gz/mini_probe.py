from pathlib import Path
import subprocess, os
root=Path('/workspace/scratch/ownership-contracts/mini-probe');(root/'src/fallible').mkdir(parents=True,exist_ok=True)
(root/'Cargo.toml').write_text('[package]\nname="ownership-mini-probe"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\ntriomphe={version="=0.1.17",default-features=false,features=["std"]}\n[lints.rust]\nunexpected_cfgs={level="warn",check-cfg=["cfg(kani)"]}\n')
(root/'src/lib.rs').write_text('''#![cfg_attr(kani, feature(allocator_api))]
#[derive(Debug)] pub enum Error { AllocationFailed { resource: &'static str, requested: u64 }, InvalidMatrixLayout, Io(std::io::Error) }
impl From<std::io::Error> for Error { fn from(e: std::io::Error) -> Self { Self::Io(e) } }
pub type Result<T> = std::result::Result<T, Error>;
mod fallible;
''')
s=Path('/workspace/varlit/crates/varlit-core/src/fallible.rs').read_text().split('#[cfg(test)]',1)[0]+'\n#[cfg(kani)] mod proofs;\n';(root/'src/fallible.rs').write_text(s)
(root/'src/fallible/proofs.rs').write_bytes(Path('/workspace/varlit/crates/varlit-core/src/fallible/proofs.rs').read_bytes())
env={**os.environ,'CARGO_TARGET_DIR':'/workspace/scratch/ownership-contracts/mini-target'}
raise SystemExit(subprocess.run(['cargo','kani','--manifest-path',str(root/'Cargo.toml'),'-Z','stubbing','-Z','unstable-options','--harness-timeout','300','--harness','copy_on_write_refusal'],env=env).returncode)
