set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
out=/workspace/scratch/ownership-contracts
export CARGO_TARGET_DIR=/workspace/scratch/fallible-ownership/target-kani
cargo kani -p varlit-core --all-features --default-unwind 5 -Z stubbing -Z unstable-options --harness-timeout 300 > "$out/kani-all-final.log" 2>&1
python3 scripts/check_proof_contracts.py --source-before "$out/source-before.json" --log "$out/kani-all-final.log" --features all --output "$out/kani-all-contracts.json"
python3 scripts/check_ownership_mutations.py --output "$out/ownership-mutations" > "$out/ownership-mutations.log" 2>&1
python3 scripts/check_resource_mutations.py --output "$out/resource-mutations" > "$out/resource-mutations.log" 2>&1
python3 scripts/check_publication_protocol.py --output "$out/protocol-mutations" > "$out/protocol-mutations.log" 2>&1
export CARGO_TARGET_DIR=/workspace/scratch/fallible-ownership/target-after
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
python3 scripts/check_storage_contracts.py --output "$out/storage-contracts" > "$out/storage-contracts.log" 2>&1
CARGO_TARGET_DIR=/workspace/scratch/fallible-ownership/target-models RUSTFLAGS='--cfg varlit_loom -D warnings' cargo run --locked --manifest-path tools/verification/Cargo.toml > "$out/loom-final.log" 2>&1
printf 'FINAL_QUALIFICATION_COMPLETE\n'
