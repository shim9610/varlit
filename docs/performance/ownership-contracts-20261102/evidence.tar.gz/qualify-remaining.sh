set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
out=/workspace/scratch/ownership-contracts
export CARGO_TARGET_DIR=/workspace/scratch/fallible-ownership/target-kani
python3 scripts/check_ownership_mutations.py --output "$out/ownership-mutations-final" > "$out/ownership-mutations-final.log" 2>&1
python3 scripts/check_resource_mutations.py --output "$out/resource-mutations" > "$out/resource-mutations.log" 2>&1
python3 scripts/check_publication_protocol.py --output "$out/protocol-mutations" > "$out/protocol-mutations.log" 2>&1
export CARGO_TARGET_DIR=/workspace/scratch/fallible-ownership/target-after
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
python3 scripts/check_storage_contracts.py --output "$out/storage-contracts" > "$out/storage-contracts.log" 2>&1
CARGO_TARGET_DIR=/workspace/scratch/fallible-ownership/target-models RUSTFLAGS='--cfg varlit_loom -D warnings' cargo run --locked --manifest-path tools/verification/Cargo.toml > "$out/loom-final.log" 2>&1
printf 'FINAL_QUALIFICATION_COMPLETE\n'
