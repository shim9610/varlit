import json,subprocess
from pathlib import Path
root=Path('/workspace/scratch/ownership-contracts/mini-target/kani')
maps=list(root.rglob('*probe_cow_only_allocation_stub.pretty_name_map.json'))
p=max(maps,key=lambda p:p.stat().st_mtime)
m=json.loads(p.read_text()); symbols=[k for k,v in m.items() if v=='fallible::proofs::probe_cow_only_allocation_stub'];print(symbols,flush=True)
goto=str(p).replace('.pretty_name_map.json','.out')
cmd=['/home/agent/.kani/kani-0.68.0/bin/cbmc',goto,'--no-malloc-may-fail','--no-undefined-shift-check','--no-signed-overflow-check','--nan-check','--no-self-loops-to-assumptions','--no-pointer-primitive-check','--object-bits','16','--unwind','5','--sat-solver','cadical','--property','fallible::proofs::probe_cow_only_allocation_stub.assertion.1','--trace','--json-ui']
out=Path('/workspace/scratch/ownership-contracts/cow-trace-full.json')
with out.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=300)
print('exit',r.returncode,flush=True)
for item in json.loads(out.read_text()):
 for prop in item.get('result',[]):
  print(prop.get('description'),prop.get('status'))
  for s in prop.get('trace',[]):
   name=s.get('lhs','')
   if any(x in name for x in ['shared','fail','CALLS','DENY','result','old_size']):
    print(name,s.get('value',{}).get('data'))
