import json,os,shutil,subprocess,sys,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/varlit/tools/storage-bench')
import run as bench, compare_read_validation as original
r=Path('/workspace/scratch/read-validation-20261104');out=r/'rebuild-check';out.mkdir()
cpus=sorted(os.sched_getaffinity(0))[:4];os.sched_setaffinity(0,cpus)
assert int(Path('/sys/fs/cgroup/memory.max').read_text())<=16*2**30
q,p=Path('/sys/fs/cgroup/cpu.max').read_text().split();assert int(q)<=4*int(p)
subprocess.run(['cc','-O2',str(bench.HERE/'measure.c'),'-o',str(out/'measure')],check=True)
new=r/'binaries/final';new.mkdir(exist_ok=True)
for kind in ['mixed','arrays']:shutil.copy2(bench.HERE/'target/release'/kind,new/kind)
profiles=[]
for case in original.cases():
 if case['name'] != 'grouped-n8388608-g512-t131072-w4-r8-varlit-indexed' and not case['name'].startswith('array-native-owned-'):continue
 for variant,folder,policy in [('before-a',r/'binaries/after','legacy'),('after-default',new,'legacy'),('full',new,'full'),('crc-only',new,'crc-only'),('structure-only',new,'structure-only'),('trusted',new,'trusted'),('before-b',r/'binaries/after','legacy')]:
  profiles.append(dict(case,name=case['name']+'--'+variant,workload=case['name'],variant=variant,read_validation=policy,binary_override=str(folder/('mixed' if case['kind']=='mixed' else 'arrays'))))
bench.save(out/'manifest.json',dict(profiles=profiles,smoke=False,repetitions=3,affinity=cpus,
 scope='Private helper identifier-only rebuild check. Before slots use the exact primary AFTER binary; not the pre-change PR baseline. Separate cohort, never pooled.',
 binaries={p['binary_override']:hashlib.sha256(Path(p['binary_override']).read_bytes()).hexdigest() for p in profiles},resource_caps=dict(cpu=4,memory_gib=16,disk_gib=32)))
(out/'memory-before.txt').write_text(Path('/sys/fs/cgroup/memory.events').read_text())
phases=[]
for p in profiles:
 if p['kind']=='mixed':phases.append((p,'gate-'+p['name'],False,True))
for rep in range(3):
 for p in profiles if rep%2==0 else reversed(profiles):phases.append((p,f'timing-{rep}-'+p['name'],False,False))
for p in profiles:phases.append((p,'probe-'+p['name'],True,False))
for p,stem,probe,gate in phases:
 assert shutil.disk_usage(out).free>=3*2**30
 row=bench.invoke(p,out,stem,probe=probe,gate=gate)
 with (out/'results.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 print(stem,row.get('error','OK'),flush=True)
 if row.get('error'):raise SystemExit('failure retained')
(out/'memory-after.txt').write_text(Path('/sys/fs/cgroup/memory.events').read_text())
