# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--before-a | 3 | 0.153526 | 0.216863 | 0.294600 | 76.25 | 130.00 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--after-default | 3 | 0.159176 | 0.192820 | 0.262506 | 76.27 | 130.00 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--full | 3 | 0.152826 | 0.190469 | 0.261610 | 76.36 | 130.00 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--crc-only | 3 | 0.150141 | 0.186753 | 0.266982 | 76.20 | 130.00 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--structure-only | 3 | 0.148029 | 0.179004 | 0.252485 | 76.33 | 130.00 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--trusted | 3 | 0.145839 | 0.175813 | 0.249144 | 76.23 | 130.00 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--before-b | 3 | 0.156651 | 0.228076 | 0.311973 | 76.41 | 130.00 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--pre-security | 3 | 0.144441 | 0.174873 | 0.246122 | 76.25 | 130.00 |
| grouped-n8388608-g512-t131072-w1-r8-varlit-indexed--before-a | 3 | 2.216832 | 3.517239 | 13.545449 | 77.28 | 1102.04 |
| grouped-n8388608-g512-t131072-w1-r8-varlit-indexed--after-default | 3 | 2.245185 | 2.981826 | 11.055552 | 77.36 | 1102.04 |
| grouped-n8388608-g512-t131072-w1-r8-varlit-indexed--full | 3 | 2.133465 | 2.666258 | 10.131839 | 77.36 | 1102.04 |
| grouped-n8388608-g512-t131072-w1-r8-varlit-indexed--crc-only | 3 | 2.336915 | 2.853215 | 10.860503 | 77.39 | 1102.04 |
| grouped-n8388608-g512-t131072-w1-r8-varlit-indexed--structure-only | 3 | 2.203759 | 2.654834 | 10.072778 | 77.34 | 1102.04 |
| grouped-n8388608-g512-t131072-w1-r8-varlit-indexed--trusted | 3 | 2.151683 | 2.535078 | 9.488721 | 77.33 | 1102.04 |
| grouped-n8388608-g512-t131072-w1-r8-varlit-indexed--before-b | 3 | 2.015203 | 3.297012 | 12.502556 | 77.38 | 1102.04 |
| grouped-n8388608-g512-t131072-w1-r8-varlit-indexed--pre-security | 3 | 2.125255 | 2.621096 | 9.997721 | 81.30 | 1102.04 |
| grouped-n8388608-g512-t131072-w4-r8-varlit-indexed--before-a | 3 | 2.147346 | 3.450808 | 13.239782 | 141.27 | 1101.11 |
| grouped-n8388608-g512-t131072-w4-r8-varlit-indexed--after-default | 3 | 2.432431 | 2.748052 | 10.510538 | 141.44 | 1102.05 |
| grouped-n8388608-g512-t131072-w4-r8-varlit-indexed--full | 3 | 2.395502 | 3.091632 | 11.791912 | 141.09 | 1101.89 |
| grouped-n8388608-g512-t131072-w4-r8-varlit-indexed--crc-only | 3 | 2.606697 | 2.926248 | 11.221579 | 141.32 | 1101.20 |
| grouped-n8388608-g512-t131072-w4-r8-varlit-indexed--structure-only | 3 | 2.540590 | 3.240148 | 11.801522 | 141.27 | 1102.90 |
| grouped-n8388608-g512-t131072-w4-r8-varlit-indexed--trusted | 3 | 2.670136 | 2.768522 | 10.702221 | 141.31 | 1101.16 |
| grouped-n8388608-g512-t131072-w4-r8-varlit-indexed--before-b | 3 | 2.169000 | 3.565256 | 13.424892 | 156.37 | 1101.89 |
| grouped-n8388608-g512-t131072-w4-r8-varlit-indexed--pre-security | 3 | 2.194744 | 2.792053 | 10.364717 | 142.19 | 1101.24 |
| grouped-n8388608-g8192-t131072-w4-r8-varlit-indexed--before-a | 3 | 1.772206 | 4.820895 | 18.847039 | 146.69 | 1026.18 |
| grouped-n8388608-g8192-t131072-w4-r8-varlit-indexed--after-default | 3 | 1.713859 | 3.951569 | 15.126772 | 146.80 | 1026.23 |
| grouped-n8388608-g8192-t131072-w4-r8-varlit-indexed--full | 3 | 1.696416 | 3.789352 | 14.631950 | 146.78 | 1026.18 |
| grouped-n8388608-g8192-t131072-w4-r8-varlit-indexed--crc-only | 3 | 1.774779 | 3.864578 | 14.845229 | 146.77 | 1026.18 |
| grouped-n8388608-g8192-t131072-w4-r8-varlit-indexed--structure-only | 3 | 1.650321 | 4.029267 | 15.561644 | 146.70 | 1026.29 |
| grouped-n8388608-g8192-t131072-w4-r8-varlit-indexed--trusted | 3 | 1.788651 | 4.209413 | 15.965745 | 146.71 | 1026.17 |
| grouped-n8388608-g8192-t131072-w4-r8-varlit-indexed--before-b | 3 | 1.778334 | 5.211997 | 20.051127 | 146.72 | 1026.18 |
| grouped-n8388608-g8192-t131072-w4-r8-varlit-indexed--pre-security | 3 | 1.722213 | 4.205598 | 15.858666 | 146.74 | 1026.18 |
| grouped-follow-n8388608-g512-t131072-w4-r8-varlit-stream--before-a | 3 | 1.571401 | 1.611016 | 4.988883 | 140.19 | 1026.52 |
| grouped-follow-n8388608-g512-t131072-w4-r8-varlit-stream--after-default | 3 | 1.555510 | 1.584778 | 4.953608 | 140.18 | 1026.52 |
| grouped-follow-n8388608-g512-t131072-w4-r8-varlit-stream--full | 3 | 1.723314 | 1.788063 | 5.736419 | 140.13 | 1026.52 |
| grouped-follow-n8388608-g512-t131072-w4-r8-varlit-stream--crc-only | 3 | 1.457427 | 1.500308 | 4.609881 | 140.12 | 1026.52 |
| grouped-follow-n8388608-g512-t131072-w4-r8-varlit-stream--structure-only | 3 | 1.500513 | 1.540905 | 4.688999 | 140.32 | 1026.52 |
| grouped-follow-n8388608-g512-t131072-w4-r8-varlit-stream--trusted | 3 | 1.506750 | 1.550037 | 4.657968 | 140.09 | 1026.52 |
| grouped-follow-n8388608-g512-t131072-w4-r8-varlit-stream--before-b | 3 | 1.519458 | 1.561420 | 4.864698 | 140.10 | 1026.52 |
| grouped-follow-n8388608-g512-t131072-w4-r8-varlit-stream--pre-security | 3 | 1.607015 | 1.650658 | 5.149134 | 156.09 | 1026.52 |
| mixed-variable-p65536-w4-r8-varlit-indexed--before-a | 3 | 1.432755 | 2.057446 | 7.580153 | 109.64 | 795.68 |
| mixed-variable-p65536-w4-r8-varlit-indexed--after-default | 3 | 1.476701 | 2.017616 | 7.550169 | 108.71 | 794.11 |
| mixed-variable-p65536-w4-r8-varlit-indexed--full | 3 | 1.524848 | 1.914288 | 7.240987 | 120.11 | 794.68 |
| mixed-variable-p65536-w4-r8-varlit-indexed--crc-only | 3 | 1.554843 | 2.044230 | 7.461378 | 112.27 | 794.70 |
| mixed-variable-p65536-w4-r8-varlit-indexed--structure-only | 3 | 1.597078 | 1.973682 | 7.528475 | 108.76 | 794.45 |
| mixed-variable-p65536-w4-r8-varlit-indexed--trusted | 3 | 1.551763 | 1.915716 | 7.181314 | 108.52 | 794.41 |
| mixed-variable-p65536-w4-r8-varlit-indexed--before-b | 3 | 1.598922 | 2.129233 | 8.027287 | 112.22 | 794.62 |
| mixed-variable-p65536-w4-r8-varlit-indexed--pre-security | 3 | 1.480356 | 2.077964 | 7.866274 | 117.39 | 794.39 |
| array-native-owned-n1073741824-g1048576--before-a | 3 | 0.813116 | 1.713077 | 1.233167 | 25.29 | 1024.12 |
| array-native-owned-n1073741824-g1048576--after-default | 3 | 0.843989 | 1.715361 | 1.210273 | 25.30 | 1024.12 |
| array-native-owned-n1073741824-g1048576--full | 3 | 0.886583 | 1.752309 | 1.267503 | 25.30 | 1024.12 |
| array-native-owned-n1073741824-g1048576--crc-only | 3 | 0.898114 | 1.762075 | 1.267285 | 25.30 | 1024.12 |
| array-native-owned-n1073741824-g1048576--structure-only | 3 | 0.851114 | 1.560351 | 1.076723 | 25.30 | 1024.12 |
| array-native-owned-n1073741824-g1048576--trusted | 3 | 0.826595 | 1.537144 | 1.063383 | 25.29 | 1024.12 |
| array-native-owned-n1073741824-g1048576--before-b | 3 | 0.820041 | 1.711221 | 1.216809 | 25.36 | 1024.12 |
| array-native-mmap-n1073741824-g1048576--before-a | 3 | 0.845786 | 1.216762 | 0.710308 | 1036.38 | 1024.12 |
| array-native-mmap-n1073741824-g1048576--after-default | 3 | 0.818939 | 1.168482 | 0.668928 | 1036.51 | 1024.12 |
| array-native-mmap-n1073741824-g1048576--full | 3 | 0.805035 | 1.155584 | 0.684194 | 1036.40 | 1024.12 |
| array-native-mmap-n1073741824-g1048576--crc-only | 3 | 0.829485 | 1.164539 | 0.678732 | 1036.36 | 1024.12 |
| array-native-mmap-n1073741824-g1048576--structure-only | 3 | 0.853512 | 1.183574 | 0.691649 | 1036.50 | 1024.12 |
| array-native-mmap-n1073741824-g1048576--trusted | 3 | 0.814787 | 1.156255 | 0.675415 | 1036.50 | 1024.12 |
| array-native-mmap-n1073741824-g1048576--before-b | 3 | 0.815259 | 1.181943 | 0.696861 | 1036.38 | 1024.12 |
| array-matrix-owned-n1073741824-g1048576--before-a | 3 | 2.228462 | 4.397563 | 3.868686 | 25.77 | 1034.80 |
| array-matrix-owned-n1073741824-g1048576--after-default | 3 | 2.270100 | 4.518706 | 4.003795 | 25.71 | 1034.80 |
| array-matrix-owned-n1073741824-g1048576--full | 3 | 2.240929 | 4.386508 | 3.871895 | 25.94 | 1034.80 |
| array-matrix-owned-n1073741824-g1048576--crc-only | 3 | 2.243668 | 4.376677 | 3.838700 | 25.80 | 1034.80 |
| array-matrix-owned-n1073741824-g1048576--structure-only | 3 | 2.232645 | 4.594864 | 4.061687 | 25.80 | 1034.80 |
| array-matrix-owned-n1073741824-g1048576--trusted | 3 | 2.257741 | 4.413860 | 3.886103 | 25.75 | 1034.80 |
| array-matrix-owned-n1073741824-g1048576--before-b | 3 | 2.260490 | 4.468382 | 3.923132 | 25.84 | 1034.80 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
