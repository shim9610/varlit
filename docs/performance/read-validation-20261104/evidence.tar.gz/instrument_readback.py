from pathlib import Path
import shutil
root=Path('/workspace/scratch/read-validation-20261104');out=root/'stage-diagnostics';out.mkdir(exist_ok=True)
for label,path in [('after',Path('/workspace/varlit/tools/storage-bench')),('before',root/'before-harness')]:
 p=path/'src/native.rs';shutil.copy2(p,out/(label+'-native-original.rs'));s=p.read_text()
 s=s.replace('        // Capture the publication boundary', '        let mut stage = [0.0f64; 5];\n        // Capture the publication boundary')
 s=s.replace('            let v = self.frames.next().ok_or("short frame prefix")??;\n            o.frame(&v);','            let clock = std::time::Instant::now();\n            let v = self.frames.next().ok_or("short frame prefix")??;\n            stage[0] += clock.elapsed().as_secs_f64();\n            let clock = std::time::Instant::now();\n            o.frame(&v);\n            stage[1] += clock.elapsed().as_secs_f64();')
 s=s.replace('                    let found = r.get::<Frame>(&k)?.ok_or("missing key")?;', '                    let clock = std::time::Instant::now();\n                    let found = r.get::<Frame>(&k)?.ok_or("missing key")?;\n                    stage[2] += clock.elapsed().as_secs_f64();\n                    let clock = std::time::Instant::now();')
 s=s.replace('                    o.point_payload(v.id, &found.payload);','                    stage[3] += clock.elapsed().as_secs_f64();\n                    let clock = std::time::Instant::now();\n                    o.point_payload(v.id, &found.payload);\n                    stage[4] += clock.elapsed().as_secs_f64();')
 s=s.replace('        while self.rc < h.rows {','        eprintln!("READBACK_STAGES {}", serde_json::json!(stage));\n        while self.rc < h.rows {')
 p.write_text(s)
