# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--before-a | 1 | 0.031560 | 0.080670 | 0.047825 | 11.38 | 2.10 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--after-default | 1 | 0.040371 | 0.082352 | 0.057726 | 11.33 | 2.10 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--full | 1 | 0.031226 | 0.050664 | 0.044547 | 11.38 | 2.10 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--crc-only | 1 | 0.021576 | 0.038984 | 0.040268 | 11.33 | 2.10 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--structure-only | 1 | 0.019953 | 0.041342 | 0.046931 | 11.30 | 2.10 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--trusted | 1 | 0.023626 | 0.042613 | 0.042443 | 11.41 | 2.10 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--before-b | 1 | 0.022135 | 0.043667 | 0.049995 | 11.39 | 2.10 |
| grouped-n1048576-g512-t131072-w1-r1-varlit-indexed--pre-security | 1 | 0.017149 | 0.034547 | 0.039002 | 11.30 | 2.10 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
