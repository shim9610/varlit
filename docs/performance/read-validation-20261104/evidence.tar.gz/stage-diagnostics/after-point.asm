
/workspace/scratch/read-validation-20261104/binaries/after/writer:     file format elf64-x86-64


Disassembly of section .text:

0000000000098b90 <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E>:
   98b90:	push   %rbp
   98b91:	push   %r15
   98b93:	push   %r14
   98b95:	push   %r13
   98b97:	push   %r12
   98b99:	push   %rbx
   98b9a:	sub    $0xb8,%rsp
   98ba1:	mov    0x68(%rdi),%r11
   98ba5:	test   %r11,%r11
   98ba8:	je     98d5d <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E+0x1cd>
   98bae:	mov    %rcx,0x10(%rsp)
   98bb3:	mov    %r11,%rax
   98bb6:	shl    $0x7,%rax
   98bba:	mov    %rax,0x18(%rsp)
   98bbf:	cmp    %rax,%rcx
   98bc2:	jne    98db8 <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E+0x228>
   98bc8:	mov    %rdx,%r8
   98bcb:	imul   %r11,%rsi
   98bcf:	mov    0xc8(%rdi),%rbx
   98bd6:	xorps  %xmm0,%xmm0
   98bd9:	lea    0x30(%rsp),%r14
   98bde:	mov    %rsp,%r15
   98be1:	lea    0x28(%rsp),%r12
   98be6:	movabs $0x5197f7d73404147,%r13
   98bf0:	jmp    98c13 <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E+0x83>
   98bf2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   98c00:	inc    %rbx
   98c03:	mov    %rbx,0xc8(%rdi)
   98c0a:	test   %r11,%r11
   98c0d:	je     98d5d <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E+0x1cd>
   98c13:	mov    %r11,%rdx
   98c16:	dec    %r11
   98c19:	movaps %xmm0,0xa0(%rsp)
   98c21:	movaps %xmm0,0x90(%rsp)
   98c29:	movaps %xmm0,0x80(%rsp)
   98c31:	movaps %xmm0,0x70(%rsp)
   98c36:	movaps %xmm0,0x60(%rsp)
   98c3b:	movaps %xmm0,0x50(%rsp)
   98c40:	movaps %xmm0,0x40(%rsp)
   98c45:	movaps %xmm0,0x30(%rsp)
   98c4a:	mov    %r11,%rax
   98c4d:	shl    $0x7,%rax
   98c51:	shl    $0x7,%rdx
   98c55:	cmp    %rcx,%rdx
   98c58:	ja     98d6f <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E+0x1df>
   98c5e:	cmp    %rax,%rdx
   98c61:	jb     98d6f <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E+0x1df>
   98c67:	movups 0x70(%r8,%rax,1),%xmm1
   98c6d:	movaps %xmm1,0xa0(%rsp)
   98c75:	movups 0x60(%r8,%rax,1),%xmm1
   98c7b:	movaps %xmm1,0x90(%rsp)
   98c83:	movups 0x50(%r8,%rax,1),%xmm1
   98c89:	movaps %xmm1,0x80(%rsp)
   98c91:	movups 0x40(%r8,%rax,1),%xmm1
   98c97:	movaps %xmm1,0x70(%rsp)
   98c9c:	movups (%r8,%rax,1),%xmm1
   98ca1:	movups 0x10(%r8,%rax,1),%xmm2
   98ca7:	movups 0x20(%r8,%rax,1),%xmm3
   98cad:	movups 0x30(%r8,%rax,1),%xmm4
   98cb3:	movaps %xmm4,0x60(%rsp)
   98cb8:	movaps %xmm3,0x50(%rsp)
   98cbd:	movaps %xmm2,0x40(%rsp)
   98cc2:	movaps %xmm1,0x30(%rsp)
   98cc7:	mov    %r14,(%rsp)
   98ccb:	movq   $0x80,0x8(%rsp)
   98cd4:	mov    0x8(%rsp),%r9
   98cd9:	cmp    $0x7,%r9
   98cdd:	jbe    98d88 <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E+0x1f8>
   98ce3:	lea    (%r11,%rsi,1),%r10
   98ce7:	mov    (%rsp),%rbp
   98ceb:	mov    %rbp,(%rsp)
   98cef:	movq   $0x8,0x8(%rsp)
   98cf8:	mov    %r10,0x28(%rsp)
   98cfd:	mov    %r12,0x20(%rsp)
   98d02:	cmp    %r10,0x0(%rbp)
   98d06:	jne    98d9f <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E+0x20f>
   98d0c:	mov    %r10,%rax
   98d0f:	mul    %r13
   98d12:	mov    %r10d,%eax
   98d15:	sub    %edx,%eax
   98d17:	shr    $1,%eax
   98d19:	add    %edx,%eax
   98d1b:	shr    $0x7,%eax
   98d1e:	imul   $0xfb,%eax,%eax
   98d24:	sub    %eax,%r10d
   98d27:	mov    $0x8,%eax
   98d2c:	nopl   0x0(%rax)
   98d30:	cmp    %rax,%r9
   98d33:	je     98c00 <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E+0x70>
   98d39:	cmp    %r10b,0x0(%rbp,%rax,1)
   98d3e:	lea    0x1(%rax),%rax
   98d42:	je     98d30 <_ZN20varlit_storage_bench5model6Oracle13point_payload17hac24f7060c11abf8E+0x1a0>
   98d44:	lea    -0x712aa(%rip),%rdi        # 27aa1 <anon.7b492a9737d355c8072027c62b266f39.5.llvm.15109050036339928808>
   98d4b:	lea    0xbd6c6(%rip),%rdx        # 156418 <anon.7b492a9737d355c8072027c62b266f39.6.llvm.15109050036339928808>
   98d52:	mov    $0x43,%esi
   98d57:	call   *0xc2ed3(%rip)        # 15bc30 <_DYNAMIC+0x2a8>
   98d5d:	add    $0xb8,%rsp
   98d64:	pop    %rbx
   98d65:	pop    %r12
   98d67:	pop    %r13
   98d69:	pop    %r14
   98d6b:	pop    %r15
   98d6d:	pop    %rbp
   98d6e:	ret
   98d6f:	lea    0xbd892(%rip),%r8        # 156608 <anon.7b492a9737d355c8072027c62b266f39.42.llvm.15109050036339928808>
   98d76:	mov    %rax,%rdi
   98d79:	mov    %rdx,%rsi
   98d7c:	mov    %rcx,%rdx
   98d7f:	mov    %r8,%rcx
   98d82:	call   *0xc2ec0(%rip)        # 15bc48 <_DYNAMIC+0x2c0>
   98d88:	lea    0xbd659(%rip),%rcx        # 1563e8 <anon.7b492a9737d355c8072027c62b266f39.3.llvm.15109050036339928808>
   98d8f:	mov    $0x8,%esi
   98d94:	xor    %edi,%edi
   98d96:	mov    %r9,%rdx
   98d99:	call   *0xc2ea9(%rip)        # 15bc48 <_DYNAMIC+0x2c0>
   98d9f:	lea    0xbd65a(%rip),%r9        # 156400 <anon.7b492a9737d355c8072027c62b266f39.4.llvm.15109050036339928808>
   98da6:	mov    %rsp,%rsi
   98da9:	lea    0x20(%rsp),%rdx
   98dae:	xor    %edi,%edi
   98db0:	xor    %ecx,%ecx
   98db2:	call   *0xc3700(%rip)        # 15c4b8 <_DYNAMIC+0xb30>
   98db8:	lea    0xbd831(%rip),%r9        # 1565f0 <anon.7b492a9737d355c8072027c62b266f39.40.llvm.15109050036339928808>
   98dbf:	lea    0x10(%rsp),%rsi
   98dc4:	lea    0x18(%rsp),%rdx
   98dc9:	xor    %edi,%edi
   98dcb:	xor    %ecx,%ecx
   98dcd:	call   *0xc2fc5(%rip)        # 15bd98 <_DYNAMIC+0x410>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
