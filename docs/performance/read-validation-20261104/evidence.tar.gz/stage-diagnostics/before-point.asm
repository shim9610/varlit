
/workspace/scratch/read-validation-20261104/binaries/before/writer:     file format elf64-x86-64


Disassembly of section .text:

000000000009fef0 <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE>:
   9fef0:	push   %rbp
   9fef1:	push   %r15
   9fef3:	push   %r14
   9fef5:	push   %r13
   9fef7:	push   %r12
   9fef9:	push   %rbx
   9fefa:	sub    $0xb8,%rsp
   9ff01:	mov    0x68(%rdi),%r11
   9ff05:	test   %r11,%r11
   9ff08:	je     a00bd <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE+0x1cd>
   9ff0e:	mov    %rcx,0x10(%rsp)
   9ff13:	mov    %r11,%rax
   9ff16:	shl    $0x7,%rax
   9ff1a:	mov    %rax,0x18(%rsp)
   9ff1f:	cmp    %rax,%rcx
   9ff22:	jne    a0118 <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE+0x228>
   9ff28:	mov    %rdx,%r8
   9ff2b:	imul   %r11,%rsi
   9ff2f:	mov    0xc8(%rdi),%rbx
   9ff36:	xorps  %xmm0,%xmm0
   9ff39:	lea    0x30(%rsp),%r14
   9ff3e:	mov    %rsp,%r15
   9ff41:	lea    0x28(%rsp),%r12
   9ff46:	movabs $0x5197f7d73404147,%r13
   9ff50:	jmp    9ff73 <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE+0x83>
   9ff52:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   9ff60:	inc    %rbx
   9ff63:	mov    %rbx,0xc8(%rdi)
   9ff6a:	test   %r11,%r11
   9ff6d:	je     a00bd <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE+0x1cd>
   9ff73:	mov    %r11,%rdx
   9ff76:	dec    %r11
   9ff79:	movaps %xmm0,0xa0(%rsp)
   9ff81:	movaps %xmm0,0x90(%rsp)
   9ff89:	movaps %xmm0,0x80(%rsp)
   9ff91:	movaps %xmm0,0x70(%rsp)
   9ff96:	movaps %xmm0,0x60(%rsp)
   9ff9b:	movaps %xmm0,0x50(%rsp)
   9ffa0:	movaps %xmm0,0x40(%rsp)
   9ffa5:	movaps %xmm0,0x30(%rsp)
   9ffaa:	mov    %r11,%rax
   9ffad:	shl    $0x7,%rax
   9ffb1:	shl    $0x7,%rdx
   9ffb5:	cmp    %rcx,%rdx
   9ffb8:	ja     a00cf <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE+0x1df>
   9ffbe:	cmp    %rax,%rdx
   9ffc1:	jb     a00cf <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE+0x1df>
   9ffc7:	movups 0x70(%r8,%rax,1),%xmm1
   9ffcd:	movaps %xmm1,0xa0(%rsp)
   9ffd5:	movups 0x60(%r8,%rax,1),%xmm1
   9ffdb:	movaps %xmm1,0x90(%rsp)
   9ffe3:	movups 0x50(%r8,%rax,1),%xmm1
   9ffe9:	movaps %xmm1,0x80(%rsp)
   9fff1:	movups 0x40(%r8,%rax,1),%xmm1
   9fff7:	movaps %xmm1,0x70(%rsp)
   9fffc:	movups (%r8,%rax,1),%xmm1
   a0001:	movups 0x10(%r8,%rax,1),%xmm2
   a0007:	movups 0x20(%r8,%rax,1),%xmm3
   a000d:	movups 0x30(%r8,%rax,1),%xmm4
   a0013:	movaps %xmm4,0x60(%rsp)
   a0018:	movaps %xmm3,0x50(%rsp)
   a001d:	movaps %xmm2,0x40(%rsp)
   a0022:	movaps %xmm1,0x30(%rsp)
   a0027:	mov    %r14,(%rsp)
   a002b:	movq   $0x80,0x8(%rsp)
   a0034:	mov    0x8(%rsp),%r9
   a0039:	cmp    $0x7,%r9
   a003d:	jbe    a00e8 <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE+0x1f8>
   a0043:	lea    (%r11,%rsi,1),%r10
   a0047:	mov    (%rsp),%rbp
   a004b:	mov    %rbp,(%rsp)
   a004f:	movq   $0x8,0x8(%rsp)
   a0058:	mov    %r10,0x28(%rsp)
   a005d:	mov    %r12,0x20(%rsp)
   a0062:	cmp    %r10,0x0(%rbp)
   a0066:	jne    a00ff <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE+0x20f>
   a006c:	mov    %r10,%rax
   a006f:	mul    %r13
   a0072:	mov    %r10d,%eax
   a0075:	sub    %edx,%eax
   a0077:	shr    $1,%eax
   a0079:	add    %edx,%eax
   a007b:	shr    $0x7,%eax
   a007e:	imul   $0xfb,%eax,%eax
   a0084:	sub    %eax,%r10d
   a0087:	mov    $0x8,%eax
   a008c:	nopl   0x0(%rax)
   a0090:	cmp    %rax,%r9
   a0093:	je     9ff60 <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE+0x70>
   a0099:	cmp    %r10b,0x0(%rbp,%rax,1)
   a009e:	lea    0x1(%rax),%rax
   a00a2:	je     a0090 <_ZN20varlit_storage_bench5model6Oracle13point_payload17h3bccc51d079aca9fE+0x1a0>
   a00a4:	lea    -0x7713e(%rip),%rdi        # 28f6d <anon.a3825dbfbcb6eb09bb5884e7ae8383ee.5.llvm.3856194390027822531>
   a00ab:	lea    0xb594e(%rip),%rdx        # 155a00 <anon.a3825dbfbcb6eb09bb5884e7ae8383ee.6.llvm.3856194390027822531>
   a00b2:	mov    $0x43,%esi
   a00b7:	call   *0xbaa63(%rip)        # 15ab20 <_DYNAMIC+0x2a8>
   a00bd:	add    $0xb8,%rsp
   a00c4:	pop    %rbx
   a00c5:	pop    %r12
   a00c7:	pop    %r13
   a00c9:	pop    %r14
   a00cb:	pop    %r15
   a00cd:	pop    %rbp
   a00ce:	ret
   a00cf:	lea    0xb5b1a(%rip),%r8        # 155bf0 <anon.a3825dbfbcb6eb09bb5884e7ae8383ee.37.llvm.3856194390027822531>
   a00d6:	mov    %rax,%rdi
   a00d9:	mov    %rdx,%rsi
   a00dc:	mov    %rcx,%rdx
   a00df:	mov    %r8,%rcx
   a00e2:	call   *0xbaa50(%rip)        # 15ab38 <_DYNAMIC+0x2c0>
   a00e8:	lea    0xb58e1(%rip),%rcx        # 1559d0 <anon.a3825dbfbcb6eb09bb5884e7ae8383ee.3.llvm.3856194390027822531>
   a00ef:	mov    $0x8,%esi
   a00f4:	xor    %edi,%edi
   a00f6:	mov    %r9,%rdx
   a00f9:	call   *0xbaa39(%rip)        # 15ab38 <_DYNAMIC+0x2c0>
   a00ff:	lea    0xb58e2(%rip),%r9        # 1559e8 <anon.a3825dbfbcb6eb09bb5884e7ae8383ee.4.llvm.3856194390027822531>
   a0106:	mov    %rsp,%rsi
   a0109:	lea    0x20(%rsp),%rdx
   a010e:	xor    %edi,%edi
   a0110:	xor    %ecx,%ecx
   a0112:	call   *0xbb388(%rip)        # 15b4a0 <_DYNAMIC+0xc28>
   a0118:	lea    0xb5ab9(%rip),%r9        # 155bd8 <anon.a3825dbfbcb6eb09bb5884e7ae8383ee.35.llvm.3856194390027822531>
   a011f:	lea    0x10(%rsp),%rsi
   a0124:	lea    0x18(%rsp),%rdx
   a0129:	xor    %edi,%edi
   a012b:	xor    %ecx,%ecx
   a012d:	call   *0xbab55(%rip)        # 15ac88 <_DYNAMIC+0x410>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
