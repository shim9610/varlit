import json,os,subprocess,shutil,hashlib
from pathlib import Path
root=Path('/workspace/scratch/read-validation-20261104');out=root/'stage-diagnostics'
for label,path in [('after',Path('/workspace/varlit/tools/storage-bench')),('before',root/'before-harness')]:
 shutil.copy2(path/'src/native.rs',out/(label+'-native-instrumented.rs'))
 shutil.copy2(out/(label+'-native-original.rs'),path/'src/native.rs')
cpus=sorted(os.sched_getaffinity(0))[:4];os.sched_setaffinity(0,cpus)
cfg=root/'diagnostics-v2/timing-0-writer-only--before-a.config.json'
manifest={'scope':'Separate instrumented attribution only, not timing qualification; frame-next,oracle-frame,indexed-get,equality,oracle-point stages. Full readback work retained.', 'affinity':cpus,'binaries':{x:hashlib.sha256((out/(x+'-writer')).read_bytes()).hexdigest() for x in ['before','after']}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for rep in range(3):
 variants=[('before','legacy'),('after','legacy'),('after','full'),('after','trusted')]
 for runtime,policy in variants if rep%2==0 else reversed(variants):
  stem=f'{rep}-{runtime}-{policy}';work=out/(stem+'.work')
  with (out/(stem+'.json')).open('w') as f,(out/(stem+'.stderr')).open('w') as err:
   subprocess.run([str(out/(runtime+'-writer')),'run','varlit-indexed',str(work),str(cfg)],env=dict(os.environ,VARLIT_BENCH_READ_VALIDATION=policy),stdout=f,stderr=err,check=True)
  shutil.rmtree(work);print(stem,flush=True)
