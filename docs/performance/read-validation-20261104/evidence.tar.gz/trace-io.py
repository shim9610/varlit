import json,os,subprocess,shutil
from pathlib import Path
p=Path('/workspace/scratch/read-validation-20261104');out=p/'io-diagnostics';out.mkdir(exist_ok=True)
rows=[json.loads(x) for x in (p/'diagnostics-v2/results.jsonl').read_text().splitlines()]
for variant in ['before-a','after-default','full','trusted']:
 r=next(x for x in rows if x['profile']['name']=='writer-only--'+variant)
 cmd=r['command'].copy();cmd[3]=str(out/(variant+'.work'))
 env=dict(os.environ,VARLIT_BENCH_READ_VALIDATION=r['profile']['read_validation'])
 with (out/(variant+'.json')).open('w') as f:
  subprocess.run(['strace','-f','-c','-e','trace=pread64,read,pwrite64,write,lseek,fsync,fdatasync','-o',str(out/(variant+'.strace')),*cmd],env=env,stdout=f,stderr=(out/(variant+'.stderr')).open('w'),check=True)
 shutil.rmtree(cmd[3]);print(variant,flush=True)
