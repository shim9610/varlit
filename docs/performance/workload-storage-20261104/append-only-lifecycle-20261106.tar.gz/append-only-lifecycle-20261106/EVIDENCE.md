# Append-only mmap lifecycle evidence

Baseline: c5db359730b1ac3e7014c04b5b48675cd4c6f9f3.
The final working-tree source changes are captured in each completed cohort's
worktree.patch, including staged new runtime files. Benchmark sources and frozen
binaries are retained. Both runtimes use the same thread_mmap.rs source;
the baseline enables guarded-mmap and the candidate session-lifecycle.
These are harness switches, not new library features or dependencies.

lifecycle-v1: 42 profiles, seven fixed randomized repetitions, 294 timings and
42 separate process/storage probes. Baseline A/B are the identical binary.
Six live profiles add actual reader-first writer reacquisition/close every
16 MiB publication. All bytes, metadata and retained initial views are checked.

lifecycle-calibration-v1: four retained warm phase alerts, fixed 30 balanced
rounds, 360 timings and 12 probes. Each of the six A/B/current orders occurs
five times per condition. Same binaries and unchanged 4 CPU /16 GiB /32 GiB
caps. Neither completed cohort changes configured resource budgets or validation.
Both have zero OOM/OOM-kill event deltas. No timing is pooled across cohorts.

interrupted-before-cleanup-v1: 150 recorded timings retained from an incomplete
run, stopped to make final native liveness cleanup failure visible to retained
readers. Its earlier binary is bin/interrupted/arrays. Its patch predates staging
of the new runtime files and is not a complete runtime source snapshot. These
unfinished observations are excluded from completed-cohort qualification.
A generated interrupted samples.bin was removed after the run stopped;
interruption.json records its logical size. Raw rows/stdout/usage are retained.

The final native cleanup change has a real read-only native-handle failure test
for explicit session close and final-authority drop with retained valid mappings.
Positive Loom models use the exact production reader/recovery atomic gate.
Both exclusive-bypass and release-order mutations compile, then fail model
assertions. They are bounded gate checks, not whole-session/OS formal proofs.

Verification logs distinguish completed native, API/compile, allocation refusal,
Clippy, script, model, documentation and rendering checks. Initial failed attempts
remain in their named logs. The legacy API inventory stays frozen;
new interfaces have executable registrations. No merge or release was performed.

Primary observations, all phase alerts, controls, repeat spreads, cgroup/cache
baselines, PSS and temporary/deleted-open storage remain in the existing combined
report/dashboard. Single 50 ms probes can miss brief peaks and are not a memory
regression qualification. Fresh writes warm the OS cache; no privileged cache
flush was used. There is no new SQLite/HDF5 measurement in this evidence.


A subsequent current-Rust CI build stopped before tests: Rust1.99.1 deprecated
AtomicUsize::fetch_update in favor of try_update. Rust1.95 and Loom0.7.2 still
share fetch_update, so that one method has an explained deprecated-lint allowance.
All other warnings remain denied. stable-fix.patch records the annotation on top
of the completed cohort source. Rust1.95/native+Loom/Clippy and Rust1.99.1 focused
native/all-target all-feature checks pass. The entire rebuilt Linux release
binary is identical to the timed c4744e... executable, not only its text section.
