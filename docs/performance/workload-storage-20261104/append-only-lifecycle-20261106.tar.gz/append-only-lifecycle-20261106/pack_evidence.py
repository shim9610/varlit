from pathlib import Path
import tarfile
root=Path('/workspace/scratch/mmap-lifecycle-20261106')
archive=Path('/workspace/varlit/docs/performance/workload-storage-20261104/append-only-lifecycle-20261106.tar.gz')
files=[]
for dirname in ['lifecycle-v1','lifecycle-calibration-v1','interrupted-before-cleanup-v1','bin','model-controls']:
    files += [p for p in (root/dirname).rglob('*') if p.is_file()]
files += list(root.glob('*.log'))
files += [root/n for n in ['EVIDENCE.md','binary-sha256.txt','summary.json','calibration-summary.json','dashboard.png','calibration-dashboard.png','pack_evidence.py']]
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for path in sorted(set(files)):
        tar.add(path,arcname='append-only-lifecycle-20261106/'+str(path.relative_to(root)),recursive=False)
print('Archive files',len(files),'bytes',archive.stat().st_size)
