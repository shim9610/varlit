push   %rbp
push   %r15
push   %r14
push   %r13
push   %r12
push   %rbx
sub    $0x1000,%rsp
movq   $0x0,(%rsp)
sub    $0xde8,%rsp
mov    %r9,%r14
mov    %r8,%r15
mov    %rdx,%rbp
mov    %rdi,%rbx
mov    0x1e20(%rsp),%rax
mov    %rax,0x128(%rsp)
mov    %rdx,0x130(%rsp)
mov    %rcx,0x8(%rsp)
mov    %rcx,0x138(%rsp)
mov    %r8,0xc0(%rsp)
mov    %r9,0xc8(%rsp)
mov    $0x1,%r13b
lea    0x1d8(%rsp),%rdi
call   ADDR <arrays::thread_mmap::Factory::open>
mov    %rbx,(%rsp)
mov    0x1d8(%rsp),%rbx
mov    0x1e0(%rsp),%r12
mov    0x1e8(%rsp),%r13
cmp    $0x3,%rbx
jne    ADDR <arrays::thread_mmap::consume+0xd8>
mov    (%rsp),%rax
mov    %r12,0x8(%rax)
mov    %rax,%r12
mov    %r13,0x10(%rax)
movabs $0x8000000000000000,%rax
mov    %rax,(%r12)
test   %r15,%r15
je     ADDR <arrays::thread_mmap::consume+0x238>
mov    $0x1,%r13b
cmp    $0x1,%r15
jne    ADDR <arrays::thread_mmap::consume+0x2aa>
lea    0xc8(%rsp),%rdi
call   ADDR <std::sync::mpmc::counter::Sender<C>::release>
jmp    ADDR <arrays::thread_mmap::consume+0xf3f>
lea    0x1f0(%rsp),%rsi
lea    0xff8(%rsp),%rdi
mov    $0xdf0,%edx
call   *DISP(%rip)        # relocated data
mov    %rbx,0xfe0(%rsp)
mov    %r12,0xfe8(%rsp)
mov    %r13,0xff0(%rsp)
movq   $0x3,0x148(%rsp)
movq   $0x0,0xe0(%rsp)
movq   $0x8,0xe8(%rsp)
movq   $0x0,0xf0(%rsp)
movq   $0x0,0xf8(%rsp)
movq   $0x8,0x100(%rsp)
movq   $0x0,0x108(%rsp)
call   *DISP(%rip)        # relocated data
mov    $0x1,%eax
mov    %rax,0x88(%rsp)
mov    $0x400000,%edi
mov    $0x1,%esi
call   *DISP(%rip)        # relocated data
mov    %rax,0xb8(%rsp)
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0x16c4>
mov    0x128(%rsp),%r12
shr    $0x18,%r12
je     ADDR <arrays::thread_mmap::consume+0x1c6>
call   *DISP(%rip)        # relocated data
mov    $0x1,%esi
mov    %r12,%rdi
call   *DISP(%rip)        # relocated data
mov    %rax,0x88(%rsp)
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0x16d6>
movq   $0x0,0x1d8(%rsp)
xorpd  %xmm0,%xmm0
movupd %xmm0,0x1f0(%rsp)
movupd %xmm0,0x200(%rsp)
movq   $0x0,0x210(%rsp)
movq   $0x8,0x1e0(%rsp)
movq   $0x0,0x1e8(%rsp)
cmp    $0x2,%r15
je     ADDR <arrays::thread_mmap::consume+0x2bc>
cmp    $0x1,%r15
jne    ADDR <arrays::thread_mmap::consume+0x2d1>
mov    $0x1,%r15b
mov    $0x1,%r13b
mov    %r14,%rdi
mov    $0x3b9aca00,%edx
call   ADDR <std::sync::mpmc::list::Channel<T>::send>
jmp    ADDR <arrays::thread_mmap::consume+0x2e4>
lock decq 0x200(%r14)
jne    ADDR <arrays::thread_mmap::consume+0xf3f>
mov    0x80(%r14),%rax
mov    0x190(%r14),%rcx
data16 data16 cs nopw 0x0(%rax,%rax,1)
mov    %rax,%rdx
or     %rcx,%rdx
lock cmpxchg %rdx,0x80(%r14)
jne    ADDR <arrays::thread_mmap::consume+0x260>
test   %rax,0x190(%r14)
jne    ADDR <arrays::thread_mmap::consume+0x289>
lea    0x140(%r14),%rdi
mov    $0x1,%r13b
call   ADDR <<std::sync::mpmc::waker::SyncWaker>::disconnect>
mov    $0x1,%r13b
mov    $0x1,%al
xchg   %al,0x210(%r14)
test   %al,%al
je     ADDR <arrays::thread_mmap::consume+0xf3f>
mov    %r14,%rdi
call   ADDR <core::ptr::drop_in_place<alloc::boxed::Box<std::sync::mpmc::counter::Counter<std::sync::mpmc::array::Channel<()>>>>>
jmp    ADDR <arrays::thread_mmap::consume+0xf3f>
lea    0xc8(%rsp),%rdi
call   ADDR <std::sync::mpmc::counter::Sender<C>::release>
jmp    ADDR <arrays::thread_mmap::consume+0xf3f>
mov    $0x1,%r15b
mov    $0x1,%r13b
mov    %r14,%rdi
mov    $0x3b9aca00,%edx
call   ADDR <std::sync::mpmc::zero::Channel<T>::send>
jmp    ADDR <arrays::thread_mmap::consume+0x2e4>
mov    $0x1,%r15b
mov    $0x1,%r13b
mov    %r14,%rdi
mov    $0x3b9aca00,%edx
call   ADDR <std::sync::mpmc::array::Channel<T>::send>
mov    0x8(%rsp),%rsi
lea    0xfe8(%rsp),%r13
cmp    $0x2,%al
je     ADDR <arrays::thread_mmap::consume+0x42a>
movzbl %al,%eax
test   %eax,%eax
je     ADDR <arrays::thread_mmap::consume+0x158b>
mov    (%rsp),%rcx
movq   $0x1,0x8(%rcx)
lea    DISP(%rip),%rax        # relocated data
mov    %rax,0x10(%rcx)
movabs $0x8000000000000000,%rax
mov    %rax,(%rcx)
mov    $0x1,%bl
mov    $0x1,%r13b
mov    0x88(%rsp),%r15
mov    0x1d8(%rsp),%rax
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0x35d>
mov    0x1e0(%rsp),%rdi
shl    $0x3,%rax
lea    (%rax,%rax,2),%rsi
mov    $0x8,%edx
call   *DISP(%rip)        # relocated data
test   %r12,%r12
je     ADDR <arrays::thread_mmap::consume+0x373>
mov    $0x1,%edx
mov    %r15,%rdi
mov    %r12,%rsi
call   *DISP(%rip)        # relocated data
mov    $0x400000,%esi
mov    $0x1,%edx
mov    0xb8(%rsp),%rdi
call   *DISP(%rip)        # relocated data
mov    0xf8(%rsp),%rax
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0x3af>
mov    0x100(%rsp),%rdi
imul   $0x68,%rax,%rsi
mov    $0x8,%edx
call   *DISP(%rip)        # relocated data
mov    0xe0(%rsp),%rax
test   %rax,%rax
mov    (%rsp),%r12
je     ADDR <arrays::thread_mmap::consume+0x3d7>
mov    0xe8(%rsp),%rdi
imul   $0x68,%rax,%rsi
mov    $0x8,%edx
call   *DISP(%rip)        # relocated data
test   %bl,%bl
je     ADDR <arrays::thread_mmap::consume+0xe6a>
mov    0x148(%rsp),%rax
lea    DISP(%rip),%rcx        # relocated data
movslq (%rcx,%rax,4),%rax
add    %rcx,%rax
jmp    *%rax
lea    0x150(%rsp),%rdi
call   *DISP(%rip)        # relocated data
mov    0x168(%rsp),%rax
lock decq (%rax)
jne    ADDR <arrays::thread_mmap::consume+0xe6a>
lea    0x168(%rsp),%rdi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0xe6a>
mov    0x1e28(%rsp),%rax
mov    %rbp,0xd0(%rsp)
mov    %rsi,0xd8(%rsp)
mov    %rax,%rcx
shr    $1,%rcx
mov    %rcx,0x1b0(%rsp)
lea    0x0(,%rax,4),%rcx
mov    %rcx,0x1a8(%rsp)
add    $0xfffffffffeffffff,%rax
mov    %rax,0x1b8(%rsp)
lea    0x50(%rsp),%rax
mov    %rax,0x198(%rsp)
lea    DISP(%rip),%rax        # relocated data
mov    %rax,0x110(%rsp)
mov    %r12,0x48(%rsp)
cmp    $0x2,%rbp
je     ADDR <arrays::thread_mmap::consume+0x4bd>
cmp    $0x1,%rbp
jne    ADDR <arrays::thread_mmap::consume+0x4ac>
lea    0x10(%rsp),%rdi
mov    $0x3b9aca00,%ecx
call   ADDR <std::sync::mpmc::list::Channel<T>::recv>
jmp    ADDR <arrays::thread_mmap::consume+0x4cc>
lea    0x10(%rsp),%rdi
mov    $0x3b9aca00,%ecx
call   ADDR <std::sync::mpmc::array::Channel<T>::recv>
jmp    ADDR <arrays::thread_mmap::consume+0x4cc>
lea    0x10(%rsp),%rdi
mov    $0x3b9aca00,%ecx
call   ADDR <std::sync::mpmc::zero::Channel<T>::recv>
cmpb   $0x0,0x10(%rsp)
jne    ADDR <arrays::thread_mmap::consume+0x120a>
mov    0x18(%rsp),%rbx
mov    0x20(%rsp),%rax
mov    %rax,0x8(%rsp)
call   *DISP(%rip)        # relocated data
mov    %rax,0x1a0(%rsp)
call   *DISP(%rip)        # relocated data
mov    %rax,0x1c8(%rsp)
mov    %edx,0x1d0(%rsp)
xorpd  %xmm0,%xmm0
movapd %xmm0,0x10(%rsp)
mov    $0x3,%edi
lea    0x10(%rsp),%rsi
call   *DISP(%rip)        # relocated data
mov    %eax,0x50(%rsp)
test   %eax,%eax
jne    ADDR <arrays::thread_mmap::consume+0x1566>
xorps  %xmm0,%xmm0
cvtsi2sdq 0x10(%rsp),%xmm0
movsd  %xmm0,0xb0(%rsp)
xorps  %xmm0,%xmm0
cvtsi2sdq 0x18(%rsp),%xmm0
divsd  DISP(%rip),%xmm0        # relocated data
movsd  %xmm0,0x118(%rsp)
call   *DISP(%rip)        # relocated data
mov    %edx,%esi
mov    $0x3c,%edx
mov    %rax,%rdi
xor    %ecx,%ecx
call   *DISP(%rip)        # relocated data
mov    %rax,%r14
mov    %edx,%ebp
mov    %rbx,0xa8(%rsp)
movsd  0x118(%rsp),%xmm0
addsd  0xb0(%rsp),%xmm0
movsd  %xmm0,0x118(%rsp)
mov    0x1e28(%rsp),%rbx
lea    0xfe0(%rsp),%r15
jmp    ADDR <arrays::thread_mmap::consume+0x5b9>
nop
cmp    %r14,%rax
jg     ADDR <arrays::thread_mmap::consume+0xfab>
mov    0x8(%rsp),%rax
cmp    %rax,0xf0(%rsp)
jb     ADDR <arrays::thread_mmap::consume+0x630>
cmpb   $0x0,0x1e30(%rsp)
je     ADDR <arrays::thread_mmap::consume+0x6ff>
cmpq   $0xffffffffff000000,0x1b8(%rsp)
jb     ADDR <arrays::thread_mmap::consume+0x16a7>
mov    0x108(%rsp),%rsi
mov    $0x1000000,%eax
xor    %edx,%edx
div    %ebx
mov    %eax,%ecx
mov    0x8(%rsp),%rax
mov    %rax,%rdx
shr    $0x20,%rdx
je     ADDR <arrays::thread_mmap::consume+0x61b>
xor    %edx,%edx
div    %rcx
add    %rax,%rax
cmp    %rax,%rsi
jb     ADDR <arrays::thread_mmap::consume+0x630>
jmp    ADDR <arrays::thread_mmap::consume+0x6ff>
xor    %edx,%edx
div    %ecx
add    %rax,%rax
cmp    %rax,%rsi
jae    ADDR <arrays::thread_mmap::consume+0x6ff>
nopl   0x0(%rax,%rax,1)
cmpl   $0x2,0xfe0(%rsp)
jne    ADDR <arrays::thread_mmap::consume+0x670>
lea    0x50(%rsp),%rdi
mov    %r13,%rsi
call   *DISP(%rip)        # relocated data
mov    0x50(%rsp),%rax
movabs $0x8000000000000000,%rcx
add    $0x83,%rcx
cmp    %rcx,%rax
je     ADDR <arrays::thread_mmap::consume+0x69d>
jmp    ADDR <arrays::thread_mmap::consume+0x108f>
nopl   0x0(%rax,%rax,1)
lea    0x50(%rsp),%rdi
mov    %r15,%rsi
call   *DISP(%rip)        # relocated data
mov    0x50(%rsp),%rax
movabs $0x8000000000000000,%rcx
add    $0x83,%rcx
cmp    %rcx,%rax
jne    ADDR <arrays::thread_mmap::consume+0x102d>
mov    %r15,%rdi
mov    $0x1,%esi
lea    0xe0(%rsp),%rdx
call   ADDR <arrays::thread_mmap::extend>
test   %rax,%rax
jne    ADDR <arrays::thread_mmap::consume+0x1105>
cmpb   $0x0,0x1e30(%rsp)
je     ADDR <arrays::thread_mmap::consume+0x6e3>
mov    %r15,%rdi
mov    $0x2,%esi
lea    0xf8(%rsp),%rdx
call   ADDR <arrays::thread_mmap::extend>
test   %rax,%rax
jne    ADDR <arrays::thread_mmap::consume+0x1105>
call   *DISP(%rip)        # relocated data
cmp    %r14,%rax
jne    ADDR <arrays::thread_mmap::consume+0x5b0>
cmp    %ebp,%edx
jbe    ADDR <arrays::thread_mmap::consume+0x5b9>
jmp    ADDR <arrays::thread_mmap::consume+0xfab>
mov    0xa8(%rsp),%rdi
cmp    %r12,%rdi
jae    ADDR <arrays::thread_mmap::consume+0x16e6>
mov    0x88(%rsp),%rax
cmpb   $0x0,(%rax,%rdi,1)
jne    ADDR <arrays::thread_mmap::consume+0x15e6>
movb   $0x1,(%rax,%rdi,1)
mov    0x1f8(%rsp),%rdi
mov    0xf0(%rsp),%rdx
mov    0x8(%rsp),%rax
cmp    %rdi,%rax
jb     ADDR <arrays::thread_mmap::consume+0x162d>
cmp    %rdx,%rax
ja     ADDR <arrays::thread_mmap::consume+0x162d>
mov    0x1f0(%rsp),%rcx
mov    %rcx,0x188(%rsp)
cmp    %rax,%rdi
jne    ADDR <arrays::thread_mmap::consume+0x831>
cmpb   $0x0,0x1e30(%rsp)
je     ADDR <arrays::thread_mmap::consume+0xd07>
mov    0x200(%rsp),%rdi
lea    0x2(%rdi),%rax
mov    0x108(%rsp),%rdx
cmp    $0xfffffffffffffffd,%rdi
ja     ADDR <arrays::thread_mmap::consume+0x1619>
cmp    %rdx,%rax
lea    0xfe0(%rsp),%r15
ja     ADDR <arrays::thread_mmap::consume+0x1619>
imul   $0x68,%rdi,%r14
add    0x100(%rsp),%r14
lea    0x10(%rsp),%rdi
mov    %r15,%rsi
mov    %r14,%rdx
call   ADDR <arrays::thread_mmap::Follower::window>
mov    0x10(%rsp),%rdx
cmp    $0x3,%rdx
je     ADDR <arrays::thread_mmap::consume+0x1323>
mov    0x18(%rsp),%rcx
mov    0x20(%rsp),%rax
lea    0x28(%rsp),%rsi
movupd (%rsi),%xmm0
movapd %xmm0,0x90(%rsp)
mov    %rdx,0x50(%rsp)
mov    %rcx,0x58(%rsp)
mov    %rax,0x60(%rsp)
lea    0x58(%rsp),%rsi
movupd %xmm0,0x10(%rsi)
mov    $0x1,%esi
test   %rdx,%rdx
je     ADDR <arrays::thread_mmap::consume+0xb0f>
cmp    $0x2,%edx
jne    ADDR <arrays::thread_mmap::consume+0xb05>
cmp    $0x1,%rcx
jne    ADDR <arrays::thread_mmap::consume+0xb0d>
mov    0x68(%rsp),%rdx
mov    %rax,%rsi
jmp    ADDR <arrays::thread_mmap::consume+0xb0f>
imul   $0x68,%rdi,%rax
mov    0xe8(%rsp),%r14
add    %rax,%r14
mov    0xa8(%rsp),%r15
shl    $0x18,%r15
imul   $0x68,0x8(%rsp),%rbp
sub    %rax,%rbp
mov    %r15,0x190(%rsp)
xor    %ebx,%ebx
jmp    ADDR <arrays::thread_mmap::consume+0x8b8>
mov    0x70(%rsp),%rax
lea    0x148(%rsp),%rcx
mov    %rax,0x20(%rcx)
movupd 0x50(%rsp),%xmm0
movupd 0x60(%rsp),%xmm1
movupd %xmm1,0x10(%rcx)
movupd %xmm0,(%rcx)
mov    %rbp,0x140(%rsp)
lea    0xfe8(%rsp),%r13
mov    0xb0(%rsp),%rbp
add    $0x68,%r14
add    0x1e28(%rsp),%r15
inc    %rbx
add    $0xffffffffffffff98,%rbp
je     ADDR <arrays::thread_mmap::consume+0x766>
lea    0x10(%rsp),%rdi
lea    0xfe0(%rsp),%rsi
mov    %r14,%rdx
call   ADDR <arrays::thread_mmap::Follower::window>
mov    0x10(%rsp),%rdx
mov    0x18(%rsp),%rcx
mov    0x20(%rsp),%rax
cmp    $0x3,%rdx
je     ADDR <arrays::thread_mmap::consume+0x11bf>
lea    0x28(%rsp),%rsi
movupd (%rsi),%xmm0
lea    0x58(%rsp),%rsi
movupd %xmm0,0x10(%rsi)
mov    %rdx,0x50(%rsp)
mov    %rcx,0x58(%rsp)
mov    %rax,0x60(%rsp)
mov    $0x1,%esi
test   %rdx,%rdx
mov    %rbp,0xb0(%rsp)
je     ADDR <arrays::thread_mmap::consume+0x940>
cmp    $0x2,%edx
jne    ADDR <arrays::thread_mmap::consume+0x92f>
cmp    $0x1,%rcx
jne    ADDR <arrays::thread_mmap::consume+0x937>
mov    0x68(%rsp),%rdx
mov    %rax,%rsi
jmp    ADDR <arrays::thread_mmap::consume+0x940>
mov    %rax,%rdx
mov    %rcx,%rsi
jmp    ADDR <arrays::thread_mmap::consume+0x940>
xor    %edx,%edx
nopl   0x0(%rax)
lea    0x10(%rsp),%rdi
call   ADDR <arrays::borrowed>
mov    0x20(%rsp),%rsi
cmpl   $0x1,0x10(%rsp)
je     ADDR <arrays::thread_mmap::consume+0x11dd>
mov    0x18(%rsp),%rbp
mov    0x28(%rsp),%r13
mov    %rbp,0x90(%rsp)
cmpb   $0x0,0x1e30(%rsp)
je     ADDR <arrays::thread_mmap::consume+0xa1d>
movq   $0x0,0x10(%rsp)
movq   $0x1,0x18(%rsp)
movq   $0x3,0x20(%rsp)
movq   $0x5,0x28(%rsp)
mov    %ebx,%eax
and    $0x3,%eax
mov    %rbx,%rcx
shr    $0x2,%rcx
imul   0x1a8(%rsp),%rcx
mov    %eax,%edx
mov    0x10(%rsp,%rdx,8),%rdx
mov    0x1b0(%rsp),%rdi
imul   %rdi,%rdx
add    0x190(%rsp),%rcx
add    %rdx,%rcx
shr    $0x7,%rcx
mov    %rcx,0x120(%rsp)
cmp    %rcx,%rbp
jne    ADDR <arrays::thread_mmap::consume+0x1527>
mov    %r13,0x170(%rsp)
movq   $0x1,0x10(%rsp)
movq   $0x2,0x18(%rsp)
movq   $0x2,0x20(%rsp)
movq   $0x3,0x28(%rsp)
mov    0x10(%rsp,%rax,8),%rax
imul   %rdi,%rax
jmp    ADDR <arrays::thread_mmap::consume+0xa45>
mov    %r15,%rax
shr    $0x7,%rax
mov    %rax,0x120(%rsp)
cmp    %rax,%rbp
jne    ADDR <arrays::thread_mmap::consume+0x1527>
mov    %r13,0x170(%rsp)
mov    0x1e28(%rsp),%rax
mov    %rax,0x1c0(%rsp)
cmp    %rax,%r13
jne    ADDR <arrays::thread_mmap::consume+0x1540>
cmp    $0x400001,%r13
jae    ADDR <arrays::thread_mmap::consume+0x150b>
mov    0xb8(%rsp),%r12
mov    %r12,%rdi
mov    %r13,%rdx
call   *DISP(%rip)        # relocated data
mov    %rbp,%rdi
mov    %r12,%rsi
mov    0x48(%rsp),%r12
mov    %r13,%rdx
call   ADDR <arrays::verify>
add    %r13,0x1f0(%rsp)
cmpl   $0x3,0x148(%rsp)
je     ADDR <arrays::thread_mmap::consume+0x861>
mov    0x50(%rsp),%rax
test   %rax,%rax
lea    0xfe8(%rsp),%r13
mov    0xb0(%rsp),%rbp
je     ADDR <arrays::thread_mmap::consume+0xae6>
cmp    $0x2,%eax
jne    ADDR <arrays::thread_mmap::consume+0xadb>
cmpq   $0x0,0x58(%rsp)
je     ADDR <arrays::thread_mmap::consume+0x89f>
lea    0x60(%rsp),%rdi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x89f>
lea    0x58(%rsp),%rdi
call   *DISP(%rip)        # relocated data
mov    0x70(%rsp),%rax
lock decq (%rax)
jne    ADDR <arrays::thread_mmap::consume+0x89f>
lea    0x70(%rsp),%rdi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x89f>
mov    %rax,%rdx
mov    %rcx,%rsi
jmp    ADDR <arrays::thread_mmap::consume+0xb0f>
xor    %edx,%edx
lea    0x10(%rsp),%rdi
call   ADDR <arrays::borrowed>
cmpl   $0x1,0x10(%rsp)
je     ADDR <arrays::thread_mmap::consume+0x1342>
mov    0xa8(%rsp),%rsi
lea    (%rsi,%rsi,1),%rbx
mov    0x18(%rsp),%rdx
mov    0x20(%rsp),%rax
mov    0x28(%rsp),%rcx
mov    %rdx,0x178(%rsp)
mov    %rax,0x10(%rsp)
mov    %rcx,0x18(%rsp)
mov    %rbx,0x180(%rsp)
cmp    %rbx,%rdx
jne    ADDR <arrays::thread_mmap::consume+0x1645>
mov    %rsi,0x90(%rsp)
cmp    $0x8,%rcx
jne    ADDR <arrays::thread_mmap::consume+0x15c4>
cmp    %rsi,(%rax)
jne    ADDR <arrays::thread_mmap::consume+0x15c4>
mov    0x50(%rsp),%rax
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0xbac>
cmp    $0x2,%eax
jne    ADDR <arrays::thread_mmap::consume+0xba1>
cmpq   $0x0,0x58(%rsp)
je     ADDR <arrays::thread_mmap::consume+0xbc2>
lea    0x60(%rsp),%rdi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0xbc2>
lea    0x58(%rsp),%rdi
call   *DISP(%rip)        # relocated data
mov    0x70(%rsp),%rax
lock decq (%rax)
jne    ADDR <arrays::thread_mmap::consume+0xbc2>
lea    0x70(%rsp),%rdi
call   *DISP(%rip)        # relocated data
add    $0x68,%r14
lea    0x10(%rsp),%rdi
mov    %r15,%rsi
mov    %r14,%rdx
call   ADDR <arrays::thread_mmap::Follower::window>
mov    0x10(%rsp),%rdx
cmp    $0x3,%rdx
je     ADDR <arrays::thread_mmap::consume+0x1323>
mov    0x18(%rsp),%rcx
mov    0x20(%rsp),%rax
lea    0x28(%rsp),%rsi
movupd (%rsi),%xmm0
movapd %xmm0,0x90(%rsp)
mov    %rdx,0x50(%rsp)
mov    %rcx,0x58(%rsp)
mov    %rax,0x60(%rsp)
lea    0x58(%rsp),%rsi
movupd %xmm0,0x10(%rsi)
mov    $0x1,%esi
test   %rdx,%rdx
je     ADDR <arrays::thread_mmap::consume+0xc43>
cmp    $0x2,%edx
jne    ADDR <arrays::thread_mmap::consume+0xc39>
cmp    $0x1,%rcx
jne    ADDR <arrays::thread_mmap::consume+0xc41>
mov    0x68(%rsp),%rdx
mov    %rax,%rsi
jmp    ADDR <arrays::thread_mmap::consume+0xc43>
mov    %rax,%rdx
mov    %rcx,%rsi
jmp    ADDR <arrays::thread_mmap::consume+0xc43>
xor    %edx,%edx
lea    0x10(%rsp),%rdi
call   ADDR <arrays::borrowed>
cmpb   $0x0,0x10(%rsp)
jne    ADDR <arrays::thread_mmap::consume+0x1342>
mov    0x18(%rsp),%rdx
mov    0x20(%rsp),%rax
mov    0x28(%rsp),%rcx
mov    %rdx,0x178(%rsp)
mov    %rax,0x10(%rsp)
mov    %rcx,0x18(%rsp)
or     $0x1,%rbx
mov    %rbx,0x180(%rsp)
cmp    %rbx,%rdx
mov    0xa8(%rsp),%rdx
jne    ADDR <arrays::thread_mmap::consume+0x1645>
mov    %rdx,0x90(%rsp)
cmp    $0x8,%rcx
jne    ADDR <arrays::thread_mmap::consume+0x15c4>
cmp    %rdx,(%rax)
jne    ADDR <arrays::thread_mmap::consume+0x15c4>
mov    0x50(%rsp),%rax
test   %rax,%rax
lea    0xfe8(%rsp),%r13
je     ADDR <arrays::thread_mmap::consume+0xce8>
cmp    $0x2,%eax
jne    ADDR <arrays::thread_mmap::consume+0xcdd>
cmpq   $0x0,0x58(%rsp)
je     ADDR <arrays::thread_mmap::consume+0xcfe>
lea    0x60(%rsp),%rdi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0xcfe>
lea    0x58(%rsp),%rdi
call   *DISP(%rip)        # relocated data
mov    0x70(%rsp),%rax
lock decq (%rax)
jne    ADDR <arrays::thread_mmap::consume+0xcfe>
lea    0x70(%rsp),%rdi
call   *DISP(%rip)        # relocated data
addq   $0x2,0x200(%rsp)
mov    0x8(%rsp),%rax
mov    %rax,0x1f8(%rsp)
lea    0x1c8(%rsp),%rdi
call   *DISP(%rip)        # relocated data
movq   %rax,%xmm0
punpckldq DISP(%rip),%xmm0        # relocated data
subpd  DISP(%rip),%xmm0        # relocated data
movapd %xmm0,%xmm1
unpckhpd %xmm0,%xmm1
addsd  %xmm0,%xmm1
xorps  %xmm0,%xmm0
cvtsi2sd %edx,%xmm0
movsd  DISP(%rip),%xmm2        # relocated data
divsd  %xmm2,%xmm0
addsd  %xmm1,%xmm0
addsd  0x208(%rsp),%xmm0
movsd  %xmm0,0x208(%rsp)
xorpd  %xmm0,%xmm0
movapd %xmm0,0x10(%rsp)
mov    $0x3,%edi
lea    0x10(%rsp),%rsi
call   *DISP(%rip)        # relocated data
mov    %eax,0x50(%rsp)
test   %eax,%eax
jne    ADDR <arrays::thread_mmap::consume+0x1566>
xorps  %xmm0,%xmm0
cvtsi2sdq 0x10(%rsp),%xmm0
xorps  %xmm1,%xmm1
cvtsi2sdq 0x18(%rsp),%xmm1
divsd  DISP(%rip),%xmm1        # relocated data
addsd  %xmm0,%xmm1
subsd  0x118(%rsp),%xmm1
addsd  0x210(%rsp),%xmm1
movsd  %xmm1,0x210(%rsp)
call   *DISP(%rip)        # relocated data
mov    %rax,%rbx
mov    0x1e8(%rsp),%r14
mov    0x1f0(%rsp),%r15
cmp    0x1d8(%rsp),%r14
jne    ADDR <arrays::thread_mmap::consume+0xdfd>
lea    0x1d8(%rsp),%rdi
call   ADDR <alloc::raw_vec::RawVec<T,A>::grow_one>
sub    0x188(%rsp),%r15
mov    0x1e0(%rsp),%rax
lea    (%r14,%r14,2),%rcx
mov    0x1a0(%rsp),%rdx
mov    %rdx,(%rax,%rcx,8)
mov    %rbx,0x8(%rax,%rcx,8)
mov    %r15,0x10(%rax,%rcx,8)
inc    %r14
mov    %r14,0x1e8(%rsp)
mov    0xd0(%rsp),%rbp
mov    0xd8(%rsp),%rsi
cmp    $0x2,%rbp
jne    ADDR <arrays::thread_mmap::consume+0x495>
jmp    ADDR <arrays::thread_mmap::consume+0x4bd>
cmpq   $0x0,0x150(%rsp)
je     ADDR <arrays::thread_mmap::consume+0xe6a>
lea    0x158(%rsp),%rdi
call   *DISP(%rip)        # relocated data
cmpl   $0x2,0xfe0(%rsp)
jne    ADDR <arrays::thread_mmap::consume+0xe83>
lea    0xfe8(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<varlit_core::file::VarlitFile>>
jmp    ADDR <arrays::thread_mmap::consume+0xeac>
lea    0xfe0(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<varlit_core::file::VarlitFile>>
mov    0x1de0(%rsp),%rax
lock decq (%rax)
jne    ADDR <arrays::thread_mmap::consume+0xeac>
lea    0x1de0(%rsp),%rdi
call   *DISP(%rip)        # relocated data
mov    0xc0(%rsp),%rax
cmp    $0x2,%rax
je     ADDR <arrays::thread_mmap::consume+0xece>
cmp    $0x1,%eax
jne    ADDR <arrays::thread_mmap::consume+0xedd>
lea    0xc8(%rsp),%rdi
call   ADDR <std::sync::mpmc::counter::Sender<C>::release>
jmp    ADDR <arrays::thread_mmap::consume+0xf3a>
lea    0xc8(%rsp),%rdi
call   ADDR <std::sync::mpmc::counter::Sender<C>::release>
jmp    ADDR <arrays::thread_mmap::consume+0xf3a>
mov    0xc8(%rsp),%rbx
lock decq 0x200(%rbx)
jne    ADDR <arrays::thread_mmap::consume+0xf3a>
mov    0x80(%rbx),%rax
mov    0x190(%rbx),%rcx
nopl   (%rax)
mov    %rax,%rdx
or     %rcx,%rdx
lock cmpxchg %rdx,0x80(%rbx)
jne    ADDR <arrays::thread_mmap::consume+0xf00>
test   %rax,0x190(%rbx)
jne    ADDR <arrays::thread_mmap::consume+0xf26>
lea    0x140(%rbx),%rdi
call   ADDR <<std::sync::mpmc::waker::SyncWaker>::disconnect>
mov    $0x1,%al
xchg   %al,0x210(%rbx)
test   %al,%al
je     ADDR <arrays::thread_mmap::consume+0xf3a>
mov    %rbx,%rdi
call   ADDR <core::ptr::drop_in_place<alloc::boxed::Box<std::sync::mpmc::counter::Counter<std::sync::mpmc::array::Channel<()>>>>>
test   %r13b,%r13b
je     ADDR <arrays::thread_mmap::consume+0xf96>
lea    0x138(%rsp),%rdi
mov    0x130(%rsp),%rax
cmp    $0x2,%rax
je     ADDR <arrays::thread_mmap::consume+0xf61>
cmp    $0x1,%eax
jne    ADDR <arrays::thread_mmap::consume+0xf68>
call   ADDR <std::sync::mpmc::counter::Receiver<C>::release>
jmp    ADDR <arrays::thread_mmap::consume+0xf96>
call   ADDR <std::sync::mpmc::counter::Receiver<C>::release>
jmp    ADDR <arrays::thread_mmap::consume+0xf96>
mov    0x138(%rsp),%rbx
lock decq 0x208(%rbx)
jne    ADDR <arrays::thread_mmap::consume+0xf96>
mov    %rbx,%rdi
call   ADDR <std::sync::mpmc::array::Channel<T>::disconnect_receivers>
mov    $0x1,%al
xchg   %al,0x210(%rbx)
test   %al,%al
je     ADDR <arrays::thread_mmap::consume+0xf96>
mov    %rbx,%rdi
call   ADDR <core::ptr::drop_in_place<alloc::boxed::Box<std::sync::mpmc::counter::Counter<std::sync::mpmc::array::Channel<(usize,usize)>>>>>
mov    %r12,%rax
add    $0x1de8,%rsp
pop    %rbx
pop    %r12
pop    %r13
pop    %r14
pop    %r15
pop    %rbp
ret
call   *DISP(%rip)        # relocated data
mov    $0x18,%edi
mov    $0x1,%esi
call   *DISP(%rip)        # relocated data
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0x16f8>
mov    %rax,%r14
movupd DISP(%rip),%xmm0        # relocated data
movupd %xmm0,(%rax)
movabs $0x74756f2064656d69,%rax
mov    %rax,0x10(%r14)
call   *DISP(%rip)        # relocated data
mov    $0x18,%edi
mov    $0x8,%esi
call   *DISP(%rip)        # relocated data
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0x15af>
movq   $0x18,(%rax)
mov    %r14,0x8(%rax)
movq   $0x18,0x10(%rax)
mov    (%rsp),%rcx
mov    %rax,0x8(%rcx)
lea    DISP(%rip),%rax        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1114>
mov    0x58(%rsp),%rcx
mov    0x80(%rsp),%rdx
mov    %rdx,0x40(%rsp)
movups 0x70(%rsp),%xmm0
movups %xmm0,0x30(%rsp)
movupd 0x60(%rsp),%xmm0
movupd %xmm0,0x20(%rsp)
mov    %rax,0x10(%rsp)
mov    %rcx,0x18(%rsp)
call   *DISP(%rip)        # relocated data
mov    $0x38,%edi
mov    $0x8,%esi
call   *DISP(%rip)        # relocated data
test   %rax,%rax
jne    ADDR <arrays::thread_mmap::consume+0x10e0>
mov    $0x8,%edi
mov    $0x38,%esi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
mov    0x58(%rsp),%rcx
mov    0x80(%rsp),%rdx
mov    %rdx,0x40(%rsp)
movups 0x70(%rsp),%xmm0
movups %xmm0,0x30(%rsp)
movupd 0x60(%rsp),%xmm0
movupd %xmm0,0x20(%rsp)
mov    %rax,0x10(%rsp)
mov    %rcx,0x18(%rsp)
call   *DISP(%rip)        # relocated data
mov    $0x38,%edi
mov    $0x8,%esi
call   *DISP(%rip)        # relocated data
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0x1604>
mov    0x40(%rsp),%rcx
mov    %rcx,0x30(%rax)
movupd 0x10(%rsp),%xmm0
movups 0x20(%rsp),%xmm1
movups 0x30(%rsp),%xmm2
movups %xmm2,0x20(%rax)
movups %xmm1,0x10(%rax)
movupd %xmm0,(%rax)
mov    (%rsp),%rcx
mov    %rax,0x8(%rcx)
lea    DISP(%rip),%rax        # relocated data
mov    %rax,0x10(%rcx)
movabs $0x8000000000000000,%rax
mov    %rax,(%rcx)
mov    0xd0(%rsp),%rax
cmp    $0x2,%rax
je     ADDR <arrays::thread_mmap::consume+0x114d>
cmp    $0x1,%eax
jne    ADDR <arrays::thread_mmap::consume+0x1162>
mov    $0x1,%r15b
xor    %r13d,%r13d
lea    0xd8(%rsp),%rdi
call   ADDR <std::sync::mpmc::counter::Receiver<C>::release>
jmp    ADDR <arrays::thread_mmap::consume+0x119c>
mov    $0x1,%r15b
xor    %r13d,%r13d
lea    0xd8(%rsp),%rdi
call   ADDR <std::sync::mpmc::counter::Receiver<C>::release>
jmp    ADDR <arrays::thread_mmap::consume+0x119c>
mov    0xd8(%rsp),%rbx
lock decq 0x208(%rbx)
jne    ADDR <arrays::thread_mmap::consume+0x119c>
mov    $0x1,%r15b
xor    %r13d,%r13d
mov    %rbx,%rdi
call   ADDR <std::sync::mpmc::array::Channel<T>::disconnect_receivers>
mov    $0x1,%r15b
mov    $0x1,%al
xchg   %al,0x210(%rbx)
test   %al,%al
je     ADDR <arrays::thread_mmap::consume+0x119c>
xor    %r13d,%r13d
mov    %rbx,%rdi
call   ADDR <core::ptr::drop_in_place<alloc::boxed::Box<std::sync::mpmc::counter::Counter<std::sync::mpmc::array::Channel<(usize,usize)>>>>>
mov    $0x1,%bl
xor    %r13d,%r13d
mov    0x88(%rsp),%r15
mov    0x1d8(%rsp),%rax
test   %rax,%rax
jne    ADDR <arrays::thread_mmap::consume+0x342>
jmp    ADDR <arrays::thread_mmap::consume+0x35d>
mov    (%rsp),%rdx
mov    %rcx,0x8(%rdx)
mov    %rax,0x10(%rdx)
movabs $0x8000000000000000,%rax
mov    %rax,(%rdx)
jmp    ADDR <arrays::thread_mmap::consume+0x1125>
mov    0x18(%rsp),%rax
mov    (%rsp),%rcx
mov    %rax,0x8(%rcx)
mov    %rsi,0x10(%rcx)
movabs $0x8000000000000000,%rax
mov    %rax,(%rcx)
lea    0x50(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<arrays::thread_mmap::Window>>
jmp    ADDR <arrays::thread_mmap::consume+0x1125>
mov    $0x1,%r15b
xor    %r13d,%r13d
lea    0xd0(%rsp),%rdi
call   ADDR <<std::sync::mpmc::Receiver<T> as core::ops::drop::Drop>::drop>
mov    0x148(%rsp),%rdx
cmp    $0x3,%rdx
jne    ADDR <arrays::thread_mmap::consume+0x12bd>
call   *DISP(%rip)        # relocated data
mov    $0x10,%edi
mov    $0x1,%esi
call   *DISP(%rip)        # relocated data
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0x170a>
mov    %rax,%r14
movupd DISP(%rip),%xmm0        # relocated data
movupd %xmm0,(%rax)
mov    $0x18,%edi
mov    0x88(%rsp),%r15
call   ADDR <alloc::boxed::box_new_uninit>
movq   $0x10,(%rax)
mov    %r14,0x8(%rax)
movq   $0x10,0x10(%rax)
mov    (%rsp),%rcx
mov    %rax,0x8(%rcx)
lea    DISP(%rip),%rax        # relocated data
mov    %rax,0x10(%rcx)
movabs $0x8000000000000000,%rax
mov    %rax,(%rcx)
xor    %ebx,%ebx
xor    %r13d,%r13d
mov    0x1d8(%rsp),%rax
test   %rax,%rax
jne    ADDR <arrays::thread_mmap::consume+0x342>
jmp    ADDR <arrays::thread_mmap::consume+0x35d>
mov    0x140(%rsp),%rbx
mov    0x150(%rsp),%rcx
mov    0x158(%rsp),%rax
movupd 0x160(%rsp),%xmm0
movupd %xmm0,0x28(%rsp)
mov    %rbx,0x90(%rsp)
mov    %rdx,0x10(%rsp)
mov    %rcx,0x18(%rsp)
mov    %rax,0x20(%rsp)
mov    $0x1,%esi
test   %rdx,%rdx
je     ADDR <arrays::thread_mmap::consume+0x136d>
cmp    $0x2,%rdx
jne    ADDR <arrays::thread_mmap::consume+0x131b>
cmp    $0x1,%rcx
jne    ADDR <arrays::thread_mmap::consume+0x136b>
mov    0x28(%rsp),%rdx
mov    %rax,%rsi
jmp    ADDR <arrays::thread_mmap::consume+0x136d>
mov    %rax,%rdx
mov    %rcx,%rsi
jmp    ADDR <arrays::thread_mmap::consume+0x136d>
movups 0x18(%rsp),%xmm0
mov    (%rsp),%rax
movups %xmm0,0x8(%rax)
movabs $0x8000000000000000,%rcx
mov    %rcx,(%rax)
jmp    ADDR <arrays::thread_mmap::consume+0x1125>
movups 0x18(%rsp),%xmm0
mov    (%rsp),%rax
movups %xmm0,0x8(%rax)
movabs $0x8000000000000000,%rcx
mov    %rcx,(%rax)
lea    0x50(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<arrays::thread_mmap::Window>>
jmp    ADDR <arrays::thread_mmap::consume+0x1125>
xor    %edx,%edx
lea    0x50(%rsp),%r14
mov    %r14,%rdi
call   ADDR <arrays::borrowed>
mov    0x60(%rsp),%rsi
cmpl   $0x1,0x50(%rsp)
jne    ADDR <arrays::thread_mmap::consume+0x13bb>
mov    0x58(%rsp),%rax
mov    (%rsp),%rcx
mov    %rax,0x8(%rcx)
mov    %rsi,0x10(%rcx)
movabs $0x8000000000000000,%rax
mov    %rax,(%rcx)
xor    %r15d,%r15d
lea    0x10(%rsp),%rdi
xor    %r13d,%r13d
call   ADDR <core::ptr::drop_in_place<arrays::thread_mmap::Window>>
xor    %ebx,%ebx
jmp    ADDR <arrays::thread_mmap::consume+0x119e>
mov    0x58(%rsp),%rax
mov    0x68(%rsp),%rdx
mov    %rax,0x50(%rsp)
cmp    %rbx,%rax
jne    ADDR <arrays::thread_mmap::consume+0x166b>
mov    %rbx,%rdi
call   ADDR <arrays::verify>
mov    0x128(%rsp),%rax
cmp    %rax,0x1f0(%rsp)
jne    ADDR <arrays::thread_mmap::consume+0x167c>
xor    %eax,%eax
mov    0x88(%rsp),%r14
cmp    %rax,%r12
je     ADDR <arrays::thread_mmap::consume+0x1429>
cmpb   $0x0,(%r14,%rax,1)
lea    0x1(%rax),%rax
jne    ADDR <arrays::thread_mmap::consume+0x13fb>
lea    DISP(%rip),%rdi        # relocated data
lea    DISP(%rip),%rdx        # relocated data
mov    $0x29,%esi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
movupd 0x1d8(%rsp),%xmm0
movupd 0x1e8(%rsp),%xmm1
movupd 0x1f8(%rsp),%xmm2
movups 0x208(%rsp),%xmm3
mov    (%rsp),%rax
movups %xmm3,0x30(%rax)
movupd %xmm2,0x20(%rax)
movupd %xmm1,0x10(%rax)
movupd %xmm0,(%rax)
lea    0x10(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<arrays::thread_mmap::Window>>
test   %r12,%r12
je     ADDR <arrays::thread_mmap::consume+0x1482>
mov    $0x1,%edx
mov    %r14,%rdi
mov    %r12,%rsi
call   *DISP(%rip)        # relocated data
mov    $0x400000,%esi
mov    $0x1,%edx
mov    0xb8(%rsp),%rdi
call   *DISP(%rip)        # relocated data
mov    0xf8(%rsp),%rax
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0x14be>
mov    0x100(%rsp),%rdi
imul   $0x68,%rax,%rsi
mov    $0x8,%edx
call   *DISP(%rip)        # relocated data
mov    0xe0(%rsp),%rax
test   %rax,%rax
mov    (%rsp),%r12
je     ADDR <arrays::thread_mmap::consume+0x14e6>
mov    0xe8(%rsp),%rdi
imul   $0x68,%rax,%rsi
mov    $0x8,%edx
call   *DISP(%rip)        # relocated data
xor    %r13d,%r13d
lea    0xfe0(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<arrays::thread_mmap::Follower>>
xor    %r13d,%r13d
lea    0xc0(%rsp),%rdi
call   ADDR <<std::sync::mpmc::Sender<T> as core::ops::drop::Drop>::drop>
jmp    ADDR <arrays::thread_mmap::consume+0xf96>
lea    DISP(%rip),%rcx        # relocated data
mov    $0x400000,%edx
xor    %edi,%edi
mov    %r13,%rsi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
lea    DISP(%rip),%r9        # relocated data
lea    0x120(%rsp),%rdx
lea    0x90(%rsp),%rsi
jmp    ADDR <arrays::thread_mmap::consume+0x1557>
lea    0x170(%rsp),%rsi
lea    0x1c0(%rsp),%rdx
lea    DISP(%rip),%r9        # relocated data
xor    %edi,%edi
xor    %ecx,%ecx
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
lea    DISP(%rip),%rdx        # relocated data
lea    DISP(%rip),%r9        # relocated data
xor    %edi,%edi
mov    0x198(%rsp),%rsi
xor    %ecx,%ecx
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
mov    $0x1,%r15b
lea    DISP(%rip),%rdi        # relocated data
lea    DISP(%rip),%rdx        # relocated data
mov    $0x28,%esi
mov    $0x1,%r13b
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
mov    $0x8,%edi
mov    $0x18,%esi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
lea    DISP(%rip),%r9        # relocated data
lea    0x10(%rsp),%rsi
lea    0x90(%rsp),%rdx
xor    %edi,%edi
xor    %ecx,%ecx
call   ADDR <core::panicking::assert_failed>
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
lea    DISP(%rip),%rdi        # relocated data
lea    DISP(%rip),%rdx        # relocated data
mov    $0x1e,%esi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
mov    $0x8,%edi
mov    $0x38,%esi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
mov    %rax,0x8(%rsp)
lea    DISP(%rip),%rax        # relocated data
mov    %rax,0x110(%rsp)
mov    0x8(%rsp),%rsi
mov    0x110(%rsp),%rcx
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
lea    DISP(%rip),%r9        # relocated data
lea    0x178(%rsp),%rsi
lea    0x180(%rsp),%rdx
xor    %edi,%edi
xor    %ecx,%ecx
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
lea    DISP(%rip),%r9        # relocated data
lea    0x90(%rsp),%rdx
jmp    ADDR <arrays::thread_mmap::consume+0x1693>
lea    DISP(%rip),%r9        # relocated data
lea    0x1e20(%rsp),%rdx
lea    0x1f0(%rsp),%r14
xor    %edi,%edi
mov    %r14,%rsi
xor    %ecx,%ecx
mov    0x48(%rsp),%r12
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
test   %rbx,%rbx
lea    DISP(%rip),%rax        # relocated data
lea    DISP(%rip),%rdi        # relocated data
cmove  %rax,%rdi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
mov    $0x1,%edi
mov    $0x400000,%esi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
mov    $0x1,%edi
mov    %r12,%rsi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
lea    DISP(%rip),%rdx        # relocated data
mov    %r12,%rsi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
mov    $0x1,%edi
mov    $0x18,%esi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x1720>
xor    %r15d,%r15d
mov    $0x1,%edi
mov    $0x10,%esi
xor    %r13d,%r13d
call   *DISP(%rip)        # relocated data
ud2
mov    %rax,%rbx
xor    %r15d,%r15d
xor    %r13d,%r13d
jmp    ADDR <arrays::thread_mmap::consume+0x1924>
mov    %rax,%rbx
mov    $0x10,%esi
mov    $0x1,%edx
mov    %r14,%rdi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x185b>
mov    %rax,%rbx
mov    0x70(%rsp),%rax
lock decq (%rax)
jne    ADDR <arrays::thread_mmap::consume+0x188a>
lea    0x70(%rsp),%rdi
call   *DISP(%rip)        # relocated data
mov    0x48(%rsp),%r12
jmp    ADDR <arrays::thread_mmap::consume+0x18e1>
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x18b4>
mov    %rax,%rbx
mov    0x70(%rsp),%rax
lock decq (%rax)
jne    ADDR <arrays::thread_mmap::consume+0x188a>
lea    0x70(%rsp),%rdi
call   *DISP(%rip)        # relocated data
mov    0x48(%rsp),%r12
jmp    ADDR <arrays::thread_mmap::consume+0x18e1>
call   *DISP(%rip)        # relocated data
mov    %rax,%rbx
mov    0x168(%rsp),%rax
lock decq (%rax)
jne    ADDR <arrays::thread_mmap::consume+0x19c0>
lea    0x168(%rsp),%rdi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x19c0>
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x18cf>
mov    %rax,%rbx
jmp    ADDR <arrays::thread_mmap::consume+0x19c0>
mov    %rax,%rbx
mov    0x1de0(%rsp),%rax
lock decq (%rax)
jne    ADDR <arrays::thread_mmap::consume+0x19cd>
lea    0x1de0(%rsp),%rdi
call   *DISP(%rip)        # relocated data
jmp    ADDR <arrays::thread_mmap::consume+0x19cd>
call   *DISP(%rip)        # relocated data
mov    %rax,%rbx
mov    $0x1,%r15b
mov    $0x1,%r13b
jmp    ADDR <arrays::thread_mmap::consume+0x193a>
jmp    ADDR <arrays::thread_mmap::consume+0x18cf>
mov    %rax,%rbx
mov    $0x1,%r15b
mov    $0x1,%r13b
jmp    ADDR <arrays::thread_mmap::consume+0x1952>
jmp    ADDR <arrays::thread_mmap::consume+0x18d4>
mov    %rax,%rbx
jmp    ADDR <arrays::thread_mmap::consume+0x19da>
mov    %rax,%rbx
jmp    ADDR <arrays::thread_mmap::consume+0x19cd>
jmp    ADDR <arrays::thread_mmap::consume+0x18cf>
mov    %rax,%rbx
lea    0x10(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<arrays::thread_mmap::Window>>
xor    %r13d,%r13d
xor    %r15d,%r15d
jmp    ADDR <arrays::thread_mmap::consume+0x18f4>
jmp    ADDR <arrays::thread_mmap::consume+0x18cf>
mov    %rax,%rbx
lea    0x10(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<varlit_core::error::Error>>
jmp    ADDR <arrays::thread_mmap::consume+0x188a>
call   *DISP(%rip)        # relocated data
mov    %rax,%rbx
lea    0x10(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<varlit_core::error::Error>>
mov    0x48(%rsp),%r12
jmp    ADDR <arrays::thread_mmap::consume+0x18e1>
call   *DISP(%rip)        # relocated data
mov    %rax,%rbx
mov    $0x18,%esi
mov    $0x1,%edx
mov    %r14,%rdi
call   *DISP(%rip)        # relocated data
mov    0x48(%rsp),%r12
jmp    ADDR <arrays::thread_mmap::consume+0x18e1>
mov    %rax,%rbx
lea    0x50(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<arrays::thread_mmap::Window>>
mov    0x48(%rsp),%r12
jmp    ADDR <arrays::thread_mmap::consume+0x18e1>
jmp    ADDR <arrays::thread_mmap::consume+0x18cf>
mov    %rax,%rbx
jmp    ADDR <arrays::thread_mmap::consume+0x18f4>
mov    %rax,%rbx
jmp    ADDR <arrays::thread_mmap::consume+0x18e1>
mov    %rax,%rbx
lea    0x50(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<arrays::thread_mmap::Window>>
lea    0xd0(%rsp),%rdi
call   ADDR <<std::sync::mpmc::Receiver<T> as core::ops::drop::Drop>::drop>
mov    $0x1,%r15b
xor    %r13d,%r13d
mov    0x1d8(%rsp),%rax
test   %rax,%rax
mov    0x88(%rsp),%r14
je     ADDR <arrays::thread_mmap::consume+0x1924>
mov    0x1e0(%rsp),%rdi
shl    $0x3,%rax
lea    (%rax,%rax,2),%rsi
mov    $0x8,%edx
call   *DISP(%rip)        # relocated data
test   %r12,%r12
je     ADDR <arrays::thread_mmap::consume+0x193a>
mov    $0x1,%edx
mov    %r14,%rdi
mov    %r12,%rsi
call   *DISP(%rip)        # relocated data
mov    $0x400000,%esi
mov    $0x1,%edx
mov    0xb8(%rsp),%rdi
call   *DISP(%rip)        # relocated data
mov    0xf8(%rsp),%rax
test   %rax,%rax
jne    ADDR <arrays::thread_mmap::consume+0x1973>
mov    0xe0(%rsp),%rax
test   %rax,%rax
jne    ADDR <arrays::thread_mmap::consume+0x1997>
test   %r15b,%r15b
jne    ADDR <arrays::thread_mmap::consume+0x19b3>
jmp    ADDR <arrays::thread_mmap::consume+0x19c0>
mov    0x100(%rsp),%rdi
imul   $0x68,%rax,%rsi
mov    $0x8,%edx
call   *DISP(%rip)        # relocated data
mov    0xe0(%rsp),%rax
test   %rax,%rax
je     ADDR <arrays::thread_mmap::consume+0x196c>
mov    0xe8(%rsp),%rdi
imul   $0x68,%rax,%rsi
mov    $0x8,%edx
call   *DISP(%rip)        # relocated data
test   %r15b,%r15b
je     ADDR <arrays::thread_mmap::consume+0x19c0>
lea    0x140(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<core::option::Option<(usize,arrays::thread_mmap::Window)>>>
lea    0xfe0(%rsp),%rdi
call   ADDR <core::ptr::drop_in_place<arrays::thread_mmap::Follower>>
lea    0xc0(%rsp),%rdi
call   ADDR <<std::sync::mpmc::Sender<T> as core::ops::drop::Drop>::drop>
test   %r13b,%r13b
je     ADDR <arrays::thread_mmap::consume+0x19ec>
lea    0x130(%rsp),%rdi
call   ADDR <<std::sync::mpmc::Receiver<T> as core::ops::drop::Drop>::drop>
mov    %rbx,%rdi
call   ADDR <_Unwind_Resume@plt>
call   *DISP(%rip)        # relocated data
