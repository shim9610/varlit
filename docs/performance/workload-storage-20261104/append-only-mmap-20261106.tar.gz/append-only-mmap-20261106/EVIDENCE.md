# Append-only mmap session evidence

Final results: primary-final-v1 (seven repeats; final metadata-only Debug). Earlier prototype: primary-v1. Resource-options correction before Debug: primary-v2. calibration-v1 and calibration-alerts-v1 use the primary-v2 binary and retain all 30 fixed rounds; never pool these cohorts or apply their qualification to a different binary.

unit1-control-v1 tests the unchanged immutable buffered/mmap routes before and after initial admission implementation. smoke-v1/v2/v3 retain functional pilot attempts. The actual partial-defaults runtime failure and its correction are retained in logs.

Each cohort contains raw JSONL, manifests, OOM counter snapshots, harness source and worktree patch against the source base. final-runtime.patch retains final library/tests/guide/harness changes. Two final binaries are included; all older binaries remain identified by hash with their source/patch/build logs. The standalone harness needs native SQLite/HDF5 installations to link, although this study executes only Varlit. Commands are in the source README and repository harness guide.

Executable text changed after the final diagnostic refinement, so primary-final-v1 was rebuilt and fully remeasured. reviewed-text-hashes.log records the difference; it is not an equivalence claim.
