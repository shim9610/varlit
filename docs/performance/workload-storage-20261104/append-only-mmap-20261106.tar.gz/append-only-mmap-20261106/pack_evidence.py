from pathlib import Path
import hashlib
import tarfile

ev = Path(__file__).parent
root = Path('/workspace/varlit')
cohorts = ['unit1-control-v1', 'smoke-v1', 'smoke-v2', 'smoke-v3', 'primary-v1',
           'primary-v2', 'primary-final-v1', 'calibration-v1', 'calibration-alerts-v1']
files = []
for cohort in cohorts:
    directory = ev / cohort
    for name in ['manifest.json', 'results.jsonl', 'memory-before.txt', 'memory-after.txt', 'worktree.patch']:
        path = directory / name
        if path.exists():
            files.append(path)
    files.extend(p for p in (directory / 'source').rglob('*') if p.is_file())
files.extend(ev.glob('*.log'))
files += [ev / name for name in ['environment.json', 'EVIDENCE.md', 'final-runtime.patch',
    'write_report.py', 'control_unit1.py', 'pack_evidence.py', 'dashboard.png'] if (ev / name).exists()]
files += [ev / 'bin/final-before/arrays', ev / 'bin/reviewed/arrays']
archive = root / 'docs/performance/workload-storage-20261104/append-only-mmap-20261106.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for path in sorted(set(files)):
        tar.add(path, arcname='append-only-mmap-20261106/' + str(path.relative_to(ev)), recursive=False)
print(len(set(files)), 'files;', archive.stat().st_size, 'bytes; SHA256', hashlib.sha256(archive.read_bytes()).hexdigest())
