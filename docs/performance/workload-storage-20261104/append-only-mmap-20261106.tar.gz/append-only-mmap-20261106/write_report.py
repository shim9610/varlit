import json
from pathlib import Path
import statistics

ROOT = Path('/workspace/varlit')
EVIDENCE = Path(__file__).parent

def load(cohort):
    groups = {}
    for line in (EVIDENCE / cohort / 'results.jsonl').open():
        r = json.loads(line)
        assert not r.get('error') and r['result']['verified']
        p = r['profile']
        groups.setdefault(p['workload'], {}).setdefault(p['variant'], []).append(r)
    result = {}
    for workload, variants in groups.items():
        result[workload] = {}
        for variant, rows in variants.items():
            times = [r for r in rows if not r['probe']]
            probes = [r for r in rows if r['probe']]
            assert len(probes) == 1
            m = {k: statistics.median(r['result'][s] for r in times) for k, s in
                 [('write', 'writer_seconds'), ('read', 'reader_active_seconds')]}
            m.update({k: statistics.median(r['usage'][s] for r in times) for k, s in
                      [('completion', 'elapsed_seconds'), ('cpu', 'cpu')]})
            m['pss'] = probes[0]['sampled_peaks']['pss_sum'] / 2**20
            m['temp'] = probes[0]['sampled_peaks']['temporary_allocated'] / 2**20
            m['deleted'] = probes[0]['sampled_peaks']['deleted_open_allocated'] / 2**20
            m['allocated'] = times[0]['result']['allocated_bytes'] / 2**20
            fractions = []
            for r in times:
                x = r['result']
                if x['warm_seconds']:
                    continue
                fractions.append(min(sum(n for a, b, n in t['intervals']
                    if a >= x['writer_start_ns'] and b <= x['writer_end_ns'])
                    for t in x['reader_stats']) / r['profile']['total'] * 100)
            m['during'] = statistics.median(fractions) if fractions else None
            m['p'] = times[0]['profile']
            result[workload][variant] = m
    return result

def label(p):
    phase = 'Live 1 GiB' if p['command_tail'][0] == 'session-live' else f'Warm {p["total"]//2**20} MiB'
    return f'{phase}, {p["group"]//1024} KiB, {p["readers"]} readers' + (' / 4 producers, variable' if p['complex'] else '')

final = load('primary-final-v1')
lines = ['## Protected append-only mmap sessions', '',
    'The new `mmap` facade keeps native writer exclusion alive through the last',
    'token, reader or owned mapping. Admission remains unsafe because external',
    'nonparticipants can bypass advisory locking; derived session mappings have',
    'safe entry points. Matrix storage and editable conversion are excluded.',
    'See the [API contract](../../api-reference.md#append-only-mmap-sessions).', '',
    'The final implementation is compared with `a3a1e26` across 12 equal-work',
    'conditions, seven fixed repetitions and 48 separate resource probes.',
    'Earlier prototype and resource-options corrections each retain their own',
    '336 timings and 48 probes. Two fixed 30-round calibrations of those earlier',
    'phase alerts add 450 timings and 15 probes. All **1,458 timings and 159 probes**',
    'remain separate in the dashboard’s **Append-only ownership** scope; they are',
    'not pooled. The final cohort includes the metadata-only empty-snapshot',
    '`Debug` refinement and was rebuilt and remeasured after executable text',
    'changed. The earlier calibrations do not qualify that final binary.', '',
    'This fixture uses one process, one active writer and independent reader',
    'threads, unlike the preceding SQLite live cohort’s reader processes. Every',
    'live reader verifies all 1 GiB during append plus final drain. Warm readers',
    'each scan all 128 MiB/1 GiB twice after writing, using one fixed snapshot.',
    'There are no random queries. Blocks average 64 KiB or 1 MiB; 16 MiB durable',
    'publications give 64 transactions and 16,384/1,024 data records per 1 GiB.',
    'Four-producer cases use bounded MPSC, variable block lengths and two metadata',
    'records per publication. Every metadata value and payload byte is checked.', '',
    '### Final 1 GiB live measurements', '',
    'Each pair below is **new ordinary mmap / new guarded mmap**, from the same',
    'binary. The dashboard also retains both identical old-runtime A/B controls.',
    'Writer-active includes input generation, queue handoff and publications;',
    'reader-active is the maximum worker’s refresh plus verified reading, including',
    'drain. Completion includes startup and cleanup; overlapping timers are not',
    'additive. CPU is kernel wait4 user+system for all threads. During-write counts',
    'only full consume intervals inside the writer window for the least-advanced',
    'guarded reader.', '',
    '| Blocks / readers / producers | Writer s | Reader-active s | Completion s | CPU s | Guarded during-write % |',
    '|---|---:|---:|---:|---:|---:|']
for work, variants in sorted(final.items()):
    raw, guarded = variants['after-raw'], variants['after-guarded']
    if raw['p']['command_tail'][0] != 'session-live':
        continue
    p = raw['p']
    name = f'{p["group"]//1024} KiB / {p["readers"]} / {p["producers"]}' + (' variable' if p['complex'] else '')
    lines.append('| ' + name + ' | ' + ' | '.join(f'{raw[k]:.3f} / {guarded[k]:.3f}'
        for k in ['write', 'read', 'completion', 'cpu']) + f' | {guarded["during"]:.2f} |')
lines += ['', 'All four read-check variants remain supported by the API; this performance',
    'cohort holds FULL checks fixed. No read limit or 4 CPU / 16 GiB / 32 GiB budget',
    'is raised. Mapping/unmapping, checksums, byte verification and fixed-snapshot',
    'index copies remain charged. Native record-window follow stops at its last',
    'cached record; it does not copy/revalidate the entire old prefix per poll.', '',
    '### Retained alerts and fixed calibration', '',
    'The prototype has warm reader-phase alerts of +7.03% (1 GiB/64 KiB) and',
    '+6.46% (128 MiB/1 MiB), plus +5.41% writer time (1 GiB/1 MiB), all with eight',
    'readers. The corrected-options cohort also observes live 1 MiB/eight-reader',
    'CPU +6.39% and reader-active +12.31%, warm 1 GiB/64 KiB CPU +5.34% and',
    'reader-active +6.23%, and 128 MiB/64 KiB writer-active +11.93%. These initial',
    'medians remain visible. An identical old-runtime A/B CPU pair differs by',
    '−10.70% in that cohort. No alert is converted to a pass by pooling repeats.', '',
    'The fixed 30-round comparisons below use one binary’s raw A/B and guarded',
    'routes, with all six execution orders occurring five times. Changes are',
    'guarded / raw A; the last column retains the raw B / raw A CPU control.', '',
    '| Condition | Writer change | Reader-active change | Completion change | CPU change | Raw B CPU change |',
    '|---|---:|---:|---:|---:|---:|']
for cohort in ['calibration-v1', 'calibration-alerts-v1']:
    for work, variants in sorted(load(cohort).items()):
        a, b, guarded = (variants[k] for k in ['raw-a', 'raw-b', 'guarded'])
        lines.append('| ' + label(a['p']) + ' | ' + ' | '.join(
            f'{100*(guarded[k]/a[k]-1):+.2f}%' for k in ['write', 'read', 'completion', 'cpu'])
            + f' | {100*(b["cpu"]/a["cpu"]-1):+.2f}% |')
lines += ['', 'The short 128 MiB/64 KiB calibration retains a **+5.01% CPU** median.',
    'The calibration therefore does not establish a blanket 5% bound, even though',
    'the larger initial phase alerts do not persist at those magnitudes. The',
    'final implementation’s own medians and repeat spreads remain separate.', '',
    'The final seven-run cohort also retains alerts: guarded versus new ordinary',
    'mmap at live 1 GiB/1 MiB/one reader is +6.85% completion and +13.32% CPU',
    '(writer +6.72%, reader-active +11.34%). The 128 MiB/eight-reader warm cases',
    'show +5.85% writer time at 1 MiB and +6.75% CPU at 64 KiB. Ordinary mmap also',
    'shows +7.90% CPU versus old A at live 1 MiB/eight readers and +5.43% with four',
    'producers. Identical old-runtime A/B controls vary by up to 9.17% completion',
    'and 7.98% CPU in this final cohort. These controls leave attribution unresolved;',
    'they do not erase the measured increases or establish a 5% regression pass.', '',
    '### Memory, storage and evidence', '']
for phase in ['session-live', 'session-warm']:
    subset = [vs for vs in final.values() if vs['after-raw']['p']['command_tail'][0] == phase]
    name = 'Live' if phase == 'session-live' else 'Two-pass warm'
    ranges = [f'{min(vs[v]["pss"] for vs in subset):.1f}–{max(vs[v]["pss"] for vs in subset):.1f}'
              for v in ['after-raw', 'after-guarded']]
    lines.append(f'{name} sampled process PSS is {ranges[0]} MiB ordinary / {ranges[1]} MiB guarded.')
for variants in final.values():
    assert len({r['allocated'] for r in variants.values()}) == 1
    assert all(r['temp'] == 0 and r['deleted'] == 0 for r in variants.values())
lines += ['', 'Every matched variant has identical final allocated storage; temporary and',
    'deleted-open peaks are zero in the final probes. Warm mappings touch the',
    'whole file, so residency can approach the dataset size. Probes sample every',
    '50 ms and can miss brief peaks; file-cache/cgroup baselines and RSS are',
    'exported separately and must not be added to PSS as independent residency.',
    'No cohort records a new OOM or OOM-kill event. Four unchanged-path unit',
    'controls also retain 84 timings and 12 probes in the archive.', '',
    'The facade adds one fallible shared-protection allocation at admission and',
    'shared ownership at token/map construction and release. Payload access and',
    'ordinary append acquire no new lock or lease clone. This does not remove',
    'existing mapping, validation and indexing costs or promise zero overhead.',
    'Native regressions cover staged/confirmed visibility, rollback and failed',
    'rollback, durability retry, aliases, writer-first drop, concurrent registration',
    'and release, panic cleanup, partial resource defaults and all read policies.', '',
    '[Raw observations, manifests, sources, patches and verification logs](append-only-mmap-20261106.tar.gz)',
    'are covered by [checksums](CURRENT_SHA256SUMS). The [harness protocol and commands](../../../tools/storage-bench/README.md#append-only-ownership-comparison)',
    'reproduce the cohorts. No new SQLite/HDF5 measurements or cross-engine ratios',
    'are inferred from this ownership study.', '']
path = ROOT/'docs/performance/workload-storage-20261104/README.md'
text = path.read_text()
start = text.find('## Protected append-only mmap sessions')
end = text.index('## SQLite mmap and append-only readers')
if start >= 0:
    text = text[:start] + text[end:]
end = text.index('## SQLite mmap and append-only readers')
path.write_text(text[:end] + '\n'.join(lines) + '\n' + text[end:])
