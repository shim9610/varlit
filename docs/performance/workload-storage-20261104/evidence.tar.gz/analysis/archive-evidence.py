from pathlib import Path
import tarfile,hashlib,json,sys,platform,subprocess,os
base=Path('/workspace/scratch/storage-bench-20261104');repo=Path('/workspace/varlit');out=repo/'docs/performance/workload-storage-20261104'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
model=next((x.split(':',1)[1].strip()for x in Path('/proc/cpuinfo').read_text().splitlines()if x.startswith('model name')),'unknown')
env=dict(system=platform.system(),kernel=platform.release(),architecture=platform.machine(),cpu_model=model,python=platform.python_version(),rustc=subprocess.check_output(['/workspace/tooling/cargo/bin/rustc','-Vv'],text=True),compiler=subprocess.check_output(['cc','--version'],text=True).splitlines()[0],cpu_max=Path('/sys/fs/cgroup/cpu.max').read_text().strip(),memory_max=Path('/sys/fs/cgroup/memory.max').read_text().strip(),filesystem_total=os.statvfs(base).f_blocks*os.statvfs(base).f_frsize,native_libraries={str(p):digest(p)for p in [Path('/lib/x86_64-linux-gnu/libsqlite3.so.0'),Path('/lib/x86_64-linux-gnu/libhdf5_serial.so.310')]})
(out/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
cohorts=['full-v1','full-v2','full-v3','full-v4','sqlite-tuning-v1','sqlite-tuning-v2','conformance-v1','conformance-v2','conformance-v3','conformance-v4','conformance-v5','conformance-v6','conformance-v7','guard-conformance','hdf-identical-binary-control','packed-v1','hdf-mixed-v1','mapped-arrays-v1','mapped-warm-v1','fixed-probe-conformance','resources-corrected-v1']
entries={}
for name in cohorts:
 folder=base/name
 if not folder.exists():continue
 for p in folder.rglob('*'):
  if not p.is_file():continue
  parts=p.relative_to(folder).parts
  if any(x.endswith(('.work','.tmp'))for x in parts):continue
  if any(x in ['data','target','__pycache__']for x in parts):continue
  if p.stat().st_size>32<<20:raise RuntimeError(f'unexpected large evidence input {p}')
  entries['runs/'+str(p.relative_to(base))]=p
for p in (base/'smoke').iterdir():
 if p.is_file()and p.suffix in ['.out','.err']:entries['prototype-smoke/'+p.name]=p
for pattern in ['config.json','table-config.json','mixed-stress.json','table-stress.json','*.config.json','compact-*.stdout','compact-*.stderr','matrix-companion-*.stdout','matrix-companion-*.stderr','packed-*.stdout','packed-*.stderr','hdf-fitted-*.stdout','hdf-fitted-*.stderr','native-mapped-smoke-*.stdout','native-mapped-smoke-*.stderr']:
 for p in base.glob(pattern):
  if p.is_file():entries['focused/'+p.name]=p
for p in (repo/'tools/storage-bench').rglob('*'):
 if p.is_file()and not any(x in ['target','__pycache__']for x in p.relative_to(repo/'tools/storage-bench').parts):entries['current-tool/'+str(p.relative_to(repo/'tools/storage-bench'))]=p
for name in ['write-report.py','archive-evidence.py']:entries['analysis/'+name]=base/name
for name in ['README.md','comparison.json','operations.md','resources.csv','environment.json']:entries['report/'+name]=out/name
metadata=dict(configurations=122,successful_timing_observations=360,successful_corrected_resource_probes=120,retained_limit_refusals=8,archive_files=[dict(path=k,bytes=p.stat().st_size,sha256=digest(p))for k,p in sorted(entries.items())],excluded_from_final_resource_metrics='Original five timing cohorts resource sampler observations; replaced by resources-corrected-v1. wait4 data retained. First too-short corrected mapping sample retained as unqualified.',excluded_tuning='sqlite-tuning-v1 follow-only schema had unused key index; v2 selects complete winners.',local_large_failure=json.loads((base/'full-v1/lossless-failure-artifact.json').read_text()),local_large_failure_path=str(base/'full-v1/timing-0-objects-follow-varlit-indexed.work/data/store.vki.gz'),large_database_payloads_in_archive=False)
manifest=out/'evidence-manifest.json';manifest.write_text(json.dumps(metadata,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=6)as tar:
 for name,p in sorted(entries.items()):
  info=tar.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with p.open('rb')as f:tar.addfile(info,f)
 info=tar.gettarinfo(str(manifest),arcname='evidence-manifest.json');info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
 with manifest.open('rb')as f:tar.addfile(info,f)
(out/'SHA256SUMS').write_text(''.join(f'{digest(out/name)}  {name}\n'for name in ['evidence.tar.gz','evidence-manifest.json','comparison.json','operations.md','resources.csv','environment.json']))
print('archive',len(entries),'files',round((out/'evidence.tar.gz').stat().st_size/2**20,2),'MiB')
