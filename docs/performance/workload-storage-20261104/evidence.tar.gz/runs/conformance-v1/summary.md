# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r2-varlit-stream | 1 | 0.007803 | 0.037320 | 0.038152 | 10.39 | 1.52 |
| mixed-p65536-r2-varlit-indexed | 1 | 0.020857 | 0.065173 | 0.041547 | 10.37 | 1.58 |
| mixed-p65536-r2-sqlite | 1 | 0.005879 | 0.064171 | 0.035189 | 10.41 | 1.53 |
| mixed-p65536-r2-hdf5 | 1 | 0.006517 | 0.032366 | 0.040819 | 13.26 | 2.01 |
| objects-follow-varlit-stream | 1 | 0.016832 | 0.068790 | 0.037531 | 8.93 | 0.08 |
| objects-follow-varlit-indexed | 1 | 0.015806 | 0.064130 | 0.043873 | 8.93 | 0.40 |
| objects-follow-sqlite | 1 | 0.003351 | 0.031971 | 0.027289 | 8.63 | 0.05 |
| objects-follow-hdf5 | 1 | 0.003909 | 0.031829 | 0.031257 | 9.38 | 0.04 |
| objects-keyed-varlit-indexed | 1 | 0.017915 | 0.065203 | 0.039075 | 8.95 | 0.40 |
| objects-keyed-sqlite | 1 | 0.003627 | 0.064182 | 0.035817 | 8.79 | 0.05 |
| table-w4-varlit-indexed | 1 | 0.058413 | 0.114347 | 0.084359 | 8.94 | 1.39 |
| table-w4-varlit-matrix | 1 | 0.038475 | 0.064131 | 0.056423 | 9.49 | 1.22 |
| table-w4-sqlite | 1 | 0.022742 | 0.065328 | 0.039614 | 9.27 | 0.10 |
| table-w4-hdf5 | 1 | 0.015010 | 0.064077 | 0.048162 | 9.79 | 0.08 |
| array-n16777216-g1048576-native-view | 1 | 0.016143 | 0.064271 | 0.029947 | 25.14 | 16.00 |
| array-n16777216-g1048576-stream | 1 | 0.025294 | 0.064754 | 0.034016 | 30.24 | 16.03 |
| array-n16777216-g1048576-indexed | 1 | 0.020425 | 0.064587 | 0.035232 | 30.44 | 16.04 |
| array-n16777216-g1048576-matrix-mmap | 1 | 0.071100 | 0.114234 | 0.091994 | 29.41 | 16.15 |
| array-n16777216-g1048576-sql-columns | 1 | 0.200085 | 0.314861 | 0.273059 | 31.75 | 19.75 |
| array-n16777216-g1048576-sql-chunks | 1 | 0.050610 | 0.114265 | 0.060744 | 32.46 | 16.03 |
| array-n16777216-g1048576-hdf-contiguous-bulk | 1 | 0.020280 | 0.064120 | 0.028956 | 40.86 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-bulk | 1 | 0.023947 | 0.064220 | 0.040974 | 50.12 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-fletcher-bulk | 1 | 0.037935 | 0.115281 | 0.070525 | 51.03 | 16.00 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
