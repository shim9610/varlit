# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r2-varlit-stream | 1 | 0.011742 | 0.031805 | 0.036343 | 10.19 | 1.52 |
| mixed-p65536-r2-varlit-indexed | 1 | 0.009657 | 0.029324 | 0.033840 | 10.36 | 1.58 |
| mixed-p65536-r2-sqlite | 1 | 0.009583 | 0.035416 | 0.038073 | 10.41 | 1.53 |
| mixed-p65536-r2-hdf5 | 1 | 0.009431 | 0.033520 | 0.046202 | 13.41 | 2.01 |
| objects-follow-varlit-stream | 1 | 0.023401 | 0.047418 | 0.047114 | 8.96 | 0.08 |
| objects-follow-varlit-indexed | 1 | 0.019877 | 0.040180 | 0.041097 | 8.95 | 0.40 |
| objects-follow-sqlite | 1 | 0.004183 | 0.026082 | 0.028683 | 8.80 | 0.05 |
| objects-follow-hdf5 | 1 | 0.003834 | 0.024773 | 0.033482 | 9.46 | 0.04 |
| objects-keyed-varlit-indexed | 1 | 0.019665 | 0.039076 | 0.040669 | 8.95 | 0.40 |
| objects-keyed-sqlite | 1 | 0.003655 | 0.025818 | 0.029062 | 8.63 | 0.05 |
| table-w4-varlit-indexed | 1 | 0.074857 | 0.096824 | 0.093578 | 8.93 | 1.41 |
| table-w4-varlit-matrix | 1 | 0.036483 | 0.055613 | 0.056120 | 9.32 | 1.22 |
| table-w4-sqlite | 1 | 0.039074 | 0.061800 | 0.043008 | 9.45 | 0.11 |
| table-w4-hdf5 | 1 | 0.013326 | 0.033977 | 0.047366 | 9.71 | 0.08 |
| array-n16777216-g1048576-native-view | 1 | 0.014971 | 0.043005 | 0.034787 | 25.08 | 16.00 |
| array-n16777216-g1048576-stream | 1 | 0.022951 | 0.041936 | 0.030961 | 30.44 | 16.03 |
| array-n16777216-g1048576-indexed | 1 | 0.022195 | 0.051699 | 0.039992 | 30.31 | 16.04 |
| array-n16777216-g1048576-matrix-mmap | 1 | 0.067999 | 0.102497 | 0.081851 | 29.42 | 16.15 |
| array-n16777216-g1048576-sql-columns | 1 | 0.200458 | 0.297377 | 0.276168 | 31.70 | 19.75 |
| array-n16777216-g1048576-sql-chunks | 1 | 0.061141 | 0.091913 | 0.069582 | 32.46 | 16.03 |
| array-n16777216-g1048576-hdf-contiguous-bulk | 1 | 0.020193 | 0.039026 | 0.030955 | 40.76 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-bulk | 1 | 0.025202 | 0.053545 | 0.046797 | 49.95 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-fletcher-bulk | 1 | 0.039975 | 0.083693 | 0.075252 | 51.04 | 16.00 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
