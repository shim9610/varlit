# Workload-specific storage comparison

This standalone diagnostic crate compares Varlit, SQLite and HDF5 using the same
logical data and successful operations. It changes neither Varlit's public API nor
its file format. It is deliberately outside the normal Cargo workspace; native
SQLite and HDF5 installations are not requirements for library users.

The performance target is **SQLite elapsed time / Varlit elapsed time >= 2** for
each equivalent operation separately. A faster write does not compensate for a
slower read. Preparing this harness, or passing its smoke tests, does not establish
that target. Candidate implementations and configurations are reported separately;
there is no claim that every possible engine-specific optimization is exhausted.

## Scenarios and storage

| Scenario | Logical work | Varlit candidates | SQLite | HDF5 |
|---|---|---|---|---|
| Mixed logging | Declared fixed Metadata and variable Frame blocks, varying payload lengths, durable batches, one producer/writer and one/eight followers | Batch stream and general composite-key disk index; persistent typed cursors and follow | Type-specific tables, sequence primary keys, composite Frame index only for keyed queries, prepared statements, WAL/FULL | Compound Frame headers and Metadata, a byte payload dataset, batched hyperslabs, SWMR |
| High cardinality | 100,000/1,000,000 independent small objects; follow-only and arbitrary composite-key lookup are separate profiles | Bounded disk-index cache; stream for follow-only | Complete indexed schema for both writes and reads | Follow-only; arbitrary composite-key lookup explicitly unsupported |
| Numerical arrays: HDF5-favorable | Regular dense time axis, 16 f64 channels/sample; write, scan, one-sample points and 4,096-sample windows | Native block views, stream, disk-indexed chunks, immutable mmap matrix after checkpoint | Typed 16-REAL-column table and large BLOB chunks with incremental BLOB reads | Native f64 two-dimensional contiguous/chunked datasets, bulk writes and hyperslab reads; optional Fletcher32 |
| Transactional tables: SQLite-favorable | Independent 64-byte business rows, bounded dense IDs partitioned by producer, multirow insert transactions, full follow plus primary-key lookup of every row; one/four producers and eight followers | General-key index and dense matrix candidates; multiple producers hand off to one writer | Typed columns, integer primary key, sequence index required for follow, independent writer connections, WAL/FULL | Compound dense-ID row axis, append-only sequence-ID dataset, SWMR; multiple producers hand off to one writer |

One Frame is an application block, **not one numeric sample**. The array workload
uses 64 KiB/1 MiB groups containing 512/8,192 complete samples. High-cardinality
objects and business rows are independent application entities, not an alternative
encoding of those samples. No dataset or table is created per object.

This is an insert/append comparison. General SQL joins, secondary predicate
queries, competing updates, deletion, update history and crash recovery are not
implemented by this suite. Do not infer equivalent functionality for them. The
SQLite table scenario exercises concurrent writer connections and multirow
visibility, not arbitrary SQL functionality or crash-equivalent ACID in other
engines. SQLite itself permits one active write transaction per database.

## Concurrency and publication

Every handle stays on its owning thread/process. The Varlit/HDF5 writer receives
transactions through a **bounded MPSC queue with capacity two**. The total number
of in-flight transactions also includes one per producer and the active writer.
CPU, queue blocking, input generation, coalescing copies and handoff are charged.
The writer never waits for reader acknowledgments in timing runs. SQLite's
multi-producer table profile uses separate native connections and database-native
transaction serialization, without an added Rust-wide writer mutex.

SQLite's compile-time thread setting is recorded and a THREADSAFE=0 build is
refused. Connections explicitly request SQLITE_OPEN_FULLMUTEX (serialized mode).
This does not make concurrent write transactions possible. Varlit/HDF5 readers
run in independent processes. In particular, HDF5's thread-safe build may serialize
API calls with a global lock; separate SWMR processes avoid that benchmark artifact.

An application Head defines the committed prefix across logical block kinds.
Readers retain handles/cursors and consume only through a captured Head. They may
skip intermediate refresh generations, but must consume every published record
exactly once. Unique appended values remain immutable, so a later root still
contains the captured prefix. This is **prefix clamping**, not a claim that
separate Varlit API calls capture one atomic root or that HDF5 provides SQL MVCC.
SQLite reads each captured prefix inside one read transaction.

HDF5 flushes data before appending a checked commit marker, then flushes and
fsyncs. Markers identify logical counts and payload extent; partially visible
markers do not authorize additional reads. Published data chunks are sealed:
compound/ID chunks match a transaction batch, metadata chunks contain its two
metadata records, and byte payloads are padded to a chunk boundary. Padding and
copy costs are included. The sealed-chunk adapter requires complete transaction
batches; unsupported shapes fail explicitly. The table ID partition ensures each
transaction owns complete dense-ID chunks. Raw HDF5 datasets can expose staged
bytes; consumers must obey this application publication protocol.

SQLite WAL/FULL, Varlit sync/checkpoint and HDF5 flush/fsync have different recovery
contracts. This suite does not assert crash-recovery equivalence. Integrity
variants are labeled: HDF5 plain versus Fletcher32, SQLite's normal integrity
behavior, and Varlit CRC verification. Matrix mmap is used only after every writer
is closed and the matrix is checkpointed; checkpoint cost belongs to writes.
No ReadLimits are increased. Table matrix reserved capacity, COW files and index
sidecars count toward storage. No live file is mapped under an immutability promise.

## Build and run

Linux, Rust 1.95+, a C compiler, Python 3, and native SQLite/HDF5 1.14 libraries
are required. The build script finds versioned shared objects without modifying
system directories. Set VARLIT_BENCH_NATIVE_LIB_DIR for a custom library directory.

```sh
cargo build --release --locked --manifest-path tools/storage-bench/Cargo.toml
python3 tools/storage-bench/run.py --suite smoke --repeats 1 --probe --output /absolute/fresh/smoke
python3 tools/storage-bench/run.py --suite tuning --repeats 3 --output /absolute/fresh/tuning
python3 tools/storage-bench/run.py --suite pilot --repeats 3 --probe --tuning-results /absolute/fresh/tuning --output /absolute/fresh/pilot
python3 tools/storage-bench/run.py --suite full --repeats 3 --probe --tuning-results /absolute/fresh/tuning --output /absolute/fresh/full
```

Run in an existing cgroup limited to **4 CPU / 16 GiB**, with the existing **32 GiB
storage budget**. The runner restricts affinity to at most four available CPUs,
refuses a memory cgroup exceeding 16 GiB, and stops when less than 3 GiB remains.
It does not change cgroup/resource limits. Ensure enough free storage for one
profile's peak, including transient compaction copies. A refusal or failure is
retained; it must not be silently replaced by a larger budget.

Smoke includes staged-but-unpublished prefix gates. These deliberately wait for
reader observations and are **not timing observations**. Pilot uses 256 MiB arrays
and mixed logging plus 100,000 objects/rows. Full adds 16 MiB/256 MiB/1 GiB arrays,
64 KiB/1 MiB groups and mixed payloads, and 1,000,000 independent objects/rows.
Use --filter with a profile-name substring to inspect or rerun a frozen subset.
Run directories must be fresh. Successful workload files are removed after their
measurements; --keep-data retains them. Failed files/logs are always preserved.

The profiles in run.py freeze complete candidate layouts before measurement.
SQLite page/cache/mmap and HDF5 chunk/cache choices are recorded. The tuning suite compares 4/16/64 KiB SQLite pages and 0/1 GiB mmap,
including both 64 KiB/1 MiB BLOB groups. --tuning-results freezes one complete
configuration per family by median overall completion after at least three
observations per candidate. The 256 MiB/64 KiB mixed-block settings transfer to
the larger primary sizes and 1 MiB payloads; those transfers are not separate
optimality proofs. Layout alternatives for Varlit/HDF5 remain separate reported
profiles. These defaults are an initial comparison grid. Before a primary
performance claim, run a separate schema/configuration tuning study, preserve all
candidates, and freeze complete winners supporting the required queries. Do not
combine one schema's write speed with another schema's read speed as one engine.
No benchmark below is a replacement for PR #18's safety tests or main-versus-PR
performance regression measurements.

## Measurements and limitations

Each reader validates all payload bytes/fields, duplicate/missing records,
metadata membership and exact query results. Timing totals include verification;
phase counters expose input/backend work where available. Every reader processes
the same logical workload. Each profile uses fresh files, then warm page cache for
reads; there is no privileged cache eviction. Array single-reader point/range
results are separate from its full scan. Stream has no point/range operation:
compare only its common scan/write metrics, never its shorter total query workload.

The runner records source/binary/lockfile hashes, configurations, native versions,
commands, exit status and original stdout/stderr. A small C exec/wait4 wrapper
avoids inheriting Python's RSS high-water before exec. CPU includes waited-for
child processes. wait4 max RSS is a maximum, **not summed physical memory**.
Separate --probe runs sample aggregate process-tree RSS/PSS, logical/allocated
files, WAL/SHM, TMPDIR and deleted-open allocated files. Sampling is every 50 ms;
it can miss shorter peaks and transient files. Probes are not timing samples.

Reader metrics include open, refresh, consumption, CPU, poll count and maximum
observed pending record count. That count is not a precise publication-to-consume
latency distribution: generation skipping and fixed 100 us idle polling affect it.
Mixed/table writer completion and reader drain are separate. Initialization and
final close/checkpoint are separate and also included in overall completion.
Resource probes report peaks; final storage includes only engine files. Reader order checksums are checked against the actual writer commit order,
independently of the membership oracle. These checksums are regression checks,
not collision-free formal proofs. No universal speed,
real-time ingestion guarantee, or OOM impossibility follows from these measurements.
