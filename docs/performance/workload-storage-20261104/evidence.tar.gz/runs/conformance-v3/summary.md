# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r2-varlit-stream | 1 | 0.009028 | 0.028243 | 0.033203 | 10.39 | 1.52 |
| mixed-p65536-r2-varlit-indexed | 1 | 0.009813 | 0.029598 | 0.033956 | 10.33 | 1.58 |
| mixed-p65536-r2-sqlite | 1 | 0.009056 | 0.033807 | 0.034050 | 10.44 | 1.52 |
| mixed-p65536-r2-hdf5 | 1 | 0.005904 | 0.028092 | 0.040943 | 13.59 | 2.01 |
| objects-follow-varlit-stream | 1 | 0.011473 | 0.032356 | 0.032455 | 8.90 | 0.08 |
| objects-follow-varlit-indexed | 1 | 0.015224 | 0.034393 | 0.036365 | 8.94 | 0.40 |
| objects-follow-sqlite | 1 | 0.003372 | 0.027282 | 0.027872 | 8.67 | 0.04 |
| objects-follow-hdf5 | 1 | 0.005148 | 0.025620 | 0.032893 | 9.38 | 0.04 |
| objects-keyed-varlit-indexed | 1 | 0.023506 | 0.059690 | 0.059483 | 8.95 | 0.40 |
| objects-keyed-sqlite | 1 | 0.003675 | 0.026755 | 0.028592 | 8.79 | 0.05 |
| table-w4-varlit-indexed | 1 | 0.060767 | 0.082629 | 0.080750 | 8.93 | 1.41 |
| table-w4-varlit-matrix | 1 | 0.036846 | 0.059056 | 0.058909 | 9.34 | 1.22 |
| table-w4-sqlite | 1 | 0.024639 | 0.049544 | 0.048713 | 9.48 | 0.10 |
| table-w4-hdf5 | 1 | 0.013306 | 0.054790 | 0.068247 | 9.51 | 0.08 |
| array-n16777216-g1048576-native-view | 1 | 0.014112 | 0.039531 | 0.032404 | 25.21 | 16.00 |
| array-n16777216-g1048576-stream | 1 | 0.019664 | 0.038822 | 0.029422 | 30.37 | 16.03 |
| array-n16777216-g1048576-indexed | 1 | 0.018456 | 0.043503 | 0.034301 | 30.24 | 16.04 |
| array-n16777216-g1048576-matrix-mmap | 1 | 0.072854 | 0.108713 | 0.087303 | 29.42 | 16.15 |
| array-n16777216-g1048576-sql-columns | 1 | 0.175449 | 0.276645 | 0.262676 | 31.57 | 19.75 |
| array-n16777216-g1048576-sql-chunks | 1 | 0.055443 | 0.083199 | 0.062436 | 32.46 | 16.03 |
| array-n16777216-g1048576-hdf-contiguous-bulk | 1 | 0.019970 | 0.037769 | 0.030010 | 40.70 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-bulk | 1 | 0.026299 | 0.050083 | 0.041950 | 49.95 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-fletcher-bulk | 1 | 0.034103 | 0.074148 | 0.066563 | 51.04 | 16.00 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
