# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r2-varlit-stream | 1 | 0.009317 | 0.028995 | 0.034592 | 10.38 | 1.52 |
| mixed-p65536-r2-varlit-indexed | 1 | 0.008988 | 0.031112 | 0.035860 | 10.44 | 1.58 |
| mixed-p65536-r2-sqlite | 1 | 0.006007 | 0.029760 | 0.034037 | 10.65 | 1.52 |
| mixed-p65536-r2-hdf5 | 1 | 0.007218 | 0.034683 | 0.054739 | 13.51 | 2.01 |
| objects-follow-varlit-stream | 1 | 0.013809 | 0.036269 | 0.037770 | 9.01 | 0.08 |
| objects-follow-varlit-indexed | 1 | 0.018558 | 0.040362 | 0.042338 | 8.96 | 0.40 |
| objects-follow-sqlite | 1 | 0.003163 | 0.025141 | 0.026362 | 8.75 | 0.04 |
| objects-follow-hdf5 | 1 | 0.004939 | 0.026373 | 0.035157 | 9.55 | 0.04 |
| objects-keyed-varlit-indexed | 1 | 0.015795 | 0.037994 | 0.043028 | 9.04 | 0.40 |
| objects-keyed-sqlite | 1 | 0.003861 | 0.027716 | 0.028880 | 8.77 | 0.05 |
| table-w4-varlit-indexed | 1 | 0.062278 | 0.085952 | 0.095983 | 8.96 | 1.38 |
| table-w4-varlit-matrix | 1 | 0.039990 | 0.062373 | 0.062108 | 9.41 | 1.22 |
| table-w4-sqlite | 1 | 0.022901 | 0.044716 | 0.037540 | 9.45 | 0.09 |
| table-w4-hdf5 | 1 | 0.020507 | 0.042976 | 0.056793 | 9.75 | 0.08 |
| array-n16777216-g1048576-native-view | 1 | 0.016083 | 0.039856 | 0.031523 | 25.20 | 16.00 |
| array-n16777216-g1048576-stream | 1 | 0.021224 | 0.037950 | 0.026729 | 30.31 | 16.03 |
| array-n16777216-g1048576-indexed | 1 | 0.020716 | 0.045866 | 0.034837 | 30.24 | 16.04 |
| array-n16777216-g1048576-matrix-mmap | 1 | 0.073236 | 0.112177 | 0.091005 | 29.41 | 16.15 |
| array-n16777216-g1048576-sql-columns | 1 | 0.187585 | 0.282513 | 0.258361 | 31.57 | 19.75 |
| array-n16777216-g1048576-sql-chunks | 1 | 0.056595 | 0.106023 | 0.087642 | 32.46 | 16.03 |
| array-n16777216-g1048576-hdf-contiguous-bulk | 1 | 0.058986 | 0.078903 | 0.070965 | 40.87 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-bulk | 1 | 0.026923 | 0.050396 | 0.040909 | 50.00 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-fletcher-bulk | 1 | 0.036439 | 0.075646 | 0.065686 | 50.95 | 16.00 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
