# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r2-varlit-stream | 1 | 0.014370 | 0.034980 | 0.034892 | 10.41 | 1.52 |
| mixed-p65536-r2-varlit-indexed | 1 | 0.015264 | 0.042686 | 0.040778 | 10.43 | 1.58 |
| mixed-p65536-r2-sqlite | 1 | 0.007185 | 0.035717 | 0.038003 | 10.57 | 1.52 |
| mixed-p65536-r2-hdf5 | 1 | 0.006202 | 0.028323 | 0.041315 | 13.57 | 2.01 |
| objects-follow-varlit-stream | 1 | 0.011919 | 0.033585 | 0.032614 | 9.05 | 0.08 |
| objects-follow-varlit-indexed | 1 | 0.017829 | 0.036949 | 0.034443 | 9.07 | 0.40 |
| objects-follow-sqlite | 1 | 0.003230 | 0.026185 | 0.027321 | 8.67 | 0.04 |
| objects-follow-hdf5 | 1 | 0.003509 | 0.026255 | 0.035170 | 9.54 | 0.04 |
| objects-keyed-varlit-indexed | 1 | 0.016040 | 0.036774 | 0.035572 | 9.04 | 0.40 |
| objects-keyed-sqlite | 1 | 0.004084 | 0.030969 | 0.033910 | 8.82 | 0.05 |
| table-w4-varlit-indexed | 1 | 0.065204 | 0.087345 | 0.079382 | 9.06 | 1.41 |
| table-w4-varlit-matrix | 1 | 0.037584 | 0.058574 | 0.056550 | 9.46 | 1.22 |
| table-w4-sqlite | 1 | 0.038855 | 0.061329 | 0.043656 | 9.46 | 0.10 |
| table-w4-hdf5 | 1 | 0.016438 | 0.037751 | 0.050760 | 9.63 | 0.08 |
| array-n16777216-g1048576-native-view | 1 | 0.013327 | 0.036913 | 0.029459 | 25.27 | 16.00 |
| array-n16777216-g1048576-stream | 1 | 0.018874 | 0.042767 | 0.032397 | 30.37 | 16.03 |
| array-n16777216-g1048576-indexed | 1 | 0.020112 | 0.048175 | 0.038089 | 30.24 | 16.04 |
| array-n16777216-g1048576-matrix-mmap | 1 | 0.074271 | 0.113094 | 0.094992 | 29.42 | 16.15 |
| array-n16777216-g1048576-sql-columns | 1 | 0.200879 | 0.299953 | 0.280689 | 31.70 | 19.75 |
| array-n16777216-g1048576-sql-chunks | 1 | 0.060256 | 0.092452 | 0.072889 | 32.47 | 16.03 |
| array-n16777216-g1048576-hdf-contiguous-bulk | 1 | 0.020920 | 0.038482 | 0.030359 | 40.87 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-bulk | 1 | 0.024711 | 0.051014 | 0.043283 | 49.95 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-fletcher-bulk | 1 | 0.038227 | 0.081303 | 0.073290 | 50.95 | 16.00 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
