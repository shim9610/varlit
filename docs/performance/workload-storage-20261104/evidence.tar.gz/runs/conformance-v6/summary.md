# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r2-varlit-stream | 1 | 0.008364 | 0.029432 | 0.030579 | 10.38 | 1.52 |
| mixed-p65536-r2-varlit-indexed | 1 | 0.010546 | 0.031255 | 0.032126 | 10.43 | 1.58 |
| mixed-p65536-r2-sqlite | 1 | 0.007614 | 0.032780 | 0.034644 | 10.46 | 1.52 |
| mixed-p65536-r2-hdf5 | 1 | 0.005915 | 0.026057 | 0.038804 | 13.43 | 2.01 |
| objects-follow-varlit-stream | 1 | 0.017534 | 0.040609 | 0.037995 | 8.97 | 0.08 |
| objects-follow-varlit-indexed | 1 | 0.017899 | 0.043284 | 0.039583 | 9.04 | 0.40 |
| objects-follow-sqlite | 1 | 0.003571 | 0.027337 | 0.030585 | 8.70 | 0.04 |
| objects-follow-hdf5 | 1 | 0.004293 | 0.030305 | 0.042327 | 9.54 | 0.04 |
| objects-keyed-varlit-indexed | 1 | 0.021404 | 0.046820 | 0.046193 | 9.04 | 0.40 |
| objects-keyed-sqlite | 1 | 0.003239 | 0.025675 | 0.026745 | 8.77 | 0.05 |
| table-w4-varlit-indexed | 1 | 0.060556 | 0.088267 | 0.087396 | 9.04 | 1.44 |
| table-w4-varlit-matrix | 1 | 0.050720 | 0.069805 | 0.060863 | 9.44 | 1.22 |
| table-w4-sqlite | 1 | 0.059084 | 0.082793 | 0.052041 | 9.50 | 0.10 |
| table-w4-hdf5 | 1 | 0.015683 | 0.038967 | 0.057085 | 9.63 | 0.08 |
| array-n16777216-g1048576-native-view | 1 | 0.015305 | 0.039816 | 0.031702 | 25.22 | 16.00 |
| array-n16777216-g1048576-stream | 1 | 0.021988 | 0.050603 | 0.040467 | 30.26 | 16.03 |
| array-n16777216-g1048576-indexed | 1 | 0.021527 | 0.050329 | 0.039414 | 30.26 | 16.04 |
| array-n16777216-g1048576-matrix-mmap | 1 | 0.041487 | 0.094610 | 0.084006 | 29.36 | 16.16 |
| array-n16777216-g1048576-matrix-owned | 1 | 0.042619 | 0.096858 | 0.086544 | 23.47 | 16.16 |
| array-n16777216-g1048576-sql-columns | 1 | 0.203497 | 0.315659 | 0.292656 | 31.59 | 19.75 |
| array-n16777216-g1048576-sql-chunks | 1 | 0.058874 | 0.091408 | 0.070068 | 32.59 | 16.03 |
| array-n16777216-g1048576-hdf-contiguous-bulk | 1 | 0.021554 | 0.041102 | 0.033143 | 40.83 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-bulk | 1 | 0.026502 | 0.051382 | 0.043237 | 50.01 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-fletcher-bulk | 1 | 0.036373 | 0.085191 | 0.076317 | 51.09 | 16.00 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
