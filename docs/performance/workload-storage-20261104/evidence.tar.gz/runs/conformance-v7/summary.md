# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r2-varlit-stream | 1 | 0.018196 | 0.036097 | 0.037350 | 10.42 | 1.52 |
| mixed-p65536-r2-varlit-indexed | 1 | 0.026290 | 0.049551 | 0.052733 | 10.49 | 1.58 |
| mixed-p65536-r2-sqlite | 1 | 0.019877 | 0.045086 | 0.051211 | 11.05 | 1.52 |
| mixed-p65536-r2-hdf5 | 1 | 0.018258 | 0.041067 | 0.057169 | 13.58 | 2.01 |
| objects-follow-varlit-stream | 1 | 0.042478 | 0.066743 | 0.058065 | 9.03 | 0.08 |
| objects-follow-varlit-indexed | 1 | 0.033646 | 0.054361 | 0.047704 | 9.03 | 0.40 |
| objects-follow-sqlite | 1 | 0.011464 | 0.031878 | 0.035412 | 8.80 | 0.04 |
| objects-follow-hdf5 | 1 | 0.016018 | 0.045097 | 0.060341 | 9.56 | 0.04 |
| objects-keyed-varlit-indexed | 1 | 0.035894 | 0.057706 | 0.053589 | 9.06 | 0.40 |
| objects-keyed-sqlite | 1 | 0.015628 | 0.038553 | 0.040569 | 8.85 | 0.05 |
| table-w4-varlit-indexed | 1 | 0.127065 | 0.149390 | 0.121283 | 9.21 | 1.38 |
| table-w4-varlit-matrix | 1 | 0.073198 | 0.094121 | 0.076326 | 9.68 | 1.22 |
| table-w4-sqlite | 1 | 0.046260 | 0.066498 | 0.052818 | 9.47 | 0.09 |
| table-w4-hdf5 | 1 | 0.026042 | 0.048582 | 0.071567 | 9.57 | 0.08 |
| array-n16777216-g1048576-native-view | 1 | 0.016005 | 0.044843 | 0.036020 | 25.04 | 16.00 |
| array-n16777216-g1048576-stream | 1 | 0.024443 | 0.046513 | 0.033789 | 30.27 | 16.03 |
| array-n16777216-g1048576-indexed | 1 | 0.022885 | 0.057964 | 0.046506 | 30.44 | 16.04 |
| array-n16777216-g1048576-matrix-mmap | 1 | 0.038712 | 0.084191 | 0.074111 | 29.36 | 16.16 |
| array-n16777216-g1048576-matrix-owned | 1 | 0.044187 | 0.111579 | 0.100223 | 23.59 | 16.16 |
| array-n16777216-g1048576-sql-columns | 1 | 0.235127 | 0.353695 | 0.325653 | 31.58 | 19.75 |
| array-n16777216-g1048576-sql-chunks | 1 | 0.067581 | 0.102038 | 0.082711 | 32.49 | 16.03 |
| array-n16777216-g1048576-hdf-contiguous-bulk | 1 | 0.023251 | 0.045038 | 0.036832 | 40.76 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-bulk | 1 | 0.030521 | 0.058095 | 0.048477 | 49.96 | 16.00 |
| array-n16777216-g1048576-hdf-chunked-fletcher-bulk | 1 | 0.041769 | 0.090572 | 0.081878 | 51.09 | 16.00 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
