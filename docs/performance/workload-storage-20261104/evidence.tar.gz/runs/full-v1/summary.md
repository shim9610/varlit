# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r1-varlit-stream | 1 | 2.133189 | 2.162360 | 2.625015 | 63.52 | 770.49 |
| mixed-p65536-r1-varlit-indexed | 1 | 0.852475 | 0.877940 | 1.086797 | 63.92 | 794.11 |
| mixed-p65536-r1-sqlite | 1 | 2.751530 | 3.005480 | 3.259832 | 63.55 | 887.82 |
| mixed-p65536-r1-hdf5 | 1 | 1.140163 | 1.174306 | 1.833492 | 85.51 | 810.54 |
| mixed-p1048576-r1-varlit-stream | 1 | 0.738574 | 0.778690 | 0.952042 | 66.44 | 767.79 |
| mixed-p1048576-r1-varlit-indexed | 1 | 0.781692 | 0.815517 | 0.977948 | 65.20 | 773.80 |
| mixed-p1048576-r1-sqlite | 1 | 1.485777 | 1.588986 | 1.730190 | 67.02 | 777.07 |
| mixed-p1048576-r1-hdf5 | 1 | 1.079545 | 1.111806 | 1.696527 | 78.55 | 810.07 |
| mixed-p65536-r8-varlit-stream | 1 | 1.183310 | 1.411575 | 5.123668 | 60.02 | 770.48 |
| mixed-p65536-r8-varlit-indexed | 1 | 1.548714 | 1.609784 | 5.663168 | 61.80 | 794.11 |
| mixed-p65536-r8-sqlite | 1 | 6.996425 | 7.506151 | 15.833515 | 63.68 | 887.82 |
| mixed-p65536-r8-hdf5 | 1 | 1.922927 | 2.264343 | 8.626318 | 85.50 | 810.54 |
| mixed-p1048576-r8-varlit-stream | 1 | 1.275718 | 1.352055 | 4.936447 | 65.49 | 767.79 |
| mixed-p1048576-r8-varlit-indexed | 1 | 1.277295 | 1.327225 | 4.765893 | 65.85 | 773.81 |
| mixed-p1048576-r8-sqlite | 1 | 1.904780 | 2.264980 | 6.914096 | 67.23 | 777.07 |
| mixed-p1048576-r8-hdf5 | 1 | 1.819087 | 2.084097 | 7.961382 | 77.57 | 810.07 |
| objects-follow-varlit-stream | 1 | 4.831591 | 7.417551 | 28.495496 | 9.05 | 268.76 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
