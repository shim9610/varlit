# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r1-varlit-stream | 1 | 2.794048 | 2.825046 | 3.537995 | 63.56 | 770.48 |
| mixed-p65536-r1-varlit-indexed | 1 | 1.382963 | 1.406957 | 1.405338 | 64.09 | 794.11 |
| mixed-p65536-r1-sqlite | 1 | 2.261847 | 2.371562 | 2.708886 | 63.68 | 887.82 |
| mixed-p65536-r1-hdf5 | 1 | 1.297108 | 1.329880 | 2.079926 | 85.54 | 810.54 |
| mixed-p1048576-r1-varlit-stream | 1 | 2.580239 | 2.613067 | 3.308958 | 66.31 | 767.79 |
| mixed-p1048576-r1-varlit-indexed | 1 | 0.943092 | 0.984188 | 1.181780 | 65.61 | 773.81 |
| mixed-p1048576-r1-sqlite | 1 | 1.635954 | 1.722964 | 1.929290 | 67.19 | 777.07 |
| mixed-p1048576-r1-hdf5 | 1 | 1.133064 | 1.163209 | 1.858400 | 78.01 | 810.07 |
| mixed-p65536-r8-varlit-stream | 1 | 1.231863 | 1.302480 | 4.737352 | 60.04 | 770.48 |
| mixed-p65536-r8-varlit-indexed | 1 | 1.559263 | 1.606112 | 5.829990 | 60.23 | 794.11 |
| mixed-p65536-r8-sqlite | 1 | 2.632451 | 3.034545 | 8.661143 | 63.68 | 887.82 |
| mixed-p65536-r8-hdf5 | 1 | 2.026720 | 2.430752 | 9.189376 | 85.71 | 810.54 |
| mixed-p1048576-r8-varlit-stream | 1 | 1.287006 | 1.379372 | 5.068267 | 65.46 | 767.79 |
| mixed-p1048576-r8-varlit-indexed | 1 | 1.336405 | 1.396814 | 5.156231 | 65.95 | 773.81 |
| mixed-p1048576-r8-sqlite | 1 | 2.305688 | 2.695144 | 8.209878 | 67.39 | 777.07 |
| mixed-p1048576-r8-hdf5 | 1 | 2.081378 | 2.393841 | 9.168682 | 78.14 | 810.07 |
| objects-follow-varlit-stream | 1 | 5.116722 | 7.225041 | 28.086513 | 9.11 | 268.75 |
| objects-follow-varlit-indexed | 1 | 55.077983 | 55.115578 | 169.795083 | 25.55 | 529.77 |
| objects-follow-sqlite | 1 | 2.694928 | 2.773197 | 6.481529 | 16.30 | 148.89 |
| objects-follow-hdf5 | 1 | 1.676232 | 1.728925 | 6.293828 | 13.93 | 152.75 |
| objects-keyed-varlit-indexed | 1 | 59.892699 | 59.970944 | 200.394111 | 25.79 | 529.77 |
| objects-keyed-sqlite | 1 | 3.842734 | 4.005523 | 13.343993 | 16.26 | 169.63 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
