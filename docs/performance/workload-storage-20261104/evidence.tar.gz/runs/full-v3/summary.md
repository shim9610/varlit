# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r1-varlit-stream | 1 | 1.617940 | 1.642831 | 1.885528 | 63.54 | 770.49 |
| mixed-p65536-r1-varlit-indexed | 1 | 0.883469 | 0.910461 | 1.080350 | 63.97 | 794.11 |
| mixed-p65536-r1-sqlite | 1 | 1.829030 | 1.917172 | 2.122004 | 63.70 | 887.82 |
| mixed-p65536-r1-hdf5 | 1 | 1.212896 | 1.244402 | 1.960246 | 85.54 | 810.54 |
| mixed-p1048576-r1-varlit-stream | 1 | 0.852314 | 0.899869 | 1.030777 | 66.38 | 767.79 |
| mixed-p1048576-r1-varlit-indexed | 1 | 0.923040 | 0.957329 | 1.120909 | 65.71 | 773.81 |
| mixed-p1048576-r1-sqlite | 1 | 1.469195 | 1.649006 | 1.790544 | 67.18 | 777.07 |
| mixed-p1048576-r1-hdf5 | 1 | 1.082957 | 1.117002 | 1.748359 | 78.16 | 810.07 |
| mixed-p65536-r8-varlit-stream | 1 | 1.380588 | 1.426770 | 5.113599 | 60.06 | 770.48 |
| mixed-p65536-r8-varlit-indexed | 1 | 1.466701 | 1.537083 | 5.394416 | 63.66 | 794.11 |
| mixed-p65536-r8-sqlite | 1 | 2.378180 | 2.784100 | 8.158522 | 63.68 | 887.82 |
| mixed-p65536-r8-hdf5 | 1 | 2.163129 | 2.366352 | 9.143751 | 85.73 | 810.54 |
| mixed-p1048576-r8-varlit-stream | 1 | 1.263196 | 1.404622 | 4.939263 | 66.44 | 767.79 |
| mixed-p1048576-r8-varlit-indexed | 1 | 1.433244 | 1.498738 | 5.255868 | 65.55 | 773.80 |
| mixed-p1048576-r8-sqlite | 1 | 2.278741 | 2.641089 | 8.091620 | 67.29 | 777.07 |
| mixed-p1048576-r8-hdf5 | 1 | 2.258670 | 2.536725 | 9.591102 | 78.25 | 810.07 |
| objects-follow-varlit-stream | 1 | 5.371809 | 7.823146 | 29.653530 | 8.96 | 268.75 |
| objects-follow-varlit-indexed | 1 | 46.325572 | 46.367193 | 103.455557 | 25.57 | 529.77 |
| objects-follow-sqlite | 1 | 2.172443 | 2.297453 | 5.508153 | 16.00 | 148.89 |
| objects-follow-hdf5 | 1 | 1.534758 | 1.580584 | 5.788458 | 14.09 | 152.75 |
| objects-keyed-varlit-indexed | 1 | 57.565931 | 57.638822 | 170.848648 | 25.38 | 529.77 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
