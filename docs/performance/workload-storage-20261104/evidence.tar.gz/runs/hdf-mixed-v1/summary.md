# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mixed-p65536-r1-chunk0-hdf5 | 3 | 1.294662 | 1.315184 | 2.030921 | 85.71 | 810.54 |
| mixed-p65536-r1-chunk16384-hdf5 | 3 | 1.786530 | 1.817384 | 2.835047 | 87.95 | 769.40 |
| mixed-p65536-r8-chunk0-hdf5 | 3 | 2.257187 | 2.620070 | 9.946830 | 85.72 | 810.54 |
| mixed-p65536-r8-chunk16384-hdf5 | 3 | 3.363594 | 3.555980 | 13.676787 | 88.40 | 769.40 |
| mixed-p1048576-r1-chunk0-hdf5 | 3 | 1.235311 | 1.262172 | 2.000555 | 78.53 | 810.07 |
| mixed-p1048576-r1-chunk262144-hdf5 | 3 | 1.213464 | 1.237259 | 1.964757 | 85.31 | 767.62 |
| mixed-p1048576-r8-chunk0-hdf5 | 3 | 2.431040 | 2.864780 | 10.987290 | 78.05 | 810.07 |
| mixed-p1048576-r8-chunk262144-hdf5 | 3 | 2.051241 | 2.378711 | 9.112570 | 84.74 | 767.62 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
