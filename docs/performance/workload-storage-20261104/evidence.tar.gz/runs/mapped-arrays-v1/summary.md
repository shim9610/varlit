# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| mapped-array-n16777216-g65536-native-mmap | 3 | 0.018979 | 0.049456 | 0.039049 | 29.29 | 16.03 |
| mapped-array-n16777216-g65536-sql-chunks | 3 | 0.043909 | 0.075457 | 0.056982 | 31.22 | 18.44 |
| mapped-array-n16777216-g1048576-native-mmap | 3 | 0.015325 | 0.042463 | 0.033994 | 28.05 | 16.00 |
| mapped-array-n16777216-g1048576-sql-chunks | 3 | 0.042446 | 0.074283 | 0.058097 | 32.05 | 16.31 |
| mapped-array-n268435456-g65536-native-mmap | 3 | 0.274749 | 0.378804 | 0.250712 | 269.72 | 256.45 |
| mapped-array-n268435456-g65536-sql-chunks | 3 | 0.555776 | 0.653028 | 0.414537 | 304.79 | 292.75 |
| mapped-array-n268435456-g1048576-native-mmap | 3 | 0.248549 | 0.325779 | 0.194723 | 268.12 | 256.04 |
| mapped-array-n268435456-g1048576-sql-chunks | 3 | 0.493567 | 0.589613 | 0.374626 | 270.96 | 258.44 |
| mapped-array-n1073741824-g65536-native-mmap | 3 | 1.127426 | 1.504583 | 0.984143 | 1040.32 | 1025.76 |
| mapped-array-n1073741824-g65536-sql-chunks | 3 | 2.153924 | 2.490024 | 1.541515 | 1043.78 | 1170.44 |
| mapped-array-n1073741824-g1048576-native-mmap | 3 | 0.924717 | 1.181546 | 0.663487 | 1036.25 | 1024.12 |
| mapped-array-n1073741824-g1048576-sql-chunks | 3 | 1.990880 | 2.296505 | 1.478272 | 1043.96 | 1033.32 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
