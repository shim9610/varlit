# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| array-mapped-n1073741824-g65536-native-mmap | 3 | 1.018031 | 1.461752 | 0.968368 | 1040.41 | 1025.76 |
| array-mapped-n1073741824-g65536-sql-chunks | 3 | 2.212392 | 2.749128 | 1.807683 | 1043.74 | 1170.44 |
| array-mapped-n1073741824-g1048576-native-mmap | 3 | 0.924810 | 1.297884 | 0.778531 | 1036.10 | 1024.12 |
| array-mapped-n1073741824-g1048576-sql-chunks | 3 | 1.920297 | 2.423240 | 1.494544 | 1044.14 | 1033.32 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
