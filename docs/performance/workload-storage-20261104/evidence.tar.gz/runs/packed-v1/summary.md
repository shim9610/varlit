# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
No statistical qualification or universal twofold speedup is inferred.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| table-w1-n100000-varlit-matrix-packed | 3 | 1.824943 | 1.853972 | 3.933913 | 9.88 | 52.59 |
| table-w1-n100000-sqlite | 3 | 1.223030 | 1.249184 | 2.983828 | 15.07 | 6.65 |
| table-w4-n100000-varlit-matrix-packed | 3 | 1.811393 | 1.845390 | 3.842844 | 9.95 | 51.99 |
| table-w4-n100000-sqlite | 3 | 1.270848 | 1.303765 | 2.660067 | 10.71 | 6.90 |
| table-w1-n1000000-varlit-matrix-packed | 3 | 17.805986 | 17.837447 | 39.714409 | 11.18 | 146.70 |
| table-w1-n1000000-sqlite | 3 | 11.619859 | 11.654555 | 28.655315 | 16.82 | 67.44 |
| table-w4-n1000000-varlit-matrix-packed | 3 | 18.500007 | 18.533158 | 40.835466 | 11.33 | 146.73 |
| table-w4-n1000000-sqlite | 3 | 11.780099 | 11.815210 | 25.318355 | 19.95 | 70.65 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
