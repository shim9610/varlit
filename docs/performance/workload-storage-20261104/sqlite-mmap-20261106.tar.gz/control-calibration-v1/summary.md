# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
These medians do not establish statistical qualification.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| array-n1073741824-g65536-native-mmap--after | 30 | 1.042717 | 2.165794 | 3.496904 | 6090.72 | 1025.76 |
| array-n1073741824-g65536-native-mmap--before-b | 30 | 1.030364 | 2.153803 | 3.413632 | 6218.61 | 1025.76 |
| array-n1073741824-g65536-native-mmap--before-a | 30 | 1.031529 | 2.209192 | 3.501575 | 6189.27 | 1025.76 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
