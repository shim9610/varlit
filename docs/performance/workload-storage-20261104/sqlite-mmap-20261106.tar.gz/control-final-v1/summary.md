# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
These medians do not establish statistical qualification.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| array-n1073741824-g65536-native-mmap--before-b | 7 | 1.069805 | 2.222271 | 3.693312 | 6030.03 | 1025.76 |
| array-n1073741824-g65536-native-mmap--after | 7 | 1.038085 | 2.300027 | 3.820501 | 6113.75 | 1025.76 |
| array-n1073741824-g65536-native-mmap--before-a | 7 | 1.055979 | 2.274131 | 3.665957 | 6448.20 | 1025.76 |
| array-n1073741824-g1048576-native-mmap--before-a | 7 | 0.845873 | 1.753414 | 2.889944 | 5860.89 | 1024.12 |
| array-n1073741824-g1048576-native-mmap--before-b | 7 | 0.903502 | 1.895298 | 2.955117 | 6008.42 | 1024.12 |
| array-n1073741824-g1048576-native-mmap--after | 7 | 0.866285 | 1.783642 | 2.935544 | 6196.34 | 1024.12 |
| array-n1073741824-g65536-native-view--before-a | 7 | 1.026988 | 2.620277 | 4.521238 | 62.61 | 1025.76 |
| array-n1073741824-g65536-native-view--after | 7 | 1.084134 | 2.682029 | 4.436801 | 62.52 | 1025.76 |
| array-n1073741824-g65536-native-view--before-b | 7 | 1.032742 | 2.645765 | 4.577881 | 62.59 | 1025.76 |
| array-n1073741824-g1048576-native-view--before-a | 7 | 0.850022 | 2.341886 | 3.653612 | 54.24 | 1024.12 |
| array-n1073741824-g1048576-native-view--before-b | 7 | 0.858853 | 2.356888 | 3.641502 | 54.23 | 1024.12 |
| array-n1073741824-g1048576-native-view--after | 7 | 0.873625 | 2.370333 | 3.733374 | 54.11 | 1024.12 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
