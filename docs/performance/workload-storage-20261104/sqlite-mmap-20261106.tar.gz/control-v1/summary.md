# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
These medians do not establish statistical qualification.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| array-n1073741824-g65536-native-mmap--before-b | 7 | 1.079213 | 2.329295 | 3.848280 | 6579.89 | 1025.76 |
| array-n1073741824-g65536-native-mmap--after | 7 | 1.095314 | 2.334965 | 3.618604 | 6210.17 | 1025.76 |
| array-n1073741824-g65536-native-mmap--before-a | 7 | 1.016232 | 2.187974 | 3.470822 | 6154.59 | 1025.76 |
| array-n1073741824-g1048576-native-mmap--before-a | 7 | 0.854686 | 1.825481 | 3.118057 | 5929.82 | 1024.12 |
| array-n1073741824-g1048576-native-mmap--before-b | 7 | 0.852054 | 1.727628 | 2.818859 | 5879.87 | 1024.12 |
| array-n1073741824-g1048576-native-mmap--after | 7 | 0.864110 | 1.791214 | 2.912019 | 6484.21 | 1024.12 |
| array-n1073741824-g65536-native-view--before-a | 7 | 0.990124 | 2.559121 | 4.398297 | 62.63 | 1025.76 |
| array-n1073741824-g65536-native-view--after | 7 | 1.048060 | 2.570383 | 4.349801 | 62.49 | 1025.76 |
| array-n1073741824-g65536-native-view--before-b | 7 | 1.059018 | 2.594599 | 4.252988 | 62.58 | 1025.76 |
| array-n1073741824-g1048576-native-view--before-a | 7 | 0.870814 | 2.336977 | 3.455813 | 54.25 | 1024.12 |
| array-n1073741824-g1048576-native-view--before-b | 7 | 0.869684 | 2.390133 | 3.598261 | 54.20 | 1024.12 |
| array-n1073741824-g1048576-native-view--after | 7 | 0.857486 | 2.328585 | 3.503047 | 54.02 | 1024.12 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
