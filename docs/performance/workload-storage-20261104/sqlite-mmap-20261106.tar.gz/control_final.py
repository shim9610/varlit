from pathlib import Path
import hashlib,json,os,random,shutil,subprocess,sys
ROOT=Path('/workspace/varlit');OUT=Path('/workspace/scratch/sqlite-mmap-20261106')
sys.path.insert(0,str(ROOT/'tools/storage-bench'))
import run as bench
cpus=sorted(os.sched_getaffinity(0))[:4];os.sched_setaffinity(0,cpus)
assert int(Path('/sys/fs/cgroup/memory.max').read_text())<=16*2**30
out=OUT/'control-final-v1';out.mkdir(exist_ok=False)
subprocess.run(['cc','-O2',str(bench.HERE/'measure.c'),'-o',str(out/'measure')],check=True)
grid=[]
for group in [65536,1<<20]:
 for mode in ['native-view','native-mmap']:
  workload=f'array-n{1<<30}-g{group}-{mode}'
  for label in ['before-a','before-b','after']:
   binary=OUT/'bin/before/arrays' if label.startswith('before') else ROOT/'target/release/arrays'
   grid.append(dict(name=workload+'--'+label,workload=workload,variant=label,kind='array',mode=mode,total=1<<30,group=group,
    page=65536,mmap=0,points=4096,ranges=128,readers=8,warm_scan=True,read_validation='full',binary_override=str(binary)))
hashes={p['binary_override']:hashlib.sha256(Path(p['binary_override']).read_bytes()).hexdigest() for p in grid}
bench.save(out/'manifest.json',dict(profiles=grid,repetitions=7,affinity=cpus,memory_max=Path('/sys/fs/cgroup/memory.max').read_text().strip(),
 cpu_max=Path('/sys/fs/cgroup/cpu.max').read_text().strip(),binaries=hashes,baseline='4b07249f36d03a125282d5d1eeb0e91b7484ab29',
 scope='Final live-window/snapshot harness: existing immutable paths, identical work. Before A/B use the same binary.'))
(out/'memory-before.txt').write_text(Path('/sys/fs/cgroup/memory.events').read_text())
rng=random.Random(9611);phases=[]
for repeat in range(7):
 cases=sorted({p['workload'] for p in grid});rng.shuffle(cases)
 for case in cases:
  variants=[p for p in grid if p['workload']==case];rng.shuffle(variants)
  phases.extend((p,f'timing-{repeat}-{p["name"]}',False) for p in variants)
phases.extend((p,'probe-'+p['name'],True) for p in grid)
rows=[]
for i,(p,stem,probe) in enumerate(phases,1):
 assert shutil.disk_usage(out).free>=3*2**30
 r=bench.invoke(p,out,stem,probe=probe);rows.append(r)
 with (out/'results.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
 print(f'{i}/{len(phases)} {stem} {r.get("error","OK")} {r["wall_seconds"]:.3f}s',flush=True)
 if r.get('error'):raise SystemExit('Failed control retained')
for path,value in hashes.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==value
(out/'memory-after.txt').write_text(Path('/sys/fs/cgroup/memory.events').read_text())
bench.summarize(rows,out)
