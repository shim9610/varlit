from pathlib import Path
import hashlib,gzip,tarfile,json,shutil,subprocess
src=Path(__file__).resolve().parent;repo=Path('/workspace/varlit');target=repo/'docs/performance/workload-storage-20261104/sqlite-mmap-20261106.tar.gz'
final_source=src/'final-source';final_source.mkdir(exist_ok=True)
paths=[repo/'tools/storage-bench'/n for n in ['src/bin/arrays.rs','run.py','compare_sqlite_mmap.py','integrate_report.py','check_report.cjs','report.html']]
paths += [repo/'scripts/tests/test_sqlite_mmap_bench.py',repo/'crates/varlit/tests/mmap_zero_copy.rs',repo/'crates/varlit-core/src/file/mapped_access.rs',repo/'crates/varlit-core/src/file/mmap_views.rs']
for p in paths:
 dest=final_source/p.relative_to(repo);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
(final_source/'manifest.json').write_text(json.dumps({str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
# Keep only one final source copy of each file.
for p in list(final_source.iterdir()):
 if p.is_file() and p.name not in ['manifest.json','worktree.patch']:p.unlink()
(final_source/'worktree.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','SECURITY.md','docs/scalable-io.md','crates','tools/storage-bench','scripts/tests/test_sqlite_mmap_bench.py'],cwd=repo))
files=set()
for p in src.iterdir():
 if p.is_file() and (p.suffix in ['.log','.py'] or p.name in ['before-binaries.json','cache-reclamation.json','content-review.json']): files.add(p)
 if not p.is_dir() or p.name in ['bin','chrome-profile','final-source']:continue
 for q in p.rglob('*'):
  if not q.is_file() or '__pycache__' in q.parts:continue
  rel=q.relative_to(p)
  if q.name in ['results.jsonl','manifest.json','memory-before.txt','memory-after.txt','evaluation.json','driver.py','worktree.patch','summary.md'] or 'source' in rel.parts or any(x.endswith('.work') for x in rel.parts) or (q.suffix=='.stderr' and q.stat().st_size):files.add(q)
files.update(p for p in final_source.rglob('*') if p.is_file())
final=src/'bin/final';final.mkdir(exist_ok=True)
for name in ['arrays','mixed']:shutil.copyfile(repo/'target/release'/name,final/name)
files.update(p for p in (src/'bin').rglob('*') if p.is_file())
manifest={str(p.relative_to(src)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(files)}
m=src/'archive-manifest.json';m.write_text(json.dumps(manifest,indent=2)+'\n');files.add(m)
with target.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(src)),recursive=False)
with tarfile.open(target,'r:gz') as tar:
 for item in tar:
  if item.name=='archive-manifest.json':continue
  assert hashlib.file_digest(tar.extractfile(item),'sha256').hexdigest()==manifest[item.name]['sha256'],item.name
print('Packed and roundtrip-verified',len(files),'evidence files;',target.stat().st_size,'compressed bytes')
