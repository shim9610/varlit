# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
These medians do not establish statistical qualification.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| live-n33554432-g65536-r2--varlit-native-mmap-crc-only | 1 | 0.038283 | 0.062909 | 0.070043 | 23.44 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-view-full | 1 | 0.036069 | 0.065721 | 0.074098 | 23.57 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-mmap-full | 1 | 0.034659 | 0.061278 | 0.077336 | 23.57 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-view-crc-only | 1 | 0.035882 | 0.064308 | 0.070863 | 23.64 | 32.06 |
| live-n33554432-g65536-r2--sqlite-m1073741824 | 1 | 0.046709 | 0.114294 | 0.117871 | 31.49 | 36.75 |
| live-n33554432-g65536-r2--sqlite-m2147483648 | 1 | 0.046865 | 0.135725 | 0.134472 | 31.43 | 36.75 |
| live-n33554432-g65536-r2--sqlite-m0 | 1 | 0.043111 | 0.108197 | 0.112237 | 31.42 | 36.75 |
| grouped-n32768-g512-t8192-w1-r2--varlit-indexed-crc-only | 1 | 0.013276 | 0.030982 | 0.040226 | 13.54 | 4.12 |
| grouped-n32768-g512-t8192-w1-r2--sqlite-m2147483648 | 1 | 0.025608 | 0.044204 | 0.045150 | 16.55 | 5.06 |
| grouped-n32768-g512-t8192-w1-r2--sqlite-m0 | 1 | 0.021801 | 0.040108 | 0.045461 | 16.77 | 5.06 |
| grouped-n32768-g512-t8192-w1-r2--sqlite-m1073741824 | 1 | 0.021512 | 0.040158 | 0.045307 | 16.55 | 5.06 |
| grouped-n32768-g512-t8192-w1-r2--varlit-indexed-full | 1 | 0.013936 | 0.031505 | 0.041768 | 13.56 | 4.12 |
| live-n33554432-g1048576-r2--varlit-native-view-full | 1 | 0.034172 | 0.059094 | 0.066904 | 25.26 | 32.00 |
| live-n33554432-g1048576-r2--varlit-native-view-crc-only | 1 | 0.034175 | 0.053151 | 0.058719 | 25.31 | 32.00 |
| live-n33554432-g1048576-r2--sqlite-m1073741824 | 1 | 0.045402 | 0.102520 | 0.109839 | 32.41 | 32.44 |
| live-n33554432-g1048576-r2--sqlite-m0 | 1 | 0.041702 | 0.094477 | 0.097938 | 32.40 | 32.44 |
| live-n33554432-g1048576-r2--varlit-native-mmap-full | 1 | 0.034567 | 0.052909 | 0.052241 | 25.26 | 32.00 |
| live-n33554432-g1048576-r2--sqlite-m2147483648 | 1 | 0.046406 | 0.101748 | 0.104865 | 32.48 | 32.44 |
| live-n33554432-g1048576-r2--varlit-native-mmap-crc-only | 1 | 0.036940 | 0.056874 | 0.058251 | 25.31 | 32.00 |
| grouped-n32768-g8192-t8192-w1-r2--sqlite-m2147483648 | 1 | 0.022361 | 0.046384 | 0.062069 | 13.98 | 4.44 |
| grouped-n32768-g8192-t8192-w1-r2--sqlite-m0 | 1 | 0.023806 | 0.044406 | 0.053977 | 13.90 | 4.44 |
| grouped-n32768-g8192-t8192-w1-r2--varlit-indexed-crc-only | 1 | 0.015464 | 0.034135 | 0.045816 | 14.55 | 4.07 |
| grouped-n32768-g8192-t8192-w1-r2--varlit-indexed-full | 1 | 0.016446 | 0.038405 | 0.056816 | 14.81 | 4.07 |
| grouped-n32768-g8192-t8192-w1-r2--sqlite-m1073741824 | 1 | 0.021124 | 0.039350 | 0.048526 | 14.00 | 4.44 |
| static-n33554432-g1048576-r2--varlit-native-view-full | 1 | 0.028014 | 0.410277 | 0.405375 | 25.19 | 32.00 |
| static-n33554432-g1048576-r2--sqlite-m1073741824 | 1 | 0.077935 | 0.128344 | 0.096155 | 82.82 | 32.44 |
| static-n33554432-g1048576-r2--varlit-native-mmap-crc-only | 1 | 0.029057 | 0.068643 | 0.057066 | 84.41 | 32.00 |
| static-n33554432-g1048576-r2--sqlite-m2147483648 | 1 | 0.066131 | 0.115419 | 0.087577 | 75.14 | 32.44 |
| static-n33554432-g1048576-r2--varlit-native-mmap-full | 1 | 0.029198 | 0.068813 | 0.057790 | 84.32 | 32.00 |
| static-n33554432-g1048576-r2--sqlite-m0 | 1 | 0.071899 | 0.253452 | 0.232499 | 32.26 | 32.44 |
| static-n33554432-g1048576-r2--varlit-native-view-crc-only | 1 | 0.030538 | 0.410954 | 0.396406 | 25.31 | 32.00 |
| static-n33554432-g65536-r2--varlit-native-view-full | 1 | 0.037987 | 0.149089 | 0.134197 | 23.41 | 32.06 |
| static-n33554432-g65536-r2--varlit-native-mmap-crc-only | 1 | 0.036431 | 0.083697 | 0.074811 | 85.85 | 32.06 |
| static-n33554432-g65536-r2--sqlite-m1073741824 | 1 | 0.071784 | 0.125005 | 0.102973 | 94.33 | 36.75 |
| static-n33554432-g65536-r2--varlit-native-view-crc-only | 1 | 0.034868 | 0.126635 | 0.113239 | 23.25 | 32.06 |
| static-n33554432-g65536-r2--sqlite-m0 | 1 | 0.072727 | 0.151243 | 0.128136 | 31.30 | 36.75 |
| static-n33554432-g65536-r2--sqlite-m2147483648 | 1 | 0.083815 | 0.132779 | 0.104929 | 84.18 | 36.75 |
| static-n33554432-g65536-r2--varlit-native-mmap-full | 1 | 0.033369 | 0.087011 | 0.078104 | 85.86 | 32.06 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
