# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
These medians do not establish statistical qualification.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| live-n33554432-g65536-r2--varlit-native-mmap-crc-only | 1 | 0.106304 | 0.133701 | 0.163748 | 31.95 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-view-full | 1 | 0.037103 | 0.057671 | 0.056317 | 31.90 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-mmap-full | 1 | 0.041562 | 0.073128 | 0.099364 | 31.91 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-view-crc-only | 1 | 0.039512 | 0.057473 | 0.056931 | 31.91 | 32.06 |
| live-n33554432-g65536-r2--sqlite-m1073741824 | 1 | 0.043828 | 0.154194 | 0.149391 | 55.41 | 36.75 |
| live-n33554432-g65536-r2--sqlite-m2147483648 | 1 | 0.051386 | 0.115629 | 0.115073 | 55.23 | 36.75 |
| live-n33554432-g65536-r2--sqlite-m0 | 1 | 0.045825 | 0.102323 | 0.095089 | 55.31 | 36.75 |
| grouped-n32768-g512-t8192-w1-r2--varlit-indexed-crc-only | 1 | 0.019933 | 0.038531 | 0.050575 | 13.53 | 4.12 |
| grouped-n32768-g512-t8192-w1-r2--sqlite-m2147483648 | 1 | 0.023849 | 0.046323 | 0.056797 | 16.52 | 5.06 |
| grouped-n32768-g512-t8192-w1-r2--sqlite-m0 | 1 | 0.026207 | 0.048395 | 0.055320 | 16.21 | 5.06 |
| grouped-n32768-g512-t8192-w1-r2--sqlite-m1073741824 | 1 | 0.027458 | 0.050641 | 0.055146 | 16.67 | 5.06 |
| grouped-n32768-g512-t8192-w1-r2--varlit-indexed-full | 1 | 0.016718 | 0.035801 | 0.044896 | 13.57 | 4.12 |
| live-n33554432-g1048576-r2--varlit-native-view-full | 1 | 0.078976 | 0.092232 | 0.090551 | 35.31 | 32.01 |
| live-n33554432-g1048576-r2--varlit-native-view-crc-only | 1 | 0.054247 | 0.069503 | 0.072505 | 35.31 | 32.01 |
| live-n33554432-g1048576-r2--sqlite-m1073741824 | 1 | 0.046391 | 0.098315 | 0.098575 | 56.39 | 32.44 |
| live-n33554432-g1048576-r2--sqlite-m0 | 1 | 0.047980 | 0.107174 | 0.101604 | 56.41 | 32.44 |
| live-n33554432-g1048576-r2--varlit-native-mmap-full | 1 | 0.049623 | 0.069193 | 0.066245 | 37.32 | 32.01 |
| live-n33554432-g1048576-r2--sqlite-m2147483648 | 1 | 0.043162 | 0.093891 | 0.090860 | 56.38 | 32.44 |
| live-n33554432-g1048576-r2--varlit-native-mmap-crc-only | 1 | 0.040060 | 0.053075 | 0.048107 | 37.44 | 32.00 |
| grouped-n32768-g8192-t8192-w1-r2--sqlite-m2147483648 | 1 | 0.022268 | 0.042165 | 0.051298 | 14.12 | 4.44 |
| grouped-n32768-g8192-t8192-w1-r2--sqlite-m0 | 1 | 0.020218 | 0.038787 | 0.046896 | 13.87 | 4.44 |
| grouped-n32768-g8192-t8192-w1-r2--varlit-indexed-crc-only | 1 | 0.015769 | 0.033099 | 0.045331 | 14.70 | 4.07 |
| grouped-n32768-g8192-t8192-w1-r2--varlit-indexed-full | 1 | 0.022029 | 0.043442 | 0.055956 | 14.48 | 4.07 |
| grouped-n32768-g8192-t8192-w1-r2--sqlite-m1073741824 | 1 | 0.020983 | 0.040451 | 0.050657 | 13.98 | 4.44 |
| static-n33554432-g1048576-r2--varlit-native-view-full | 1 | 0.030072 | 0.445390 | 0.431684 | 25.13 | 32.00 |
| static-n33554432-g1048576-r2--sqlite-m1073741824 | 1 | 0.092165 | 0.145365 | 0.104402 | 88.04 | 32.44 |
| static-n33554432-g1048576-r2--varlit-native-mmap-crc-only | 1 | 0.033151 | 0.075360 | 0.065909 | 84.30 | 32.00 |
| static-n33554432-g1048576-r2--sqlite-m2147483648 | 1 | 0.069338 | 0.120976 | 0.092967 | 65.07 | 32.44 |
| static-n33554432-g1048576-r2--varlit-native-mmap-full | 1 | 0.025513 | 0.064595 | 0.054817 | 78.44 | 32.00 |
| static-n33554432-g1048576-r2--sqlite-m0 | 1 | 0.075610 | 0.262863 | 0.233331 | 32.20 | 32.44 |
| static-n33554432-g1048576-r2--varlit-native-view-crc-only | 1 | 0.024774 | 0.435045 | 0.428486 | 25.35 | 32.00 |
| static-n33554432-g65536-r2--varlit-native-view-full | 1 | 0.260641 | 0.370483 | 0.136890 | 23.26 | 32.06 |
| static-n33554432-g65536-r2--varlit-native-mmap-crc-only | 1 | 0.032465 | 0.090038 | 0.083776 | 85.83 | 32.06 |
| static-n33554432-g65536-r2--sqlite-m1073741824 | 1 | 0.083200 | 0.134819 | 0.105889 | 94.32 | 36.75 |
| static-n33554432-g65536-r2--varlit-native-view-crc-only | 1 | 0.031202 | 0.138045 | 0.133864 | 23.37 | 32.06 |
| static-n33554432-g65536-r2--sqlite-m0 | 1 | 0.080736 | 0.166576 | 0.141028 | 31.23 | 36.75 |
| static-n33554432-g65536-r2--sqlite-m2147483648 | 1 | 0.075494 | 0.135918 | 0.109731 | 94.27 | 36.75 |
| static-n33554432-g65536-r2--varlit-native-mmap-full | 1 | 0.029836 | 0.082333 | 0.075969 | 85.77 | 32.06 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
