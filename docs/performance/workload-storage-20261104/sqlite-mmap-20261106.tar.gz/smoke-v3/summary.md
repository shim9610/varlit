# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
These medians do not establish statistical qualification.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| live-n33554432-g65536-r2--varlit-native-mmap-crc-only | 1 | 0.047253 | 0.076040 | 0.089853 | 23.54 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-view-full | 1 | 0.033925 | 0.058414 | 0.068610 | 23.57 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-mmap-full | 1 | 0.036295 | 0.063530 | 0.075035 | 23.55 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-view-crc-only | 1 | 0.037511 | 0.064750 | 0.078308 | 23.54 | 32.06 |
| live-n33554432-g65536-r2--sqlite-m1073741824 | 1 | 0.046636 | 0.119388 | 0.122619 | 31.24 | 36.75 |
| live-n33554432-g65536-r2--sqlite-m2147483648 | 1 | 0.052913 | 0.122537 | 0.120826 | 31.44 | 36.75 |
| live-n33554432-g65536-r2--sqlite-m0 | 1 | 0.048234 | 0.111585 | 0.114036 | 31.43 | 36.75 |
| grouped-n32768-g512-t8192-w1-r2--varlit-indexed-crc-only | 1 | 0.016658 | 0.034429 | 0.043118 | 13.60 | 4.12 |
| grouped-n32768-g512-t8192-w1-r2--sqlite-m2147483648 | 1 | 0.024035 | 0.044192 | 0.047587 | 16.63 | 5.06 |
| grouped-n32768-g512-t8192-w1-r2--sqlite-m0 | 1 | 0.024238 | 0.044735 | 0.050980 | 16.53 | 5.06 |
| grouped-n32768-g512-t8192-w1-r2--sqlite-m1073741824 | 1 | 0.024695 | 0.043537 | 0.047527 | 16.53 | 5.06 |
| grouped-n32768-g512-t8192-w1-r2--varlit-indexed-full | 1 | 0.015233 | 0.032264 | 0.040137 | 13.41 | 4.12 |
| live-n33554432-g1048576-r2--varlit-native-view-full | 1 | 0.035910 | 0.059232 | 0.062556 | 25.26 | 32.00 |
| live-n33554432-g1048576-r2--varlit-native-view-crc-only | 1 | 0.032089 | 0.051133 | 0.054293 | 25.26 | 32.00 |
| live-n33554432-g1048576-r2--sqlite-m1073741824 | 1 | 0.044180 | 0.102136 | 0.106706 | 32.38 | 32.44 |
| live-n33554432-g1048576-r2--sqlite-m0 | 1 | 0.044558 | 0.103270 | 0.111180 | 32.46 | 32.44 |
| live-n33554432-g1048576-r2--varlit-native-mmap-full | 1 | 0.036515 | 0.055710 | 0.057519 | 25.26 | 32.00 |
| live-n33554432-g1048576-r2--sqlite-m2147483648 | 1 | 0.041349 | 0.097858 | 0.100950 | 32.21 | 32.44 |
| live-n33554432-g1048576-r2--varlit-native-mmap-crc-only | 1 | 0.031884 | 0.051179 | 0.056814 | 25.27 | 32.00 |
| grouped-n32768-g8192-t8192-w1-r2--sqlite-m2147483648 | 1 | 0.020881 | 0.041971 | 0.055053 | 13.98 | 4.44 |
| grouped-n32768-g8192-t8192-w1-r2--sqlite-m0 | 1 | 0.020043 | 0.043989 | 0.058246 | 14.01 | 4.44 |
| grouped-n32768-g8192-t8192-w1-r2--varlit-indexed-crc-only | 1 | 0.017081 | 0.034585 | 0.048897 | 14.66 | 4.07 |
| grouped-n32768-g8192-t8192-w1-r2--varlit-indexed-full | 1 | 0.018017 | 0.036382 | 0.049255 | 14.71 | 4.07 |
| grouped-n32768-g8192-t8192-w1-r2--sqlite-m1073741824 | 1 | 0.021399 | 0.040220 | 0.048572 | 13.89 | 4.44 |
| static-n33554432-g1048576-r2--varlit-native-view-full | 1 | 0.025389 | 0.413302 | 0.403237 | 25.12 | 32.00 |
| static-n33554432-g1048576-r2--sqlite-m1073741824 | 1 | 0.068984 | 0.114208 | 0.091922 | 87.98 | 32.44 |
| static-n33554432-g1048576-r2--varlit-native-mmap-crc-only | 1 | 0.030646 | 0.069595 | 0.056881 | 84.33 | 32.00 |
| static-n33554432-g1048576-r2--sqlite-m2147483648 | 1 | 0.062159 | 0.106206 | 0.083040 | 83.90 | 32.44 |
| static-n33554432-g1048576-r2--varlit-native-mmap-full | 1 | 0.029841 | 0.072653 | 0.063812 | 84.30 | 32.00 |
| static-n33554432-g1048576-r2--sqlite-m0 | 1 | 0.069891 | 0.240609 | 0.214243 | 32.26 | 32.44 |
| static-n33554432-g1048576-r2--varlit-native-view-crc-only | 1 | 0.029717 | 0.429731 | 0.423769 | 25.29 | 32.00 |
| static-n33554432-g65536-r2--varlit-native-view-full | 1 | 0.048648 | 0.141032 | 0.116720 | 23.37 | 32.06 |
| static-n33554432-g65536-r2--varlit-native-mmap-crc-only | 1 | 0.032370 | 0.078910 | 0.068668 | 85.81 | 32.06 |
| static-n33554432-g65536-r2--sqlite-m1073741824 | 1 | 0.074240 | 0.126262 | 0.101225 | 94.35 | 36.75 |
| static-n33554432-g65536-r2--varlit-native-view-crc-only | 1 | 0.032389 | 0.131560 | 0.124062 | 23.25 | 32.06 |
| static-n33554432-g65536-r2--sqlite-m0 | 1 | 0.075332 | 0.158614 | 0.137162 | 31.30 | 36.75 |
| static-n33554432-g65536-r2--sqlite-m2147483648 | 1 | 0.070709 | 0.120583 | 0.097712 | 94.31 | 36.75 |
| static-n33554432-g65536-r2--varlit-native-mmap-full | 1 | 0.032702 | 0.080666 | 0.071202 | 85.96 | 32.06 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
