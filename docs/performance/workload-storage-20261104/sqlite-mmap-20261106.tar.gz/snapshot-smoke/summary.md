# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
These medians do not establish statistical qualification.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| live-n33554432-g65536-r2--varlit-native-mmap-crc-only | 1 | 0.033567 | 0.061340 | 0.071379 | 23.64 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-mmap-snapshot-full | 1 | 0.040532 | 0.067546 | 0.078366 | 27.52 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-mmap-full | 1 | 0.038729 | 0.068713 | 0.084638 | 23.64 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-view-crc-only | 1 | 0.033511 | 0.061758 | 0.075539 | 23.50 | 32.06 |
| live-n33554432-g65536-r2--sqlite-m1073741824 | 1 | 0.044576 | 0.133657 | 0.136650 | 31.30 | 36.75 |
| live-n33554432-g65536-r2--sqlite-m2147483648 | 1 | 0.051976 | 0.119594 | 0.119604 | 31.41 | 36.75 |
| live-n33554432-g65536-r2--sqlite-m0 | 1 | 0.043604 | 0.110014 | 0.112312 | 31.42 | 36.75 |
| live-n33554432-g65536-r2--varlit-native-view-full | 1 | 0.034994 | 0.061167 | 0.068591 | 23.50 | 32.06 |
| live-n33554432-g65536-r2--varlit-native-mmap-snapshot-crc-only | 1 | 0.034796 | 0.063067 | 0.067565 | 27.51 | 32.06 |
| live-n33554432-g1048576-r2--sqlite-m2147483648 | 1 | 0.043690 | 0.113430 | 0.122450 | 32.44 | 32.44 |
| live-n33554432-g1048576-r2--varlit-native-mmap-full | 1 | 0.049936 | 0.071771 | 0.078126 | 25.34 | 32.00 |
| live-n33554432-g1048576-r2--varlit-native-mmap-snapshot-crc-only | 1 | 0.037568 | 0.057233 | 0.060334 | 27.73 | 32.00 |
| live-n33554432-g1048576-r2--sqlite-m0 | 1 | 0.049183 | 0.109003 | 0.115137 | 32.40 | 32.44 |
| live-n33554432-g1048576-r2--varlit-native-mmap-crc-only | 1 | 0.038902 | 0.061768 | 0.063520 | 25.35 | 32.00 |
| live-n33554432-g1048576-r2--varlit-native-view-full | 1 | 0.039364 | 0.061135 | 0.068271 | 25.35 | 32.00 |
| live-n33554432-g1048576-r2--sqlite-m1073741824 | 1 | 0.042452 | 0.108232 | 0.112974 | 32.39 | 32.44 |
| live-n33554432-g1048576-r2--varlit-native-mmap-snapshot-full | 1 | 0.038034 | 0.058371 | 0.059537 | 27.78 | 32.00 |
| live-n33554432-g1048576-r2--varlit-native-view-crc-only | 1 | 0.035821 | 0.055604 | 0.059871 | 25.35 | 32.00 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
