# Storage comparison observations

Medians of successful timing observations; failures remain in results.jsonl.
These medians do not establish statistical qualification.

| Profile | n | Write s | Completion s | CPU s | wait4 max RSS MiB | Final allocated MiB |
|---|---:|---:|---:|---:|---:|---:|
| live-n1073741824-g65536-r8--sqlite-m0 | 7 | 2.684609 | 3.230268 | 7.187161 | 31.47 | 1170.45 |
| live-n1073741824-g65536-r8--varlit-native-mmap-snapshot-crc-only | 7 | 1.949840 | 2.081352 | 7.168709 | 80.08 | 1025.76 |
| live-n1073741824-g65536-r8--varlit-native-view-crc-only | 7 | 1.633691 | 1.688227 | 4.026534 | 23.60 | 1025.76 |
| live-n1073741824-g65536-r8--sqlite-m1073741824 | 7 | 2.631724 | 3.220522 | 7.247570 | 31.43 | 1170.45 |
| live-n1073741824-g65536-r8--varlit-native-mmap-snapshot-full | 7 | 1.903580 | 2.040219 | 6.829613 | 80.98 | 1025.76 |
| live-n1073741824-g65536-r8--varlit-native-view-full | 7 | 1.576704 | 1.619861 | 3.965071 | 23.64 | 1025.76 |
| live-n1073741824-g65536-r8--sqlite-m2147483648 | 7 | 2.672751 | 3.191190 | 7.390020 | 31.43 | 1170.45 |
| live-n1073741824-g65536-r8--varlit-native-mmap-crc-only | 7 | 1.723928 | 1.764769 | 4.490572 | 23.59 | 1025.76 |
| live-n1073741824-g65536-r8--varlit-native-mmap-full | 7 | 1.770500 | 1.828674 | 4.792647 | 23.59 | 1025.76 |
| live-n1073741824-g1048576-r1--varlit-native-view-crc-only | 7 | 0.959363 | 0.979990 | 0.758939 | 25.36 | 1024.12 |
| live-n1073741824-g1048576-r1--varlit-native-view-full | 7 | 0.951725 | 0.972296 | 0.743427 | 25.32 | 1024.12 |
| live-n1073741824-g1048576-r1--varlit-native-mmap-full | 7 | 0.957652 | 0.990489 | 0.736906 | 25.31 | 1024.12 |
| live-n1073741824-g1048576-r1--sqlite-m2147483648 | 7 | 1.719014 | 2.155821 | 1.886683 | 32.52 | 1033.32 |
| live-n1073741824-g1048576-r1--varlit-native-mmap-crc-only | 7 | 0.957196 | 0.981068 | 0.729571 | 25.28 | 1024.12 |
| live-n1073741824-g1048576-r1--varlit-native-mmap-snapshot-full | 7 | 0.986811 | 1.012271 | 0.805424 | 28.02 | 1024.12 |
| live-n1073741824-g1048576-r1--sqlite-m0 | 7 | 1.685398 | 2.116194 | 1.849121 | 32.52 | 1033.32 |
| live-n1073741824-g1048576-r1--varlit-native-mmap-snapshot-crc-only | 7 | 0.989960 | 1.015178 | 0.807877 | 27.98 | 1024.12 |
| live-n1073741824-g1048576-r1--sqlite-m1073741824 | 7 | 1.635784 | 2.062665 | 1.888467 | 32.48 | 1033.32 |
| live-n1073741824-g65536-r1--varlit-native-view-full | 7 | 1.116414 | 1.143068 | 1.008551 | 23.68 | 1025.76 |
| live-n1073741824-g65536-r1--varlit-native-mmap-snapshot-full | 7 | 1.165323 | 1.219718 | 1.536307 | 48.86 | 1025.76 |
| live-n1073741824-g65536-r1--varlit-native-mmap-crc-only | 7 | 1.128414 | 1.154516 | 1.043582 | 23.68 | 1025.76 |
| live-n1073741824-g65536-r1--varlit-native-mmap-snapshot-crc-only | 7 | 1.138245 | 1.194029 | 1.543703 | 48.91 | 1025.76 |
| live-n1073741824-g65536-r1--varlit-native-mmap-full | 7 | 1.134567 | 1.163857 | 1.078601 | 23.71 | 1025.76 |
| live-n1073741824-g65536-r1--sqlite-m0 | 7 | 1.770742 | 2.282731 | 1.950493 | 31.55 | 1170.45 |
| live-n1073741824-g65536-r1--varlit-native-view-crc-only | 7 | 1.131671 | 1.159166 | 0.976940 | 23.67 | 1025.76 |
| live-n1073741824-g65536-r1--sqlite-m1073741824 | 7 | 1.796438 | 2.290271 | 2.026934 | 31.54 | 1170.45 |
| live-n1073741824-g65536-r1--sqlite-m2147483648 | 7 | 1.816027 | 2.309477 | 2.001672 | 31.46 | 1170.45 |
| live-n1073741824-g1048576-r8--varlit-native-view-full | 7 | 1.326258 | 1.366716 | 3.146965 | 25.26 | 1024.12 |
| live-n1073741824-g1048576-r8--varlit-native-mmap-crc-only | 7 | 1.268946 | 1.306105 | 2.731266 | 25.30 | 1024.12 |
| live-n1073741824-g1048576-r8--varlit-native-mmap-full | 7 | 1.298601 | 1.338646 | 2.699649 | 25.25 | 1024.12 |
| live-n1073741824-g1048576-r8--varlit-native-view-crc-only | 7 | 1.306702 | 1.347698 | 3.082529 | 25.30 | 1024.12 |
| live-n1073741824-g1048576-r8--sqlite-m2147483648 | 7 | 2.367235 | 2.829617 | 6.406007 | 32.41 | 1033.32 |
| live-n1073741824-g1048576-r8--varlit-native-mmap-snapshot-full | 7 | 1.275676 | 1.314727 | 2.658943 | 28.11 | 1024.12 |
| live-n1073741824-g1048576-r8--varlit-native-mmap-snapshot-crc-only | 7 | 1.289154 | 1.325988 | 2.930870 | 28.11 | 1024.12 |
| live-n1073741824-g1048576-r8--sqlite-m0 | 7 | 2.426691 | 2.960724 | 6.425376 | 32.38 | 1033.32 |
| live-n1073741824-g1048576-r8--sqlite-m1073741824 | 7 | 2.356035 | 2.822529 | 6.368842 | 32.48 | 1033.32 |

wait4 max RSS is not aggregate physical memory. Use separate sampled process-tree PSS/RSS probes.
Array completion includes different supported query sets for stream (no point/range API); compare its common scan/write metrics only.
