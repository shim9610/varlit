import subprocess,json,time,os
from pathlib import Path
root=Path('/workspace/scratch/chunk-stream'); jobs=[]
def run(name,args,cwd='/workspace/varlit'):
 print('START',name,flush=True); start=time.monotonic()
 with (root/(name+'.log')).open('w') as f:r=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 jobs.append(dict(name=name,command=args,exit=r.returncode,seconds=time.monotonic()-start));(root/'validation-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
 print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('fmt',['cargo','fmt','--all','--','--check'])
run('stream-tests',['cargo','test','-p','varlit-core','--all-features','--test','chunk_stream'])
for feature in ['', 'integrity','compression-zstd']:
 run('feature-'+(feature or 'none'),['cargo','test','-p','varlit-core','--no-default-features',*(['--features',feature] if feature else []),'--test','chunk_stream'])
run('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings'])
run('workspace',['cargo','test','--workspace','--all-features'])
run('contracts',['python3','scripts/check_storage_contracts.py','--output',str(root/'contracts')])
run('python',['python3','-m','unittest','discover','-s','scripts/tests'])
run('proof-source',['python3','scripts/check_proof_contracts.py','--capture',str(root/'source-before.json')])
for feature in ['default','all']:
 run('kani-'+feature,['cargo','kani','-p','varlit-core',*(['--all-features'] if feature=='all' else []),'--default-unwind','5','-Z','unstable-options','--harness-timeout','300'])
 run('proof-check-'+feature,['python3','scripts/check_proof_contracts.py','--log',str(root/('kani-'+feature+'.log')),'--features',feature,'--source-before',str(root/'source-before.json'),'--output',str(root/('kani-'+feature+'.json'))])
run('resource-mutations',['python3','scripts/check_resource_mutations.py','--output',str(root/'resource-mutations')])
run('fuzz-codec',['cargo','+nightly','fuzz','run','codec_arbitrary','--','-max_total_time=120','-rss_limit_mb=4096'],cwd='/workspace/varlit/fuzz')
print('DONE',flush=True)
