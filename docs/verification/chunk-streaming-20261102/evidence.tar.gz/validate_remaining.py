import subprocess,json,time,os
from pathlib import Path
root=Path('/workspace/scratch/chunk-stream'); jobs=json.loads((root/'validation-jobs.json').read_text())
def run(name,args,cwd='/workspace/varlit'):
 print('START',name,flush=True); start=time.monotonic()
 with (root/(name+'.log')).open('w') as f:r=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 jobs.append(dict(name=name,command=args,exit=r.returncode,seconds=time.monotonic()-start));(root/'validation-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
 print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('python',['python3','-m','unittest','discover','-s','scripts/tests'])
run('proof-source',['python3','scripts/check_proof_contracts.py','--capture',str(root/'source-before.json')])
for feature in ['default','all']:
 run('kani-'+feature,['cargo','kani','-p','varlit-core',*(['--all-features'] if feature=='all' else []),'--default-unwind','5','-Z','unstable-options','--harness-timeout','300'])
 run('proof-check-'+feature,['python3','scripts/check_proof_contracts.py','--log',str(root/('kani-'+feature+'.log')),'--features',feature,'--source-before',str(root/'source-before.json'),'--output',str(root/('kani-'+feature+'.json'))])
run('resource-mutations',['python3','scripts/check_resource_mutations.py','--output',str(root/'resource-mutations')])
run('fuzz-codec',['cargo','+nightly-2026-10-12','fuzz','run','codec_arbitrary','--','-max_total_time=120','-rss_limit_mb=4096'],cwd='/workspace/varlit/fuzz')
print('DONE',flush=True)
