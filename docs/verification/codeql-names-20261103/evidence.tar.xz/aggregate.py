import json,statistics,hashlib
from pathlib import Path
r=Path('/workspace/scratch/codeql-fix');repo=Path('/workspace/varlit')
def read(p):return json.loads(p.read_text())
for p,h in read(r/'source-after.json').items():assert hashlib.sha256((repo/p).read_bytes()).hexdigest()==h
xs=read(r/'native/native-samples.json')
if (r/'confirmation/native-samples.json').exists():xs+=read(r/'confirmation/native-samples.json')
summary=[]
for c in sorted({x['case'] for x in xs}):
 ys=[x for x in xs if x['case']==c];work=[{k:v for k,v in x['result'].items() if k!='seconds'} for x in ys];assert all(x==work[0] for x in work);metrics={}
 for k,fn,agg in [('operation_seconds',lambda x:x['result']['seconds'],statistics.median),('cpu_seconds',lambda x:x['usage']['cpu'],statistics.median),('rss_kib',lambda x:x['usage']['rss'],max),('write_bytes',lambda x:x['usage']['write_blocks']*512,statistics.median)]:
  a,b=[agg(fn(x) for x in ys if x['side']==s) for s in ['before','after']];d=100*(b/a-1) if a else None
  metrics[k]={'before':a,'after':b,'change_percent':d,'status':'passed' if (d is not None and d<=5) or (d is None and b==0) else 'failed'}
 summary.append({'case':c,'pairs':len(ys)//2,'work':work[0],'metrics':metrics})
result={'baseline':'6940af6a5e3a873db8645198e1d6aebc9dc823dd','native':summary,'timing_observations':len(xs)+12,'swmr':{n:read(r/f'swmr/swmr-{n}-comparison.json') for n in ['1','4']},'resources':{s:read(r/f'resources-{s}.json') for s in ['before','after']},'host':read(r/'host.json'),'sections':read(r/'section-hashes.json')}
result['performance_status']='passed' if all(m['status']=='passed' for c in summary for m in c['metrics'].values()) and all(s['status']=='passed' for s in result['swmr'].values()) else 'failed'
(r/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['performance_status'],result['timing_observations'])
for c in summary:print(c['case'],c['pairs'],{k:v['change_percent'] for k,v in c['metrics'].items()})
for n,s in result['swmr'].items():print('SWMR',n,s['status'],{k:v['change_percent'] for k,v in s['metrics'].items()})
