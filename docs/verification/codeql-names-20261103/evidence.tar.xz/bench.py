import json,os,subprocess,sys
from pathlib import Path
r=Path('/workspace/scratch/codeql-fix');repo=Path('/workspace/varlit')
host={k:Path('/sys/fs/cgroup',k).read_text() for k in ['cpu.max','memory.max','memory.events']}
(r/'host.json').write_text(json.dumps(host,indent=2)+'\n')
common=['--before',str(r/'before-bin'),'--after',str(r/'after-bin'),'--repo',str(repo)]
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:code=subprocess.run(args,cwd=repo,stdout=f,stderr=subprocess.STDOUT).returncode
 print('END',name,code,flush=True);return code
base=['python3',str(repo/'docs/performance/audit-followup-20261102/bench.py'),*common]
assert run('bench-native',base+['--phase','native','--pairs','5','--native-cases','0','4','7','9','10','--output',str(r/'native')])==0
flagged=[str(v['case']) for v in json.loads((r/'native/native-summary.json').read_text()) if any((m['change_percent'] or 0)>5 for m in v['metrics'].values())]
if flagged: assert run('bench-confirmation',base+['--phase','native','--pairs','15','--native-cases',*flagged,'--output',str(r/'confirmation')])==0
run('bench-swmr',base+['--phase','concurrent','--pairs','3','--output',str(r/'swmr')])
for side in ['before','after']:
 os.environ['TMPDIR']=str(r/'resource-disk');(r/'resource-disk').mkdir(exist_ok=True)
 assert run('resources-'+side,['python3',str(repo/'docs/performance/audit-followup-20261102/resource_probe.py'),'--output',str(r/('resources-'+side+'.json')),str(r/(side+'-bin')/'oom_maintenance_load'),'complex','65536','512'])==0
host['memory.events_after']=Path('/sys/fs/cgroup/memory.events').read_text();(r/'host.json').write_text(json.dumps(host,indent=2)+'\n')
print('DONE',flush=True)
