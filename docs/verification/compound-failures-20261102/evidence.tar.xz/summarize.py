import json,statistics
from pathlib import Path
root=Path('/workspace/scratch/compound-hardening');r=root/'final'
rows=[]
for series in ['native','confirmation']:
 p=r/series/'native-samples.json'
 if p.exists(): rows += [{**x,'series':series} for x in json.loads(p.read_text())]
out={'baseline':'598ec8b31dcf09d718955d901fa7bed4d2360eb2','diagnostic_timing_observations':62,'diagnostic_resource_probes':2,'native':[]}
for case in sorted({x['case'] for x in rows}):
 selected=[x for x in rows if x['case']==case];metrics={}
 for k,fn,agg in [('operation_seconds',lambda x:x['result']['seconds'],statistics.median),('cpu_seconds',lambda x:x['usage']['cpu'],statistics.median),('peak_rss_kib',lambda x:x['usage']['rss'],max),('write_bytes',lambda x:x['usage']['write_blocks']*512,statistics.median)]:
  a,b=[agg(fn(x) for x in selected if x['side']==s) for s in ['before','after']];delta=100*(b/a-1) if a else None;metrics[k]={'before':a,'after':b,'change_percent':delta,'status':'failed' if delta is not None and delta>5 else 'passed'}
 out['native'].append({'case':case,'pairs':len(selected)//2,'metrics':metrics})
out['swmr']={str(n):json.loads((r/'swmr'/f'swmr-{n}-comparison.json').read_text()) for n in [1,4]}
out['resources']={side:json.loads((r/f'resources-{side}.json').read_text()) for side in ['before','after']}
out['host']=json.loads((r/'host.json').read_text());out['qualified_timing_observations']=len(rows)+12;out['qualified_resource_probes']=2
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['qualified_timing_observations','qualified_resource_probes','native']},indent=2))
