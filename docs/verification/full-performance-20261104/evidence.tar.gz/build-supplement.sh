#!/usr/bin/env bash
set -euo pipefail
r=/workspace/scratch/full-performance-20261104
# Run only after the complete primary timing driver has exited.
python3 - <<'PY'
from pathlib import Path
import shutil
head=Path('/workspace/varlit');base=Path('/workspace/varlit-full-bench-main');r=Path('/workspace/scratch/full-performance-20261104')
# Baseline's original load CLI predates fixed work/open-count options. Use the
# exact current benchmark harness on both runtimes for the corrected comparison.
shutil.copy2(head/'crates/varlit/examples/scalable_load.rs',base/'crates/varlit/examples/scalable_load.rs')
(base/'crates/varlit/examples/scalable_load.rs').touch()
s=(head/'crates/varlit/examples/full_record_mutation_load.rs').read_text()
before='\n    0_u64;\n    let start = Instant::now();'
assert s.count(before)==1
s=s.replace(before,'\n    if args.get(6).is_some_and(|s| s == "warm") {\n        writer.mark_record_dead(*offsets.iter().max().unwrap())?;\n    }'+before)
for repo in [head,base]:(repo/'crates/varlit/examples/warm_record_mutation_load.rs').write_text(s)
for side in ['head-bin','main-bin']:(r/'supplement'/side).mkdir(parents=True,exist_ok=True)
shutil.copy2(r/'head-bin/scalable_load',r/'supplement/head-bin/scalable_load')
shutil.copy2(r/'measure',r/'supplement/measure')
PY
source /workspace/tooling/varlit/env.sh
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
cd /workspace/varlit
cargo build --locked --release --features integrity,compression-zstd,mmap,zero-copy,experimental-matrix-reuse -p varlit --example warm_record_mutation_load > "$r/build-warm-head.log" 2>&1
cp target/release/examples/warm_record_mutation_load "$r/supplement/head-bin/warm_record_mutation_load"
cd /workspace/varlit-full-bench-main
export CARGO_TARGET_DIR=/workspace/varlit/target
cargo build --locked --release --features integrity,compression-zstd,mmap,zero-copy,experimental-matrix-reuse -p varlit --example warm_record_mutation_load --example scalable_load > "$r/build-canonical-main.log" 2>&1
cp /workspace/varlit/target/release/examples/warm_record_mutation_load "$r/supplement/main-bin/warm_record_mutation_load"
cp /workspace/varlit/target/release/examples/scalable_load "$r/supplement/main-bin/scalable_load"
# Extra default/no-CRC matrix; all builds finish before supplemental timing.
python3 - <<'PY'
from pathlib import Path
import shutil
r=Path('/workspace/scratch/full-performance-20261104')
head=Path('/workspace/varlit');base=Path('/workspace/varlit-full-bench-main')
for name in ['full_record_mutation_load','full_perf_bench','full_native_streaming_load','scalable_load']:
 s=(head/'crates/varlit/examples'/(name+'.rs')).read_text().replace('integrity: crc32;','')
 for repo in [head,base]:(repo/'crates/varlit/examples'/('default_'+name+'.rs')).write_text(s)
for side in ['head-bin','main-bin']:(r/'default'/side).mkdir(parents=True,exist_ok=True)
shutil.copy2(r/'measure',r/'default/measure')
PY
cd /workspace/varlit
unset CARGO_TARGET_DIR
cargo build --locked --release -p varlit --example default_full_record_mutation_load --example default_full_perf_bench --example default_full_native_streaming_load --example default_scalable_load > "$r/build-default-head.log" 2>&1
cargo build --locked --release -p varlit-core --example ownership_load --example decoder_memory_load >> "$r/build-default-head.log" 2>&1
python3 - <<'PY'
from pathlib import Path
import shutil
for n in ['default_full_record_mutation_load','default_full_perf_bench','default_full_native_streaming_load','default_scalable_load','ownership_load','decoder_memory_load']:shutil.copy2(Path('/workspace/varlit/target/release/examples')/n,Path('/workspace/scratch/full-performance-20261104/default/head-bin')/n)
PY
cd /workspace/varlit-full-bench-main
export CARGO_TARGET_DIR=/workspace/varlit/target
cargo build --locked --release -p varlit --example default_full_record_mutation_load --example default_full_perf_bench --example default_full_native_streaming_load --example default_scalable_load > "$r/build-default-main.log" 2>&1
cargo build --locked --release -p varlit-core --example ownership_load --example decoder_memory_load >> "$r/build-default-main.log" 2>&1
python3 - <<'PY'
from pathlib import Path
import shutil
for n in ['default_full_record_mutation_load','default_full_perf_bench','default_full_native_streaming_load','default_scalable_load','ownership_load','decoder_memory_load']:shutil.copy2(Path('/workspace/varlit/target/release/examples')/n,Path('/workspace/scratch/full-performance-20261104/default/main-bin')/n)
PY
