"""Default features/no native CRC: eight fixed common-path workloads."""
import run as suite
root=suite.R;suite.CASES=[]
suite.case('default-fixed-2m','default_full_record_mutation_load',['writer','fixed','forward',2000000,200000],'default-native')
suite.case('default-variable','default_full_record_mutation_load',['writer','variable','random',200000,20000],'default-native')
suite.case('default-mixed-4g','default_full_record_mutation_load',['writer','mixed','random',131072,8192],'default-native')
suite.case('default-codec-merge','default_full_perf_bench',[100000],'default-codec-merge')
suite.case('default-map-decode','decoder_memory_load',['fixed',1048576,8],'default-codec')
suite.case('default-owner-64m','ownership_load',['bytes',67108864,16],'default-ownership')
suite.case('default-independent-4g-4m-r8','default_full_native_streaming_load',[4<<30,4<<20,16<<20,8,16,0,'resident'],'default-independent',True)
suite.case('default-batch-indexed-1g-1m-r8','default_scalable_load',['indexed',1<<30,1<<20,8],'default-batch-index',True,'scalable')
suite.R=root/'default';suite.OUT=suite.R/'timings';suite.OUT.mkdir(exist_ok=True)
suite.BINS={'main-a':suite.R/'main-bin','main-b':suite.R/'main-bin','head':suite.R/'head-bin'}
original=suite.manifest
def manifest():
 p=original();p['features']='Default Cargo features (none); native CRC disabled in format and --crc false. Internal format-mandated checks unchanged.';return p
suite.manifest=manifest
invoke=suite.invoke
def no_crc(c,label,args,stem,events_required=True):
 if c['kind']=='scalable':args=[*args];args[args.index('--crc')+1]='false'
 return invoke(c,label,args,stem,events_required)
suite.invoke=no_crc
if __name__=='__main__':suite.run()
