from pathlib import Path
import json
O=Path('/workspace/varlit/docs/verification/full-performance-20261104')
d=json.loads((O/'results.json').read_text())
rows=[{k:s.get(k) for k in ['case','family','configuration','groups','status','values','comparisons','primary_metrics','same_binary_percent']} for s in d['cases']]
text="""<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>varlit 전체 성능 비교</title>
<style>body{font:14px system-ui,sans-serif;margin:24px;color:#20242a;background:#fff}h1{font-size:24px}p{max-width:1100px;line-height:1.6}select,input{padding:8px;margin:4px}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}th,td{padding:8px;border-bottom:1px solid #ddd;text-align:right}th{position:sticky;top:0;background:#eef1f5}td:first-child,th:first-child{text-align:left}td:first-child{font-family:monospace}.bad{color:#a51d26}.warn{color:#8b5d00}.good{color:#176f42}small{color:#555}</style>
<h1>varlit 전체 성능 비교</h1><p>74개 조건. main ba541cc → PR 런타임 1e59239. 4 CPU / 16 GiB / 32 GiB, 관측 기준 5%. 시간은 해당 루프, CPU와 RSS는 입력 준비를 포함한 전체 프로세스입니다. 배치는 write 단계가 기본 표시이며 다른 단계와 모든 초과 지표는 Markdown·JSON 보고서에 있습니다. 전체 상태는 모든 지표를 합친 판정이므로 선택한 지표가 기준 안이어도 초과일 수 있습니다.</p>
<label>검색 <input id="query" placeholder="예: independent, matrix, default"></label>
<label>설정 <select id="config"><option value="">전체</option><option>CRC/zstd/mmap/zero-copy</option><option>default/no-native-CRC</option></select></label>
<label>지표 <select id="metric"><option value="time">주 작업 시간(s)</option><option value="cpu">전체 CPU(s)</option><option value="rss">최대 RSS(KiB)</option><option value="writer_cpu_seconds">독립 writer CPU(s)</option></select></label>
<label>정렬 <select id="sort"><option value="source">조건 순서</option><option value="descending">최대 증가율 내림차순</option></select></label>
<p id="count"></p><table><thead><tr><th>조건</th><th>그룹</th><th>main A</th><th>main B</th><th>PR</th><th>A 대비</th><th>B 대비</th><th>대조군 B/A</th><th>전체 상태</th></tr></thead><tbody id="body"></tbody></table>
<p><small>대조군 편차는 입력 준비·스케줄링 등의 영향을 포함합니다. 5%는 통계적 오차 범위가 아닙니다. 초과 지표와 불확실한 조건을 그대로 보존했습니다. 데이터·출처: <a href="results.json">results.json</a>, <a href="README.md">상세 보고서</a>.</small></p>
<script>const DATA=__DATA__;
const state={passed:"관측 기준 통과",regression:"관측 기준 초과",unqualified:"대조군 편차 초과",execution_failed:"실행 실패",work_mismatch:"작업량 불일치"};
function pct(a,b){return b===0?(a===0?0:null):100*(a/b-1)}
function percent(n){return n===null?"추가됨":(n>=0?"+":"")+n.toFixed(2)+"%"}
function render(){const q=document.getElementById("query").value.toLowerCase(),c=document.getElementById("config").value,m=document.getElementById("metric").value;
let list=DATA.filter(r=>r.case.toLowerCase().includes(q)&&(!c||r.configuration===c)).map(r=>{const key=r.primary_metrics[m]||m;return {r:r,v:r.values&&r.values[key]}}).filter(x=>x.v||m!=="writer_cpu_seconds");
if(document.getElementById("sort").value==="descending")list.sort((a,b)=>(b.v?Math.max(pct(b.v.head,b.v["main-a"]),pct(b.v.head,b.v["main-b"])):Infinity)-(a.v?Math.max(pct(a.v.head,a.v["main-a"]),pct(a.v.head,a.v["main-b"])):Infinity));
const target=document.getElementById("body");target.textContent="";
for(const x of list){const r=x.r,v=x.v,tr=document.createElement("tr");const cells=v?[r.case,r.groups,v["main-a"].toFixed(6),v["main-b"].toFixed(6),v.head.toFixed(6),percent(pct(v.head,v["main-a"])),percent(pct(v.head,v["main-b"])),percent(pct(v["main-b"],v["main-a"])),state[r.status]]:[r.case,r.groups,"—","—","—","—","—","—",state[r.status]];
cells.forEach((value,i)=>{const td=document.createElement("td");td.textContent=value;if(i===8)td.className=r.status==="passed"?"good":r.status==="unqualified"?"warn":"bad";tr.appendChild(td)});target.appendChild(tr)}
document.getElementById("count").textContent=list.length+"개 조건 표시";}for(const name of ["query","config","metric","sort"])document.getElementById(name).addEventListener("input",render);render();</script></html>"""
(O/'report.html').write_text(text.replace('__DATA__',json.dumps(rows,ensure_ascii=False).replace('<','\\u003c')))
print('Interactive report written',len(rows))
