"""Freeze exact sources and raw observations only after all measurements finish."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile
R=Path(__file__).resolve().parent;REPO=Path('/workspace/varlit');BASE=Path('/workspace/varlit-full-bench-main')
O=REPO/'docs/verification/full-performance-20261104'
assert (O/'results.json').exists()
S=R/'source-snapshot';assert not S.exists(),'Do not overwrite a frozen source snapshot'
for side,repo in [('head',REPO),('main',BASE)]:
 for folder in ['crates/varlit/examples','crates/varlit-core/examples']:
  for p in (repo/folder).glob('*.rs'):
   # Keep every directly referenced harness and original surrounding examples.
   dest=S/side/p.relative_to(repo);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 for name in ['Cargo.toml','Cargo.lock','crates/varlit/Cargo.toml','crates/varlit-core/Cargo.toml']:
  dest=S/side/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,dest)
for label,rev in [('head','1e592397d34f4f576111f1107fb29303b9d472b0'),('main','ba541cc3082cecdf7f385d06897a58a3889e1294')]:
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',rev,'crates/varlit-core/src','crates/varlit/src','crates/varlit-macros/src'],cwd=REPO,text=True).splitlines()
 for name in paths:
  dest=S/label/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',rev+':'+name],cwd=REPO))
 p=S/label/'original-scalable_load.rs';p.write_bytes(subprocess.check_output(['git','show',rev+':crates/varlit/examples/scalable_load.rs'],cwd=REPO))
manifest=[]
allow={'.json','.jsonl','.log','.py','.sh','.rs','.c','.stdout','.stderr','.md','.toml','.lock'}
patterns=[rb'github_pat_[A-Za-z0-9_]{30,}',rb'ghp_[A-Za-z0-9]{30,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 parts=p.relative_to(R).parts
 if any(x.endswith('-bin') or x in ('disk-data','fixtures','target','build','__pycache__') for x in parts):continue
 if p.name.startswith('HANDOFF') or p.name.startswith('pr-body'):continue
 if p.suffix not in allow:continue
 raw=p.read_bytes();assert not any(re.search(pattern,raw) for pattern in patterns),p
 files.append(p);manifest.append({'path':str(p.relative_to(R)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
fixtures={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (R/'fixtures').iterdir() if p.is_file()}
(O/'fixture-provenance.json').write_text(json.dumps({'fixtures':fixtures,'generation':['main-bin/oom_maintenance_load prepare-decode 67108864 1048576 fixtures/chunks.bin','main-bin/chunk_stream_load prepare fixtures/random.bin 67108864 1048576 random'],'note':'Workload files and executables are excluded from the archive; exact source and binary digests are retained.'},indent=2)+'\n')
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=6) as t:
 for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
 t.add(O/'evidence-manifest.json',arcname='evidence-manifest.json',recursive=False)
with tarfile.open(O/'evidence.tar.gz','r:gz') as t:
 for m in manifest:
  b=t.extractfile(m['path']).read();assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
(O/'evidence.sha256').write_text(hashlib.sha256((O/'evidence.tar.gz').read_bytes()).hexdigest()+'  evidence.tar.gz\n')
print('Verified',len(files),'raw/source entries;',sum(m['bytes'] for m in manifest),'raw bytes;', (O/'evidence.tar.gz').stat().st_size,'compressed bytes',flush=True)
