"""Run only after timings. Sampling may miss peaks; file/FD snapshots are not atomic."""
from pathlib import Path
import json,os,stat,subprocess,time
import run as suite
R=suite.R
import sys
DEFAULT='--default' in sys.argv
if DEFAULT:
 import default
OUT=(R/'default' if DEFAULT else R)/'resource-probes';OUT.mkdir(exist_ok=True)
suite.OUT=OUT
PROBES=[]
def invoke(c,label,args,stem,events_required=True):
 usage=OUT/(stem+'.usage.json');pidfile=OUT/(stem+'.pid');stdout=OUT/(stem+'.stdout');stderr=OUT/(stem+'.stderr')
 pidfile.unlink(missing_ok=True)
 folder=suite.BINS[label]
 if not DEFAULT and (c['kind']=='scalable' or c['exe']=='warm_record_mutation_load'):folder=R/'supplement'/('head-bin' if label=='head' else 'main-bin')
 if DEFAULT and c['kind']=='scalable':args=[*args];args[args.index('--crc')+1]='false'
 cmd=[str(R/'measure'),str(usage),str(pidfile),str(folder/c['exe']),*args]
 peaks={k:0 for k in ['visible_logical_bytes','visible_allocated_bytes','deleted_logical_bytes','deleted_allocated_bytes','total_data_allocated_bytes','open_regular_allocated_bytes','cgroup_current_bytes']}
 started=time.monotonic();native=None;samples=status_samples=fd_samples=0;errors={};file_peaks={}
 with stdout.open('w') as o,stderr.open('w') as e:
  p=subprocess.Popen(cmd,stdout=o,stderr=e,start_new_session=True,env={**os.environ,'TMPDIR':str(suite.DATA)})
  while p.poll() is None:
   if time.monotonic()-started>900:
    import signal
    os.killpg(p.pid,signal.SIGKILL);p.wait();raise RuntimeError('probe timeout '+stem)
   if native is None:
    try:native=int(pidfile.read_text())
    except (OSError,ValueError):time.sleep(.001);continue
   v=dict.fromkeys(peaks,0);visible=set();opened=set();deleted=set()
   def note(kind,e):errors[kind+':'+str(getattr(e,'errno','unknown'))]=errors.get(kind+':'+str(getattr(e,'errno','unknown')),0)+1
   try:
    for f in suite.DATA.rglob('*'):
     try:
      m=f.stat()
      if not stat.S_ISREG(m.st_mode):continue
      key=(m.st_dev,m.st_ino)
      if key in visible:continue
      visible.add(key);v['visible_logical_bytes']+=m.st_size;v['visible_allocated_bytes']+=m.st_blocks*512
      item=file_peaks.setdefault(f.name,{'logical_bytes':0,'allocated_bytes':0})
      item['logical_bytes']=max(item['logical_bytes'],m.st_size);item['allocated_bytes']=max(item['allocated_bytes'],m.st_blocks*512)
     except OSError as error:note('visible',error)
   except OSError as error:note('walk',error)
   try:
    Path(f'/proc/{native}/status').read_text();status_samples+=1
   except OSError as error:note('status',error)
   try:
    fds=list(Path(f'/proc/{native}/fd').iterdir());fd_samples+=1
    for fd in fds:
     if fd.name in ['0','1','2']:continue
     try:
      m=fd.stat();key=(m.st_dev,m.st_ino)
      if not stat.S_ISREG(m.st_mode) or key in opened:continue
      opened.add(key);v['open_regular_allocated_bytes']+=m.st_blocks*512
      if os.readlink(fd).endswith(' (deleted)') and key not in visible and key not in deleted:
       deleted.add(key);v['deleted_logical_bytes']+=m.st_size;v['deleted_allocated_bytes']+=m.st_blocks*512
     except OSError as error:note('fd',error)
   except OSError as error:note('fdscan',error)
   v['total_data_allocated_bytes']=v['visible_allocated_bytes']+v['deleted_allocated_bytes']
   v['cgroup_current_bytes']=int(Path('/sys/fs/cgroup/memory.current').read_text())
   peaks={k:max(peaks[k],value) for k,value in v.items()};samples+=1;time.sleep(.005)
 events=[json.loads(s) for s in stdout.read_text().splitlines() if s.startswith('{')]
 row={'case':c['name'],'label':label,'stem':stem,'command':cmd,'exit':p.returncode,'samples':samples,'status_samples':status_samples,'fd_samples':fd_samples,'sampling_errors':errors,'observed_visible_file_peaks':file_peaks,'peaks':peaks,'usage':json.loads(usage.read_text()) if usage.exists() else None,'events':events,'interval_seconds':.005,'time_scope':'Observer-affected; do not use as qualification timings'}
 PROBES.append(row)
 with (OUT/'calls.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 if p.returncode:raise RuntimeError(f'exit {p.returncode}: {stem}')
 if not status_samples or not fd_samples:raise RuntimeError('No valid process/FD sample: '+stem)
 return {'command':cmd,'events':events,'usage':row['usage'],'probe':row}
suite.invoke=invoke
if not DEFAULT:suite.case('lazy-first-mark-4g','warm_record_mutation_load',['lazy','large','reverse',65536,1],'cold-warm-followup')
if not DEFAULT:suite.case('lazy-warm-marks-4g','warm_record_mutation_load',['lazy','large','reverse',65536,4096,'warm'],'cold-warm-followup')
rows=[]
for c in suite.CASES:
 for label in ['main-a','head']:
  row={'case':c['name'],'family':c['family'],'label':label}
  try:row['data']=suite.observation(c,label,0)
  except Exception as e:row['error']=str(e)
  rows.append(row);suite.save(OUT/'results.json',rows)
  print(c['name'],label,row.get('error','sampled'),flush=True)
print('FINISHED RESOURCE PROBES',len(rows),flush=True)
