"""Generate after all timing and resource stages; preserve failed initial CLI runs."""
from pathlib import Path
import collections,json,random,statistics
R=Path(__file__).resolve().parent
O=Path('/workspace/varlit/docs/verification/full-performance-20261104')
def load(p):return json.loads((R/p).read_text())
def percentage(x):return '추가됨' if x is None else f'{x:+.2f}%'
def main():
 for path,text in [('driver.log','FINISHED ALL 64 CASES'),('supplement-driver.log','FINISHED ALL 9 CASES'),('default-driver.log','FINISHED ALL 8 CASES'),('probe-driver.log','FINISHED RESOURCE PROBES 132'),('probe-default-driver.log','FINISHED RESOURCE PROBES 16')]:
  assert text in (R/path).read_text(),path
 O.mkdir(exist_ok=True)
 pp=load('timings/summary.json');sp=load('supplement/timings/summary.json');dd=load('default/timings/summary.json')
 assert (len(pp),len(sp),len(dd))==(64,9,8)
 fixed={s['case'] for s in sp if s['case'].startswith('batch-')}
 final=[s for s in pp if s['case'] not in fixed]+sp+dd
 assert len(final)==74 and len({s['case'] for s in final})==74
 probes=load('resource-probes/results.json')+load('default/resource-probes/results.json')
 assert len(probes)==148
 samples=[]
 for path in ['timings/samples.jsonl','supplement/timings/samples.jsonl','default/timings/samples.jsonl']:
  for line in (R/path).read_text().splitlines():
   row=json.loads(line)
   if path=='timings/samples.jsonl' and row['case'] in fixed:continue
   samples.append(row)
 for s in final:
  batch=s['case'].startswith(('batch-','default-batch'))
  s['configuration']='default/no-native-CRC' if s['case'].startswith('default-') else 'CRC/zstd/mmap/zero-copy'
  s['primary_metrics']={'time':'write_seconds' if batch else 'seconds','cpu':'write_cpu' if batch else 'cpu','rss':'write_rss_kib' if batch else 'rss_kib'}
  s['resource_probes']=[p for p in probes if p['case']==s['case']]
  if 'values' not in s:continue
  rows=[r for r in samples if r['case']==s['case']];groups=sorted({r['group'] for r in rows});by={(r['group'],r['label']):r for r in rows}
  rng=random.Random(961004+sum(map(ord,s['case'])));intervals={}
  for key in [s['primary_metrics']['time'],s['primary_metrics']['cpu']]:
   for before in ['main-a','main-b']:
    xs=[]
    for _ in range(2000):
     chosen=rng.choices(groups,k=len(groups))
     a=statistics.median(by[(g,before)]['data']['metrics'][key] for g in chosen)
     b=statistics.median(by[(g,'head')]['data']['metrics'][key] for g in chosen)
     xs.append(100*(b/a-1))
    xs.sort();intervals[key+'/'+before]={'low_percent':xs[49],'high_percent':xs[1949]}
  s['supplemental_group_bootstrap95']=intervals
 plans={name:load(path) for name,path in [('primary','plan.json'),('corrected_batch_and_coldwarm','supplement/plan.json'),('default','default/plan.json')]}
 cache_diagnosis=load('stale-build-diagnosis.json')
 data={'harness_cache_diagnosis':cache_diagnosis,'interrupted_stale_supplement':load('stale-build-interruption.json'),'base':plans['primary']['base'],'runtime_head':plans['primary']['head'],'workload_conditions':74,'limits':plans['primary']['limits'],'gate_percent':5,'plans':plans,'cases':final,'initial_incompatible_batch_harness_attempts':[s for s in pp if s['case'] in fixed],'status_counts':dict(collections.Counter(s['status'] for s in final)),'observations':len(samples),'bootstrap':'2,000 matched-group resamples; supplementary, not a relaxed/replaced 5% gate','scope':'Linux workload matrix covering the requested benchmark families and eight default-feature conditions; not every platform/input/feature combination.','raw_field_note':'full_codec_load field crc is an FNV-1a-64 payload fingerprint. Native format uses CRC32 separately; payloads are compared byte-for-byte.','sampling_note':'5 ms non-atomic file/FD observations may miss short peaks. Probe timings are observer affected. Native-child wait4 resource counters in official timing are separate.'}
 (O/'results.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
 labels={'passed':'관측 기준 통과','regression':'관측 기준 초과','unqualified':'대조군 편차 초과','execution_failed':'실행 실패','work_mismatch':'작업량 불일치'}
 def worst(s,key):
  xs=[s['comparisons'][b][key]['percent'] for b in ['main-a','main-b']]
  return None if None in xs else max(xs)
 status_text=', '.join(f'{labels[k]} {v}개' for k,v in data['status_counts'].items())
 lines=['# 전체 성능 비교 — 2026-11-04','',f"main {data['base']}와 PR #18 런타임 {data['runtime_head']}를 비교했다. 기본 64개에 lazy 최초/반복 검증 2개와 기본 feature·체크섬 비활성 8개를 추가해 74개 조건을 측정했다. 최초 배치 7개는 아래의 공통 벤치 소스 수정 후 전체를 재측정했다.",'',f"상태: {status_text}. 조건별 실패·편차와 절대량은 아래에 남겼다. 5%는 허용 성능 저하 기준이며 측정 오차의 정의가 아니다.",'','## 측정 방법','',
 '4 CPU / 16 GiB / 32 GiB를 유지했다. 단일 프로세스 작업은 같은 논리 CPU 하나, 다중 스레드는 같은 논리 CPU 네 개에 고정했다. main A/B는 동일 바이너리다. 6개 실행 순열로 첫 6그룹을 균형 있게 실행하고, 관측 지표나 대조군이 5%를 넘으면 정해 둔 6그룹을 한 번만 추가해 모두 합산했다. 실패한 항목 뒤에도 나머지를 계속 측정했다. 공식 타이밍에 빌드·검사·프로파일링·압축을 겹치지 않았다.','',
 '시간·CPU·출력 블록은 중앙값, 최대 상주 메모리(RSS)는 최대값이다. C 부모가 실제 실행 바이너리를 자식으로 만들어 wait4로 측정하므로 Python의 실행 전 메모리 최고값을 포함하지 않는다. 함수 타이머와 전체 프로세스 CPU의 범위는 다르다. Map 디코딩 CPU에는 입력 인코딩 준비가, mmap CPU에는 행렬 생성·초기 쓰기가 포함된다. 배치 write_cpu에는 writer와 reader 전체가 들어간다. 독립 writer의 writer_cpu_seconds만 writer 스레드 단독 CPU다.','',
 'cold/warm은 검증 메타데이터 상태이며 OS 파일 캐시 강제 비우기를 뜻하지 않는다. 마킹 벤치는 경계 검증·삭제 표시 작업이며 일반 payload 읽기와 구분한다. 독립 writer는 reader 응답을 기다리지 않는다. 배치 indexed의 reader는 정해진 작업량을 마칠 때 기다리는 별도 조건이다. indexed/matrix의 reader 8개에는 고정 스냅샷 reader 1개가 추가된다. Native 마커 게시와 배치 sync의 내구성 경계도 같지 않으므로 서로 다른 행의 절대 처리량을 그대로 비교하면 안 된다.','',
 '새 TryClone·try_box·공유 소유자 API는 마스터의 기존 Clone·Box·생성 API와 성공 결과를 비교한다. 범위 스트리밍은 마스터에서 전체 디코딩 후 같은 구간을 전달하는 경로와 비교한다. 결과는 같지만 내부 처리량·실패 의미까지 동일한 API라는 뜻은 아니다.','',
 '마스터의 기존 scalable_load CLI에는 고정 reader 작업량·writer-open 옵션이 없어 최초 배치 비교가 실행되지 않았다. 공통 소스를 복사한 첫 재시도에서도 보존된 예전 수정시각 때문에 Cargo가 기존 바이너리를 재사용했다. 기존/재사용 바이너리의 같은 hash와 실패·중단 기록을 보존했다. 소스 수정시각을 갱신해 강제로 재빌드하고 다른 hash 및 write/verify/open 동작을 확인한 뒤 배치 7개 전체를 다시 측정했다. 아래 배치 결과는 마지막 수정된 비교다.','',
 '## 전체 조건','',
 '시간은 주 타이머, CPU·RSS는 전체 작업 프로세스다. 배치의 주 타이머는 write이며 scan/point/open/compact 단계도 각각 판정했다. 변화율은 두 대조군 중 더 불리한 값이다. 상태는 등록된 모든 지표와 대조군을 함께 판정한다. 따라서 상태가 초과여도 주 타이머 자체는 기준 안일 수 있다.','',
 '| 조건 | 그룹 | main A/B 시간(s) | PR 시간(s) | 시간 변화 | CPU 변화 | RSS 변화 | 상태 |',
 '|---|---:|---:|---:|---:|---:|---:|---|']
 for s in final:
  if 'values' not in s:
   lines.append(f"| {s['case']} | {s['groups']} | — | — | — | — | — | {labels[s['status']]} |");continue
  k=s['primary_metrics'];v=s['values'][k['time']]
  lines.append(f"| {s['case']} | {s['groups']} | {v['main-a']:.6f}/{v['main-b']:.6f} | {v['head']:.6f} | {percentage(worst(s,k['time']))} | {percentage(worst(s,k['cpu']))} | {percentage(worst(s,k['rss']))} | {labels[s['status']]} |")
 lines+=['','## 지표별 관측 기준 초과','',
 '합계가 개별 단계의 증가를 가리지 않도록 각 단계도 판정했다. 시간·CPU 지표의 단위는 초, RSS는 KiB, 쓰기·임시 저장은 bytes다. 0→양수의 증가는 비율을 계산할 수 없다. 출력 블록은 OS에 계상된 쓰기이며 준비·검증·로그를 포함한다. 작은 압축 파일의 몇 KiB 증가를 처리시간 증가와 혼동하면 안 된다.','',
 '| 조건 | 지표 | main A/B | PR | A/B 대비 |','|---|---|---:|---:|---:|']
 for s in final:
  if 'values' not in s:continue
  for k,v in s['values'].items():
   mm=[s['comparisons'][b][k] for b in ['main-a','main-b']]
   if any(not m['passed'] for m in mm):lines.append(f"| {s['case']} | {k} | {v['main-a']:.6f}/{v['main-b']:.6f} | {v['head']:.6f} | {percentage(mm[0]['percent'])}/{percentage(mm[1]['percent'])} |")
 lines+=['','## 별도 저장 공간 관측','',
 '공식 타이밍 뒤 각 조건·버전에 별도 프로브를 실행했다. 5 ms 간격의 경로·FD 관측은 원자적 스냅샷이 아니며 짧은 최대값을 놓칠 수 있다. 입력용 고정 fixture와 로그는 작업 데이터 합계에서 제외했다. cgroup 메모리는 페이지 캐시·작업 공간·관측기를 포함하므로 라이브러리 heap과 같지 않다.','',
 '| 조건 | main/PR 최대 관측 할당량(MiB) | main/PR 삭제된 열린 파일(MiB) | 상태 |','|---|---:|---:|---|']
 for s in final:
  out=[]
  for label in ['main-a','head']:
   rr=[p for p in s['resource_probes'] if p['label']==label];calls=[]
   for p in rr:
    d=p.get('data',{})
    if 'run' in d:calls.append(d['run']['probe'])
    calls += [r['probe'] for r in d.get('runs',{}).values()]
   out.append({'total':max([p['peaks']['total_data_allocated_bytes'] for p in calls],default=None),'deleted':max([p['peaks']['deleted_allocated_bytes'] for p in calls],default=None),'errors':[p['error'] for p in rr if 'error' in p]})
  def pair(key):return '/'.join('—' if p[key] is None else f"{p[key]/(1<<20):.3f}" for p in out)
  lines.append(f"| {s['case']} | {pair('total')} | {pair('deleted')} | {'확인 필요' if any(p['errors'] for p in out) else '관측 완료'} |")
 lines+=['','## 해석과 원본','',
 '실제 저하와 대조군 편차를 구분하고 초과값을 그대로 보존했다. 검사나 자원 상한을 제거해 통과시키지 않았고, 이번 비교를 실행하면서 제품 코드를 최적화하지 않았다. 최적화 추적은 [이슈 #20](https://github.com/shim9610/varlit/issues/20)에 남긴다.','',
 '물리 데이터 레코드 수와 reader 합산 읽기 수는 다르다. Native independent의 4 GiB에서는 64 KiB가 65,536개, 1 MiB가 4,096개, 4 MiB가 1,024개이며 reader별로 전체를 읽는다. BatchOptions는 여러 논리 레코드의 I/O를 묶고 레코드 자체를 합치지는 않는다.','',
 '상세 작업량·대조군·부가적인 그룹 부트스트랩 95% 범위는 [results.json](results.json), 모든 시도·소스·도구·바이너리 hash는 [원본 증거](evidence.tar.gz), [파일별 hash](evidence-manifest.json), [압축 파일 checksum](evidence.sha256)에 있다. 부트스트랩은 관측 5% 기준을 바꾸지 않는다.']
 by={x['case']:x for x in final}
 def delta(name,key):
  x=by[name]
  return '/'.join(percentage(x['comparisons'][b][key]['percent']) for b in ['main-a','main-b'])
 def value(name,key):
  v=by[name]['values'][key]
  return "{:.6f}/{:.6f} → {:.6f}".format(v["main-a"],v["main-b"],v["head"])
 highlights=['## 주요 결과','',
  '- reader 없는 indexed 배치의 4 MiB 레코드·4 GiB 쓰기: 시간 '+delta('batch-indexed-4g-4096k-r0','write_seconds')+', 전체 CPU '+delta('batch-indexed-4g-4096k-r0','write_cpu')+'. 쓰기 바이트 수보다 커널 CPU와 minor page fault 증가가 두드러졌다. 시스템 CPU 중앙값은 main 약 1.05–1.13 s, PR 약 3.03 s였고 minor fault는 약 25.6만→213만 회였다. 정확한 할당 호출 경로는 별도 프로파일링하지 않았다.',
  '- 일반 행렬 갱신: 시간 '+delta('matrix-ordinary','seconds')+', 전체 CPU '+delta('matrix-ordinary','cpu')+'. 대형 셀 mmap은 읽기 타이머와 준비를 포함한 전체 CPU를 구분해야 한다. 전체 CPU 증가는 초기 생성·쓰기 비용도 포함한다.',
  '- 고정 map 디코딩: 루프 시간 '+delta('decode-map-fixed','seconds')+'. 작은 고정/가변 값 인코딩·디코딩도 개별 지표에서 기준을 넘었다. 전체 CPU의 입력 준비 비용 감소가 이 루프 시간 증가를 가리지 않도록 별도 표시했다.',
  '- 공유 소유자 생성·복제·취소 100만 회: 시간 '+delta('owner-shared-owner','seconds')+' ('+value('owner-shared-owner','seconds')+' s). 큰 byte/nested clone 결과와 이 제어 경로를 같은 비용으로 취급하면 안 된다.',
  '- 비상주 검증 후 마킹: '+value('nonresident-open-warm','seconds')+' s. lazy 첫 마킹: '+value('lazy-first-mark-4g','seconds')+' s; 검증 후 4,096회 마킹: '+value('lazy-warm-marks-4g','seconds')+' s. 최초 검증 비용과 반복 비용을 구분한다.',
  '- 독립 writer·8-reader·4 GiB: 1 MiB 레코드는 관측 기준 통과, 4 MiB 레코드는 writer CPU '+delta('independent-4g-4096k-r8','writer_cpu_seconds')+'. 묶음이 커지면 항상 빨라진다고 결론낼 수 없다.',
  '- 고정 200만 레코드 마킹과 미커밋 follow, 다수 유지보수·clone 조건은 개선 또는 관측 기준 안이었다. 예를 들어 작은 pending follow 시간은 '+value('pending-small','seconds')+' s였다. 이 개선을 다른 항목의 초과와 상쇄해 전체 통과로 계산하지 않았다.',
  '']
 at=lines.index('## 측정 방법')
 lines[at:at]=highlights
 (O/'README.md').write_text(chr(10).join(lines)+chr(10))
 print('REPORT',len(final),'conditions',data['status_counts'],len(samples),'observations')
if __name__=='__main__':main()
