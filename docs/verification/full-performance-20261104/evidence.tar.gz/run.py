from pathlib import Path
import argparse, hashlib, itertools, json, os, platform, random, statistics, subprocess, sys, tempfile, time
R=Path(__file__).resolve().parent
OUT=R/'timings'; OUT.mkdir(exist_ok=True)
DATA=R/'disk-data'; DATA.mkdir(exist_ok=True)
BINS={'main-a':R/'main-bin','main-b':R/'main-bin','head':R/'head-bin'}
CPUS=sorted(os.sched_getaffinity(0))[:4]; assert len(CPUS)==4
CASES=[]
def case(name,exe,args,family,parallel=False,kind='normal'):
 CASES.append(dict(name=name,exe=exe,args=list(map(str,args)),family=family,parallel=parallel,kind=kind))
for name,args in [
 ('fixed-2m',['writer','fixed','forward',2000000,200000]),
 ('variable-random',['writer','variable','random',200000,20000]),
 ('epochs',['epochs','fixed','random',200000,20000]),
 ('rewrite-variable',['rewrite','variable','random',200000,20000]),
 ('rewrite-all-marks',['rewrite','variable','random',200000,200000]),
 ('recovery',['recovery','fixed','forward',200000,20000]),
 ('large-4g',['writer','large','reverse',65536,4096]),
 ('lazy-4g',['lazy','large','reverse',65536,4096]),
 ('mixed-4g',['writer','mixed','random',131072,8192])]:case('native-'+name,'full_record_mutation_load',args,'native-mutation')
for name,args in [('live',['nonresident','mixed','random',65536,8192]),('open-cold',['nonresident-open','mixed','random',65536,8192]),('open-warm',['nonresident-open','mixed','random',65536,8192,'warm'])]:case('nonresident-'+name,'full_nonresident_boundary_load',args,'nonresident')
for name,args in [('replace',['replace',500000,128]),('defragment',['defragment',500000,128]),('complex',['complex',65536,512]),('checkpoint',['checkpoint',200000,256]),('replace-4g',['replace',65536,65536])]:case('maintenance-'+name,'oom_maintenance_load',args,'maintenance')
case('map-encode-million','oom_maintenance_load',['hash',1000000,8],'codec')
case('chunk-compress-64m','oom_maintenance_load',['chunks',67108864,1048576],'compression')
case('chunk-decode-64m','oom_maintenance_load',['decode',67108864,1048576,'{fixture}'],'compression')
for shape,count,rounds in [('fixed',1048576,8),('strings',16384,16),('nested',2048,8)]:case('decode-map-'+shape,'decoder_memory_load',[shape,count,rounds],'codec')
for name,exe,args in [('bytes-64m','ownership_load',['bytes',67108864,16]),('bytes-1g','ownership_load',['bytes',1073741824,2]),('nested','ownership_load',['nested',16384,16]),('box','ownership_boundary_load',['box',1000000]),('shared-owner','ownership_boundary_load',['shared',1000000]),('boxed-nested','ownership_boundary_load',['nested-box',2048])]:case('owner-'+name,exe,args,'ownership')
for mode,readers in [('write',1),('read',1),('read',8)]:case(f'native-zstd-{mode}-r{readers}','full_codec_load',[mode,1048576,64,4,readers],'compression',readers>1)
for mode,count,readers in [('full',67108864,1),('stream',67108864,1),('stream-4k',67108864,1),('full',1048576,8),('stream-4k',1048576,8)]:case(f'chunk-range-{mode}-{count}-r{readers}','chunk_stream_load',[mode,'{randomfixture}',67108864,0,count,4,readers,'random'],'range-streaming',readers>1)
for diverse,count in [(False,200000),(True,5000)]:case('scan-open-'+str(diverse).lower(),'scan_open_load',[count,str(diverse).lower(),8],'open-scan')
case('codec-merge-compact','full_perf_bench',[100000],'codec-merge-compact')
for mode in ['ordinary','durable']:case('matrix-'+mode,'matrix_ownership_load',[8192,64,8,512,mode],'matrix',True)
for size,cells,reads in [('small',65536,200000),('large',8192,20000)]:
 for mode in ['whole','cell']:case(f'mmap-{size}-{mode}','matrix_mmap_load',[size,cells,reads,mode],'mmap')
for total,payload,readers in [(1<<30,65536,1),(1<<30,65536,8),(4<<30,65536,8),(1<<30,1<<20,8),(4<<30,1<<20,8),(1<<30,4<<20,8),(4<<30,4<<20,8)]:case(f'independent-{total>>30}g-{payload>>10}k-r{readers}','full_native_streaming_load',[total,payload,16<<20,readers,16,0,'resident'],'independent-streaming',True)
for name,args in [('small',['pending',16<<20,128,32,8,8,4,0,'resident']),('large',['pending',1<<30,65536,64,8,16,4,0,'resident']),('complex',['pending',256<<20,4096,64,8,8,4,0,'resident','varying']),('nonresident',['pending',1<<30,65536,64,8,16,4,0,'nonresident'])]:case('pending-'+name,'native_follow_load',args,'pending-follow',True)
for mode,total,payload,readers in [('stream',1<<30,65536,0),('stream',4<<30,4<<20,0),('indexed',1<<30,65536,0),('indexed',1<<30,1<<20,0),('indexed',4<<30,4<<20,0),('indexed',1<<30,65536,8),('indexed',4<<30,4<<20,8)]:case(f'batch-{mode}-{total>>30}g-{payload>>10}k-r{readers}','scalable_load',[mode,total,payload,readers],'batch-stream-index',True,'scalable')

def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest():
 return dict(base='ba541cc3082cecdf7f385d06897a58a3889e1294',head='1e592397d34f4f576111f1107fb29303b9d472b0',seed=961004,initial_groups=6,extension_groups=6,extension_trigger='Any >5% observed primary metric or >5% same-binary operation/CPU calibration. One fixed extension only; pool all groups. Continue other cases on failure.',features='integrity,compression-zstd,mmap,zero-copy,experimental-matrix-reuse for facade; core same except experimental-matrix-reuse; NO fault-injection feature',affinity=CPUS,single_process_affinity=[CPUS[0]],platform=platform.platform(),python=sys.version,limits={k:Path('/sys/fs/cgroup',k).read_text().strip() for k in ['cpu.max','memory.max']},host=subprocess.check_output(['rustc','-Vv'],text=True),cases=CASES,binary_sha256={label:{n:sha(folder/n) for n in sorted({c['exe'] for c in CASES})} for label,folder in BINS.items()},method='C-parent native-child wait4 avoids Python pre-exec RSS. Median times/CPU/write bytes; maximum RSS. Bootstrap intervals are supplemental. Operation timers and whole-process CPU have distinct scope. Internal timing probes are identical in both harnesses. Separate sampled storage probes do not supply qualification timing.')

def work(events):
 keys=['part','processed','emitted','mode','layout','order','count','marks','records','payload','rounds','iterations','sum','crc','length','start','readers','checks','rows','epochs','bytes','read_bytes','trace','follows','polls','residency','diverse','repeats','shape','input_bytes','cells','reads','stride','whole','total','dropped','work','epoch_bytes','snapshots','batches','trace_hash','keys_checked','opens','payload_bytes','markers']
 return [{k:e[k] for k in keys if k in e} for e in events]

def invoke(c,label,args,stem,events_required=True):
 usage=OUT/(stem+'.usage.json');pid=OUT/(stem+'.pid');stdout=OUT/(stem+'.stdout');stderr=OUT/(stem+'.stderr')
 cmd=[str(R/'measure'),str(usage),str(pid),str(BINS[label]/c['exe']),*args]
 started=time.monotonic()
 with stdout.open('w') as o,stderr.open('w') as e:
  try:result=subprocess.run(cmd,stdout=o,stderr=e,env={**os.environ,'TMPDIR':str(DATA)},timeout=900)
  except subprocess.TimeoutExpired:raise RuntimeError('timeout '+stem)
 if result.returncode:raise RuntimeError(f'exit {result.returncode}: {stem}; see {stderr.name}')
 events=[json.loads(l) for l in stdout.read_text().splitlines() if l.startswith('{')]
 if events_required and not events:raise RuntimeError('no result '+stem)
 u=json.loads(usage.read_text());u['process_wall_seconds']=time.monotonic()-started
 return dict(events=events,usage=u,command=cmd)

def scalable(c,label,stem):
 mode,total,payload,readers=c['args'];total=int(total);payload=int(payload);readers=int(readers)
 with tempfile.TemporaryDirectory(prefix='batch-',dir=DATA) as tmp:
  common=['--mode',mode,'--root',tmp,'--total-bytes',str(total),'--record-bytes',str(payload),'--epoch-bytes',str(64<<20),'--batch-bytes',str(4<<20),'--index-batch-records','16384','--cache-bytes',str(8<<20),'--readers',str(readers),'--pinned-readers','1','--crc','true','--reader-pause-us','0','--seconds','1','--open-count','32']
  stages=['write','verify']+(['point','writer-open','compact'] if mode=='indexed' else [])
  runs={};metrics={};works={};storage={}
  for phase in stages:
   args=['--phase',phase,*common]
   if phase=='write' and readers:args+=['--reader-checks-per-epoch','256']
   r=invoke(c,label,args,stem+'-'+phase);runs[phase]=r
   selected=[e for e in r['events'] if e.get('event') in ['write_complete','verify_complete','point_complete','writer_open_complete','compact_complete']]
   if len(selected)!=1:raise RuntimeError('missing complete event '+phase)
   metrics[phase+'_seconds']=selected[0]['seconds']
   for k in ['cpu','rss_kib','write_bytes']:metrics[phase+'_'+k]=r['usage'][k]
   works[phase]=work(selected)
   if phase=='write' and readers:
    sys.path.insert(0,'/workspace/varlit/scripts');from load_scalable import validate_fixed_readers
    validate_fixed_readers({'mode':mode,'readers':readers,'pinned':1,'record':payload,'checks_per_epoch':256},total,64<<20,r['events'])
    works['readers']=work(sorted([e for e in r['events'] if e.get('event')=='reader'],key=lambda e:e['id']))
   storage[phase]=sum(p.stat().st_blocks*512 for p in Path(tmp).rglob('*') if p.is_file())
  return dict(runs=runs,metrics=metrics,work=works,storage_after_phases_bytes=storage)

def observation(c,label,group):
 os.sched_setaffinity(0,set(CPUS if c['parallel'] else CPUS[:1]))
 stem=f"{c['name']}-g{group:02}-{label}"
 if c['kind']=='scalable':return scalable(c,label,stem)
 args=[str(R/'fixtures/chunks.bin') if a=='{fixture}' else str(R/'fixtures/random.bin') if a=='{randomfixture}' else a for a in c['args']]
 r=invoke(c,label,args,stem);es=r['events'];metrics={'seconds':sum(e['seconds'] for e in es),'cpu':r['usage']['cpu'],'rss_kib':r['usage']['rss_kib'],'write_bytes':r['usage']['write_bytes']}
 for e in es:
  if 'part' in e:metrics[e['part']+'_seconds']=e['seconds']
 for k in ['writer_seconds','writer_cpu_seconds','write_seconds','read_seconds']:
  if k in es[-1]:metrics[k]=es[-1][k]
 if 'temporary_bytes' in es[-1]:metrics['private_bytes']=es[-1]['temporary_bytes']
 return dict(run=r,metrics=metrics,work=work(es))

def summary(c,rows):
 selected=[r for r in rows if r['case']==c['name']]
 good=[r for r in selected if 'error' not in r]
 result={'case':c['name'],'family':c['family'],'groups':len({r['group'] for r in selected}),'observations':len(selected)}
 if len(good)!=len(selected):return {**result,'status':'execution_failed','errors':[r for r in selected if 'error' in r]}
 works=[r['data']['work'] for r in good]
 if any(w!=works[0] for w in works):return {**result,'status':'work_mismatch','work_examples':works}
 keys=list(good[0]['data']['metrics']);vals={}
 for k in keys:
  agg=max if k.endswith('rss_kib') or k=='private_bytes' else statistics.median
  vals[k]={label:agg(r['data']['metrics'][k] for r in good if r['label']==label) for label in BINS}
 comps={label:{k:{'percent':100*(v['head']/v[label]-1) if v[label] else (0 if not v['head'] else None),'passed':v['head']<=1.05*v[label]} for k,v in vals.items()} for label in ['main-a','main-b']}
 cal={k:100*(v['main-b']/v['main-a']-1) for k,v in vals.items() if (k.endswith('seconds') or k.endswith('cpu')) and v['main-a']}
 bad=any(not m['passed'] for comp in comps.values() for m in comp.values())
 noisy=any(abs(v)>5 for v in cal.values())
 return {**result,'work':works[0],'values':vals,'comparisons':comps,'same_binary_percent':cal,'observed_gates_passed':not bad,'calibration_passed':not noisy,'status':'passed' if not bad and not noisy else 'unqualified' if noisy else 'regression'}

def run():
 plan=manifest();p=R/'plan.json'
 if p.exists():assert json.loads(p.read_text())==plan
 else:save(p,plan)
 rows=[json.loads(s) for s in (OUT/'samples.jsonl').read_text().splitlines()] if (OUT/'samples.jsonl').exists() else []
 done={(r['case'],r['group'],r['label']) for r in rows};summaries=[]
 for number,c in enumerate(CASES):
  orders=[];rng=random.Random(961004+number)
  for _ in range(2):
   block=list(itertools.permutations(BINS));rng.shuffle(block);orders.extend(block)
  need=6
  for g in range(12):
   if g>=need:break
   for label in orders[g]:
    if (c['name'],g,label) in done:continue
    record={'case':c['name'],'group':g,'label':label}
    try:record['data']=observation(c,label,g)
    except Exception as error:record['error']=str(error)
    rows.append(record)
    with (OUT/'samples.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
    print(c['name'],g,label,record.get('error',record.get('data',{}).get('metrics')),flush=True)
   if g==5:
    s=summary(c,rows)
    if s['status'] in ['regression','unqualified']:need=12
    if s['status'] in ['execution_failed','work_mismatch']:break
  s=summary(c,rows);summaries.append(s);save(OUT/'summary.json',summaries)
  print('SUMMARY',c['name'],s['status'],'groups',s['groups'],flush=True)
 print('FINISHED ALL',len(CASES),'CASES',flush=True)

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--plan-only',action='store_true');args=parser.parse_args()
 if args.plan_only:save(R/'plan.json',manifest());print(len(CASES),'cases frozen')
 else:run()
