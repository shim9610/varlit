use std::hash::Hash;
use std::path::Path;

use crate::traits::KeyedBlockContract;
use crate::{FormatSpec, Result, VarlitKeyedBlock};

pub trait VarlitMerge: VarlitKeyedBlock + Clone {
    type Op: crate::VarlitEncode + crate::VarlitDecode;

    fn apply_op(&mut self, op: Self::Op) -> Result<()>;
}

pub enum MergeAction<T>
where
    T: VarlitMerge,
{
    Put(T),
    Delete(T::Key),
    Op { key: T::Key, op: T::Op },
}

pub struct SequencedMergeAction<T>
where
    T: VarlitMerge,
{
    pub sequence: u64,
    pub action: MergeAction<T>,
}

/// Compacts `input` into `output`, keeping only the final value per key.
///
/// # Scale contract
///
/// This is a **resident** operation and is deliberately not PB-scale. It is a
/// thin delegate to [`compact_keyed_files`](crate::compact_keyed_files) with no
/// delta shards and inherits that function's bounds exactly. It opens `input`
/// as a whole [`VarlitFile`](crate::VarlitFile) and accumulates one map entry per
/// distinct key ever seen - including keys whose latest record is a tombstone -
/// plus the live values that survive to the output:
///
/// - time: `Theta(records + decoded bytes) + O(N log N) + O(K-live log K-live)`,
///   where the `O(N log N)` term is the input open's sequence-uniqueness sort
///   over its `N` records; it degrades to `Theta(N)` when the input's sequences
///   ascend with offset, but the sort is the guaranteed bound (PERF3-05);
/// - memory: `O(K-ever + resident input index + 8N uniqueness temporary +
///   retained live values)`, where `K-ever` is the number of distinct keys in
///   `input`.
///
/// Nothing here spills to disk, so `K-ever` must fit in memory. Varlit exports
/// no bounded-memory external merge/compact; the scalable stream and indexed
/// writers cover bounded *ingest*, not bounded compaction. Callers whose key
/// cardinality is not known to be resident-sized should size the operation
/// first with [`estimate_keyed_merge`](crate::estimate_keyed_merge) (pass an
/// empty delta slice) or bound it with [`compact_keyed_file_with_key_limit`],
/// which fails with a typed limit error instead of exhausting memory.
pub fn compact_keyed_file<T, P>(spec: FormatSpec, input: P, output: P) -> Result<()>
where
    T: VarlitMerge,
    T::Key: Eq + Hash,
    P: AsRef<Path>,
{
    // API2-03: every public keyed generic entry point evaluates the
    // compile-time keyedness contract post-monomorphization.
    let () = KeyedBlockContract::<T>::OK;
    let empty: &[P] = &[];
    crate::file::compact_keyed_files::<T, P>(spec, input, empty, output)
}

/// [`compact_keyed_file`] with an explicit ceiling on distinct retained keys.
///
/// The collector checks `max_distinct_keys` before it admits each new key, so
/// an input whose cardinality exceeds the caller's memory budget fails with
/// [`Error::LimitExceeded`](crate::Error::LimitExceeded)
/// (`resource = "merge distinct keys"`) at the boundary instead of being
/// discovered by the allocator. The ceiling counts tombstoned keys, matching
/// what the state actually retains. Nothing is published when the ceiling is
/// exceeded: `output` is not created.
///
/// See [`compact_keyed_file`] for the full resident scale contract.
pub fn compact_keyed_file_with_key_limit<T, P>(
    spec: FormatSpec,
    input: P,
    output: P,
    max_distinct_keys: u64,
) -> Result<()>
where
    T: VarlitMerge,
    T::Key: Eq + Hash,
    P: AsRef<Path>,
{
    // API2-03: every public keyed generic entry point evaluates the
    // compile-time keyedness contract post-monomorphization.
    let () = KeyedBlockContract::<T>::OK;
    let empty: &[P] = &[];
    crate::file::compact_keyed_files_with_key_limit::<T, P>(
        spec,
        input,
        empty,
        output,
        max_distinct_keys,
    )
}
