use std::{hint::black_box, time::Instant};
use varlit::*;
#[derive(VarlitBlock)]
#[varlit(id = 1, version = 1, kind = "variable")]
struct Blob { #[varlit(field_id = 1)] bytes: Vec<u8>, }
varlit_format! { struct Capture {
 magic: b"FULLCODE"; version: 1; endian: little; schema_hash: computed;
 integrity: crc32; blocks: [Blob];
} }
fn main() -> std::result::Result<(), Box<dyn std::error::Error>> {
 let a: Vec<_> = std::env::args().collect(); let mode=&a[1];
 let payload: usize=a[2].parse()?; let records: usize=a[3].parse()?;
 let rounds: usize=a[4].parse()?; let readers: usize=a[5].parse()?;
 let d=tempfile::tempdir()?; let path=d.path().join("compressed");
 let spec=Capture::spec().with_compression_policy(CompressionPolicy::VariableBlocks(
     VariableCompression::zstd(CompressionHeaderMode::RecordExplicit))).with_computed_schema_hash();
 let value=Blob { bytes: (0..payload).map(|i| (i%251) as u8).collect() };
 let expected=value.bytes.iter().fold(14695981039346656037u64, |h,b| (h ^ u64::from(*b)).wrapping_mul(1099511628211));
 let start=Instant::now();
 let mut writer=spec.create(&path)?;
 for _ in 0..records { writer.push(&value)?; } writer.sync()?; drop(writer);
 let write_seconds=start.elapsed().as_secs_f64();
 let start=Instant::now();
 std::thread::scope(|scope| -> varlit::Result<()> {
  let mut joins=Vec::new();
  for _ in 0..readers { let path=&path; let expected_bytes=&value.bytes; joins.push(scope.spawn(move || -> varlit::Result<()> {
   let reader=VarlitFile::open_readonly(spec,path)?;
   for _ in 0..rounds { let values=reader.blocks::<Blob>()?; assert_eq!(values.len(),records);
    for value in values.iter() { let value=value?; assert_eq!(value.bytes.len(),payload); assert_eq!(&value.bytes,expected_bytes); black_box(value); }
   } Ok(()) })); }
  for j in joins { j.join().unwrap()?; } Ok(())
 })?;
 let read_seconds=start.elapsed().as_secs_f64();
 let seconds=if mode=="write" {write_seconds} else {read_seconds};
 println!("{{\"mode\":\"{mode}\",\"payload\":{payload},\"records\":{records},\"rounds\":{rounds},\"readers\":{readers},\"crc\":{expected},\"seconds\":{seconds},\"write_seconds\":{write_seconds},\"read_seconds\":{read_seconds}}}");
 Ok(())
}
