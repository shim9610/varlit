"""Canonical batch-harness correction and separately declared cold/warm followup."""
from pathlib import Path
import run as suite
root=suite.R
suite.CASES=[c for c in suite.CASES if c['kind']=='scalable']
suite.case('lazy-first-mark-4g','warm_record_mutation_load',['lazy','large','reverse',65536,1],'cold-warm-followup')
suite.case('lazy-warm-marks-4g','warm_record_mutation_load',['lazy','large','reverse',65536,4096,'warm'],'cold-warm-followup')
suite.R=root/'supplement';suite.OUT=suite.R/'timings';suite.OUT.mkdir(exist_ok=True)
suite.BINS={'main-a':suite.R/'main-bin','main-b':suite.R/'main-bin','head':suite.R/'head-bin'}
suite.run()
