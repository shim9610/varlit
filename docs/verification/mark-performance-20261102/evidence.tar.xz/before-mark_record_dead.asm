
/workspace/scratch/compound-hardening/final/after-bin/record_mutation_load:     file format elf64-x86-64


Disassembly of section .text:

000000000007b930 <varlit_core::file::VarlitFile::mark_record_dead>:
   7b930:	55                   	push   %rbp
   7b931:	41 57                	push   %r15
   7b933:	41 56                	push   %r14
   7b935:	41 55                	push   %r13
   7b937:	41 54                	push   %r12
   7b939:	53                   	push   %rbx
   7b93a:	48 81 ec c8 03 00 00 	sub    $0x3c8,%rsp
   7b941:	48 89 fb             	mov    %rdi,%rbx
   7b944:	49 be 7d 00 00 00 00 	movabs $0x800000000000007d,%r14
   7b94b:	00 00 80 
   7b94e:	49 8d 4e be          	lea    -0x42(%r14),%rcx
   7b952:	48 8d 05 8b e9 f9 ff 	lea    -0x61675(%rip),%rax        # 1a2e4 <anon.63872d7b999ac94d8e2eb8c408e6a338.76.llvm.7982912888733972306+0x8>
   7b959:	80 be 90 0d 00 00 00 	cmpb   $0x0,0xd90(%rsi)
   7b960:	0f 85 6d 02 00 00    	jne    7bbd3 <varlit_core::file::VarlitFile::mark_record_dead+0x2a3>
   7b966:	80 be 91 0d 00 00 00 	cmpb   $0x0,0xd91(%rsi)
   7b96d:	0f 85 60 02 00 00    	jne    7bbd3 <varlit_core::file::VarlitFile::mark_record_dead+0x2a3>
   7b973:	80 be 92 0d 00 00 00 	cmpb   $0x0,0xd92(%rsi)
   7b97a:	0f 84 35 02 00 00    	je     7bbb5 <varlit_core::file::VarlitFile::mark_record_dead+0x285>
   7b980:	80 be 92 02 00 00 00 	cmpb   $0x0,0x292(%rsi)
   7b987:	0f 84 72 02 00 00    	je     7bbff <varlit_core::file::VarlitFile::mark_record_dead+0x2cf>
   7b98d:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   7b992:	4c 8d a6 98 02 00 00 	lea    0x298(%rsi),%r12
   7b999:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   7b9a0:	00 
   7b9a1:	4c 89 e6             	mov    %r12,%rsi
   7b9a4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   7b9a9:	e8 42 a0 06 00       	call   e59f0 <varlit_core::file::resident_index::ResidentIndex::has_verified_boundary>
   7b9ae:	48 8b 8c 24 30 01 00 	mov    0x130(%rsp),%rcx
   7b9b5:	00 
   7b9b6:	0f b6 84 24 38 01 00 	movzbl 0x138(%rsp),%eax
   7b9bd:	00 
   7b9be:	4c 39 f1             	cmp    %r14,%rcx
   7b9c1:	0f 85 54 02 00 00    	jne    7bc1b <varlit_core::file::VarlitFile::mark_record_dead+0x2eb>
   7b9c7:	a8 01                	test   $0x1,%al
   7b9c9:	0f 84 78 02 00 00    	je     7bc47 <varlit_core::file::VarlitFile::mark_record_dead+0x317>
   7b9cf:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   7b9d4:	4c 8d a0 20 0d 00 00 	lea    0xd20(%rax),%r12
   7b9db:	0f b6 88 8d 02 00 00 	movzbl 0x28d(%rax),%ecx
   7b9e2:	88 4c 24 50          	mov    %cl,0x50(%rsp)
   7b9e6:	0f b6 88 8e 02 00 00 	movzbl 0x28e(%rax),%ecx
   7b9ed:	88 4c 24 07          	mov    %cl,0x7(%rsp)
   7b9f1:	0f b6 88 8f 02 00 00 	movzbl 0x28f(%rax),%ecx
   7b9f8:	88 4c 24 06          	mov    %cl,0x6(%rsp)
   7b9fc:	0f b6 88 92 02 00 00 	movzbl 0x292(%rax),%ecx
   7ba03:	88 4c 24 05          	mov    %cl,0x5(%rsp)
   7ba07:	0f b6 88 97 02 00 00 	movzbl 0x297(%rax),%ecx
   7ba0e:	88 4c 24 60          	mov    %cl,0x60(%rsp)
   7ba12:	4c 8b a8 28 0d 00 00 	mov    0xd28(%rax),%r13
   7ba19:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   7ba20:	25 00 00 00 00 
   7ba25:	48 8b 88 98 ff ff ff 	mov    -0x68(%rax),%rcx
   7ba2c:	48 ff c1             	inc    %rcx
   7ba2f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
   7ba36:	48 0f 45 d1          	cmovne %rcx,%rdx
   7ba3a:	48 89 90 98 ff ff ff 	mov    %rdx,-0x68(%rax)
   7ba41:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   7ba48:	00 
   7ba49:	45 31 ff             	xor    %r15d,%r15d
   7ba4c:	ba 00 02 00 00       	mov    $0x200,%edx
   7ba51:	31 f6                	xor    %esi,%esi
   7ba53:	ff 15 07 0b 15 00    	call   *0x150b07(%rip)        # 1cc560 <memset@GLIBC_2.2.5>
   7ba59:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   7ba5e:	49 29 d5             	sub    %rdx,%r13
   7ba61:	4d 0f 43 fd          	cmovae %r13,%r15
   7ba65:	49 83 ff 21          	cmp    $0x21,%r15
   7ba69:	bd 20 00 00 00       	mov    $0x20,%ebp
   7ba6e:	49 0f 43 ef          	cmovae %r15,%rbp
   7ba72:	4c 8d bc 24 30 01 00 	lea    0x130(%rsp),%r15
   7ba79:	00 
   7ba7a:	48 81 fd 00 02 00 00 	cmp    $0x200,%rbp
   7ba81:	b8 00 02 00 00       	mov    $0x200,%eax
   7ba86:	48 0f 43 e8          	cmovae %rax,%rbp
   7ba8a:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7ba8f:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
   7ba96:	00 
   7ba97:	4c 89 e6             	mov    %r12,%rsi
   7ba9a:	4c 89 f9             	mov    %r15,%rcx
   7ba9d:	49 89 e8             	mov    %rbp,%r8
   7baa0:	ff 15 ca 0f 15 00    	call   *0x150fca(%rip)        # 1cca70 <_DYNAMIC+0x858>
   7baa6:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
   7baab:	4d 39 f5             	cmp    %r14,%r13
   7baae:	0f 85 d6 01 00 00    	jne    7bc8a <varlit_core::file::VarlitFile::mark_record_dead+0x35a>
   7bab4:	4c 89 bc 24 a0 00 00 	mov    %r15,0xa0(%rsp)
   7babb:	00 
   7babc:	48 c7 84 24 a8 00 00 	movq   $0x20,0xa8(%rsp)
   7bac3:	00 20 00 00 00 
   7bac8:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7bacd:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   7bad4:	00 
   7bad5:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   7bada:	e8 11 bd 07 00       	call   f77f0 <varlit_core::native_layout::read_native_record_header>
   7badf:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
   7bae4:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
   7bae9:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
   7baee:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
   7baf3:	44 8b 64 24 34       	mov    0x34(%rsp),%r12d
   7baf8:	44 8b 4c 24 38       	mov    0x38(%rsp),%r9d
   7bafd:	44 0f b7 5c 24 3c    	movzwl 0x3c(%rsp),%r11d
   7bb03:	0f b7 74 24 3e       	movzwl 0x3e(%rsp),%esi
   7bb08:	4d 39 f5             	cmp    %r14,%r13
   7bb0b:	0f 85 6b 02 00 00    	jne    7bd7c <varlit_core::file::VarlitFile::mark_record_dead+0x44c>
   7bb11:	4c 89 8c 24 80 00 00 	mov    %r9,0x80(%rsp)
   7bb18:	00 
   7bb19:	48 89 b4 24 88 00 00 	mov    %rsi,0x88(%rsp)
   7bb20:	00 
   7bb21:	4c 89 5c 24 68       	mov    %r11,0x68(%rsp)
   7bb26:	4c 89 54 24 58       	mov    %r10,0x58(%rsp)
   7bb2b:	4c 89 84 24 90 00 00 	mov    %r8,0x90(%rsp)
   7bb32:	00 
   7bb33:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   7bb38:	48 83 f8 df          	cmp    $0xffffffffffffffdf,%rax
   7bb3c:	0f 87 0f 06 00 00    	ja     7c151 <varlit_core::file::VarlitFile::mark_record_dead+0x821>
   7bb42:	4c 89 7c 24 78       	mov    %r15,0x78(%rsp)
   7bb47:	48 83 c0 20          	add    $0x20,%rax
   7bb4b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   7bb50:	48 8d 05 ad 69 fa ff 	lea    -0x59653(%rip),%rax        # 22504 <anon.48385641d07dc56499de4af04e4ddc4c.132.llvm.6019142963973739168+0x22>
   7bb57:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   7bb5c:	48 c7 44 24 28 15 00 	movq   $0x15,0x28(%rsp)
   7bb63:	00 00 
   7bb65:	4d 8d 6e 98          	lea    -0x68(%r14),%r13
   7bb69:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
   7bb6e:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7bb73:	e8 c8 cc 00 00       	call   88840 <core::ptr::drop_in_place<varlit_core::error::Error>>
   7bb78:	80 7c 24 60 02       	cmpb   $0x2,0x60(%rsp)
   7bb7d:	0f 85 0f 02 00 00    	jne    7bd92 <varlit_core::file::VarlitFile::mark_record_dead+0x462>
   7bb83:	0f b6 44 24 07       	movzbl 0x7(%rsp),%eax
   7bb88:	38 44 24 50          	cmp    %al,0x50(%rsp)
   7bb8c:	0f 85 00 02 00 00    	jne    7bd92 <varlit_core::file::VarlitFile::mark_record_dead+0x462>
   7bb92:	f6 44 24 50 01       	testb  $0x1,0x50(%rsp)
   7bb97:	0f 85 f5 01 00 00    	jne    7bd92 <varlit_core::file::VarlitFile::mark_record_dead+0x462>
   7bb9d:	f6 44 24 06 01       	testb  $0x1,0x6(%rsp)
   7bba2:	0f 85 ea 01 00 00    	jne    7bd92 <varlit_core::file::VarlitFile::mark_record_dead+0x462>
   7bba8:	31 c9                	xor    %ecx,%ecx
   7bbaa:	31 d2                	xor    %edx,%edx
   7bbac:	31 ff                	xor    %edi,%edi
   7bbae:	31 ed                	xor    %ebp,%ebp
   7bbb0:	e9 df 02 00 00       	jmp    7be94 <varlit_core::file::VarlitFile::mark_record_dead+0x564>
   7bbb5:	48 8d 35 a3 66 fa ff 	lea    -0x5995d(%rip),%rsi        # 2225f <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1920>
   7bbbc:	ba 19 00 00 00       	mov    $0x19,%edx
   7bbc1:	bf 01 00 00 00       	mov    $0x1,%edi
   7bbc6:	ff 15 fc 0d 15 00    	call   *0x150dfc(%rip)        # 1cc9c8 <_DYNAMIC+0x7b0>
   7bbcc:	49 83 c6 89          	add    $0xffffffffffffff89,%r14
   7bbd0:	4c 89 f1             	mov    %r14,%rcx
   7bbd3:	48 89 0b             	mov    %rcx,(%rbx)
   7bbd6:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7bbda:	48 c7 43 10 04 00 00 	movq   $0x4,0x10(%rbx)
   7bbe1:	00 
   7bbe2:	48 c7 43 18 04 00 00 	movq   $0x4,0x18(%rbx)
   7bbe9:	00 
   7bbea:	48 89 d8             	mov    %rbx,%rax
   7bbed:	48 81 c4 c8 03 00 00 	add    $0x3c8,%rsp
   7bbf4:	5b                   	pop    %rbx
   7bbf5:	41 5c                	pop    %r12
   7bbf7:	41 5d                	pop    %r13
   7bbf9:	41 5e                	pop    %r14
   7bbfb:	41 5f                	pop    %r15
   7bbfd:	5d                   	pop    %rbp
   7bbfe:	c3                   	ret
   7bbff:	49 83 c6 a1          	add    $0xffffffffffffffa1,%r14
   7bc03:	4c 89 33             	mov    %r14,(%rbx)
   7bc06:	48 8d 05 2e 67 fa ff 	lea    -0x598d2(%rip),%rax        # 2233b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x19fc>
   7bc0d:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7bc11:	48 c7 43 10 30 00 00 	movq   $0x30,0x10(%rbx)
   7bc18:	00 
   7bc19:	eb cf                	jmp    7bbea <varlit_core::file::VarlitFile::mark_record_dead+0x2ba>
   7bc1b:	0f 10 84 24 39 01 00 	movups 0x139(%rsp),%xmm0
   7bc22:	00 
   7bc23:	0f 10 8c 24 49 01 00 	movups 0x149(%rsp),%xmm1
   7bc2a:	00 
   7bc2b:	0f 10 94 24 58 01 00 	movups 0x158(%rsp),%xmm2
   7bc32:	00 
   7bc33:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
   7bc37:	0f 11 4b 19          	movups %xmm1,0x19(%rbx)
   7bc3b:	0f 11 43 09          	movups %xmm0,0x9(%rbx)
   7bc3f:	48 89 0b             	mov    %rcx,(%rbx)
   7bc42:	88 43 08             	mov    %al,0x8(%rbx)
   7bc45:	eb a3                	jmp    7bbea <varlit_core::file::VarlitFile::mark_record_dead+0x2ba>
   7bc47:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   7bc4c:	83 b9 28 09 00 00 02 	cmpl   $0x2,0x928(%rcx)
   7bc53:	75 74                	jne    7bcc9 <varlit_core::file::VarlitFile::mark_record_dead+0x399>
   7bc55:	4c 8b a9 a8 0b 00 00 	mov    0xba8(%rcx),%r13
   7bc5c:	48 8d ac 24 30 01 00 	lea    0x130(%rsp),%rbp
   7bc63:	00 
   7bc64:	ba 98 02 00 00       	mov    $0x298,%edx
   7bc69:	48 89 ef             	mov    %rbp,%rdi
   7bc6c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   7bc71:	ff 15 a9 08 15 00    	call   *0x1508a9(%rip)        # 1cc520 <memcpy@GLIBC_2.14>
   7bc77:	48 89 ef             	mov    %rbp,%rdi
   7bc7a:	4c 89 ee             	mov    %r13,%rsi
   7bc7d:	ff 15 25 0a 15 00    	call   *0x150a25(%rip)        # 1cc6a8 <_DYNAMIC+0x490>
   7bc83:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   7bc88:	eb 46                	jmp    7bcd0 <varlit_core::file::VarlitFile::mark_record_dead+0x3a0>
   7bc8a:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
   7bc8f:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
   7bc94:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   7bc99:	4d 89 fc             	mov    %r15,%r12
   7bc9c:	49 c1 ec 20          	shr    $0x20,%r12
   7bca0:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
   7bca5:	4d 89 cb             	mov    %r9,%r11
   7bca8:	49 c1 eb 20          	shr    $0x20,%r11
   7bcac:	4c 89 ce             	mov    %r9,%rsi
   7bcaf:	48 c1 ee 30          	shr    $0x30,%rsi
   7bcb3:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
   7bcb8:	48 89 e8             	mov    %rbp,%rax
   7bcbb:	48 c1 e8 20          	shr    $0x20,%rax
   7bcbf:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   7bcc4:	e9 74 03 00 00       	jmp    7c03d <varlit_core::file::VarlitFile::mark_record_dead+0x70d>
   7bcc9:	48 8b 81 f8 0a 00 00 	mov    0xaf8(%rcx),%rax
   7bcd0:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   7bcd5:	48 39 c2             	cmp    %rax,%rdx
   7bcd8:	72 2f                	jb     7bd09 <varlit_core::file::VarlitFile::mark_record_dead+0x3d9>
   7bcda:	48 3b 91 a8 08 00 00 	cmp    0x8a8(%rcx),%rdx
   7bce1:	73 26                	jae    7bd09 <varlit_core::file::VarlitFile::mark_record_dead+0x3d9>
   7bce3:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   7bcea:	00 
   7bceb:	4c 89 e6             	mov    %r12,%rsi
   7bcee:	48 89 d1             	mov    %rdx,%rcx
   7bcf1:	48 89 c2             	mov    %rax,%rdx
   7bcf4:	e8 27 94 06 00       	call   e5120 <varlit_core::file::resident_index::ResidentIndex::extend_boundary_proof>
   7bcf9:	4c 39 b4 24 30 01 00 	cmp    %r14,0x130(%rsp)
   7bd00:	00 
   7bd01:	0f 84 c8 fc ff ff    	je     7b9cf <varlit_core::file::VarlitFile::mark_record_dead+0x9f>
   7bd07:	eb 27                	jmp    7bd30 <varlit_core::file::VarlitFile::mark_record_dead+0x400>
   7bd09:	49 83 c6 94          	add    $0xffffffffffffff94,%r14
   7bd0d:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   7bd14:	00 
   7bd15:	48 8d 05 24 14 fb ff 	lea    -0x4ebdc(%rip),%rax        # 2d140 <anon.ffd425f973af7d01e09094328418b03c.34.llvm.16485786794908342638>
   7bd1c:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
   7bd23:	00 
   7bd24:	48 c7 84 24 40 01 00 	movq   $0x26,0x140(%rsp)
   7bd2b:	00 26 00 00 00 
   7bd30:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
   7bd37:	00 
   7bd38:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7bd3c:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
   7bd43:	00 
   7bd44:	48 8b 8c 24 38 01 00 	mov    0x138(%rsp),%rcx
   7bd4b:	00 
   7bd4c:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
   7bd53:	00 
   7bd54:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   7bd5b:	00 
   7bd5c:	0f 10 84 24 50 01 00 	movups 0x150(%rsp),%xmm0
   7bd63:	00 
   7bd64:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   7bd68:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   7bd6c:	48 89 73 18          	mov    %rsi,0x18(%rbx)
   7bd70:	48 89 03             	mov    %rax,(%rbx)
   7bd73:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   7bd77:	e9 6e fe ff ff       	jmp    7bbea <varlit_core::file::VarlitFile::mark_record_dead+0x2ba>
   7bd7c:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
   7bd81:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   7bd86:	48 89 e8             	mov    %rbp,%rax
   7bd89:	48 c1 e8 20          	shr    $0x20,%rax
   7bd8d:	e9 ab 02 00 00       	jmp    7c03d <varlit_core::file::VarlitFile::mark_record_dead+0x70d>
   7bd92:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
   7bd97:	4c 03 7c 24 70       	add    0x70(%rsp),%r15
   7bd9c:	0f 82 d2 03 00 00    	jb     7c174 <varlit_core::file::VarlitFile::mark_record_dead+0x844>
   7bda2:	48 8d 05 c2 65 fa ff 	lea    -0x59a3e(%rip),%rax        # 2236b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a2c>
   7bda9:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   7bdae:	48 c7 44 24 28 14 00 	movq   $0x14,0x28(%rsp)
   7bdb5:	00 00 
   7bdb7:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
   7bdbc:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7bdc1:	e8 7a ca 00 00       	call   88840 <core::ptr::drop_in_place<varlit_core::error::Error>>
   7bdc6:	0f 57 c0             	xorps  %xmm0,%xmm0
   7bdc9:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   7bdd0:	00 
   7bdd1:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   7bdd8:	00 
   7bdd9:	4c 89 f8             	mov    %r15,%rax
   7bddc:	48 2b 44 24 08       	sub    0x8(%rsp),%rax
   7bde1:	48 89 c2             	mov    %rax,%rdx
   7bde4:	48 83 ea e0          	sub    $0xffffffffffffffe0,%rdx
   7bde8:	4c 89 f9             	mov    %r15,%rcx
   7bdeb:	73 12                	jae    7bdff <varlit_core::file::VarlitFile::mark_record_dead+0x4cf>
   7bded:	48 39 ea             	cmp    %rbp,%rdx
   7bdf0:	77 0d                	ja     7bdff <varlit_core::file::VarlitFile::mark_record_dead+0x4cf>
   7bdf2:	48 8d 2c 04          	lea    (%rsp,%rax,1),%rbp
   7bdf6:	48 81 c5 30 01 00 00 	add    $0x130,%rbp
   7bdfd:	eb 3b                	jmp    7be3a <varlit_core::file::VarlitFile::mark_record_dead+0x50a>
   7bdff:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7be04:	48 8d ac 24 a0 00 00 	lea    0xa0(%rsp),%rbp
   7be0b:	00 
   7be0c:	41 b8 20 00 00 00    	mov    $0x20,%r8d
   7be12:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
   7be19:	00 
   7be1a:	49 89 cf             	mov    %rcx,%r15
   7be1d:	48 89 ca             	mov    %rcx,%rdx
   7be20:	48 89 e9             	mov    %rbp,%rcx
   7be23:	ff 15 47 0c 15 00    	call   *0x150c47(%rip)        # 1cca70 <_DYNAMIC+0x858>
   7be29:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
   7be2e:	4d 39 f1             	cmp    %r14,%r9
   7be31:	0f 85 ab 01 00 00    	jne    7bfe2 <varlit_core::file::VarlitFile::mark_record_dead+0x6b2>
   7be37:	4c 89 f9             	mov    %r15,%rcx
   7be3a:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7be3f:	ba 20 00 00 00       	mov    $0x20,%edx
   7be44:	48 89 ee             	mov    %rbp,%rsi
   7be47:	49 89 cf             	mov    %rcx,%r15
   7be4a:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
   7be4f:	e8 4c c4 07 00       	call   f82a0 <varlit_core::native_layout::decode_native_record_footer>
   7be54:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
   7be59:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   7be5e:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   7be63:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   7be68:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
   7be6d:	8b 6c 24 40          	mov    0x40(%rsp),%ebp
   7be71:	4d 39 f1             	cmp    %r14,%r9
   7be74:	0f 85 35 01 00 00    	jne    7bfaf <varlit_core::file::VarlitFile::mark_record_dead+0x67f>
   7be7a:	85 ed                	test   %ebp,%ebp
   7be7c:	0f 94 c0             	sete   %al
   7be7f:	0f b6 4c 24 05       	movzbl 0x5(%rsp),%ecx
   7be84:	08 c1                	or     %al,%cl
   7be86:	f6 c1 01             	test   $0x1,%cl
   7be89:	0f 84 7a 01 00 00    	je     7c009 <varlit_core::file::VarlitFile::mark_record_dead+0x6d9>
   7be8f:	b9 01 00 00 00       	mov    $0x1,%ecx
   7be94:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   7be99:	4c 8b 4c 24 58       	mov    0x58(%rsp),%r9
   7be9e:	4c 8b 54 24 68       	mov    0x68(%rsp),%r10
   7bea3:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   7bea8:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
   7beaf:	00 
   7beb0:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
   7beb5:	4c 89 bc 24 d0 00 00 	mov    %r15,0xd0(%rsp)
   7bebc:	00 
   7bebd:	48 89 94 24 d8 00 00 	mov    %rdx,0xd8(%rsp)
   7bec4:	00 
   7bec5:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
   7becc:	00 
   7becd:	48 89 bc 24 e8 00 00 	mov    %rdi,0xe8(%rsp)
   7bed4:	00 
   7bed5:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
   7bedc:	00 
   7bedd:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
   7bee4:	00 
   7bee5:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
   7beec:	00 
   7beed:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   7bef2:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
   7bef9:	00 
   7befa:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
   7beff:	48 89 8c 24 08 01 00 	mov    %rcx,0x108(%rsp)
   7bf06:	00 
   7bf07:	4c 89 8c 24 10 01 00 	mov    %r9,0x110(%rsp)
   7bf0e:	00 
   7bf0f:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   7bf14:	89 94 24 18 01 00 00 	mov    %edx,0x118(%rsp)
   7bf1b:	44 89 a4 24 1c 01 00 	mov    %r12d,0x11c(%rsp)
   7bf22:	00 
   7bf23:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
   7bf2a:	00 
   7bf2b:	89 8c 24 20 01 00 00 	mov    %ecx,0x120(%rsp)
   7bf32:	89 ac 24 24 01 00 00 	mov    %ebp,0x124(%rsp)
   7bf39:	66 44 89 94 24 28 01 	mov    %r10w,0x128(%rsp)
   7bf40:	00 00 
   7bf42:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   7bf49:	00 
   7bf4a:	66 89 8c 24 2a 01 00 	mov    %cx,0x12a(%rsp)
   7bf51:	00 
   7bf52:	c6 84 24 2c 01 00 00 	movb   $0x0,0x12c(%rsp)
   7bf59:	00 
   7bf5a:	49 89 d4             	mov    %rdx,%r12
   7bf5d:	4c 8d bc 24 30 01 00 	lea    0x130(%rsp),%r15
   7bf64:	00 
   7bf65:	ba 98 02 00 00       	mov    $0x298,%edx
   7bf6a:	4c 89 ff             	mov    %r15,%rdi
   7bf6d:	48 89 c6             	mov    %rax,%rsi
   7bf70:	ff 15 aa 05 15 00    	call   *0x1505aa(%rip)        # 1cc520 <memcpy@GLIBC_2.14>
   7bf76:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7bf7b:	48 8d 94 24 c8 00 00 	lea    0xc8(%rsp),%rdx
   7bf82:	00 
   7bf83:	4c 89 fe             	mov    %r15,%rsi
   7bf86:	e8 e5 64 00 00       	call   82470 <varlit_core::file::header_codec::validate_record_entry>
   7bf8b:	4c 39 74 24 18       	cmp    %r14,0x18(%rsp)
   7bf90:	75 28                	jne    7bfba <varlit_core::file::VarlitFile::mark_record_dead+0x68a>
   7bf92:	41 81 fc ff fe ff ff 	cmp    $0xfffffeff,%r12d
   7bf99:	0f 86 e9 00 00 00    	jbe    7c088 <varlit_core::file::VarlitFile::mark_record_dead+0x758>
   7bf9f:	49 83 c6 9f          	add    $0xffffffffffffff9f,%r14
   7bfa3:	4c 89 33             	mov    %r14,(%rbx)
   7bfa6:	44 89 63 08          	mov    %r12d,0x8(%rbx)
   7bfaa:	e9 3b fc ff ff       	jmp    7bbea <varlit_core::file::VarlitFile::mark_record_dead+0x2ba>
   7bfaf:	8b 44 24 44          	mov    0x44(%rsp),%eax
   7bfb3:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   7bfb8:	eb 59                	jmp    7c013 <varlit_core::file::VarlitFile::mark_record_dead+0x6e3>
   7bfba:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   7bfbf:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7bfc3:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
   7bfc8:	0f 10 4c 24 28       	movups 0x28(%rsp),%xmm1
   7bfcd:	0f 10 54 24 38       	movups 0x38(%rsp),%xmm2
   7bfd2:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
   7bfd6:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
   7bfda:	0f 11 03             	movups %xmm0,(%rbx)
   7bfdd:	e9 08 fc ff ff       	jmp    7bbea <varlit_core::file::VarlitFile::mark_record_dead+0x2ba>
   7bfe2:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   7bfe7:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   7bfec:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   7bff1:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
   7bff6:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
   7bffb:	48 89 e8             	mov    %rbp,%rax
   7bffe:	48 c1 e8 20          	shr    $0x20,%rax
   7c002:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   7c007:	eb 0a                	jmp    7c013 <varlit_core::file::VarlitFile::mark_record_dead+0x6e3>
   7c009:	49 83 c6 b3          	add    $0xffffffffffffffb3,%r14
   7c00d:	4c 89 fa             	mov    %r15,%rdx
   7c010:	4d 89 f1             	mov    %r14,%r9
   7c013:	4d 89 c3             	mov    %r8,%r11
   7c016:	49 c1 eb 20          	shr    $0x20,%r11
   7c01a:	4d 89 c6             	mov    %r8,%r14
   7c01d:	49 c1 ee 30          	shr    $0x30,%r14
   7c021:	49 89 fc             	mov    %rdi,%r12
   7c024:	49 c1 ec 20          	shr    $0x20,%r12
   7c028:	41 89 ff             	mov    %edi,%r15d
   7c02b:	44 89 c7             	mov    %r8d,%edi
   7c02e:	49 89 f2             	mov    %rsi,%r10
   7c031:	4c 89 f6             	mov    %r14,%rsi
   7c034:	49 89 d0             	mov    %rdx,%r8
   7c037:	4d 89 cd             	mov    %r9,%r13
   7c03a:	49 89 f9             	mov    %rdi,%r9
   7c03d:	49 c1 e4 20          	shl    $0x20,%r12
   7c041:	44 89 fa             	mov    %r15d,%edx
   7c044:	4c 09 e2             	or     %r12,%rdx
   7c047:	0f b7 f6             	movzwl %si,%esi
   7c04a:	48 c1 e6 30          	shl    $0x30,%rsi
   7c04e:	41 0f b7 fb          	movzwl %r11w,%edi
   7c052:	48 c1 e7 20          	shl    $0x20,%rdi
   7c056:	48 09 f7             	or     %rsi,%rdi
   7c059:	44 89 ce             	mov    %r9d,%esi
   7c05c:	48 09 fe             	or     %rdi,%rsi
   7c05f:	48 c1 e0 20          	shl    $0x20,%rax
   7c063:	89 ef                	mov    %ebp,%edi
   7c065:	48 09 c7             	or     %rax,%rdi
   7c068:	4c 89 2b             	mov    %r13,(%rbx)
   7c06b:	4c 89 43 08          	mov    %r8,0x8(%rbx)
   7c06f:	4c 89 53 10          	mov    %r10,0x10(%rbx)
   7c073:	48 89 53 18          	mov    %rdx,0x18(%rbx)
   7c077:	48 89 73 20          	mov    %rsi,0x20(%rbx)
   7c07b:	48 89 7b 28          	mov    %rdi,0x28(%rbx)
   7c07f:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
   7c083:	e9 62 fb ff ff       	jmp    7bbea <varlit_core::file::VarlitFile::mark_record_dead+0x2ba>
   7c088:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
   7c08e:	74 79                	je     7c109 <varlit_core::file::VarlitFile::mark_record_dead+0x7d9>
   7c090:	48 83 7c 24 50 e3    	cmpq   $0xffffffffffffffe3,0x50(%rsp)
   7c096:	0f 87 f4 00 00 00    	ja     7c190 <varlit_core::file::VarlitFile::mark_record_dead+0x860>
   7c09c:	48 8d 05 c8 62 fa ff 	lea    -0x59d38(%rip),%rax        # 2236b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a2c>
   7c0a3:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
   7c0aa:	00 
   7c0ab:	48 c7 84 24 40 01 00 	movq   $0x14,0x140(%rsp)
   7c0b2:	00 14 00 00 00 
   7c0b7:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
   7c0be:	00 
   7c0bf:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   7c0c6:	00 
   7c0c7:	e8 74 c7 00 00       	call   88840 <core::ptr::drop_in_place<varlit_core::error::Error>>
   7c0cc:	89 e9                	mov    %ebp,%ecx
   7c0ce:	83 c9 01             	or     $0x1,%ecx
   7c0d1:	39 e9                	cmp    %ebp,%ecx
   7c0d3:	74 2c                	je     7c101 <varlit_core::file::VarlitFile::mark_record_dead+0x7d1>
   7c0d5:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
   7c0da:	48 83 c2 1c          	add    $0x1c,%rdx
   7c0de:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   7c0e3:	48 81 c6 e0 0b 00 00 	add    $0xbe0,%rsi
   7c0ea:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   7c0f1:	00 
   7c0f2:	e8 b9 dc 02 00       	call   a9db0 <varlit_core::file::record_file::RecordFile::overwrite_record_mutable_flags>
   7c0f7:	4c 39 b4 24 30 01 00 	cmp    %r14,0x130(%rsp)
   7c0fe:	00 
   7c0ff:	75 27                	jne    7c128 <varlit_core::file::VarlitFile::mark_record_dead+0x7f8>
   7c101:	4c 89 33             	mov    %r14,(%rbx)
   7c104:	e9 e1 fa ff ff       	jmp    7bbea <varlit_core::file::VarlitFile::mark_record_dead+0x2ba>
   7c109:	49 83 c6 a1          	add    $0xffffffffffffffa1,%r14
   7c10d:	4c 89 33             	mov    %r14,(%rbx)
   7c110:	48 8d 05 68 62 fa ff 	lea    -0x59d98(%rip),%rax        # 2237f <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a40>
   7c117:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7c11b:	48 c7 43 10 29 00 00 	movq   $0x29,0x10(%rbx)
   7c122:	00 
   7c123:	e9 c2 fa ff ff       	jmp    7bbea <varlit_core::file::VarlitFile::mark_record_dead+0x2ba>
   7c128:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
   7c12f:	00 
   7c130:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7c134:	0f 10 84 24 30 01 00 	movups 0x130(%rsp),%xmm0
   7c13b:	00 
   7c13c:	0f 10 8c 24 40 01 00 	movups 0x140(%rsp),%xmm1
   7c143:	00 
   7c144:	0f 10 94 24 50 01 00 	movups 0x150(%rsp),%xmm2
   7c14b:	00 
   7c14c:	e9 81 fe ff ff       	jmp    7bfd2 <varlit_core::file::VarlitFile::mark_record_dead+0x6a2>
   7c151:	49 83 c6 98          	add    $0xffffffffffffff98,%r14
   7c155:	4c 8d 05 a8 63 fa ff 	lea    -0x59c58(%rip),%r8        # 22504 <anon.48385641d07dc56499de4af04e4ddc4c.132.llvm.6019142963973739168+0x22>
   7c15c:	41 ba 15 00 00 00    	mov    $0x15,%r10d
   7c162:	45 31 e4             	xor    %r12d,%r12d
   7c165:	31 f6                	xor    %esi,%esi
   7c167:	45 31 db             	xor    %r11d,%r11d
   7c16a:	31 c0                	xor    %eax,%eax
   7c16c:	4d 89 f5             	mov    %r14,%r13
   7c16f:	e9 c9 fe ff ff       	jmp    7c03d <varlit_core::file::VarlitFile::mark_record_dead+0x70d>
   7c174:	4c 8d 05 f0 61 fa ff 	lea    -0x59e10(%rip),%r8        # 2236b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a2c>
   7c17b:	41 ba 14 00 00 00    	mov    $0x14,%r10d
   7c181:	45 31 e4             	xor    %r12d,%r12d
   7c184:	31 f6                	xor    %esi,%esi
   7c186:	45 31 db             	xor    %r11d,%r11d
   7c189:	31 c0                	xor    %eax,%eax
   7c18b:	e9 ad fe ff ff       	jmp    7c03d <varlit_core::file::VarlitFile::mark_record_dead+0x70d>
   7c190:	48 c7 84 24 40 01 00 	movq   $0x14,0x140(%rsp)
   7c197:	00 14 00 00 00 
   7c19c:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
   7c1a3:	00 
   7c1a4:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7c1a8:	0f 10 84 24 50 01 00 	movups 0x150(%rsp),%xmm0
   7c1af:	00 
   7c1b0:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   7c1b4:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
   7c1bb:	00 
   7c1bc:	48 89 43 10          	mov    %rax,0x10(%rbx)
   7c1c0:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
   7c1c7:	00 
   7c1c8:	48 89 43 18          	mov    %rax,0x18(%rbx)
   7c1cc:	4c 89 2b             	mov    %r13,(%rbx)
   7c1cf:	48 8d 05 95 61 fa ff 	lea    -0x59e6b(%rip),%rax        # 2236b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a2c>
   7c1d6:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7c1da:	e9 0b fa ff ff       	jmp    7bbea <varlit_core::file::VarlitFile::mark_record_dead+0x2ba>
