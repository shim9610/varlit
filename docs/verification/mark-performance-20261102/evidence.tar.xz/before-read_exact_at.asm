
/workspace/scratch/compound-hardening/final/after-bin/record_mutation_load:     file format elf64-x86-64


Disassembly of section .text:

00000000000b9640 <varlit_core::snapshot::SnapshotFile::read_exact_at>:
   b9640:	55                   	push   %rbp
   b9641:	41 57                	push   %r15
   b9643:	41 56                	push   %r14
   b9645:	41 55                	push   %r13
   b9647:	41 54                	push   %r12
   b9649:	53                   	push   %rbx
   b964a:	48 83 ec 48          	sub    $0x48,%rsp
   b964e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
   b9653:	48 89 3c 24          	mov    %rdi,(%rsp)
   b9657:	48 bd 15 00 00 00 00 	movabs $0x8000000000000015,%rbp
   b965e:	00 00 80 
   b9661:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   b9665:	4d 89 c4             	mov    %r8,%r12
   b9668:	48 8d 0d 0e ab f6 ff 	lea    -0x954f2(%rip),%rcx        # 2417d <anon.0624e7d5e48278245b12a454ff79655c.105.llvm.2515505084513145378>
   b966f:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   b9674:	48 c7 44 24 20 0e 00 	movq   $0xe,0x20(%rsp)
   b967b:	00 00 
   b967d:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
   b9682:	49 01 d4             	add    %rdx,%r12
   b9685:	0f 82 39 01 00 00    	jb     b97c4 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x184>
   b968b:	4d 89 c6             	mov    %r8,%r14
   b968e:	49 89 d7             	mov    %rdx,%r15
   b9691:	49 89 f5             	mov    %rsi,%r13
   b9694:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   b9699:	e8 c2 e9 fe ff       	call   a8060 <core::ptr::drop_in_place<varlit_core::error::Error>>
   b969e:	49 39 dc             	cmp    %rbx,%r12
   b96a1:	76 1f                	jbe    b96c2 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x82>
   b96a3:	48 83 c5 02          	add    $0x2,%rbp
   b96a7:	4c 89 f9             	mov    %r15,%rcx
   b96aa:	48 8b 04 24          	mov    (%rsp),%rax
   b96ae:	4c 89 70 10          	mov    %r14,0x10(%rax)
   b96b2:	48 89 58 18          	mov    %rbx,0x18(%rax)
   b96b6:	48 89 28             	mov    %rbp,(%rax)
   b96b9:	48 89 48 08          	mov    %rcx,0x8(%rax)
   b96bd:	e9 a3 00 00 00       	jmp    b9765 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x125>
   b96c2:	4d 85 f6             	test   %r14,%r14
   b96c5:	0f 84 8f 00 00 00    	je     b975a <varlit_core::snapshot::SnapshotFile::read_exact_at+0x11a>
   b96cb:	4d 8b 6d 00          	mov    0x0(%r13),%r13
   b96cf:	49 83 c5 08          	add    $0x8,%r13
   b96d3:	45 31 e4             	xor    %r12d,%r12d
   b96d6:	eb 0d                	jmp    b96e5 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xa5>
   b96d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   b96df:	00 
   b96e0:	4d 39 f4             	cmp    %r14,%r12
   b96e3:	73 75                	jae    b975a <varlit_core::snapshot::SnapshotFile::read_exact_at+0x11a>
   b96e5:	4c 89 e3             	mov    %r12,%rbx
   b96e8:	4c 01 fb             	add    %r15,%rbx
   b96eb:	0f 82 9a 00 00 00    	jb     b978b <varlit_core::snapshot::SnapshotFile::read_exact_at+0x14b>
   b96f1:	48 8d 05 c8 b4 f6 ff 	lea    -0x94b38(%rip),%rax        # 24bc0 <anon.44dfe6286d6883d57c2709f00721256e.109.llvm.13865937089330926611>
   b96f8:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   b96fd:	48 c7 44 24 20 14 00 	movq   $0x14,0x20(%rsp)
   b9704:	00 00 
   b9706:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
   b970b:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   b9710:	e8 4b 03 00 00       	call   b9a60 <core::ptr::drop_in_place<varlit_core::error::Error>>
   b9715:	4c 89 f2             	mov    %r14,%rdx
   b9718:	4c 29 e2             	sub    %r12,%rdx
   b971b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   b9720:	4a 8d 34 20          	lea    (%rax,%r12,1),%rsi
   b9724:	4c 89 ef             	mov    %r13,%rdi
   b9727:	48 89 d9             	mov    %rbx,%rcx
   b972a:	ff 15 b8 35 11 00    	call   *0x1135b8(%rip)        # 1ccce8 <_DYNAMIC+0xad0>
   b9730:	48 89 d3             	mov    %rdx,%rbx
   b9733:	48 83 f8 01          	cmp    $0x1,%rax
   b9737:	75 17                	jne    b9750 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x110>
   b9739:	48 89 df             	mov    %rbx,%rdi
   b973c:	e8 3f bf ff ff       	call   b5680 <<std::io::error::Error>::kind>
   b9741:	3c 23                	cmp    $0x23,%al
   b9743:	75 35                	jne    b977a <varlit_core::snapshot::SnapshotFile::read_exact_at+0x13a>
   b9745:	48 89 df             	mov    %rbx,%rdi
   b9748:	e8 63 02 00 00       	call   b99b0 <core::ptr::drop_in_place<std::io::error::Error>>
   b974d:	eb 91                	jmp    b96e0 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xa0>
   b974f:	90                   	nop
   b9750:	48 85 db             	test   %rbx,%rbx
   b9753:	74 1f                	je     b9774 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x134>
   b9755:	49 01 dc             	add    %rbx,%r12
   b9758:	eb 86                	jmp    b96e0 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xa0>
   b975a:	48 83 c5 68          	add    $0x68,%rbp
   b975e:	48 8b 04 24          	mov    (%rsp),%rax
   b9762:	48 89 28             	mov    %rbp,(%rax)
   b9765:	48 83 c4 48          	add    $0x48,%rsp
   b9769:	5b                   	pop    %rbx
   b976a:	41 5c                	pop    %r12
   b976c:	41 5d                	pop    %r13
   b976e:	41 5e                	pop    %r14
   b9770:	41 5f                	pop    %r15
   b9772:	5d                   	pop    %rbp
   b9773:	c3                   	ret
   b9774:	48 83 c5 f6          	add    $0xfffffffffffffff6,%rbp
   b9778:	eb e4                	jmp    b975e <varlit_core::snapshot::SnapshotFile::read_exact_at+0x11e>
   b977a:	48 83 c5 f1          	add    $0xfffffffffffffff1,%rbp
   b977e:	48 8b 04 24          	mov    (%rsp),%rax
   b9782:	48 89 28             	mov    %rbp,(%rax)
   b9785:	48 89 58 08          	mov    %rbx,0x8(%rax)
   b9789:	eb da                	jmp    b9765 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x125>
   b978b:	48 c7 44 24 20 14 00 	movq   $0x14,0x20(%rsp)
   b9792:	00 00 
   b9794:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
   b9799:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
   b979d:	48 8b 04 24          	mov    (%rsp),%rax
   b97a1:	48 89 48 30          	mov    %rcx,0x30(%rax)
   b97a5:	0f 10 02             	movups (%rdx),%xmm0
   b97a8:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
   b97ac:	0f 11 48 20          	movups %xmm1,0x20(%rax)
   b97b0:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   b97b4:	48 89 28             	mov    %rbp,(%rax)
   b97b7:	48 8d 0d 02 b4 f6 ff 	lea    -0x94bfe(%rip),%rcx        # 24bc0 <anon.44dfe6286d6883d57c2709f00721256e.109.llvm.13865937089330926611>
   b97be:	48 89 48 08          	mov    %rcx,0x8(%rax)
   b97c2:	eb a1                	jmp    b9765 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x125>
   b97c4:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   b97ca:	e9 db fe ff ff       	jmp    b96aa <varlit_core::snapshot::SnapshotFile::read_exact_at+0x6a>
