
/workspace/scratch/mark-perf-fix/branch-errors-bin/record_mutation_load:     file format elf64-x86-64


Disassembly of section .text:

000000000007b930 <varlit_core::file::VarlitFile::mark_record_dead>:
   7b930:	55                   	push   %rbp
   7b931:	41 57                	push   %r15
   7b933:	41 56                	push   %r14
   7b935:	41 55                	push   %r13
   7b937:	41 54                	push   %r12
   7b939:	53                   	push   %rbx
   7b93a:	48 81 ec b8 03 00 00 	sub    $0x3b8,%rsp
   7b941:	48 89 fb             	mov    %rdi,%rbx
   7b944:	49 bc 7d 00 00 00 00 	movabs $0x800000000000007d,%r12
   7b94b:	00 00 80 
   7b94e:	49 8d 4c 24 be       	lea    -0x42(%r12),%rcx
   7b953:	48 8d 05 8a e9 f9 ff 	lea    -0x61676(%rip),%rax        # 1a2e4 <anon.17b082cb49e65867434834b0b59514e7.62.llvm.178743251253153762+0x8>
   7b95a:	80 be 90 0d 00 00 00 	cmpb   $0x0,0xd90(%rsi)
   7b961:	0f 85 63 01 00 00    	jne    7baca <varlit_core::file::VarlitFile::mark_record_dead+0x19a>
   7b967:	49 89 f6             	mov    %rsi,%r14
   7b96a:	80 be 91 0d 00 00 00 	cmpb   $0x0,0xd91(%rsi)
   7b971:	0f 85 53 01 00 00    	jne    7baca <varlit_core::file::VarlitFile::mark_record_dead+0x19a>
   7b977:	41 80 be 92 0d 00 00 	cmpb   $0x0,0xd92(%r14)
   7b97e:	00 
   7b97f:	0f 84 27 01 00 00    	je     7baac <varlit_core::file::VarlitFile::mark_record_dead+0x17c>
   7b985:	41 80 be 92 02 00 00 	cmpb   $0x0,0x292(%r14)
   7b98c:	00 
   7b98d:	0f 84 63 01 00 00    	je     7baf6 <varlit_core::file::VarlitFile::mark_record_dead+0x1c6>
   7b993:	49 8d ae 98 02 00 00 	lea    0x298(%r14),%rbp
   7b99a:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7b9a1:	00 
   7b9a2:	48 89 ee             	mov    %rbp,%rsi
   7b9a5:	49 89 d5             	mov    %rdx,%r13
   7b9a8:	e8 b3 69 04 00       	call   c2360 <varlit_core::file::resident_index::ResidentIndex::has_verified_boundary>
   7b9ad:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
   7b9b4:	00 
   7b9b5:	0f b6 84 24 28 01 00 	movzbl 0x128(%rsp),%eax
   7b9bc:	00 
   7b9bd:	4c 39 e1             	cmp    %r12,%rcx
   7b9c0:	0f 85 4c 01 00 00    	jne    7bb12 <varlit_core::file::VarlitFile::mark_record_dead+0x1e2>
   7b9c6:	a8 01                	test   $0x1,%al
   7b9c8:	0f 84 70 01 00 00    	je     7bb3e <varlit_core::file::VarlitFile::mark_record_dead+0x20e>
   7b9ce:	41 0f b6 86 8d 02 00 	movzbl 0x28d(%r14),%eax
   7b9d5:	00 
   7b9d6:	88 44 24 10          	mov    %al,0x10(%rsp)
   7b9da:	41 0f b6 86 8e 02 00 	movzbl 0x28e(%r14),%eax
   7b9e1:	00 
   7b9e2:	88 44 24 78          	mov    %al,0x78(%rsp)
   7b9e6:	41 0f b6 86 8f 02 00 	movzbl 0x28f(%r14),%eax
   7b9ed:	00 
   7b9ee:	88 44 24 70          	mov    %al,0x70(%rsp)
   7b9f2:	41 0f b6 86 92 02 00 	movzbl 0x292(%r14),%eax
   7b9f9:	00 
   7b9fa:	88 44 24 07          	mov    %al,0x7(%rsp)
   7b9fe:	41 0f b6 86 97 02 00 	movzbl 0x297(%r14),%eax
   7ba05:	00 
   7ba06:	88 44 24 28          	mov    %al,0x28(%rsp)
   7ba0a:	49 8b ae 28 0d 00 00 	mov    0xd28(%r14),%rbp
   7ba11:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   7ba18:	25 00 00 00 00 
   7ba1d:	48 8b 88 38 ff ff ff 	mov    -0xc8(%rax),%rcx
   7ba24:	48 ff c1             	inc    %rcx
   7ba27:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
   7ba2e:	48 0f 45 d1          	cmovne %rcx,%rdx
   7ba32:	48 89 90 38 ff ff ff 	mov    %rdx,-0xc8(%rax)
   7ba39:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7ba40:	00 
   7ba41:	41 bf 00 02 00 00    	mov    $0x200,%r15d
   7ba47:	ba 00 02 00 00       	mov    $0x200,%edx
   7ba4c:	31 f6                	xor    %esi,%esi
   7ba4e:	ff 15 6c 0d 15 00    	call   *0x150d6c(%rip)        # 1cc7c0 <memset@GLIBC_2.2.5>
   7ba54:	48 89 e8             	mov    %rbp,%rax
   7ba57:	4c 29 e8             	sub    %r13,%rax
   7ba5a:	b9 00 00 00 00       	mov    $0x0,%ecx
   7ba5f:	48 0f 43 c8          	cmovae %rax,%rcx
   7ba63:	48 83 f9 21          	cmp    $0x21,%rcx
   7ba67:	4c 89 ea             	mov    %r13,%rdx
   7ba6a:	41 bd 20 00 00 00    	mov    $0x20,%r13d
   7ba70:	4c 0f 43 e9          	cmovae %rcx,%r13
   7ba74:	49 81 fd 00 02 00 00 	cmp    $0x200,%r13
   7ba7b:	4d 0f 43 ef          	cmovae %r15,%r13
   7ba7f:	49 8d 44 24 98       	lea    -0x68(%r12),%rax
   7ba84:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   7ba89:	4c 89 e8             	mov    %r13,%rax
   7ba8c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   7ba91:	48 01 d0             	add    %rdx,%rax
   7ba94:	0f 82 07 07 00 00    	jb     7c1a1 <varlit_core::file::VarlitFile::mark_record_dead+0x871>
   7ba9a:	48 39 e8             	cmp    %rbp,%rax
   7ba9d:	0f 86 dc 00 00 00    	jbe    7bb7f <varlit_core::file::VarlitFile::mark_record_dead+0x24f>
   7baa3:	49 83 c4 9a          	add    $0xffffffffffffff9a,%r12
   7baa7:	e9 17 03 00 00       	jmp    7bdc3 <varlit_core::file::VarlitFile::mark_record_dead+0x493>
   7baac:	48 8d 35 ac 67 fa ff 	lea    -0x59854(%rip),%rsi        # 2225f <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1920>
   7bab3:	ba 19 00 00 00       	mov    $0x19,%edx
   7bab8:	bf 01 00 00 00       	mov    $0x1,%edi
   7babd:	ff 15 65 11 15 00    	call   *0x151165(%rip)        # 1ccc28 <_DYNAMIC+0x7b0>
   7bac3:	49 83 c4 89          	add    $0xffffffffffffff89,%r12
   7bac7:	4c 89 e1             	mov    %r12,%rcx
   7baca:	48 89 0b             	mov    %rcx,(%rbx)
   7bacd:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7bad1:	48 c7 43 10 04 00 00 	movq   $0x4,0x10(%rbx)
   7bad8:	00 
   7bad9:	48 c7 43 18 04 00 00 	movq   $0x4,0x18(%rbx)
   7bae0:	00 
   7bae1:	48 89 d8             	mov    %rbx,%rax
   7bae4:	48 81 c4 b8 03 00 00 	add    $0x3b8,%rsp
   7baeb:	5b                   	pop    %rbx
   7baec:	41 5c                	pop    %r12
   7baee:	41 5d                	pop    %r13
   7baf0:	41 5e                	pop    %r14
   7baf2:	41 5f                	pop    %r15
   7baf4:	5d                   	pop    %rbp
   7baf5:	c3                   	ret
   7baf6:	49 83 c4 a1          	add    $0xffffffffffffffa1,%r12
   7bafa:	4c 89 23             	mov    %r12,(%rbx)
   7bafd:	48 8d 05 37 68 fa ff 	lea    -0x597c9(%rip),%rax        # 2233b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x19fc>
   7bb04:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7bb08:	48 c7 43 10 30 00 00 	movq   $0x30,0x10(%rbx)
   7bb0f:	00 
   7bb10:	eb cf                	jmp    7bae1 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7bb12:	0f 10 84 24 29 01 00 	movups 0x129(%rsp),%xmm0
   7bb19:	00 
   7bb1a:	0f 10 8c 24 39 01 00 	movups 0x139(%rsp),%xmm1
   7bb21:	00 
   7bb22:	0f 10 94 24 48 01 00 	movups 0x148(%rsp),%xmm2
   7bb29:	00 
   7bb2a:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
   7bb2e:	0f 11 4b 19          	movups %xmm1,0x19(%rbx)
   7bb32:	0f 11 43 09          	movups %xmm0,0x9(%rbx)
   7bb36:	48 89 0b             	mov    %rcx,(%rbx)
   7bb39:	88 43 08             	mov    %al,0x8(%rbx)
   7bb3c:	eb a3                	jmp    7bae1 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7bb3e:	41 83 be 28 09 00 00 	cmpl   $0x2,0x928(%r14)
   7bb45:	02 
   7bb46:	0f 85 d8 00 00 00    	jne    7bc24 <varlit_core::file::VarlitFile::mark_record_dead+0x2f4>
   7bb4c:	4d 8b be a8 0b 00 00 	mov    0xba8(%r14),%r15
   7bb53:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7bb5a:	00 
   7bb5b:	ba 98 02 00 00       	mov    $0x298,%edx
   7bb60:	4c 89 f6             	mov    %r14,%rsi
   7bb63:	ff 15 17 0c 15 00    	call   *0x150c17(%rip)        # 1cc780 <memcpy@GLIBC_2.14>
   7bb69:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7bb70:	00 
   7bb71:	4c 89 fe             	mov    %r15,%rsi
   7bb74:	ff 15 8e 0d 15 00    	call   *0x150d8e(%rip)        # 1cc908 <_DYNAMIC+0x490>
   7bb7a:	e9 ac 00 00 00       	jmp    7bc2b <varlit_core::file::VarlitFile::mark_record_dead+0x2fb>
   7bb7f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   7bb84:	49 8d 86 20 0d 00 00 	lea    0xd20(%r14),%rax
   7bb8b:	48 8b 00             	mov    (%rax),%rax
   7bb8e:	48 83 c0 08          	add    $0x8,%rax
   7bb92:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   7bb97:	31 ed                	xor    %ebp,%ebp
   7bb99:	49 8d 44 24 89       	lea    -0x77(%r12),%rax
   7bb9e:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   7bba5:	00 
   7bba6:	49 8d 44 24 8e       	lea    -0x72(%r12),%rax
   7bbab:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   7bbb2:	00 
   7bbb3:	eb 14                	jmp    7bbc9 <varlit_core::file::VarlitFile::mark_record_dead+0x299>
   7bbb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   7bbbc:	00 00 00 00 
   7bbc0:	4c 39 ed             	cmp    %r13,%rbp
   7bbc3:	0f 83 09 01 00 00    	jae    7bcd2 <varlit_core::file::VarlitFile::mark_record_dead+0x3a2>
   7bbc9:	48 89 e9             	mov    %rbp,%rcx
   7bbcc:	48 03 4c 24 08       	add    0x8(%rsp),%rcx
   7bbd1:	0f 82 80 05 00 00    	jb     7c157 <varlit_core::file::VarlitFile::mark_record_dead+0x827>
   7bbd7:	4c 89 ea             	mov    %r13,%rdx
   7bbda:	48 29 ea             	sub    %rbp,%rdx
   7bbdd:	48 8d 34 2c          	lea    (%rsp,%rbp,1),%rsi
   7bbe1:	48 81 c6 20 01 00 00 	add    $0x120,%rsi
   7bbe8:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   7bbed:	ff 15 ed 10 15 00    	call   *0x1510ed(%rip)        # 1ccce0 <_DYNAMIC+0x868>
   7bbf3:	49 89 d7             	mov    %rdx,%r15
   7bbf6:	48 83 f8 01          	cmp    $0x1,%rax
   7bbfa:	75 1a                	jne    7bc16 <varlit_core::file::VarlitFile::mark_record_dead+0x2e6>
   7bbfc:	4c 89 ff             	mov    %r15,%rdi
   7bbff:	e8 4c 95 03 00       	call   b5150 <<std::io::error::Error>::kind>
   7bc04:	3c 23                	cmp    $0x23,%al
   7bc06:	0f 85 9f 01 00 00    	jne    7bdab <varlit_core::file::VarlitFile::mark_record_dead+0x47b>
   7bc0c:	4c 89 ff             	mov    %r15,%rdi
   7bc0f:	e8 3c d9 03 00       	call   b9550 <core::ptr::drop_in_place<std::io::error::Error>>
   7bc14:	eb aa                	jmp    7bbc0 <varlit_core::file::VarlitFile::mark_record_dead+0x290>
   7bc16:	4d 85 ff             	test   %r15,%r15
   7bc19:	0f 84 82 01 00 00    	je     7bda1 <varlit_core::file::VarlitFile::mark_record_dead+0x471>
   7bc1f:	4c 01 fd             	add    %r15,%rbp
   7bc22:	eb 9c                	jmp    7bbc0 <varlit_core::file::VarlitFile::mark_record_dead+0x290>
   7bc24:	49 8b 86 f8 0a 00 00 	mov    0xaf8(%r14),%rax
   7bc2b:	4c 89 e9             	mov    %r13,%rcx
   7bc2e:	49 39 c5             	cmp    %rax,%r13
   7bc31:	72 2c                	jb     7bc5f <varlit_core::file::VarlitFile::mark_record_dead+0x32f>
   7bc33:	49 3b 8e a8 08 00 00 	cmp    0x8a8(%r14),%rcx
   7bc3a:	73 23                	jae    7bc5f <varlit_core::file::VarlitFile::mark_record_dead+0x32f>
   7bc3c:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7bc43:	00 
   7bc44:	48 89 ee             	mov    %rbp,%rsi
   7bc47:	48 89 c2             	mov    %rax,%rdx
   7bc4a:	e8 41 5e 04 00       	call   c1a90 <varlit_core::file::resident_index::ResidentIndex::extend_boundary_proof>
   7bc4f:	4c 39 a4 24 20 01 00 	cmp    %r12,0x120(%rsp)
   7bc56:	00 
   7bc57:	0f 84 71 fd ff ff    	je     7b9ce <varlit_core::file::VarlitFile::mark_record_dead+0x9e>
   7bc5d:	eb 27                	jmp    7bc86 <varlit_core::file::VarlitFile::mark_record_dead+0x356>
   7bc5f:	49 83 c4 94          	add    $0xffffffffffffff94,%r12
   7bc63:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
   7bc6a:	00 
   7bc6b:	48 8d 05 6e a8 fa ff 	lea    -0x55792(%rip),%rax        # 264e0 <anon.8f1670067bce45509c5e836771b79779.34.llvm.11334353632041370036>
   7bc72:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
   7bc79:	00 
   7bc7a:	48 c7 84 24 30 01 00 	movq   $0x26,0x130(%rsp)
   7bc81:	00 26 00 00 00 
   7bc86:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   7bc8d:	00 
   7bc8e:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7bc92:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
   7bc99:	00 
   7bc9a:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
   7bca1:	00 
   7bca2:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
   7bca9:	00 
   7bcaa:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
   7bcb1:	00 
   7bcb2:	0f 10 84 24 40 01 00 	movups 0x140(%rsp),%xmm0
   7bcb9:	00 
   7bcba:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   7bcbe:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   7bcc2:	48 89 73 18          	mov    %rsi,0x18(%rbx)
   7bcc6:	48 89 03             	mov    %rax,(%rbx)
   7bcc9:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   7bccd:	e9 0f fe ff ff       	jmp    7bae1 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7bcd2:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
   7bcd9:	00 
   7bcda:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   7bce1:	00 
   7bce2:	48 c7 84 24 98 00 00 	movq   $0x20,0x98(%rsp)
   7bce9:	00 20 00 00 00 
   7bcee:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   7bcf3:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   7bcfa:	00 
   7bcfb:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
   7bd00:	48 89 ea             	mov    %rbp,%rdx
   7bd03:	e8 58 b8 06 00       	call   e7560 <varlit_core::native_layout::read_native_record_header>
   7bd08:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   7bd0d:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   7bd12:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
   7bd17:	8b 44 24 50          	mov    0x50(%rsp),%eax
   7bd1b:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   7bd20:	44 8b 7c 24 54       	mov    0x54(%rsp),%r15d
   7bd25:	8b 44 24 58          	mov    0x58(%rsp),%eax
   7bd29:	89 44 24 20          	mov    %eax,0x20(%rsp)
   7bd2d:	44 0f b7 5c 24 5c    	movzwl 0x5c(%rsp),%r11d
   7bd33:	0f b7 7c 24 5e       	movzwl 0x5e(%rsp),%edi
   7bd38:	4c 39 e2             	cmp    %r12,%rdx
   7bd3b:	0f 85 e6 00 00 00    	jne    7be27 <varlit_core::file::VarlitFile::mark_record_dead+0x4f7>
   7bd41:	49 8d 54 24 98       	lea    -0x68(%r12),%rdx
   7bd46:	48 83 fd df          	cmp    $0xffffffffffffffdf,%rbp
   7bd4a:	0f 87 65 04 00 00    	ja     7c1b5 <varlit_core::file::VarlitFile::mark_record_dead+0x885>
   7bd50:	48 83 c5 20          	add    $0x20,%rbp
   7bd54:	80 7c 24 28 02       	cmpb   $0x2,0x28(%rsp)
   7bd59:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
   7bd5e:	0f 85 e2 00 00 00    	jne    7be46 <varlit_core::file::VarlitFile::mark_record_dead+0x516>
   7bd64:	0f b6 44 24 78       	movzbl 0x78(%rsp),%eax
   7bd69:	38 44 24 10          	cmp    %al,0x10(%rsp)
   7bd6d:	0f 85 d3 00 00 00    	jne    7be46 <varlit_core::file::VarlitFile::mark_record_dead+0x516>
   7bd73:	f6 44 24 10 01       	testb  $0x1,0x10(%rsp)
   7bd78:	0f 85 c8 00 00 00    	jne    7be46 <varlit_core::file::VarlitFile::mark_record_dead+0x516>
   7bd7e:	f6 44 24 70 01       	testb  $0x1,0x70(%rsp)
   7bd83:	0f 85 bd 00 00 00    	jne    7be46 <varlit_core::file::VarlitFile::mark_record_dead+0x516>
   7bd89:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
   7bd8e:	31 c0                	xor    %eax,%eax
   7bd90:	31 c9                	xor    %ecx,%ecx
   7bd92:	31 f6                	xor    %esi,%esi
   7bd94:	45 31 c9             	xor    %r9d,%r9d
   7bd97:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
   7bd9c:	e9 b3 01 00 00       	jmp    7bf54 <varlit_core::file::VarlitFile::mark_record_dead+0x624>
   7bda1:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
   7bda8:	00 
   7bda9:	eb 0d                	jmp    7bdb8 <varlit_core::file::VarlitFile::mark_record_dead+0x488>
   7bdab:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
   7bdb2:	00 
   7bdb3:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   7bdb8:	41 bd 14 00 00 00    	mov    $0x14,%r13d
   7bdbe:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   7bdc3:	49 89 ef             	mov    %rbp,%r15
   7bdc6:	49 c1 ef 20          	shr    $0x20,%r15
   7bdca:	48 89 ee             	mov    %rbp,%rsi
   7bdcd:	31 ff                	xor    %edi,%edi
   7bdcf:	45 31 db             	xor    %r11d,%r11d
   7bdd2:	4d 89 e8             	mov    %r13,%r8
   7bdd5:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
   7bdda:	45 31 c9             	xor    %r9d,%r9d
   7bddd:	49 c1 e7 20          	shl    $0x20,%r15
   7bde1:	89 f1                	mov    %esi,%ecx
   7bde3:	4c 09 f9             	or     %r15,%rcx
   7bde6:	0f b7 d7             	movzwl %di,%edx
   7bde9:	48 c1 e2 30          	shl    $0x30,%rdx
   7bded:	41 0f b7 f3          	movzwl %r11w,%esi
   7bdf1:	48 c1 e6 20          	shl    $0x20,%rsi
   7bdf5:	48 09 d6             	or     %rdx,%rsi
   7bdf8:	89 ea                	mov    %ebp,%edx
   7bdfa:	48 09 f2             	or     %rsi,%rdx
   7bdfd:	49 c1 e1 20          	shl    $0x20,%r9
   7be01:	44 89 f6             	mov    %r14d,%esi
   7be04:	4c 09 ce             	or     %r9,%rsi
   7be07:	4c 89 23             	mov    %r12,(%rbx)
   7be0a:	4c 89 53 08          	mov    %r10,0x8(%rbx)
   7be0e:	4c 89 43 10          	mov    %r8,0x10(%rbx)
   7be12:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
   7be16:	48 89 53 20          	mov    %rdx,0x20(%rbx)
   7be1a:	48 89 73 28          	mov    %rsi,0x28(%rbx)
   7be1e:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7be22:	e9 ba fc ff ff       	jmp    7bae1 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7be27:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
   7be2c:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   7be31:	4d 89 f1             	mov    %r14,%r9
   7be34:	49 c1 e9 20          	shr    $0x20,%r9
   7be38:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   7be3d:	49 89 d4             	mov    %rdx,%r12
   7be40:	8b 6c 24 20          	mov    0x20(%rsp),%ebp
   7be44:	eb 97                	jmp    7bddd <varlit_core::file::VarlitFile::mark_record_dead+0x4ad>
   7be46:	4c 89 c1             	mov    %r8,%rcx
   7be49:	48 01 e9             	add    %rbp,%rcx
   7be4c:	0f 82 72 03 00 00    	jb     7c1c4 <varlit_core::file::VarlitFile::mark_record_dead+0x894>
   7be52:	4c 89 5c 24 78       	mov    %r11,0x78(%rsp)
   7be57:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
   7be5c:	4c 89 44 24 70       	mov    %r8,0x70(%rsp)
   7be61:	0f 57 c0             	xorps  %xmm0,%xmm0
   7be64:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   7be6b:	00 
   7be6c:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   7be73:	00 
   7be74:	48 89 c8             	mov    %rcx,%rax
   7be77:	48 2b 44 24 08       	sub    0x8(%rsp),%rax
   7be7c:	48 89 c2             	mov    %rax,%rdx
   7be7f:	48 83 ea e0          	sub    $0xffffffffffffffe0,%rdx
   7be83:	73 17                	jae    7be9c <varlit_core::file::VarlitFile::mark_record_dead+0x56c>
   7be85:	4c 39 ea             	cmp    %r13,%rdx
   7be88:	77 12                	ja     7be9c <varlit_core::file::VarlitFile::mark_record_dead+0x56c>
   7be8a:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
   7be8f:	48 8d 34 04          	lea    (%rsp,%rax,1),%rsi
   7be93:	48 81 c6 20 01 00 00 	add    $0x120,%rsi
   7be9a:	eb 47                	jmp    7bee3 <varlit_core::file::VarlitFile::mark_record_dead+0x5b3>
   7be9c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   7bea1:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
   7bea8:	00 
   7bea9:	41 b8 20 00 00 00    	mov    $0x20,%r8d
   7beaf:	49 8d b6 20 0d 00 00 	lea    0xd20(%r14),%rsi
   7beb6:	49 89 cd             	mov    %rcx,%r13
   7beb9:	48 89 ca             	mov    %rcx,%rdx
   7bebc:	48 89 c1             	mov    %rax,%rcx
   7bebf:	ff 15 0b 0e 15 00    	call   *0x150e0b(%rip)        # 1cccd0 <_DYNAMIC+0x858>
   7bec5:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   7beca:	4c 39 e0             	cmp    %r12,%rax
   7becd:	0f 85 ba 01 00 00    	jne    7c08d <varlit_core::file::VarlitFile::mark_record_dead+0x75d>
   7bed3:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
   7bed8:	4c 89 e9             	mov    %r13,%rcx
   7bedb:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   7bee2:	00 
   7bee3:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   7bee8:	ba 20 00 00 00       	mov    $0x20,%edx
   7beed:	48 89 cd             	mov    %rcx,%rbp
   7bef0:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
   7bef5:	4d 89 e8             	mov    %r13,%r8
   7bef8:	e8 13 c1 06 00       	call   e8010 <varlit_core::native_layout::decode_native_record_footer>
   7befd:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   7bf02:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   7bf07:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   7bf0c:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   7bf11:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   7bf16:	44 8b 54 24 60       	mov    0x60(%rsp),%r10d
   7bf1b:	4c 39 e0             	cmp    %r12,%rax
   7bf1e:	0f 85 2c 01 00 00    	jne    7c050 <varlit_core::file::VarlitFile::mark_record_dead+0x720>
   7bf24:	45 85 d2             	test   %r10d,%r10d
   7bf27:	0f 94 c0             	sete   %al
   7bf2a:	44 0f b6 44 24 07    	movzbl 0x7(%rsp),%r8d
   7bf30:	41 08 c0             	or     %al,%r8b
   7bf33:	41 f6 c0 01          	test   $0x1,%r8b
   7bf37:	0f 84 7d 01 00 00    	je     7c0ba <varlit_core::file::VarlitFile::mark_record_dead+0x78a>
   7bf3d:	4d 89 d1             	mov    %r10,%r9
   7bf40:	b8 01 00 00 00       	mov    $0x1,%eax
   7bf45:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
   7bf4a:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
   7bf4f:	4c 8b 5c 24 78       	mov    0x78(%rsp),%r11
   7bf54:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   7bf59:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   7bf60:	00 
   7bf61:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
   7bf66:	48 89 ac 24 c0 00 00 	mov    %rbp,0xc0(%rsp)
   7bf6d:	00 
   7bf6e:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
   7bf75:	00 
   7bf76:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
   7bf7d:	00 
   7bf7e:	48 89 b4 24 d8 00 00 	mov    %rsi,0xd8(%rsp)
   7bf85:	00 
   7bf86:	48 89 bc 24 e0 00 00 	mov    %rdi,0xe0(%rsp)
   7bf8d:	00 
   7bf8e:	4c 89 94 24 e8 00 00 	mov    %r10,0xe8(%rsp)
   7bf95:	00 
   7bf96:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
   7bf9d:	00 
   7bf9e:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   7bfa3:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
   7bfaa:	00 
   7bfab:	4c 89 84 24 00 01 00 	mov    %r8,0x100(%rsp)
   7bfb2:	00 
   7bfb3:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
   7bfb8:	44 89 ac 24 08 01 00 	mov    %r13d,0x108(%rsp)
   7bfbf:	00 
   7bfc0:	44 89 bc 24 0c 01 00 	mov    %r15d,0x10c(%rsp)
   7bfc7:	00 
   7bfc8:	8b 44 24 20          	mov    0x20(%rsp),%eax
   7bfcc:	89 84 24 10 01 00 00 	mov    %eax,0x110(%rsp)
   7bfd3:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
   7bfd8:	44 89 8c 24 14 01 00 	mov    %r9d,0x114(%rsp)
   7bfdf:	00 
   7bfe0:	66 44 89 9c 24 18 01 	mov    %r11w,0x118(%rsp)
   7bfe7:	00 00 
   7bfe9:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   7bfee:	66 89 84 24 1a 01 00 	mov    %ax,0x11a(%rsp)
   7bff5:	00 
   7bff6:	c6 84 24 1c 01 00 00 	movb   $0x0,0x11c(%rsp)
   7bffd:	00 
   7bffe:	4c 8d bc 24 20 01 00 	lea    0x120(%rsp),%r15
   7c005:	00 
   7c006:	ba 98 02 00 00       	mov    $0x298,%edx
   7c00b:	4c 89 ff             	mov    %r15,%rdi
   7c00e:	4c 89 f6             	mov    %r14,%rsi
   7c011:	ff 15 69 07 15 00    	call   *0x150769(%rip)        # 1cc780 <memcpy@GLIBC_2.14>
   7c017:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   7c01c:	48 8d 94 24 b8 00 00 	lea    0xb8(%rsp),%rdx
   7c023:	00 
   7c024:	4c 89 fe             	mov    %r15,%rsi
   7c027:	e8 34 65 00 00       	call   82560 <varlit_core::file::header_codec::validate_record_entry>
   7c02c:	4c 39 64 24 38       	cmp    %r12,0x38(%rsp)
   7c031:	75 32                	jne    7c065 <varlit_core::file::VarlitFile::mark_record_dead+0x735>
   7c033:	41 81 fd ff fe ff ff 	cmp    $0xfffffeff,%r13d
   7c03a:	0f 86 a6 00 00 00    	jbe    7c0e6 <varlit_core::file::VarlitFile::mark_record_dead+0x7b6>
   7c040:	49 83 c4 9f          	add    $0xffffffffffffff9f,%r12
   7c044:	4c 89 23             	mov    %r12,(%rbx)
   7c047:	44 89 6b 08          	mov    %r13d,0x8(%rbx)
   7c04b:	e9 91 fa ff ff       	jmp    7bae1 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7c050:	49 89 c0             	mov    %rax,%r8
   7c053:	44 8b 4c 24 64       	mov    0x64(%rsp),%r9d
   7c058:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   7c05d:	4d 89 c4             	mov    %r8,%r12
   7c060:	4d 89 d6             	mov    %r10,%r14
   7c063:	eb 5c                	jmp    7c0c1 <varlit_core::file::VarlitFile::mark_record_dead+0x791>
   7c065:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   7c06a:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7c06e:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
   7c073:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
   7c078:	0f 10 54 24 58       	movups 0x58(%rsp),%xmm2
   7c07d:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
   7c081:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
   7c085:	0f 11 03             	movups %xmm0,(%rbx)
   7c088:	e9 54 fa ff ff       	jmp    7bae1 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7c08d:	49 89 c0             	mov    %rax,%r8
   7c090:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   7c095:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   7c09a:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   7c09f:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   7c0a4:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
   7c0a9:	4d 89 f1             	mov    %r14,%r9
   7c0ac:	49 c1 e9 20          	shr    $0x20,%r9
   7c0b0:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   7c0b5:	4d 89 c4             	mov    %r8,%r12
   7c0b8:	eb 07                	jmp    7c0c1 <varlit_core::file::VarlitFile::mark_record_dead+0x791>
   7c0ba:	49 83 c4 b3          	add    $0xffffffffffffffb3,%r12
   7c0be:	48 89 e9             	mov    %rbp,%rcx
   7c0c1:	49 89 fb             	mov    %rdi,%r11
   7c0c4:	49 c1 eb 20          	shr    $0x20,%r11
   7c0c8:	49 89 f8             	mov    %rdi,%r8
   7c0cb:	49 c1 e8 30          	shr    $0x30,%r8
   7c0cf:	49 89 f7             	mov    %rsi,%r15
   7c0d2:	49 c1 ef 20          	shr    $0x20,%r15
   7c0d6:	89 fd                	mov    %edi,%ebp
   7c0d8:	4c 89 c7             	mov    %r8,%rdi
   7c0db:	49 89 d0             	mov    %rdx,%r8
   7c0de:	49 89 ca             	mov    %rcx,%r10
   7c0e1:	e9 f7 fc ff ff       	jmp    7bddd <varlit_core::file::VarlitFile::mark_record_dead+0x4ad>
   7c0e6:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
   7c0ec:	74 4a                	je     7c138 <varlit_core::file::VarlitFile::mark_record_dead+0x808>
   7c0ee:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   7c0f3:	48 83 fa e3          	cmp    $0xffffffffffffffe3,%rdx
   7c0f7:	0f 87 dc 00 00 00    	ja     7c1d9 <varlit_core::file::VarlitFile::mark_record_dead+0x8a9>
   7c0fd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   7c102:	89 c1                	mov    %eax,%ecx
   7c104:	83 c9 01             	or     $0x1,%ecx
   7c107:	39 c1                	cmp    %eax,%ecx
   7c109:	74 25                	je     7c130 <varlit_core::file::VarlitFile::mark_record_dead+0x800>
   7c10b:	48 83 c2 1c          	add    $0x1c,%rdx
   7c10f:	49 81 c6 e0 0b 00 00 	add    $0xbe0,%r14
   7c116:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7c11d:	00 
   7c11e:	4c 89 f6             	mov    %r14,%rsi
   7c121:	e8 5a d7 02 00       	call   a9880 <varlit_core::file::record_file::RecordFile::overwrite_record_mutable_flags>
   7c126:	4c 39 a4 24 20 01 00 	cmp    %r12,0x120(%rsp)
   7c12d:	00 
   7c12e:	75 48                	jne    7c178 <varlit_core::file::VarlitFile::mark_record_dead+0x848>
   7c130:	4c 89 23             	mov    %r12,(%rbx)
   7c133:	e9 a9 f9 ff ff       	jmp    7bae1 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7c138:	49 83 c4 a1          	add    $0xffffffffffffffa1,%r12
   7c13c:	4c 89 23             	mov    %r12,(%rbx)
   7c13f:	48 8d 05 39 62 fa ff 	lea    -0x59dc7(%rip),%rax        # 2237f <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a40>
   7c146:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7c14a:	48 c7 43 10 29 00 00 	movq   $0x29,0x10(%rbx)
   7c151:	00 
   7c152:	e9 8a f9 ff ff       	jmp    7bae1 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7c157:	48 8d 05 43 89 fa ff 	lea    -0x576bd(%rip),%rax        # 24aa1 <anon.44dfe6286d6883d57c2709f00721256e.111.llvm.7670212196679453716>
   7c15e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   7c163:	41 bd 14 00 00 00    	mov    $0x14,%r13d
   7c169:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   7c16e:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
   7c173:	e9 4b fc ff ff       	jmp    7bdc3 <varlit_core::file::VarlitFile::mark_record_dead+0x493>
   7c178:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   7c17f:	00 
   7c180:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7c184:	0f 10 84 24 20 01 00 	movups 0x120(%rsp),%xmm0
   7c18b:	00 
   7c18c:	0f 10 8c 24 30 01 00 	movups 0x130(%rsp),%xmm1
   7c193:	00 
   7c194:	0f 10 94 24 40 01 00 	movups 0x140(%rsp),%xmm2
   7c19b:	00 
   7c19c:	e9 dc fe ff ff       	jmp    7c07d <varlit_core::file::VarlitFile::mark_record_dead+0x74d>
   7c1a1:	41 bd 0e 00 00 00    	mov    $0xe,%r13d
   7c1a7:	48 8d 05 1c 88 fa ff 	lea    -0x577e4(%rip),%rax        # 249ca <anon.44dfe6286d6883d57c2709f00721256e.28.llvm.7670212196679453716>
   7c1ae:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   7c1b3:	eb b9                	jmp    7c16e <varlit_core::file::VarlitFile::mark_record_dead+0x83e>
   7c1b5:	4c 8d 15 48 63 fa ff 	lea    -0x59cb8(%rip),%r10        # 22504 <anon.48385641d07dc56499de4af04e4ddc4c.132.llvm.15324202487898183613+0x22>
   7c1bc:	41 b8 15 00 00 00    	mov    $0x15,%r8d
   7c1c2:	eb 0d                	jmp    7c1d1 <varlit_core::file::VarlitFile::mark_record_dead+0x8a1>
   7c1c4:	4c 8d 15 a0 61 fa ff 	lea    -0x59e60(%rip),%r10        # 2236b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a2c>
   7c1cb:	41 b8 14 00 00 00    	mov    $0x14,%r8d
   7c1d1:	49 89 d4             	mov    %rdx,%r12
   7c1d4:	e9 04 fc ff ff       	jmp    7bddd <varlit_core::file::VarlitFile::mark_record_dead+0x4ad>
   7c1d9:	49 83 c4 98          	add    $0xffffffffffffff98,%r12
   7c1dd:	4c 89 23             	mov    %r12,(%rbx)
   7c1e0:	48 8d 05 84 61 fa ff 	lea    -0x59e7c(%rip),%rax        # 2236b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a2c>
   7c1e7:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7c1eb:	48 c7 43 10 14 00 00 	movq   $0x14,0x10(%rbx)
   7c1f2:	00 
   7c1f3:	e9 e9 f8 ff ff       	jmp    7bae1 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
