
/workspace/scratch/mark-perf-fix/lazy-errors-bin/record_mutation_load:     file format elf64-x86-64


Disassembly of section .text:

000000000007b970 <varlit_core::file::VarlitFile::mark_record_dead>:
   7b970:	55                   	push   %rbp
   7b971:	41 57                	push   %r15
   7b973:	41 56                	push   %r14
   7b975:	41 55                	push   %r13
   7b977:	41 54                	push   %r12
   7b979:	53                   	push   %rbx
   7b97a:	48 81 ec b8 03 00 00 	sub    $0x3b8,%rsp
   7b981:	48 89 fb             	mov    %rdi,%rbx
   7b984:	49 bc 7d 00 00 00 00 	movabs $0x800000000000007d,%r12
   7b98b:	00 00 80 
   7b98e:	49 8d 4c 24 be       	lea    -0x42(%r12),%rcx
   7b993:	48 8d 05 6a e9 f9 ff 	lea    -0x61696(%rip),%rax        # 1a304 <anon.63872d7b999ac94d8e2eb8c408e6a338.76.llvm.7982912888733972306+0x8>
   7b99a:	80 be 90 0d 00 00 00 	cmpb   $0x0,0xd90(%rsi)
   7b9a1:	0f 85 91 01 00 00    	jne    7bb38 <varlit_core::file::VarlitFile::mark_record_dead+0x1c8>
   7b9a7:	49 89 f6             	mov    %rsi,%r14
   7b9aa:	80 be 91 0d 00 00 00 	cmpb   $0x0,0xd91(%rsi)
   7b9b1:	0f 85 81 01 00 00    	jne    7bb38 <varlit_core::file::VarlitFile::mark_record_dead+0x1c8>
   7b9b7:	41 80 be 92 0d 00 00 	cmpb   $0x0,0xd92(%r14)
   7b9be:	00 
   7b9bf:	0f 84 55 01 00 00    	je     7bb1a <varlit_core::file::VarlitFile::mark_record_dead+0x1aa>
   7b9c5:	41 80 be 92 02 00 00 	cmpb   $0x0,0x292(%r14)
   7b9cc:	00 
   7b9cd:	0f 84 91 01 00 00    	je     7bb64 <varlit_core::file::VarlitFile::mark_record_dead+0x1f4>
   7b9d3:	49 8d ae 98 02 00 00 	lea    0x298(%r14),%rbp
   7b9da:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7b9e1:	00 
   7b9e2:	48 89 ee             	mov    %rbp,%rsi
   7b9e5:	49 89 d7             	mov    %rdx,%r15
   7b9e8:	e8 13 a7 06 00       	call   e6100 <varlit_core::file::resident_index::ResidentIndex::has_verified_boundary>
   7b9ed:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
   7b9f4:	00 
   7b9f5:	0f b6 84 24 28 01 00 	movzbl 0x128(%rsp),%eax
   7b9fc:	00 
   7b9fd:	4c 39 e1             	cmp    %r12,%rcx
   7ba00:	0f 85 7a 01 00 00    	jne    7bb80 <varlit_core::file::VarlitFile::mark_record_dead+0x210>
   7ba06:	a8 01                	test   $0x1,%al
   7ba08:	0f 84 9e 01 00 00    	je     7bbac <varlit_core::file::VarlitFile::mark_record_dead+0x23c>
   7ba0e:	41 0f b6 86 8d 02 00 	movzbl 0x28d(%r14),%eax
   7ba15:	00 
   7ba16:	88 44 24 58          	mov    %al,0x58(%rsp)
   7ba1a:	41 0f b6 86 8e 02 00 	movzbl 0x28e(%r14),%eax
   7ba21:	00 
   7ba22:	88 84 24 80 00 00 00 	mov    %al,0x80(%rsp)
   7ba29:	41 0f b6 86 8f 02 00 	movzbl 0x28f(%r14),%eax
   7ba30:	00 
   7ba31:	88 44 24 78          	mov    %al,0x78(%rsp)
   7ba35:	41 0f b6 86 92 02 00 	movzbl 0x292(%r14),%eax
   7ba3c:	00 
   7ba3d:	88 44 24 07          	mov    %al,0x7(%rsp)
   7ba41:	41 0f b6 86 97 02 00 	movzbl 0x297(%r14),%eax
   7ba48:	00 
   7ba49:	88 44 24 10          	mov    %al,0x10(%rsp)
   7ba4d:	49 8b ae 28 0d 00 00 	mov    0xd28(%r14),%rbp
   7ba54:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   7ba5b:	25 00 00 00 00 
   7ba60:	48 8b 88 98 ff ff ff 	mov    -0x68(%rax),%rcx
   7ba67:	48 ff c1             	inc    %rcx
   7ba6a:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
   7ba71:	48 0f 45 d1          	cmovne %rcx,%rdx
   7ba75:	48 89 90 98 ff ff ff 	mov    %rdx,-0x68(%rax)
   7ba7c:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7ba83:	00 
   7ba84:	45 31 ed             	xor    %r13d,%r13d
   7ba87:	ba 00 02 00 00       	mov    $0x200,%edx
   7ba8c:	31 f6                	xor    %esi,%esi
   7ba8e:	ff 15 cc 11 15 00    	call   *0x1511cc(%rip)        # 1ccc60 <memset@GLIBC_2.2.5>
   7ba94:	48 89 e8             	mov    %rbp,%rax
   7ba97:	4c 29 f8             	sub    %r15,%rax
   7ba9a:	4c 0f 43 e8          	cmovae %rax,%r13
   7ba9e:	49 83 fd 21          	cmp    $0x21,%r13
   7baa2:	4c 89 f8             	mov    %r15,%rax
   7baa5:	41 bf 20 00 00 00    	mov    $0x20,%r15d
   7baab:	4d 0f 43 fd          	cmovae %r13,%r15
   7baaf:	49 81 ff 00 02 00 00 	cmp    $0x200,%r15
   7bab6:	b9 00 02 00 00       	mov    $0x200,%ecx
   7babb:	4c 0f 43 f9          	cmovae %rcx,%r15
   7babf:	49 8d 54 24 98       	lea    -0x68(%r12),%rdx
   7bac4:	4d 89 fd             	mov    %r15,%r13
   7bac7:	48 8d 0d cf 86 fa ff 	lea    -0x57931(%rip),%rcx        # 2419d <anon.0624e7d5e48278245b12a454ff79655c.105.llvm.2515505084513145378>
   7bace:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   7bad3:	48 c7 44 24 28 0e 00 	movq   $0xe,0x28(%rsp)
   7bada:	00 00 
   7badc:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   7bae1:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   7bae6:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   7baeb:	49 01 c5             	add    %rax,%r13
   7baee:	48 89 6c 24 60       	mov    %rbp,0x60(%rsp)
   7baf3:	0f 82 df 06 00 00    	jb     7c1d8 <varlit_core::file::VarlitFile::mark_record_dead+0x868>
   7baf9:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7bafe:	e8 fd c9 02 00       	call   a8500 <core::ptr::drop_in_place<varlit_core::error::Error>>
   7bb03:	49 39 ed             	cmp    %rbp,%r13
   7bb06:	0f 86 e1 00 00 00    	jbe    7bbed <varlit_core::file::VarlitFile::mark_record_dead+0x27d>
   7bb0c:	49 83 c4 9a          	add    $0xffffffffffffff9a,%r12
   7bb10:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
   7bb15:	e9 00 03 00 00       	jmp    7be1a <varlit_core::file::VarlitFile::mark_record_dead+0x4aa>
   7bb1a:	48 8d 35 5e 67 fa ff 	lea    -0x598a2(%rip),%rsi        # 2227f <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1920>
   7bb21:	ba 19 00 00 00       	mov    $0x19,%edx
   7bb26:	bf 01 00 00 00       	mov    $0x1,%edi
   7bb2b:	ff 15 97 15 15 00    	call   *0x151597(%rip)        # 1cd0c8 <_DYNAMIC+0x7b0>
   7bb31:	49 83 c4 89          	add    $0xffffffffffffff89,%r12
   7bb35:	4c 89 e1             	mov    %r12,%rcx
   7bb38:	48 89 0b             	mov    %rcx,(%rbx)
   7bb3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7bb3f:	48 c7 43 10 04 00 00 	movq   $0x4,0x10(%rbx)
   7bb46:	00 
   7bb47:	48 c7 43 18 04 00 00 	movq   $0x4,0x18(%rbx)
   7bb4e:	00 
   7bb4f:	48 89 d8             	mov    %rbx,%rax
   7bb52:	48 81 c4 b8 03 00 00 	add    $0x3b8,%rsp
   7bb59:	5b                   	pop    %rbx
   7bb5a:	41 5c                	pop    %r12
   7bb5c:	41 5d                	pop    %r13
   7bb5e:	41 5e                	pop    %r14
   7bb60:	41 5f                	pop    %r15
   7bb62:	5d                   	pop    %rbp
   7bb63:	c3                   	ret
   7bb64:	49 83 c4 a1          	add    $0xffffffffffffffa1,%r12
   7bb68:	4c 89 23             	mov    %r12,(%rbx)
   7bb6b:	48 8d 05 e9 67 fa ff 	lea    -0x59817(%rip),%rax        # 2235b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x19fc>
   7bb72:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7bb76:	48 c7 43 10 30 00 00 	movq   $0x30,0x10(%rbx)
   7bb7d:	00 
   7bb7e:	eb cf                	jmp    7bb4f <varlit_core::file::VarlitFile::mark_record_dead+0x1df>
   7bb80:	0f 10 84 24 29 01 00 	movups 0x129(%rsp),%xmm0
   7bb87:	00 
   7bb88:	0f 10 8c 24 39 01 00 	movups 0x139(%rsp),%xmm1
   7bb8f:	00 
   7bb90:	0f 10 94 24 48 01 00 	movups 0x148(%rsp),%xmm2
   7bb97:	00 
   7bb98:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
   7bb9c:	0f 11 4b 19          	movups %xmm1,0x19(%rbx)
   7bba0:	0f 11 43 09          	movups %xmm0,0x9(%rbx)
   7bba4:	48 89 0b             	mov    %rcx,(%rbx)
   7bba7:	88 43 08             	mov    %al,0x8(%rbx)
   7bbaa:	eb a3                	jmp    7bb4f <varlit_core::file::VarlitFile::mark_record_dead+0x1df>
   7bbac:	41 83 be 28 09 00 00 	cmpl   $0x2,0x928(%r14)
   7bbb3:	02 
   7bbb4:	0f 85 ca 00 00 00    	jne    7bc84 <varlit_core::file::VarlitFile::mark_record_dead+0x314>
   7bbba:	4d 8b ae a8 0b 00 00 	mov    0xba8(%r14),%r13
   7bbc1:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7bbc8:	00 
   7bbc9:	ba 98 02 00 00       	mov    $0x298,%edx
   7bbce:	4c 89 f6             	mov    %r14,%rsi
   7bbd1:	ff 15 49 10 15 00    	call   *0x151049(%rip)        # 1ccc20 <memcpy@GLIBC_2.14>
   7bbd7:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7bbde:	00 
   7bbdf:	4c 89 ee             	mov    %r13,%rsi
   7bbe2:	ff 15 c0 11 15 00    	call   *0x1511c0(%rip)        # 1ccda8 <_DYNAMIC+0x490>
   7bbe8:	e9 9e 00 00 00       	jmp    7bc8b <varlit_core::file::VarlitFile::mark_record_dead+0x31b>
   7bbed:	49 8d 86 20 0d 00 00 	lea    0xd20(%r14),%rax
   7bbf4:	48 8b 00             	mov    (%rax),%rax
   7bbf7:	48 83 c0 08          	add    $0x8,%rax
   7bbfb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   7bc00:	31 ed                	xor    %ebp,%ebp
   7bc02:	49 8d 44 24 89       	lea    -0x77(%r12),%rax
   7bc07:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   7bc0c:	49 8d 44 24 8e       	lea    -0x72(%r12),%rax
   7bc11:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   7bc18:	00 
   7bc19:	eb 0e                	jmp    7bc29 <varlit_core::file::VarlitFile::mark_record_dead+0x2b9>
   7bc1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   7bc20:	4c 39 fd             	cmp    %r15,%rbp
   7bc23:	0f 83 09 01 00 00    	jae    7bd32 <varlit_core::file::VarlitFile::mark_record_dead+0x3c2>
   7bc29:	48 89 e9             	mov    %rbp,%rcx
   7bc2c:	48 03 4c 24 08       	add    0x8(%rsp),%rcx
   7bc31:	0f 82 61 05 00 00    	jb     7c198 <varlit_core::file::VarlitFile::mark_record_dead+0x828>
   7bc37:	4c 89 fa             	mov    %r15,%rdx
   7bc3a:	48 29 ea             	sub    %rbp,%rdx
   7bc3d:	48 8d 34 2c          	lea    (%rsp,%rbp,1),%rsi
   7bc41:	48 81 c6 20 01 00 00 	add    $0x120,%rsi
   7bc48:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   7bc4d:	ff 15 2d 15 15 00    	call   *0x15152d(%rip)        # 1cd180 <_DYNAMIC+0x868>
   7bc53:	49 89 d5             	mov    %rdx,%r13
   7bc56:	48 83 f8 01          	cmp    $0x1,%rax
   7bc5a:	75 1a                	jne    7bc76 <varlit_core::file::VarlitFile::mark_record_dead+0x306>
   7bc5c:	4c 89 ef             	mov    %r13,%rdi
   7bc5f:	e8 bc 9e 03 00       	call   b5b20 <<std::io::error::Error>::kind>
   7bc64:	3c 23                	cmp    $0x23,%al
   7bc66:	0f 85 a3 01 00 00    	jne    7be0f <varlit_core::file::VarlitFile::mark_record_dead+0x49f>
   7bc6c:	4c 89 ef             	mov    %r13,%rdi
   7bc6f:	e8 fc e2 03 00       	call   b9f70 <core::ptr::drop_in_place<std::io::error::Error>>
   7bc74:	eb aa                	jmp    7bc20 <varlit_core::file::VarlitFile::mark_record_dead+0x2b0>
   7bc76:	4d 85 ed             	test   %r13,%r13
   7bc79:	0f 84 86 01 00 00    	je     7be05 <varlit_core::file::VarlitFile::mark_record_dead+0x495>
   7bc7f:	4c 01 ed             	add    %r13,%rbp
   7bc82:	eb 9c                	jmp    7bc20 <varlit_core::file::VarlitFile::mark_record_dead+0x2b0>
   7bc84:	49 8b 86 f8 0a 00 00 	mov    0xaf8(%r14),%rax
   7bc8b:	4c 89 f9             	mov    %r15,%rcx
   7bc8e:	49 39 c7             	cmp    %rax,%r15
   7bc91:	72 2c                	jb     7bcbf <varlit_core::file::VarlitFile::mark_record_dead+0x34f>
   7bc93:	49 3b 8e a8 08 00 00 	cmp    0x8a8(%r14),%rcx
   7bc9a:	73 23                	jae    7bcbf <varlit_core::file::VarlitFile::mark_record_dead+0x34f>
   7bc9c:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7bca3:	00 
   7bca4:	48 89 ee             	mov    %rbp,%rsi
   7bca7:	48 89 c2             	mov    %rax,%rdx
   7bcaa:	e8 81 9b 06 00       	call   e5830 <varlit_core::file::resident_index::ResidentIndex::extend_boundary_proof>
   7bcaf:	4c 39 a4 24 20 01 00 	cmp    %r12,0x120(%rsp)
   7bcb6:	00 
   7bcb7:	0f 84 51 fd ff ff    	je     7ba0e <varlit_core::file::VarlitFile::mark_record_dead+0x9e>
   7bcbd:	eb 27                	jmp    7bce6 <varlit_core::file::VarlitFile::mark_record_dead+0x376>
   7bcbf:	49 83 c4 94          	add    $0xffffffffffffff94,%r12
   7bcc3:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
   7bcca:	00 
   7bccb:	48 8d 05 8e 14 fb ff 	lea    -0x4eb72(%rip),%rax        # 2d160 <anon.ffd425f973af7d01e09094328418b03c.34.llvm.15086305853390219681>
   7bcd2:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
   7bcd9:	00 
   7bcda:	48 c7 84 24 30 01 00 	movq   $0x26,0x130(%rsp)
   7bce1:	00 26 00 00 00 
   7bce6:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   7bced:	00 
   7bcee:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7bcf2:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
   7bcf9:	00 
   7bcfa:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
   7bd01:	00 
   7bd02:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
   7bd09:	00 
   7bd0a:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
   7bd11:	00 
   7bd12:	0f 10 84 24 40 01 00 	movups 0x140(%rsp),%xmm0
   7bd19:	00 
   7bd1a:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   7bd1e:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   7bd22:	48 89 73 18          	mov    %rsi,0x18(%rbx)
   7bd26:	48 89 03             	mov    %rax,(%rbx)
   7bd29:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   7bd2d:	e9 1d fe ff ff       	jmp    7bb4f <varlit_core::file::VarlitFile::mark_record_dead+0x1df>
   7bd32:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
   7bd39:	00 
   7bd3a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   7bd41:	00 
   7bd42:	48 c7 84 24 98 00 00 	movq   $0x20,0x98(%rsp)
   7bd49:	00 20 00 00 00 
   7bd4e:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7bd53:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   7bd5a:	00 
   7bd5b:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
   7bd60:	4c 89 ea             	mov    %r13,%rdx
   7bd63:	e8 98 c1 07 00       	call   f7f00 <varlit_core::native_layout::read_native_record_header>
   7bd68:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   7bd6d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   7bd72:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   7bd77:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
   7bd7c:	8b 44 24 30          	mov    0x30(%rsp),%eax
   7bd80:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   7bd85:	8b 6c 24 34          	mov    0x34(%rsp),%ebp
   7bd89:	44 8b 44 24 38       	mov    0x38(%rsp),%r8d
   7bd8e:	44 0f b7 54 24 3c    	movzwl 0x3c(%rsp),%r10d
   7bd94:	44 0f b7 5c 24 3e    	movzwl 0x3e(%rsp),%r11d
   7bd9a:	4c 39 e1             	cmp    %r12,%rcx
   7bd9d:	0f 85 da 00 00 00    	jne    7be7d <varlit_core::file::VarlitFile::mark_record_dead+0x50d>
   7bda3:	49 8d 54 24 98       	lea    -0x68(%r12),%rdx
   7bda8:	49 83 fd df          	cmp    $0xffffffffffffffdf,%r13
   7bdac:	0f 87 31 04 00 00    	ja     7c1e3 <varlit_core::file::VarlitFile::mark_record_dead+0x873>
   7bdb2:	49 8d 4d 20          	lea    0x20(%r13),%rcx
   7bdb6:	80 7c 24 10 02       	cmpb   $0x2,0x10(%rsp)
   7bdbb:	44 89 44 24 50       	mov    %r8d,0x50(%rsp)
   7bdc0:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   7bdc5:	0f 85 d5 00 00 00    	jne    7bea0 <varlit_core::file::VarlitFile::mark_record_dead+0x530>
   7bdcb:	0f b6 84 24 80 00 00 	movzbl 0x80(%rsp),%eax
   7bdd2:	00 
   7bdd3:	38 44 24 58          	cmp    %al,0x58(%rsp)
   7bdd7:	0f 85 c3 00 00 00    	jne    7bea0 <varlit_core::file::VarlitFile::mark_record_dead+0x530>
   7bddd:	f6 44 24 58 01       	testb  $0x1,0x58(%rsp)
   7bde2:	0f 85 b8 00 00 00    	jne    7bea0 <varlit_core::file::VarlitFile::mark_record_dead+0x530>
   7bde8:	f6 44 24 78 01       	testb  $0x1,0x78(%rsp)
   7bded:	0f 85 ad 00 00 00    	jne    7bea0 <varlit_core::file::VarlitFile::mark_record_dead+0x530>
   7bdf3:	31 c0                	xor    %eax,%eax
   7bdf5:	31 d2                	xor    %edx,%edx
   7bdf7:	31 ff                	xor    %edi,%edi
   7bdf9:	31 c9                	xor    %ecx,%ecx
   7bdfb:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   7be00:	e9 9e 01 00 00       	jmp    7bfa3 <varlit_core::file::VarlitFile::mark_record_dead+0x633>
   7be05:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
   7be0c:	00 
   7be0d:	eb 05                	jmp    7be14 <varlit_core::file::VarlitFile::mark_record_dead+0x4a4>
   7be0f:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   7be14:	41 bf 14 00 00 00    	mov    $0x14,%r15d
   7be1a:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   7be1f:	48 89 fd             	mov    %rdi,%rbp
   7be22:	48 c1 ed 20          	shr    $0x20,%rbp
   7be26:	45 31 db             	xor    %r11d,%r11d
   7be29:	45 31 d2             	xor    %r10d,%r10d
   7be2c:	31 c0                	xor    %eax,%eax
   7be2e:	4d 89 f9             	mov    %r15,%r9
   7be31:	48 c1 e5 20          	shl    $0x20,%rbp
   7be35:	89 fa                	mov    %edi,%edx
   7be37:	48 09 ea             	or     %rbp,%rdx
   7be3a:	41 0f b7 f3          	movzwl %r11w,%esi
   7be3e:	48 c1 e6 30          	shl    $0x30,%rsi
   7be42:	41 0f b7 fa          	movzwl %r10w,%edi
   7be46:	48 c1 e7 20          	shl    $0x20,%rdi
   7be4a:	48 09 f7             	or     %rsi,%rdi
   7be4d:	44 89 c6             	mov    %r8d,%esi
   7be50:	48 09 fe             	or     %rdi,%rsi
   7be53:	48 c1 e0 20          	shl    $0x20,%rax
   7be57:	44 89 f7             	mov    %r14d,%edi
   7be5a:	48 09 c7             	or     %rax,%rdi
   7be5d:	4c 89 23             	mov    %r12,(%rbx)
   7be60:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
   7be64:	4c 89 4b 10          	mov    %r9,0x10(%rbx)
   7be68:	48 89 53 18          	mov    %rdx,0x18(%rbx)
   7be6c:	48 89 73 20          	mov    %rsi,0x20(%rbx)
   7be70:	48 89 7b 28          	mov    %rdi,0x28(%rbx)
   7be74:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
   7be78:	e9 d2 fc ff ff       	jmp    7bb4f <varlit_core::file::VarlitFile::mark_record_dead+0x1df>
   7be7d:	48 89 ca             	mov    %rcx,%rdx
   7be80:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
   7be85:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   7be8a:	4c 89 f0             	mov    %r14,%rax
   7be8d:	48 c1 e8 20          	shr    $0x20,%rax
   7be91:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   7be96:	4c 8b 6c 24 68       	mov    0x68(%rsp),%r13
   7be9b:	49 89 d4             	mov    %rdx,%r12
   7be9e:	eb 91                	jmp    7be31 <varlit_core::file::VarlitFile::mark_record_dead+0x4c1>
   7bea0:	4c 89 c8             	mov    %r9,%rax
   7bea3:	48 01 c8             	add    %rcx,%rax
   7bea6:	0f 82 46 03 00 00    	jb     7c1f2 <varlit_core::file::VarlitFile::mark_record_dead+0x882>
   7beac:	4c 89 5c 24 58       	mov    %r11,0x58(%rsp)
   7beb1:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
   7beb6:	4c 89 8c 24 80 00 00 	mov    %r9,0x80(%rsp)
   7bebd:	00 
   7bebe:	0f 57 c0             	xorps  %xmm0,%xmm0
   7bec1:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   7bec8:	00 
   7bec9:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   7bed0:	00 
   7bed1:	49 89 c5             	mov    %rax,%r13
   7bed4:	48 2b 44 24 08       	sub    0x8(%rsp),%rax
   7bed9:	48 89 c1             	mov    %rax,%rcx
   7bedc:	48 83 e9 e0          	sub    $0xffffffffffffffe0,%rcx
   7bee0:	73 12                	jae    7bef4 <varlit_core::file::VarlitFile::mark_record_dead+0x584>
   7bee2:	4c 39 f9             	cmp    %r15,%rcx
   7bee5:	77 0d                	ja     7bef4 <varlit_core::file::VarlitFile::mark_record_dead+0x584>
   7bee7:	4c 8d 3c 04          	lea    (%rsp,%rax,1),%r15
   7beeb:	49 81 c7 20 01 00 00 	add    $0x120,%r15
   7bef2:	eb 34                	jmp    7bf28 <varlit_core::file::VarlitFile::mark_record_dead+0x5b8>
   7bef4:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7bef9:	4c 8d bc 24 90 00 00 	lea    0x90(%rsp),%r15
   7bf00:	00 
   7bf01:	41 b8 20 00 00 00    	mov    $0x20,%r8d
   7bf07:	49 8d b6 20 0d 00 00 	lea    0xd20(%r14),%rsi
   7bf0e:	4c 89 ea             	mov    %r13,%rdx
   7bf11:	4c 89 f9             	mov    %r15,%rcx
   7bf14:	ff 15 56 12 15 00    	call   *0x151256(%rip)        # 1cd170 <_DYNAMIC+0x858>
   7bf1a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   7bf1f:	4c 39 e0             	cmp    %r12,%rax
   7bf22:	0f 85 b0 01 00 00    	jne    7c0d8 <varlit_core::file::VarlitFile::mark_record_dead+0x768>
   7bf28:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7bf2d:	ba 20 00 00 00       	mov    $0x20,%edx
   7bf32:	4c 89 fe             	mov    %r15,%rsi
   7bf35:	4c 89 e9             	mov    %r13,%rcx
   7bf38:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   7bf3d:	4d 89 f8             	mov    %r15,%r8
   7bf40:	e8 6b ca 07 00       	call   f89b0 <varlit_core::native_layout::decode_native_record_footer>
   7bf45:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   7bf4a:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   7bf4f:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   7bf54:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   7bf59:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
   7bf5e:	44 8b 54 24 40       	mov    0x40(%rsp),%r10d
   7bf63:	4c 39 e0             	cmp    %r12,%rax
   7bf66:	0f 85 30 01 00 00    	jne    7c09c <varlit_core::file::VarlitFile::mark_record_dead+0x72c>
   7bf6c:	4c 89 54 24 78       	mov    %r10,0x78(%rsp)
   7bf71:	45 85 d2             	test   %r10d,%r10d
   7bf74:	0f 94 c0             	sete   %al
   7bf77:	0f b6 4c 24 07       	movzbl 0x7(%rsp),%ecx
   7bf7c:	08 c1                	or     %al,%cl
   7bf7e:	f6 c1 01             	test   $0x1,%cl
   7bf81:	0f 84 7e 01 00 00    	je     7c105 <varlit_core::file::VarlitFile::mark_record_dead+0x795>
   7bf87:	b8 01 00 00 00       	mov    $0x1,%eax
   7bf8c:	4c 8b 8c 24 80 00 00 	mov    0x80(%rsp),%r9
   7bf93:	00 
   7bf94:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
   7bf99:	4c 8b 5c 24 58       	mov    0x58(%rsp),%r11
   7bf9e:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   7bfa3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   7bfa8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   7bfaf:	00 
   7bfb0:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   7bfb5:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
   7bfbc:	00 
   7bfbd:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
   7bfc4:	00 
   7bfc5:	48 89 b4 24 d0 00 00 	mov    %rsi,0xd0(%rsp)
   7bfcc:	00 
   7bfcd:	48 89 bc 24 d8 00 00 	mov    %rdi,0xd8(%rsp)
   7bfd4:	00 
   7bfd5:	4c 89 84 24 e0 00 00 	mov    %r8,0xe0(%rsp)
   7bfdc:	00 
   7bfdd:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   7bfe2:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
   7bfe9:	00 
   7bfea:	4c 89 bc 24 f0 00 00 	mov    %r15,0xf0(%rsp)
   7bff1:	00 
   7bff2:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   7bff7:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
   7bffe:	00 
   7bfff:	4c 89 8c 24 00 01 00 	mov    %r9,0x100(%rsp)
   7c006:	00 
   7c007:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
   7c00c:	44 89 bc 24 08 01 00 	mov    %r15d,0x108(%rsp)
   7c013:	00 
   7c014:	89 ac 24 0c 01 00 00 	mov    %ebp,0x10c(%rsp)
   7c01b:	8b 44 24 50          	mov    0x50(%rsp),%eax
   7c01f:	89 84 24 10 01 00 00 	mov    %eax,0x110(%rsp)
   7c026:	48 89 cd             	mov    %rcx,%rbp
   7c029:	89 8c 24 14 01 00 00 	mov    %ecx,0x114(%rsp)
   7c030:	66 44 89 94 24 18 01 	mov    %r10w,0x118(%rsp)
   7c037:	00 00 
   7c039:	66 44 89 9c 24 1a 01 	mov    %r11w,0x11a(%rsp)
   7c040:	00 00 
   7c042:	c6 84 24 1c 01 00 00 	movb   $0x0,0x11c(%rsp)
   7c049:	00 
   7c04a:	4c 8d ac 24 20 01 00 	lea    0x120(%rsp),%r13
   7c051:	00 
   7c052:	ba 98 02 00 00       	mov    $0x298,%edx
   7c057:	4c 89 ef             	mov    %r13,%rdi
   7c05a:	4c 89 f6             	mov    %r14,%rsi
   7c05d:	ff 15 bd 0b 15 00    	call   *0x150bbd(%rip)        # 1ccc20 <memcpy@GLIBC_2.14>
   7c063:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   7c068:	48 8d 94 24 b8 00 00 	lea    0xb8(%rsp),%rdx
   7c06f:	00 
   7c070:	4c 89 ee             	mov    %r13,%rsi
   7c073:	e8 d8 66 00 00       	call   82750 <varlit_core::file::header_codec::validate_record_entry>
   7c078:	4c 39 64 24 18       	cmp    %r12,0x18(%rsp)
   7c07d:	75 31                	jne    7c0b0 <varlit_core::file::VarlitFile::mark_record_dead+0x740>
   7c07f:	41 81 ff ff fe ff ff 	cmp    $0xfffffeff,%r15d
   7c086:	0f 86 a0 00 00 00    	jbe    7c12c <varlit_core::file::VarlitFile::mark_record_dead+0x7bc>
   7c08c:	49 83 c4 9f          	add    $0xffffffffffffff9f,%r12
   7c090:	4c 89 23             	mov    %r12,(%rbx)
   7c093:	44 89 7b 08          	mov    %r15d,0x8(%rbx)
   7c097:	e9 b3 fa ff ff       	jmp    7bb4f <varlit_core::file::VarlitFile::mark_record_dead+0x1df>
   7c09c:	49 89 c1             	mov    %rax,%r9
   7c09f:	8b 44 24 44          	mov    0x44(%rsp),%eax
   7c0a3:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   7c0a8:	4d 89 cc             	mov    %r9,%r12
   7c0ab:	4d 89 d6             	mov    %r10,%r14
   7c0ae:	eb 5c                	jmp    7c10c <varlit_core::file::VarlitFile::mark_record_dead+0x79c>
   7c0b0:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   7c0b5:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7c0b9:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
   7c0be:	0f 10 4c 24 28       	movups 0x28(%rsp),%xmm1
   7c0c3:	0f 10 54 24 38       	movups 0x38(%rsp),%xmm2
   7c0c8:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
   7c0cc:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
   7c0d0:	0f 11 03             	movups %xmm0,(%rbx)
   7c0d3:	e9 77 fa ff ff       	jmp    7bb4f <varlit_core::file::VarlitFile::mark_record_dead+0x1df>
   7c0d8:	49 89 c1             	mov    %rax,%r9
   7c0db:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   7c0e0:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   7c0e5:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   7c0ea:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
   7c0ef:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
   7c0f4:	4c 89 f0             	mov    %r14,%rax
   7c0f7:	48 c1 e8 20          	shr    $0x20,%rax
   7c0fb:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   7c100:	4d 89 cc             	mov    %r9,%r12
   7c103:	eb 07                	jmp    7c10c <varlit_core::file::VarlitFile::mark_record_dead+0x79c>
   7c105:	49 83 c4 b3          	add    $0xffffffffffffffb3,%r12
   7c109:	4c 89 ea             	mov    %r13,%rdx
   7c10c:	4d 89 c2             	mov    %r8,%r10
   7c10f:	49 c1 ea 20          	shr    $0x20,%r10
   7c113:	4d 89 c3             	mov    %r8,%r11
   7c116:	49 c1 eb 30          	shr    $0x30,%r11
   7c11a:	48 89 fd             	mov    %rdi,%rbp
   7c11d:	48 c1 ed 20          	shr    $0x20,%rbp
   7c121:	49 89 f1             	mov    %rsi,%r9
   7c124:	49 89 d5             	mov    %rdx,%r13
   7c127:	e9 05 fd ff ff       	jmp    7be31 <varlit_core::file::VarlitFile::mark_record_dead+0x4c1>
   7c12c:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
   7c132:	74 45                	je     7c179 <varlit_core::file::VarlitFile::mark_record_dead+0x809>
   7c134:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   7c139:	48 83 fa e3          	cmp    $0xffffffffffffffe3,%rdx
   7c13d:	0f 87 c4 00 00 00    	ja     7c207 <varlit_core::file::VarlitFile::mark_record_dead+0x897>
   7c143:	89 e9                	mov    %ebp,%ecx
   7c145:	83 c9 01             	or     $0x1,%ecx
   7c148:	39 e9                	cmp    %ebp,%ecx
   7c14a:	74 25                	je     7c171 <varlit_core::file::VarlitFile::mark_record_dead+0x801>
   7c14c:	48 83 c2 1c          	add    $0x1c,%rdx
   7c150:	49 81 c6 e0 0b 00 00 	add    $0xbe0,%r14
   7c157:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7c15e:	00 
   7c15f:	4c 89 f6             	mov    %r14,%rsi
   7c162:	e8 e9 e0 02 00       	call   aa250 <varlit_core::file::record_file::RecordFile::overwrite_record_mutable_flags>
   7c167:	4c 39 a4 24 20 01 00 	cmp    %r12,0x120(%rsp)
   7c16e:	00 
   7c16f:	75 3e                	jne    7c1af <varlit_core::file::VarlitFile::mark_record_dead+0x83f>
   7c171:	4c 89 23             	mov    %r12,(%rbx)
   7c174:	e9 d6 f9 ff ff       	jmp    7bb4f <varlit_core::file::VarlitFile::mark_record_dead+0x1df>
   7c179:	49 83 c4 a1          	add    $0xffffffffffffffa1,%r12
   7c17d:	4c 89 23             	mov    %r12,(%rbx)
   7c180:	48 8d 05 18 62 fa ff 	lea    -0x59de8(%rip),%rax        # 2239f <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a40>
   7c187:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7c18b:	48 c7 43 10 29 00 00 	movq   $0x29,0x10(%rbx)
   7c192:	00 
   7c193:	e9 b7 f9 ff ff       	jmp    7bb4f <varlit_core::file::VarlitFile::mark_record_dead+0x1df>
   7c198:	41 bf 14 00 00 00    	mov    $0x14,%r15d
   7c19e:	4c 8d 2d 3b 8a fa ff 	lea    -0x575c5(%rip),%r13        # 24be0 <anon.44dfe6286d6883d57c2709f00721256e.109.llvm.10558354968853684156>
   7c1a5:	4c 8b 64 24 50       	mov    0x50(%rsp),%r12
   7c1aa:	e9 6b fc ff ff       	jmp    7be1a <varlit_core::file::VarlitFile::mark_record_dead+0x4aa>
   7c1af:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   7c1b6:	00 
   7c1b7:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7c1bb:	0f 10 84 24 20 01 00 	movups 0x120(%rsp),%xmm0
   7c1c2:	00 
   7c1c3:	0f 10 8c 24 30 01 00 	movups 0x130(%rsp),%xmm1
   7c1ca:	00 
   7c1cb:	0f 10 94 24 40 01 00 	movups 0x140(%rsp),%xmm2
   7c1d2:	00 
   7c1d3:	e9 f0 fe ff ff       	jmp    7c0c8 <varlit_core::file::VarlitFile::mark_record_dead+0x758>
   7c1d8:	41 bf 0e 00 00 00    	mov    $0xe,%r15d
   7c1de:	49 89 cd             	mov    %rcx,%r13
   7c1e1:	eb c2                	jmp    7c1a5 <varlit_core::file::VarlitFile::mark_record_dead+0x835>
   7c1e3:	4c 8d 2d 3a 63 fa ff 	lea    -0x59cc6(%rip),%r13        # 22524 <anon.48385641d07dc56499de4af04e4ddc4c.132.llvm.462820364269179058+0x22>
   7c1ea:	41 b9 15 00 00 00    	mov    $0x15,%r9d
   7c1f0:	eb 0d                	jmp    7c1ff <varlit_core::file::VarlitFile::mark_record_dead+0x88f>
   7c1f2:	4c 8d 2d 92 61 fa ff 	lea    -0x59e6e(%rip),%r13        # 2238b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a2c>
   7c1f9:	41 b9 14 00 00 00    	mov    $0x14,%r9d
   7c1ff:	49 89 d4             	mov    %rdx,%r12
   7c202:	e9 2a fc ff ff       	jmp    7be31 <varlit_core::file::VarlitFile::mark_record_dead+0x4c1>
   7c207:	49 83 c4 98          	add    $0xffffffffffffff98,%r12
   7c20b:	4c 89 23             	mov    %r12,(%rbx)
   7c20e:	48 8d 05 76 61 fa ff 	lea    -0x59e8a(%rip),%rax        # 2238b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a2c>
   7c215:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7c219:	48 c7 43 10 14 00 00 	movq   $0x14,0x10(%rbx)
   7c220:	00 
   7c221:	e9 29 f9 ff ff       	jmp    7bb4f <varlit_core::file::VarlitFile::mark_record_dead+0x1df>
