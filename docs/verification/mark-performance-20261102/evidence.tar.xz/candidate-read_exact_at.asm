
/workspace/scratch/mark-perf-fix/lazy-errors-bin/record_mutation_load:     file format elf64-x86-64


Disassembly of section .text:

00000000000b9c00 <varlit_core::snapshot::SnapshotFile::read_exact_at>:
   b9c00:	55                   	push   %rbp
   b9c01:	41 57                	push   %r15
   b9c03:	41 56                	push   %r14
   b9c05:	41 55                	push   %r13
   b9c07:	41 54                	push   %r12
   b9c09:	53                   	push   %rbx
   b9c0a:	48 83 ec 48          	sub    $0x48,%rsp
   b9c0e:	49 89 cc             	mov    %rcx,%r12
   b9c11:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   b9c16:	48 b8 15 00 00 00 00 	movabs $0x8000000000000015,%rax
   b9c1d:	00 00 80 
   b9c20:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   b9c24:	4c 89 c5             	mov    %r8,%rbp
   b9c27:	48 8d 0d 6f a5 f6 ff 	lea    -0x95a91(%rip),%rcx        # 2419d <anon.0624e7d5e48278245b12a454ff79655c.105.llvm.2515505084513145378>
   b9c2e:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   b9c33:	48 c7 44 24 20 0e 00 	movq   $0xe,0x20(%rsp)
   b9c3a:	00 00 
   b9c3c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   b9c41:	48 01 d5             	add    %rdx,%rbp
   b9c44:	0f 82 28 01 00 00    	jb     b9d72 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x172>
   b9c4a:	4d 89 c6             	mov    %r8,%r14
   b9c4d:	49 89 d7             	mov    %rdx,%r15
   b9c50:	49 89 f5             	mov    %rsi,%r13
   b9c53:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   b9c58:	e8 a3 e8 fe ff       	call   a8500 <core::ptr::drop_in_place<varlit_core::error::Error>>
   b9c5d:	48 39 dd             	cmp    %rbx,%rbp
   b9c60:	76 2a                	jbe    b9c8c <varlit_core::snapshot::SnapshotFile::read_exact_at+0x8c>
   b9c62:	48 ba 15 00 00 00 00 	movabs $0x8000000000000015,%rdx
   b9c69:	00 00 80 
   b9c6c:	48 83 c2 02          	add    $0x2,%rdx
   b9c70:	4c 89 f9             	mov    %r15,%rcx
   b9c73:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   b9c78:	4c 89 70 10          	mov    %r14,0x10(%rax)
   b9c7c:	48 89 58 18          	mov    %rbx,0x18(%rax)
   b9c80:	48 89 10             	mov    %rdx,(%rax)
   b9c83:	48 89 48 08          	mov    %rcx,0x8(%rax)
   b9c87:	e9 84 00 00 00       	jmp    b9d10 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x110>
   b9c8c:	4d 85 f6             	test   %r14,%r14
   b9c8f:	74 69                	je     b9cfa <varlit_core::snapshot::SnapshotFile::read_exact_at+0xfa>
   b9c91:	4d 8b 6d 00          	mov    0x0(%r13),%r13
   b9c95:	49 83 c5 08          	add    $0x8,%r13
   b9c99:	31 db                	xor    %ebx,%ebx
   b9c9b:	eb 08                	jmp    b9ca5 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xa5>
   b9c9d:	0f 1f 00             	nopl   (%rax)
   b9ca0:	4c 39 f3             	cmp    %r14,%rbx
   b9ca3:	73 55                	jae    b9cfa <varlit_core::snapshot::SnapshotFile::read_exact_at+0xfa>
   b9ca5:	48 89 d9             	mov    %rbx,%rcx
   b9ca8:	4c 01 f9             	add    %r15,%rcx
   b9cab:	0f 82 9a 00 00 00    	jb     b9d4b <varlit_core::snapshot::SnapshotFile::read_exact_at+0x14b>
   b9cb1:	4c 89 f2             	mov    %r14,%rdx
   b9cb4:	48 29 da             	sub    %rbx,%rdx
   b9cb7:	49 8d 34 1c          	lea    (%r12,%rbx,1),%rsi
   b9cbb:	4c 89 ef             	mov    %r13,%rdi
   b9cbe:	ff 15 bc 34 11 00    	call   *0x1134bc(%rip)        # 1cd180 <_DYNAMIC+0x868>
   b9cc4:	48 89 d5             	mov    %rdx,%rbp
   b9cc7:	48 83 f8 01          	cmp    $0x1,%rax
   b9ccb:	75 23                	jne    b9cf0 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xf0>
   b9ccd:	48 89 ef             	mov    %rbp,%rdi
   b9cd0:	e8 4b be ff ff       	call   b5b20 <<std::io::error::Error>::kind>
   b9cd5:	3c 23                	cmp    $0x23,%al
   b9cd7:	75 56                	jne    b9d2f <varlit_core::snapshot::SnapshotFile::read_exact_at+0x12f>
   b9cd9:	48 89 ef             	mov    %rbp,%rdi
   b9cdc:	e8 8f 02 00 00       	call   b9f70 <core::ptr::drop_in_place<std::io::error::Error>>
   b9ce1:	eb bd                	jmp    b9ca0 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xa0>
   b9ce3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   b9cea:	84 00 00 00 00 00 
   b9cf0:	48 85 ed             	test   %rbp,%rbp
   b9cf3:	74 2a                	je     b9d1f <varlit_core::snapshot::SnapshotFile::read_exact_at+0x11f>
   b9cf5:	48 01 eb             	add    %rbp,%rbx
   b9cf8:	eb a6                	jmp    b9ca0 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xa0>
   b9cfa:	48 b9 15 00 00 00 00 	movabs $0x8000000000000015,%rcx
   b9d01:	00 00 80 
   b9d04:	48 83 c1 68          	add    $0x68,%rcx
   b9d08:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   b9d0d:	48 89 08             	mov    %rcx,(%rax)
   b9d10:	48 83 c4 48          	add    $0x48,%rsp
   b9d14:	5b                   	pop    %rbx
   b9d15:	41 5c                	pop    %r12
   b9d17:	41 5d                	pop    %r13
   b9d19:	41 5e                	pop    %r14
   b9d1b:	41 5f                	pop    %r15
   b9d1d:	5d                   	pop    %rbp
   b9d1e:	c3                   	ret
   b9d1f:	48 b9 15 00 00 00 00 	movabs $0x8000000000000015,%rcx
   b9d26:	00 00 80 
   b9d29:	48 83 c1 f6          	add    $0xfffffffffffffff6,%rcx
   b9d2d:	eb d9                	jmp    b9d08 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x108>
   b9d2f:	48 b9 15 00 00 00 00 	movabs $0x8000000000000015,%rcx
   b9d36:	00 00 80 
   b9d39:	48 83 c1 f1          	add    $0xfffffffffffffff1,%rcx
   b9d3d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   b9d42:	48 89 08             	mov    %rcx,(%rax)
   b9d45:	48 89 68 08          	mov    %rbp,0x8(%rax)
   b9d49:	eb c5                	jmp    b9d10 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x110>
   b9d4b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   b9d50:	48 b9 15 00 00 00 00 	movabs $0x8000000000000015,%rcx
   b9d57:	00 00 80 
   b9d5a:	48 89 08             	mov    %rcx,(%rax)
   b9d5d:	48 8d 0d 7c ae f6 ff 	lea    -0x95184(%rip),%rcx        # 24be0 <anon.44dfe6286d6883d57c2709f00721256e.109.llvm.10558354968853684156>
   b9d64:	48 89 48 08          	mov    %rcx,0x8(%rax)
   b9d68:	48 c7 40 10 14 00 00 	movq   $0x14,0x10(%rax)
   b9d6f:	00 
   b9d70:	eb 9e                	jmp    b9d10 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x110>
   b9d72:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   b9d78:	48 ba 15 00 00 00 00 	movabs $0x8000000000000015,%rdx
   b9d7f:	00 00 80 
   b9d82:	e9 ec fe ff ff       	jmp    b9c73 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x73>
