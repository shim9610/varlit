import os,json,subprocess,statistics,random,hashlib
from pathlib import Path
r=Path('/workspace/scratch/mark-perf-fix');bins=Path('/workspace/scratch/compound-hardening/final');measure=bins/'native/measure-child'
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});rng=random.Random(24601);rows=[]
meta={k:Path('/sys/fs/cgroup',k).read_text() for k in ['cpu.max','memory.max','memory.events']};meta['command']=['writer','large','reverse','65536','4096'];meta['binary_hashes']={s:hashlib.sha256((bins/(s+'-bin/record_mutation_load')).read_bytes()).hexdigest() for s in ['before','after']};(r/'control-host.json').write_text(json.dumps(meta,indent=2)+'\n')
for group in range(12):
 labels=['old-a','old-b','current'];rng.shuffle(labels)
 for label in labels:
  side='after' if label=='current' else 'before';cmd=[str(measure),str(r/'usage.json'),str(bins/(side+'-bin/record_mutation_load')),*meta['command']]
  run=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=600);row={'group':group,'label':label,'result':json.loads(run.stdout),'usage':json.loads((r/'usage.json').read_text())};rows.append(row);(r/'control-samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(group,label,row['result']['seconds'],flush=True)
metrics={}
for label in ['old-a','old-b','current']:
 xs=[x for x in rows if x['label']==label];metrics[label]={'operation':statistics.median(x['result']['seconds'] for x in xs),'cpu':statistics.median(x['usage']['cpu'] for x in xs),'rss':max(x['usage']['rss'] for x in xs)}
(r/'control-summary.json').write_text(json.dumps(metrics,indent=2)+'\n');print(metrics)
