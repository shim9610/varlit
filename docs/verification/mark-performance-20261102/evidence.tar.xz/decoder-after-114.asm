000000000006d050 <varlit_core::native_layout::read_native_record_header>:
   6d050:	55                   	push   %rbp
   6d051:	41 57                	push   %r15
   6d053:	41 56                	push   %r14
   6d055:	41 55                	push   %r13
   6d057:	41 54                	push   %r12
   6d059:	53                   	push   %rbx
   6d05a:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
   6d061:	49 89 f6             	mov    %rsi,%r14
   6d064:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   6d069:	0f 57 c0             	xorps  %xmm0,%xmm0
   6d06c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   6d073:	00 
   6d074:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   6d079:	41 bf 20 00 00 00    	mov    $0x20,%r15d
   6d07f:	4c 8d 64 24 70       	lea    0x70(%rsp),%r12
   6d084:	48 8b 1d bd f2 15 00 	mov    0x15f2bd(%rip),%rbx        # 1cc348 <_DYNAMIC+0x350>
   6d08b:	4c 8d 2d 42 31 fb ff 	lea    -0x4cebe(%rip),%r13        # 201d4 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x20b4>
   6d092:	48 bd 00 00 00 00 23 	movabs $0x2300000000,%rbp
   6d099:	00 00 00 
   6d09c:	eb 34                	jmp    6d0d2 <varlit_core::native_layout::read_native_record_header+0x82>
   6d09e:	48 89 d0             	mov    %rdx,%rax
   6d0a1:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   6d0a8:	ff ff ff 
   6d0ab:	48 21 c8             	and    %rcx,%rax
   6d0ae:	48 b9 00 00 00 00 04 	movabs $0x400000000,%rcx
   6d0b5:	00 00 00 
   6d0b8:	48 39 c8             	cmp    %rcx,%rax
   6d0bb:	0f 85 85 00 00 00    	jne    6d146 <varlit_core::native_layout::read_native_record_header+0xf6>
   6d0c1:	48 89 d7             	mov    %rdx,%rdi
   6d0c4:	e8 37 46 00 00       	call   71700 <core::ptr::drop_in_place<std::io::error::Error>>
   6d0c9:	4d 85 ff             	test   %r15,%r15
   6d0cc:	0f 84 98 00 00 00    	je     6d16a <varlit_core::native_layout::read_native_record_header+0x11a>
   6d0d2:	4c 89 f7             	mov    %r14,%rdi
   6d0d5:	4c 89 e6             	mov    %r12,%rsi
   6d0d8:	4c 89 fa             	mov    %r15,%rdx
   6d0db:	ff d3                	call   *%rbx
   6d0dd:	48 83 f8 01          	cmp    $0x1,%rax
   6d0e1:	75 1d                	jne    6d100 <varlit_core::native_layout::read_native_record_header+0xb0>
   6d0e3:	89 d0                	mov    %edx,%eax
   6d0e5:	83 e0 03             	and    $0x3,%eax
   6d0e8:	49 63 44 85 00       	movslq 0x0(%r13,%rax,4),%rax
   6d0ed:	4c 01 e8             	add    %r13,%rax
   6d0f0:	ff e0                	jmp    *%rax
   6d0f2:	80 7a 10 23          	cmpb   $0x23,0x10(%rdx)
   6d0f6:	74 c9                	je     6d0c1 <varlit_core::native_layout::read_native_record_header+0x71>
   6d0f8:	eb 51                	jmp    6d14b <varlit_core::native_layout::read_native_record_header+0xfb>
   6d0fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   6d100:	48 85 d2             	test   %rdx,%rdx
   6d103:	74 38                	je     6d13d <varlit_core::native_layout::read_native_record_header+0xed>
   6d105:	4c 89 f8             	mov    %r15,%rax
   6d108:	48 29 d0             	sub    %rdx,%rax
   6d10b:	0f 82 d5 00 00 00    	jb     6d1e6 <varlit_core::native_layout::read_native_record_header+0x196>
   6d111:	49 01 d4             	add    %rdx,%r12
   6d114:	49 89 c7             	mov    %rax,%r15
   6d117:	4d 85 ff             	test   %r15,%r15
   6d11a:	75 b6                	jne    6d0d2 <varlit_core::native_layout::read_native_record_header+0x82>
   6d11c:	eb 4c                	jmp    6d16a <varlit_core::native_layout::read_native_record_header+0x11a>
   6d11e:	48 89 d0             	mov    %rdx,%rax
   6d121:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   6d128:	ff ff ff 
   6d12b:	48 21 c8             	and    %rcx,%rax
   6d12e:	48 39 e8             	cmp    %rbp,%rax
   6d131:	74 8e                	je     6d0c1 <varlit_core::native_layout::read_native_record_header+0x71>
   6d133:	eb 11                	jmp    6d146 <varlit_core::native_layout::read_native_record_header+0xf6>
   6d135:	80 7a 0f 23          	cmpb   $0x23,0xf(%rdx)
   6d139:	74 86                	je     6d0c1 <varlit_core::native_layout::read_native_record_header+0x71>
   6d13b:	eb 0e                	jmp    6d14b <varlit_core::native_layout::read_native_record_header+0xfb>
   6d13d:	48 8d 15 4c 97 15 00 	lea    0x15974c(%rip),%rdx        # 1c6890 <anon.a0ff4f46869377479ad462f429370715.2.llvm.5402889094323598768>
   6d144:	eb 05                	jmp    6d14b <varlit_core::native_layout::read_native_record_header+0xfb>
   6d146:	48 85 d2             	test   %rdx,%rdx
   6d149:	74 1f                	je     6d16a <varlit_core::native_layout::read_native_record_header+0x11a>
   6d14b:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
   6d152:	00 00 80 
   6d155:	48 83 c0 05          	add    $0x5,%rax
   6d159:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   6d15e:	48 89 03             	mov    %rax,(%rbx)
   6d161:	48 89 53 08          	mov    %rdx,0x8(%rbx)
   6d165:	e9 56 07 00 00       	jmp    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6d16a:	41 bc 20 00 00 00    	mov    $0x20,%r12d
   6d170:	48 8d 5c 24 70       	lea    0x70(%rsp),%rbx
   6d175:	41 b9 38 00 00 00    	mov    $0x38,%r9d
   6d17b:	48 bd 01 00 00 00 00 	movabs $0x8000000000000001,%rbp
   6d182:	00 00 80 
   6d185:	c7 44 24 3c 00 00 00 	movl   $0x0,0x3c(%rsp)
   6d18c:	00 
   6d18d:	4c 8d 15 bc 94 15 00 	lea    0x1594bc(%rip),%r10        # 1c6650 <__frame_dummy_init_array_entry+0xad0>
   6d194:	4b 8b 44 11 c8       	mov    -0x38(%r9,%r10,1),%rax
   6d199:	4f 8b 74 11 d0       	mov    -0x30(%r9,%r10,1),%r14
   6d19e:	48 8d 0d 3f 30 fb ff 	lea    -0x4cfc1(%rip),%rcx        # 201e4 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x20c4>
   6d1a5:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   6d1a9:	48 01 c8             	add    %rcx,%rax
   6d1ac:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   6d1b3:	00 
   6d1b4:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   6d1b8:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
   6d1bf:	00 
   6d1c0:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   6d1c7:	00 
   6d1c8:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
   6d1cc:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   6d1d3:	00 
   6d1d4:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
   6d1db:	00 
   6d1dc:	c7 44 24 34 00 00 00 	movl   $0x0,0x34(%rsp)
   6d1e3:	00 
   6d1e4:	ff e0                	jmp    *%rax
   6d1e6:	48 8d 0d bb 96 15 00 	lea    0x1596bb(%rip),%rcx        # 1c68a8 <anon.a0ff4f46869377479ad462f429370715.4.llvm.5402889094323598768>
   6d1ed:	48 89 d7             	mov    %rdx,%rdi
   6d1f0:	4c 89 fe             	mov    %r15,%rsi
   6d1f3:	4c 89 fa             	mov    %r15,%rdx
   6d1f6:	ff 15 b4 f1 15 00    	call   *0x15f1b4(%rip)        # 1cc3b0 <_DYNAMIC+0x3b8>
   6d1fc:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
   6d201:	4c 89 4c 24 68       	mov    %r9,0x68(%rsp)
   6d206:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   6d20c:	31 ed                	xor    %ebp,%ebp
   6d20e:	4d 85 f6             	test   %r14,%r14
   6d211:	0f 85 83 00 00 00    	jne    6d29a <varlit_core::native_layout::read_native_record_header+0x24a>
   6d217:	49 89 dc             	mov    %rbx,%r12
   6d21a:	49 89 ee             	mov    %rbp,%r14
   6d21d:	4c 89 ef             	mov    %r13,%rdi
   6d220:	48 89 de             	mov    %rbx,%rsi
   6d223:	48 89 ea             	mov    %rbp,%rdx
   6d226:	ff 15 d4 f0 15 00    	call   *0x15f0d4(%rip)        # 1cc300 <memcpy@GLIBC_2.14>
   6d22c:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
   6d231:	48 bd 01 00 00 00 00 	movabs $0x8000000000000001,%rbp
   6d238:	00 00 80 
   6d23b:	4c 8b 4c 24 68       	mov    0x68(%rsp),%r9
   6d240:	4c 8d 15 09 94 15 00 	lea    0x159409(%rip),%r10        # 1c6650 <__frame_dummy_init_array_entry+0xad0>
   6d247:	44 89 e9             	mov    %r13d,%ecx
   6d24a:	44 89 e8             	mov    %r13d,%eax
   6d24d:	c1 e8 08             	shr    $0x8,%eax
   6d250:	4c 89 ee             	mov    %r13,%rsi
   6d253:	48 c1 ee 10          	shr    $0x10,%rsi
   6d257:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
   6d25e:	ff ff ff 
   6d261:	49 21 d5             	and    %rdx,%r13
   6d264:	c1 e0 08             	shl    $0x8,%eax
   6d267:	0f b6 c9             	movzbl %cl,%ecx
   6d26a:	09 c8                	or     %ecx,%eax
   6d26c:	c1 e6 10             	shl    $0x10,%esi
   6d26f:	0f b7 d0             	movzwl %ax,%edx
   6d272:	09 f2                	or     %esi,%edx
   6d274:	4d 89 ef             	mov    %r13,%r15
   6d277:	49 09 d7             	or     %rdx,%r15
   6d27a:	43 0f b6 34 11       	movzbl (%r9,%r10,1),%esi
   6d27f:	4c 8d 05 72 2f fb ff 	lea    -0x4d08e(%rip),%r8        # 201f8 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x20d8>
   6d286:	49 63 3c b0          	movslq (%r8,%rsi,4),%rdi
   6d28a:	4c 01 c7             	add    %r8,%rdi
   6d28d:	4c 89 e3             	mov    %r12,%rbx
   6d290:	48 89 d6             	mov    %rdx,%rsi
   6d293:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   6d298:	ff e7                	jmp    *%rdi
   6d29a:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   6d2a1:	00 
   6d2a2:	ba 01 00 00 00       	mov    $0x1,%edx
   6d2a7:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   6d2ad:	41 b9 01 00 00 00    	mov    $0x1,%r9d
   6d2b3:	31 f6                	xor    %esi,%esi
   6d2b5:	4c 89 f1             	mov    %r14,%rcx
   6d2b8:	e8 93 1c 00 00       	call   6ef50 <alloc::raw_vec::RawVecInner<A>::finish_grow>
   6d2bd:	83 bc 24 90 00 00 00 	cmpl   $0x1,0x90(%rsp)
   6d2c4:	01 
   6d2c5:	74 6b                	je     6d332 <varlit_core::native_layout::read_native_record_header+0x2e2>
   6d2c7:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   6d2ce:	00 
   6d2cf:	4c 89 e8             	mov    %r13,%rax
   6d2d2:	49 83 fe 01          	cmp    $0x1,%r14
   6d2d6:	48 bd 01 00 00 00 00 	movabs $0x8000000000000001,%rbp
   6d2dd:	00 00 80 
   6d2e0:	74 16                	je     6d2f8 <varlit_core::native_layout::read_native_record_header+0x2a8>
   6d2e2:	49 8d 56 ff          	lea    -0x1(%r14),%rdx
   6d2e6:	4c 89 ef             	mov    %r13,%rdi
   6d2e9:	31 f6                	xor    %esi,%esi
   6d2eb:	ff 15 4f f0 15 00    	call   *0x15f04f(%rip)        # 1cc340 <memset@GLIBC_2.2.5>
   6d2f1:	4b 8d 04 2e          	lea    (%r14,%r13,1),%rax
   6d2f5:	48 ff c8             	dec    %rax
   6d2f8:	c6 00 00             	movb   $0x0,(%rax)
   6d2fb:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   6d300:	4c 29 f0             	sub    %r14,%rax
   6d303:	72 4d                	jb     6d352 <varlit_core::native_layout::read_native_record_header+0x302>
   6d305:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   6d30a:	4e 8d 24 33          	lea    (%rbx,%r14,1),%r12
   6d30e:	49 83 fe 01          	cmp    $0x1,%r14
   6d312:	75 16                	jne    6d32a <varlit_core::native_layout::read_native_record_header+0x2da>
   6d314:	0f b6 03             	movzbl (%rbx),%eax
   6d317:	41 88 45 00          	mov    %al,0x0(%r13)
   6d31b:	b8 01 00 00 00       	mov    $0x1,%eax
   6d320:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   6d325:	e9 11 ff ff ff       	jmp    6d23b <varlit_core::native_layout::read_native_record_header+0x1eb>
   6d32a:	4c 89 f5             	mov    %r14,%rbp
   6d32d:	e9 eb fe ff ff       	jmp    6d21d <varlit_core::native_layout::read_native_record_header+0x1cd>
   6d332:	48 bd 01 00 00 00 00 	movabs $0x8000000000000001,%rbp
   6d339:	00 00 80 
   6d33c:	48 83 c5 15          	add    $0x15,%rbp
   6d340:	48 8d 05 30 31 fb ff 	lea    -0x4ced0(%rip),%rax        # 20477 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x2357>
   6d347:	41 bf 18 00 00 00    	mov    $0x18,%r15d
   6d34d:	e9 d6 03 00 00       	jmp    6d728 <varlit_core::native_layout::read_native_record_header+0x6d8>
   6d352:	ba 01 00 00 00       	mov    $0x1,%edx
   6d357:	4c 89 ef             	mov    %r13,%rdi
   6d35a:	4c 89 f6             	mov    %r14,%rsi
   6d35d:	ff 15 85 ef 15 00    	call   *0x15ef85(%rip)        # 1cc2e8 <_DYNAMIC+0x2f0>
   6d363:	48 83 c5 05          	add    $0x5,%rbp
   6d367:	48 8d 05 ca 92 15 00 	lea    0x1592ca(%rip),%rax        # 1c6638 <__frame_dummy_init_array_entry+0xab8>
   6d36e:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
   6d373:	e9 b0 03 00 00       	jmp    6d728 <varlit_core::native_layout::read_native_record_header+0x6d8>
   6d378:	49 ff cc             	dec    %r12
   6d37b:	0f b6 0b             	movzbl (%rbx),%ecx
   6d37e:	48 ff c3             	inc    %rbx
   6d381:	4c 8d 75 ff          	lea    -0x1(%rbp),%r14
   6d385:	45 31 ed             	xor    %r13d,%r13d
   6d388:	31 c0                	xor    %eax,%eax
   6d38a:	c1 e0 08             	shl    $0x8,%eax
   6d38d:	0f b6 c9             	movzbl %cl,%ecx
   6d390:	09 c8                	or     %ecx,%eax
   6d392:	31 d2                	xor    %edx,%edx
   6d394:	c1 e2 10             	shl    $0x10,%edx
   6d397:	44 0f b7 f8          	movzwl %ax,%r15d
   6d39b:	41 09 d7             	or     %edx,%r15d
   6d39e:	43 0f b6 14 11       	movzbl (%r9,%r10,1),%edx
   6d3a3:	48 8d 35 4e 2e fb ff 	lea    -0x4d1b2(%rip),%rsi        # 201f8 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x20d8>
   6d3aa:	48 63 3c 96          	movslq (%rsi,%rdx,4),%rdi
   6d3ae:	48 01 f7             	add    %rsi,%rdi
   6d3b1:	44 89 fa             	mov    %r15d,%edx
   6d3b4:	4c 89 fe             	mov    %r15,%rsi
   6d3b7:	ff e7                	jmp    *%rdi
   6d3b9:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
   6d3be:	49 83 fc 02          	cmp    $0x2,%r12
   6d3c2:	0f 82 55 03 00 00    	jb     6d71d <varlit_core::native_layout::read_native_record_header+0x6cd>
   6d3c8:	49 83 c4 fe          	add    $0xfffffffffffffffe,%r12
   6d3cc:	0f b7 03             	movzwl (%rbx),%eax
   6d3cf:	48 83 c3 02          	add    $0x2,%rbx
   6d3d3:	89 c1                	mov    %eax,%ecx
   6d3d5:	c1 e8 08             	shr    $0x8,%eax
   6d3d8:	45 31 ed             	xor    %r13d,%r13d
   6d3db:	c1 e0 08             	shl    $0x8,%eax
   6d3de:	0f b6 c9             	movzbl %cl,%ecx
   6d3e1:	09 c8                	or     %ecx,%eax
   6d3e3:	31 d2                	xor    %edx,%edx
   6d3e5:	c1 e2 10             	shl    $0x10,%edx
   6d3e8:	44 0f b7 f8          	movzwl %ax,%r15d
   6d3ec:	41 09 d7             	or     %edx,%r15d
   6d3ef:	43 0f b6 14 11       	movzbl (%r9,%r10,1),%edx
   6d3f4:	48 8d 35 fd 2d fb ff 	lea    -0x4d203(%rip),%rsi        # 201f8 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x20d8>
   6d3fb:	48 63 3c 96          	movslq (%rsi,%rdx,4),%rdi
   6d3ff:	48 01 f7             	add    %rsi,%rdi
   6d402:	44 89 fa             	mov    %r15d,%edx
   6d405:	49 89 ee             	mov    %rbp,%r14
   6d408:	4c 89 fe             	mov    %r15,%rsi
   6d40b:	ff e7                	jmp    *%rdi
   6d40d:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
   6d412:	49 83 fc 04          	cmp    $0x4,%r12
   6d416:	0f 82 01 03 00 00    	jb     6d71d <varlit_core::native_layout::read_native_record_header+0x6cd>
   6d41c:	49 83 c4 fc          	add    $0xfffffffffffffffc,%r12
   6d420:	8b 13                	mov    (%rbx),%edx
   6d422:	48 83 c3 04          	add    $0x4,%rbx
   6d426:	89 d1                	mov    %edx,%ecx
   6d428:	89 d0                	mov    %edx,%eax
   6d42a:	c1 e8 08             	shr    $0x8,%eax
   6d42d:	c1 ea 10             	shr    $0x10,%edx
   6d430:	4c 8d 75 01          	lea    0x1(%rbp),%r14
   6d434:	45 31 ed             	xor    %r13d,%r13d
   6d437:	c1 e0 08             	shl    $0x8,%eax
   6d43a:	0f b6 c9             	movzbl %cl,%ecx
   6d43d:	09 c8                	or     %ecx,%eax
   6d43f:	c1 e2 10             	shl    $0x10,%edx
   6d442:	44 0f b7 f8          	movzwl %ax,%r15d
   6d446:	41 09 d7             	or     %edx,%r15d
   6d449:	43 0f b6 14 11       	movzbl (%r9,%r10,1),%edx
   6d44e:	48 8d 35 a3 2d fb ff 	lea    -0x4d25d(%rip),%rsi        # 201f8 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x20d8>
   6d455:	48 63 3c 96          	movslq (%rsi,%rdx,4),%rdi
   6d459:	48 01 f7             	add    %rsi,%rdi
   6d45c:	44 89 fa             	mov    %r15d,%edx
   6d45f:	4c 89 fe             	mov    %r15,%rsi
   6d462:	ff e7                	jmp    *%rdi
   6d464:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
   6d469:	49 83 fc 08          	cmp    $0x8,%r12
   6d46d:	0f 82 aa 02 00 00    	jb     6d71d <varlit_core::native_layout::read_native_record_header+0x6cd>
   6d473:	49 83 c4 f8          	add    $0xfffffffffffffff8,%r12
   6d477:	4c 8b 2b             	mov    (%rbx),%r13
   6d47a:	48 83 c3 08          	add    $0x8,%rbx
   6d47e:	44 89 e9             	mov    %r13d,%ecx
   6d481:	44 89 e8             	mov    %r13d,%eax
   6d484:	c1 e8 08             	shr    $0x8,%eax
   6d487:	4c 89 ee             	mov    %r13,%rsi
   6d48a:	48 c1 ee 10          	shr    $0x10,%rsi
   6d48e:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
   6d495:	ff ff ff 
   6d498:	49 21 d5             	and    %rdx,%r13
   6d49b:	4c 8d 75 02          	lea    0x2(%rbp),%r14
   6d49f:	c1 e0 08             	shl    $0x8,%eax
   6d4a2:	0f b6 c9             	movzbl %cl,%ecx
   6d4a5:	09 c8                	or     %ecx,%eax
   6d4a7:	c1 e6 10             	shl    $0x10,%esi
   6d4aa:	0f b7 d0             	movzwl %ax,%edx
   6d4ad:	09 f2                	or     %esi,%edx
   6d4af:	4d 89 ef             	mov    %r13,%r15
   6d4b2:	49 09 d7             	or     %rdx,%r15
   6d4b5:	43 0f b6 34 11       	movzbl (%r9,%r10,1),%esi
   6d4ba:	4c 8d 05 37 2d fb ff 	lea    -0x4d2c9(%rip),%r8        # 201f8 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x20d8>
   6d4c1:	49 63 3c b0          	movslq (%r8,%rsi,4),%rdi
   6d4c5:	4c 01 c7             	add    %r8,%rdi
   6d4c8:	48 89 d6             	mov    %rdx,%rsi
   6d4cb:	ff e7                	jmp    *%rdi
   6d4cd:	49 8d 3c 2e          	lea    (%r14,%rbp,1),%rdi
   6d4d1:	4c 89 f6             	mov    %r14,%rsi
   6d4d4:	48 c1 fe 3f          	sar    $0x3f,%rsi
   6d4d8:	48 21 fe             	and    %rdi,%rsi
   6d4db:	48 ff ce             	dec    %rsi
   6d4de:	48 83 fe 03          	cmp    $0x3,%rsi
   6d4e2:	0f 87 a4 03 00 00    	ja     6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d4e8:	40 b7 01             	mov    $0x1,%dil
   6d4eb:	89 7c 24 4c          	mov    %edi,0x4c(%rsp)
   6d4ef:	48 8d 3d 7a 2d fb ff 	lea    -0x4d286(%rip),%rdi        # 20270 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x2150>
   6d4f6:	48 63 34 b7          	movslq (%rdi,%rsi,4),%rsi
   6d4fa:	48 01 fe             	add    %rdi,%rsi
   6d4fd:	ff e6                	jmp    *%rsi
   6d4ff:	0f b6 c1             	movzbl %cl,%eax
   6d502:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   6d506:	4d 85 f6             	test   %r14,%r14
   6d509:	0f 8f b7 01 00 00    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d50f:	e9 d0 01 00 00       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d514:	49 8d 3c 2e          	lea    (%r14,%rbp,1),%rdi
   6d518:	4c 89 f6             	mov    %r14,%rsi
   6d51b:	48 c1 fe 3f          	sar    $0x3f,%rsi
   6d51f:	48 21 fe             	and    %rdi,%rsi
   6d522:	48 ff ce             	dec    %rsi
   6d525:	48 83 fe 03          	cmp    $0x3,%rsi
   6d529:	0f 87 5d 03 00 00    	ja     6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d52f:	40 b7 01             	mov    $0x1,%dil
   6d532:	89 7c 24 38          	mov    %edi,0x38(%rsp)
   6d536:	48 8d 3d 03 2d fb ff 	lea    -0x4d2fd(%rip),%rdi        # 20240 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x2120>
   6d53d:	48 63 34 b7          	movslq (%rdi,%rsi,4),%rsi
   6d541:	48 01 fe             	add    %rdi,%rsi
   6d544:	ff e6                	jmp    *%rsi
   6d546:	0f b6 c1             	movzbl %cl,%eax
   6d549:	89 44 24 18          	mov    %eax,0x18(%rsp)
   6d54d:	4d 85 f6             	test   %r14,%r14
   6d550:	0f 8f 70 01 00 00    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d556:	e9 89 01 00 00       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d55b:	49 8d 3c 2e          	lea    (%r14,%rbp,1),%rdi
   6d55f:	4c 89 f2             	mov    %r14,%rdx
   6d562:	48 c1 fa 3f          	sar    $0x3f,%rdx
   6d566:	48 21 fa             	and    %rdi,%rdx
   6d569:	48 ff ca             	dec    %rdx
   6d56c:	48 83 fa 03          	cmp    $0x3,%rdx
   6d570:	0f 87 16 03 00 00    	ja     6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d576:	40 b7 01             	mov    $0x1,%dil
   6d579:	89 7c 24 40          	mov    %edi,0x40(%rsp)
   6d57d:	48 8d 3d dc 2c fb ff 	lea    -0x4d324(%rip),%rdi        # 20260 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x2140>
   6d584:	48 63 14 97          	movslq (%rdi,%rdx,4),%rdx
   6d588:	48 01 fa             	add    %rdi,%rdx
   6d58b:	ff e2                	jmp    *%rdx
   6d58d:	0f b6 c1             	movzbl %cl,%eax
   6d590:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   6d595:	4d 85 f6             	test   %r14,%r14
   6d598:	0f 8f 28 01 00 00    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d59e:	e9 41 01 00 00       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d5a3:	49 8d 3c 2e          	lea    (%r14,%rbp,1),%rdi
   6d5a7:	4c 89 f2             	mov    %r14,%rdx
   6d5aa:	48 c1 fa 3f          	sar    $0x3f,%rdx
   6d5ae:	48 21 fa             	and    %rdi,%rdx
   6d5b1:	48 ff ca             	dec    %rdx
   6d5b4:	48 83 fa 03          	cmp    $0x3,%rdx
   6d5b8:	0f 87 ce 02 00 00    	ja     6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d5be:	40 b7 01             	mov    $0x1,%dil
   6d5c1:	89 7c 24 3c          	mov    %edi,0x3c(%rsp)
   6d5c5:	48 8d 3d 84 2c fb ff 	lea    -0x4d37c(%rip),%rdi        # 20250 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x2130>
   6d5cc:	48 63 14 97          	movslq (%rdi,%rdx,4),%rdx
   6d5d0:	48 01 fa             	add    %rdi,%rdx
   6d5d3:	ff e2                	jmp    *%rdx
   6d5d5:	0f b6 c1             	movzbl %cl,%eax
   6d5d8:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   6d5dd:	4d 85 f6             	test   %r14,%r14
   6d5e0:	0f 8f e0 00 00 00    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d5e6:	e9 f9 00 00 00       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d5eb:	49 8d 34 2e          	lea    (%r14,%rbp,1),%rsi
   6d5ef:	4c 89 f2             	mov    %r14,%rdx
   6d5f2:	48 c1 fa 3f          	sar    $0x3f,%rdx
   6d5f6:	48 21 f2             	and    %rsi,%rdx
   6d5f9:	40 b6 01             	mov    $0x1,%sil
   6d5fc:	89 74 24 48          	mov    %esi,0x48(%rsp)
   6d600:	48 83 fa 04          	cmp    $0x4,%rdx
   6d604:	0f 84 49 01 00 00    	je     6d753 <varlit_core::native_layout::read_native_record_header+0x703>
   6d60a:	48 83 fa 02          	cmp    $0x2,%rdx
   6d60e:	0f 84 4c 01 00 00    	je     6d760 <varlit_core::native_layout::read_native_record_header+0x710>
   6d614:	48 83 fa 01          	cmp    $0x1,%rdx
   6d618:	0f 85 6e 02 00 00    	jne    6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d61e:	0f b6 c1             	movzbl %cl,%eax
   6d621:	89 44 24 20          	mov    %eax,0x20(%rsp)
   6d625:	4d 85 f6             	test   %r14,%r14
   6d628:	0f 8f 98 00 00 00    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d62e:	e9 b1 00 00 00       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d633:	49 8d 34 2e          	lea    (%r14,%rbp,1),%rsi
   6d637:	4c 89 f2             	mov    %r14,%rdx
   6d63a:	48 c1 fa 3f          	sar    $0x3f,%rdx
   6d63e:	48 21 f2             	and    %rsi,%rdx
   6d641:	40 b6 01             	mov    $0x1,%sil
   6d644:	89 74 24 44          	mov    %esi,0x44(%rsp)
   6d648:	48 83 fa 04          	cmp    $0x4,%rdx
   6d64c:	0f 84 20 01 00 00    	je     6d772 <varlit_core::native_layout::read_native_record_header+0x722>
   6d652:	48 83 fa 02          	cmp    $0x2,%rdx
   6d656:	0f 84 23 01 00 00    	je     6d77f <varlit_core::native_layout::read_native_record_header+0x72f>
   6d65c:	48 83 fa 01          	cmp    $0x1,%rdx
   6d660:	0f 85 26 02 00 00    	jne    6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d666:	0f b6 c1             	movzbl %cl,%eax
   6d669:	89 44 24 24          	mov    %eax,0x24(%rsp)
   6d66d:	4d 85 f6             	test   %r14,%r14
   6d670:	7f 54                	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d672:	eb 70                	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d674:	49 8d 3c 2e          	lea    (%r14,%rbp,1),%rdi
   6d678:	4c 89 f6             	mov    %r14,%rsi
   6d67b:	48 c1 fe 3f          	sar    $0x3f,%rsi
   6d67f:	48 21 fe             	and    %rdi,%rsi
   6d682:	48 ff ce             	dec    %rsi
   6d685:	48 83 fe 03          	cmp    $0x3,%rsi
   6d689:	0f 87 fd 01 00 00    	ja     6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d68f:	40 b7 01             	mov    $0x1,%dil
   6d692:	89 7c 24 34          	mov    %edi,0x34(%rsp)
   6d696:	48 8d 3d 93 2b fb ff 	lea    -0x4d46d(%rip),%rdi        # 20230 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x2110>
   6d69d:	48 63 34 b7          	movslq (%rdi,%rsi,4),%rsi
   6d6a1:	48 01 fe             	add    %rdi,%rsi
   6d6a4:	ff e6                	jmp    *%rsi
   6d6a6:	0f b6 c1             	movzbl %cl,%eax
   6d6a9:	89 44 24 14          	mov    %eax,0x14(%rsp)
   6d6ad:	4d 85 f6             	test   %r14,%r14
   6d6b0:	7f 14                	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d6b2:	eb 30                	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d6b4:	4d 85 ed             	test   %r13,%r13
   6d6b7:	0f 85 cf 01 00 00    	jne    6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d6bd:	89 54 24 1c          	mov    %edx,0x1c(%rsp)
   6d6c1:	4d 85 f6             	test   %r14,%r14
   6d6c4:	7e 1e                	jle    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d6c6:	ba 01 00 00 00       	mov    $0x1,%edx
   6d6cb:	4c 89 ff             	mov    %r15,%rdi
   6d6ce:	4c 89 f6             	mov    %r14,%rsi
   6d6d1:	4d 89 ce             	mov    %r9,%r14
   6d6d4:	ff 15 0e ec 15 00    	call   *0x15ec0e(%rip)        # 1cc2e8 <_DYNAMIC+0x2f0>
   6d6da:	4c 8d 15 6f 8f 15 00 	lea    0x158f6f(%rip),%r10        # 1c6650 <__frame_dummy_init_array_entry+0xad0>
   6d6e1:	4d 89 f1             	mov    %r14,%r9
   6d6e4:	49 83 c1 40          	add    $0x40,%r9
   6d6e8:	49 81 f9 f8 01 00 00 	cmp    $0x1f8,%r9
   6d6ef:	0f 84 e0 01 00 00    	je     6d8d5 <varlit_core::native_layout::read_native_record_header+0x885>
   6d6f5:	4b 8b 44 11 c8       	mov    -0x38(%r9,%r10,1),%rax
   6d6fa:	4f 8b 74 11 d0       	mov    -0x30(%r9,%r10,1),%r14
   6d6ff:	48 8d 0d de 2a fb ff 	lea    -0x4d522(%rip),%rcx        # 201e4 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x20c4>
   6d706:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   6d70a:	48 01 c8             	add    %rcx,%rax
   6d70d:	ff e0                	jmp    *%rax
   6d70f:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
   6d714:	4d 85 e4             	test   %r12,%r12
   6d717:	0f 85 5b fc ff ff    	jne    6d378 <varlit_core::native_layout::read_native_record_header+0x328>
   6d71d:	48 83 c5 05          	add    $0x5,%rbp
   6d721:	48 8d 05 10 8f 15 00 	lea    0x158f10(%rip),%rax        # 1c6638 <__frame_dummy_init_array_entry+0xab8>
   6d728:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   6d72d:	48 89 2b             	mov    %rbp,(%rbx)
   6d730:	48 89 43 08          	mov    %rax,0x8(%rbx)
   6d734:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
   6d738:	4c 89 73 18          	mov    %r14,0x18(%rbx)
   6d73c:	e9 7f 01 00 00       	jmp    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6d741:	0f b7 c0             	movzwl %ax,%eax
   6d744:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   6d748:	4d 85 f6             	test   %r14,%r14
   6d74b:	0f 8f 75 ff ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d751:	eb 91                	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d753:	49 81 ff ff ff 00 00 	cmp    $0xffff,%r15
   6d75a:	0f 87 2c 01 00 00    	ja     6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d760:	89 44 24 20          	mov    %eax,0x20(%rsp)
   6d764:	4d 85 f6             	test   %r14,%r14
   6d767:	0f 8f 59 ff ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d76d:	e9 72 ff ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d772:	49 81 ff ff ff 00 00 	cmp    $0xffff,%r15
   6d779:	0f 87 0d 01 00 00    	ja     6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d77f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   6d783:	4d 85 f6             	test   %r14,%r14
   6d786:	0f 8f 3a ff ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d78c:	e9 53 ff ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d791:	4d 85 ed             	test   %r13,%r13
   6d794:	0f 85 f2 00 00 00    	jne    6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d79a:	89 54 24 18          	mov    %edx,0x18(%rsp)
   6d79e:	4d 85 f6             	test   %r14,%r14
   6d7a1:	0f 8f 1f ff ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d7a7:	e9 38 ff ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d7ac:	0f b7 c0             	movzwl %ax,%eax
   6d7af:	89 44 24 18          	mov    %eax,0x18(%rsp)
   6d7b3:	4d 85 f6             	test   %r14,%r14
   6d7b6:	0f 8f 0a ff ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d7bc:	e9 23 ff ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d7c1:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
   6d7c6:	4d 85 f6             	test   %r14,%r14
   6d7c9:	0f 8f f7 fe ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d7cf:	e9 10 ff ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d7d4:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
   6d7d9:	4d 85 f6             	test   %r14,%r14
   6d7dc:	0f 8f e4 fe ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d7e2:	e9 fd fe ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d7e7:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
   6d7ec:	4d 85 f6             	test   %r14,%r14
   6d7ef:	0f 8f d1 fe ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d7f5:	e9 ea fe ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d7fa:	0f b7 c0             	movzwl %ax,%eax
   6d7fd:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   6d802:	4d 85 f6             	test   %r14,%r14
   6d805:	0f 8f bb fe ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d80b:	e9 d4 fe ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d810:	4c 89 7c 24 58       	mov    %r15,0x58(%rsp)
   6d815:	4d 85 f6             	test   %r14,%r14
   6d818:	0f 8f a8 fe ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d81e:	e9 c1 fe ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d823:	0f b7 c0             	movzwl %ax,%eax
   6d826:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   6d82b:	4d 85 f6             	test   %r14,%r14
   6d82e:	0f 8f 92 fe ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d834:	e9 ab fe ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d839:	4d 85 ed             	test   %r13,%r13
   6d83c:	75 4e                	jne    6d88c <varlit_core::native_layout::read_native_record_header+0x83c>
   6d83e:	89 54 24 14          	mov    %edx,0x14(%rsp)
   6d842:	4d 85 f6             	test   %r14,%r14
   6d845:	0f 8f 7b fe ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d84b:	e9 94 fe ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d850:	0f b7 c0             	movzwl %ax,%eax
   6d853:	89 44 24 14          	mov    %eax,0x14(%rsp)
   6d857:	4d 85 f6             	test   %r14,%r14
   6d85a:	0f 8f 66 fe ff ff    	jg     6d6c6 <varlit_core::native_layout::read_native_record_header+0x676>
   6d860:	e9 7f fe ff ff       	jmp    6d6e4 <varlit_core::native_layout::read_native_record_header+0x694>
   6d865:	48 83 c5 1d          	add    $0x1d,%rbp
   6d869:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   6d86e:	48 89 2b             	mov    %rbp,(%rbx)
   6d871:	48 8d 05 af 2c fb ff 	lea    -0x4d351(%rip),%rax        # 20527 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x2407>
   6d878:	48 89 43 08          	mov    %rax,0x8(%rbx)
   6d87c:	b8 2d 00 00 00       	mov    $0x2d,%eax
   6d881:	48 89 43 10          	mov    %rax,0x10(%rbx)
   6d885:	4d 85 f6             	test   %r14,%r14
   6d888:	7f 25                	jg     6d8af <varlit_core::native_layout::read_native_record_header+0x85f>
   6d88a:	eb 34                	jmp    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6d88c:	4b 8b 4c 11 f0       	mov    -0x10(%r9,%r10,1),%rcx
   6d891:	4b 8b 44 11 f8       	mov    -0x8(%r9,%r10,1),%rax
   6d896:	48 83 c5 6d          	add    $0x6d,%rbp
   6d89a:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   6d89f:	48 89 2b             	mov    %rbp,(%rbx)
   6d8a2:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   6d8a6:	48 89 43 10          	mov    %rax,0x10(%rbx)
   6d8aa:	4d 85 f6             	test   %r14,%r14
   6d8ad:	7e 11                	jle    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6d8af:	ba 01 00 00 00       	mov    $0x1,%edx
   6d8b4:	4c 89 ff             	mov    %r15,%rdi
   6d8b7:	4c 89 f6             	mov    %r14,%rsi
   6d8ba:	ff 15 28 ea 15 00    	call   *0x15ea28(%rip)        # 1cc2e8 <_DYNAMIC+0x2f0>
   6d8c0:	48 89 d8             	mov    %rbx,%rax
   6d8c3:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   6d8ca:	5b                   	pop    %rbx
   6d8cb:	41 5c                	pop    %r12
   6d8cd:	41 5d                	pop    %r13
   6d8cf:	41 5e                	pop    %r14
   6d8d1:	41 5f                	pop    %r15
   6d8d3:	5d                   	pop    %rbp
   6d8d4:	c3                   	ret
   6d8d5:	4d 85 e4             	test   %r12,%r12
   6d8d8:	74 21                	je     6d8fb <varlit_core::native_layout::read_native_record_header+0x8ab>
   6d8da:	48 83 c5 1d          	add    $0x1d,%rbp
   6d8de:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   6d8e3:	48 89 2b             	mov    %rbp,(%rbx)
   6d8e6:	48 8d 05 67 2c fb ff 	lea    -0x4d399(%rip),%rax        # 20554 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x2434>
   6d8ed:	48 89 43 08          	mov    %rax,0x8(%rbx)
   6d8f1:	48 c7 43 10 36 00 00 	movq   $0x36,0x10(%rbx)
   6d8f8:	00 
   6d8f9:	eb c5                	jmp    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6d8fb:	f6 44 24 4c 01       	testb  $0x1,0x4c(%rsp)
   6d900:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   6d905:	0f 84 8d 00 00 00    	je     6d998 <varlit_core::native_layout::read_native_record_header+0x948>
   6d90b:	f6 44 24 48 01       	testb  $0x1,0x48(%rsp)
   6d910:	0f 84 a1 00 00 00    	je     6d9b7 <varlit_core::native_layout::read_native_record_header+0x967>
   6d916:	f6 44 24 44 01       	testb  $0x1,0x44(%rsp)
   6d91b:	0f 84 b5 00 00 00    	je     6d9d6 <varlit_core::native_layout::read_native_record_header+0x986>
   6d921:	f6 44 24 40 01       	testb  $0x1,0x40(%rsp)
   6d926:	0f 84 c9 00 00 00    	je     6d9f5 <varlit_core::native_layout::read_native_record_header+0x9a5>
   6d92c:	f6 44 24 3c 01       	testb  $0x1,0x3c(%rsp)
   6d931:	0f 84 ce 00 00 00    	je     6da05 <varlit_core::native_layout::read_native_record_header+0x9b5>
   6d937:	f6 44 24 38 01       	testb  $0x1,0x38(%rsp)
   6d93c:	0f 84 e2 00 00 00    	je     6da24 <varlit_core::native_layout::read_native_record_header+0x9d4>
   6d942:	f6 44 24 34 01       	testb  $0x1,0x34(%rsp)
   6d947:	0f 84 ea 00 00 00    	je     6da37 <varlit_core::native_layout::read_native_record_header+0x9e7>
   6d94d:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   6d952:	48 89 43 08          	mov    %rax,0x8(%rbx)
   6d956:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   6d95b:	48 89 43 10          	mov    %rax,0x10(%rbx)
   6d95f:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
   6d963:	89 43 18             	mov    %eax,0x18(%rbx)
   6d966:	8b 44 24 18          	mov    0x18(%rsp),%eax
   6d96a:	89 43 1c             	mov    %eax,0x1c(%rbx)
   6d96d:	8b 44 24 14          	mov    0x14(%rsp),%eax
   6d971:	89 43 20             	mov    %eax,0x20(%rbx)
   6d974:	8b 44 24 20          	mov    0x20(%rsp),%eax
   6d978:	66 89 43 24          	mov    %ax,0x24(%rbx)
   6d97c:	8b 44 24 24          	mov    0x24(%rsp),%eax
   6d980:	66 89 43 26          	mov    %ax,0x26(%rbx)
   6d984:	48 c7 43 28 20 00 00 	movq   $0x20,0x28(%rbx)
   6d98b:	00 
   6d98c:	48 83 c5 7c          	add    $0x7c,%rbp
   6d990:	48 89 2b             	mov    %rbp,(%rbx)
   6d993:	e9 28 ff ff ff       	jmp    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6d998:	48 83 c5 6b          	add    $0x6b,%rbp
   6d99c:	48 89 2b             	mov    %rbp,(%rbx)
   6d99f:	48 8d 05 22 c5 fa ff 	lea    -0x53ade(%rip),%rax        # 19ec8 <anon.96378bedfb121199e70b9883f72b5729.54.llvm.1968423816126862537>
   6d9a6:	48 89 43 08          	mov    %rax,0x8(%rbx)
   6d9aa:	48 c7 43 10 08 00 00 	movq   $0x8,0x10(%rbx)
   6d9b1:	00 
   6d9b2:	e9 09 ff ff ff       	jmp    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6d9b7:	48 83 c5 6b          	add    $0x6b,%rbp
   6d9bb:	48 89 2b             	mov    %rbp,(%rbx)
   6d9be:	48 8d 05 29 2b fb ff 	lea    -0x4d4d7(%rip),%rax        # 204ee <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x23ce>
   6d9c5:	48 89 43 08          	mov    %rax,0x8(%rbx)
   6d9c9:	48 c7 43 10 0d 00 00 	movq   $0xd,0x10(%rbx)
   6d9d0:	00 
   6d9d1:	e9 ea fe ff ff       	jmp    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6d9d6:	48 83 c5 6b          	add    $0x6b,%rbp
   6d9da:	48 89 2b             	mov    %rbp,(%rbx)
   6d9dd:	48 8d 05 ff 2a fb ff 	lea    -0x4d501(%rip),%rax        # 204e3 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x23c3>
   6d9e4:	48 89 43 08          	mov    %rax,0x8(%rbx)
   6d9e8:	48 c7 43 10 05 00 00 	movq   $0x5,0x10(%rbx)
   6d9ef:	00 
   6d9f0:	e9 cb fe ff ff       	jmp    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6d9f5:	48 83 c5 6b          	add    $0x6b,%rbp
   6d9f9:	48 89 2b             	mov    %rbp,(%rbx)
   6d9fc:	48 8d 05 7d c3 fa ff 	lea    -0x53c83(%rip),%rax        # 19d80 <anon.96378bedfb121199e70b9883f72b5729.57.llvm.1968423816126862537>
   6da03:	eb a1                	jmp    6d9a6 <varlit_core::native_layout::read_native_record_header+0x956>
   6da05:	48 83 c5 6b          	add    $0x6b,%rbp
   6da09:	48 89 2b             	mov    %rbp,(%rbx)
   6da0c:	48 8d 05 f4 2a fb ff 	lea    -0x4d50c(%rip),%rax        # 20507 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x23e7>
   6da13:	48 89 43 08          	mov    %rax,0x8(%rbx)
   6da17:	48 c7 43 10 0b 00 00 	movq   $0xb,0x10(%rbx)
   6da1e:	00 
   6da1f:	e9 9c fe ff ff       	jmp    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6da24:	48 83 c5 6b          	add    $0x6b,%rbp
   6da28:	48 89 2b             	mov    %rbp,(%rbx)
   6da2b:	48 8d 05 c6 c3 fa ff 	lea    -0x53c3a(%rip),%rax        # 19df8 <anon.96378bedfb121199e70b9883f72b5729.59.llvm.1968423816126862537>
   6da32:	e9 6f ff ff ff       	jmp    6d9a6 <varlit_core::native_layout::read_native_record_header+0x956>
   6da37:	48 83 c5 6b          	add    $0x6b,%rbp
   6da3b:	48 89 2b             	mov    %rbp,(%rbx)
   6da3e:	48 8d 05 cd 2a fb ff 	lea    -0x4d533(%rip),%rax        # 20512 <anon.448b402f6b485a5246de2a7255556581.6.llvm.3259275527870437861+0x23f2>
   6da45:	48 89 43 08          	mov    %rax,0x8(%rbx)
   6da49:	48 c7 43 10 15 00 00 	movq   $0x15,0x10(%rbx)
   6da50:	00 
   6da51:	e9 6a fe ff ff       	jmp    6d8c0 <varlit_core::native_layout::read_native_record_header+0x870>
   6da56:	cc                   	int3
   6da57:	cc                   	int3
   6da58:	cc                   	int3
   6da59:	cc                   	int3
   6da5a:	cc                   	int3
   6da5b:	cc                   	int3
   6da5c:	cc                   	int3
   6da5d:	cc                   	int3
   6da5e:	cc                   	int3
   6da5f:	cc                   	int3

