000000000007b690 <varlit_core::file::VarlitFile::mark_record_dead>:
   7b690:	55                   	push   %rbp
   7b691:	41 57                	push   %r15
   7b693:	41 56                	push   %r14
   7b695:	41 55                	push   %r13
   7b697:	41 54                	push   %r12
   7b699:	53                   	push   %rbx
   7b69a:	48 81 ec b8 03 00 00 	sub    $0x3b8,%rsp
   7b6a1:	48 89 fb             	mov    %rdi,%rbx
   7b6a4:	49 bc 7d 00 00 00 00 	movabs $0x800000000000007d,%r12
   7b6ab:	00 00 80 
   7b6ae:	49 8d 4c 24 be       	lea    -0x42(%r12),%rcx
   7b6b3:	48 8d 05 8a ec f9 ff 	lea    -0x61376(%rip),%rax        # 1a344 <anon.96378bedfb121199e70b9883f72b5729.63.llvm.1968423816126862537+0x8>
   7b6ba:	80 be 90 0d 00 00 00 	cmpb   $0x0,0xd90(%rsi)
   7b6c1:	0f 85 63 01 00 00    	jne    7b82a <varlit_core::file::VarlitFile::mark_record_dead+0x19a>
   7b6c7:	49 89 f6             	mov    %rsi,%r14
   7b6ca:	80 be 91 0d 00 00 00 	cmpb   $0x0,0xd91(%rsi)
   7b6d1:	0f 85 53 01 00 00    	jne    7b82a <varlit_core::file::VarlitFile::mark_record_dead+0x19a>
   7b6d7:	41 80 be 92 0d 00 00 	cmpb   $0x0,0xd92(%r14)
   7b6de:	00 
   7b6df:	0f 84 27 01 00 00    	je     7b80c <varlit_core::file::VarlitFile::mark_record_dead+0x17c>
   7b6e5:	41 80 be 92 02 00 00 	cmpb   $0x0,0x292(%r14)
   7b6ec:	00 
   7b6ed:	0f 84 63 01 00 00    	je     7b856 <varlit_core::file::VarlitFile::mark_record_dead+0x1c6>
   7b6f3:	49 8d ae 98 02 00 00 	lea    0x298(%r14),%rbp
   7b6fa:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7b701:	00 
   7b702:	48 89 ee             	mov    %rbp,%rsi
   7b705:	49 89 d5             	mov    %rdx,%r13
   7b708:	e8 03 7d 02 00       	call   a3410 <varlit_core::file::resident_index::ResidentIndex::has_verified_boundary>
   7b70d:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
   7b714:	00 
   7b715:	0f b6 84 24 28 01 00 	movzbl 0x128(%rsp),%eax
   7b71c:	00 
   7b71d:	4c 39 e1             	cmp    %r12,%rcx
   7b720:	0f 85 4c 01 00 00    	jne    7b872 <varlit_core::file::VarlitFile::mark_record_dead+0x1e2>
   7b726:	a8 01                	test   $0x1,%al
   7b728:	0f 84 70 01 00 00    	je     7b89e <varlit_core::file::VarlitFile::mark_record_dead+0x20e>
   7b72e:	41 0f b6 86 8d 02 00 	movzbl 0x28d(%r14),%eax
   7b735:	00 
   7b736:	88 44 24 10          	mov    %al,0x10(%rsp)
   7b73a:	41 0f b6 86 8e 02 00 	movzbl 0x28e(%r14),%eax
   7b741:	00 
   7b742:	88 44 24 78          	mov    %al,0x78(%rsp)
   7b746:	41 0f b6 86 8f 02 00 	movzbl 0x28f(%r14),%eax
   7b74d:	00 
   7b74e:	88 44 24 70          	mov    %al,0x70(%rsp)
   7b752:	41 0f b6 86 92 02 00 	movzbl 0x292(%r14),%eax
   7b759:	00 
   7b75a:	88 44 24 07          	mov    %al,0x7(%rsp)
   7b75e:	41 0f b6 86 97 02 00 	movzbl 0x297(%r14),%eax
   7b765:	00 
   7b766:	88 44 24 28          	mov    %al,0x28(%rsp)
   7b76a:	49 8b ae 28 0d 00 00 	mov    0xd28(%r14),%rbp
   7b771:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   7b778:	25 00 00 00 00 
   7b77d:	48 8b 88 20 ff ff ff 	mov    -0xe0(%rax),%rcx
   7b784:	48 ff c1             	inc    %rcx
   7b787:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
   7b78e:	48 0f 45 d1          	cmovne %rcx,%rdx
   7b792:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
   7b799:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7b7a0:	00 
   7b7a1:	41 bf 00 02 00 00    	mov    $0x200,%r15d
   7b7a7:	ba 00 02 00 00       	mov    $0x200,%edx
   7b7ac:	31 f6                	xor    %esi,%esi
   7b7ae:	ff 15 8c 0b 15 00    	call   *0x150b8c(%rip)        # 1cc340 <memset@GLIBC_2.2.5>
   7b7b4:	48 89 e8             	mov    %rbp,%rax
   7b7b7:	4c 29 e8             	sub    %r13,%rax
   7b7ba:	b9 00 00 00 00       	mov    $0x0,%ecx
   7b7bf:	48 0f 43 c8          	cmovae %rax,%rcx
   7b7c3:	48 83 f9 21          	cmp    $0x21,%rcx
   7b7c7:	4c 89 ea             	mov    %r13,%rdx
   7b7ca:	41 bd 20 00 00 00    	mov    $0x20,%r13d
   7b7d0:	4c 0f 43 e9          	cmovae %rcx,%r13
   7b7d4:	49 81 fd 00 02 00 00 	cmp    $0x200,%r13
   7b7db:	4d 0f 43 ef          	cmovae %r15,%r13
   7b7df:	49 8d 44 24 98       	lea    -0x68(%r12),%rax
   7b7e4:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   7b7e9:	4c 89 e8             	mov    %r13,%rax
   7b7ec:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   7b7f1:	48 01 d0             	add    %rdx,%rax
   7b7f4:	0f 82 07 07 00 00    	jb     7bf01 <varlit_core::file::VarlitFile::mark_record_dead+0x871>
   7b7fa:	48 39 e8             	cmp    %rbp,%rax
   7b7fd:	0f 86 dc 00 00 00    	jbe    7b8df <varlit_core::file::VarlitFile::mark_record_dead+0x24f>
   7b803:	49 83 c4 9a          	add    $0xffffffffffffff9a,%r12
   7b807:	e9 17 03 00 00       	jmp    7bb23 <varlit_core::file::VarlitFile::mark_record_dead+0x493>
   7b80c:	48 8d 35 ac 6a fa ff 	lea    -0x59554(%rip),%rsi        # 222bf <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1920>
   7b813:	ba 19 00 00 00       	mov    $0x19,%edx
   7b818:	bf 01 00 00 00       	mov    $0x1,%edi
   7b81d:	ff 15 85 0f 15 00    	call   *0x150f85(%rip)        # 1cc7a8 <_DYNAMIC+0x7b0>
   7b823:	49 83 c4 89          	add    $0xffffffffffffff89,%r12
   7b827:	4c 89 e1             	mov    %r12,%rcx
   7b82a:	48 89 0b             	mov    %rcx,(%rbx)
   7b82d:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7b831:	48 c7 43 10 04 00 00 	movq   $0x4,0x10(%rbx)
   7b838:	00 
   7b839:	48 c7 43 18 04 00 00 	movq   $0x4,0x18(%rbx)
   7b840:	00 
   7b841:	48 89 d8             	mov    %rbx,%rax
   7b844:	48 81 c4 b8 03 00 00 	add    $0x3b8,%rsp
   7b84b:	5b                   	pop    %rbx
   7b84c:	41 5c                	pop    %r12
   7b84e:	41 5d                	pop    %r13
   7b850:	41 5e                	pop    %r14
   7b852:	41 5f                	pop    %r15
   7b854:	5d                   	pop    %rbp
   7b855:	c3                   	ret
   7b856:	49 83 c4 a1          	add    $0xffffffffffffffa1,%r12
   7b85a:	4c 89 23             	mov    %r12,(%rbx)
   7b85d:	48 8d 05 37 6b fa ff 	lea    -0x594c9(%rip),%rax        # 2239b <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x19fc>
   7b864:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7b868:	48 c7 43 10 30 00 00 	movq   $0x30,0x10(%rbx)
   7b86f:	00 
   7b870:	eb cf                	jmp    7b841 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7b872:	0f 10 84 24 29 01 00 	movups 0x129(%rsp),%xmm0
   7b879:	00 
   7b87a:	0f 10 8c 24 39 01 00 	movups 0x139(%rsp),%xmm1
   7b881:	00 
   7b882:	0f 10 94 24 48 01 00 	movups 0x148(%rsp),%xmm2
   7b889:	00 
   7b88a:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
   7b88e:	0f 11 4b 19          	movups %xmm1,0x19(%rbx)
   7b892:	0f 11 43 09          	movups %xmm0,0x9(%rbx)
   7b896:	48 89 0b             	mov    %rcx,(%rbx)
   7b899:	88 43 08             	mov    %al,0x8(%rbx)
   7b89c:	eb a3                	jmp    7b841 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7b89e:	41 83 be 28 09 00 00 	cmpl   $0x2,0x928(%r14)
   7b8a5:	02 
   7b8a6:	0f 85 d8 00 00 00    	jne    7b984 <varlit_core::file::VarlitFile::mark_record_dead+0x2f4>
   7b8ac:	4d 8b be a8 0b 00 00 	mov    0xba8(%r14),%r15
   7b8b3:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7b8ba:	00 
   7b8bb:	ba 98 02 00 00       	mov    $0x298,%edx
   7b8c0:	4c 89 f6             	mov    %r14,%rsi
   7b8c3:	ff 15 37 0a 15 00    	call   *0x150a37(%rip)        # 1cc300 <memcpy@GLIBC_2.14>
   7b8c9:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7b8d0:	00 
   7b8d1:	4c 89 fe             	mov    %r15,%rsi
   7b8d4:	ff 15 ae 0b 15 00    	call   *0x150bae(%rip)        # 1cc488 <_DYNAMIC+0x490>
   7b8da:	e9 ac 00 00 00       	jmp    7b98b <varlit_core::file::VarlitFile::mark_record_dead+0x2fb>
   7b8df:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   7b8e4:	49 8d 86 20 0d 00 00 	lea    0xd20(%r14),%rax
   7b8eb:	48 8b 00             	mov    (%rax),%rax
   7b8ee:	48 83 c0 08          	add    $0x8,%rax
   7b8f2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   7b8f7:	31 ed                	xor    %ebp,%ebp
   7b8f9:	49 8d 44 24 89       	lea    -0x77(%r12),%rax
   7b8fe:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   7b905:	00 
   7b906:	49 8d 44 24 8e       	lea    -0x72(%r12),%rax
   7b90b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   7b912:	00 
   7b913:	eb 14                	jmp    7b929 <varlit_core::file::VarlitFile::mark_record_dead+0x299>
   7b915:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   7b91c:	00 00 00 00 
   7b920:	4c 39 ed             	cmp    %r13,%rbp
   7b923:	0f 83 09 01 00 00    	jae    7ba32 <varlit_core::file::VarlitFile::mark_record_dead+0x3a2>
   7b929:	48 89 e9             	mov    %rbp,%rcx
   7b92c:	48 03 4c 24 08       	add    0x8(%rsp),%rcx
   7b931:	0f 82 80 05 00 00    	jb     7beb7 <varlit_core::file::VarlitFile::mark_record_dead+0x827>
   7b937:	4c 89 ea             	mov    %r13,%rdx
   7b93a:	48 29 ea             	sub    %rbp,%rdx
   7b93d:	48 8d 34 2c          	lea    (%rsp,%rbp,1),%rsi
   7b941:	48 81 c6 20 01 00 00 	add    $0x120,%rsi
   7b948:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   7b94d:	ff 15 0d 0f 15 00    	call   *0x150f0d(%rip)        # 1cc860 <_DYNAMIC+0x868>
   7b953:	49 89 d7             	mov    %rdx,%r15
   7b956:	48 83 f8 01          	cmp    $0x1,%rax
   7b95a:	75 1a                	jne    7b976 <varlit_core::file::VarlitFile::mark_record_dead+0x2e6>
   7b95c:	4c 89 ff             	mov    %r15,%rdi
   7b95f:	e8 1c 92 04 00       	call   c4b80 <<std::io::error::Error>::kind>
   7b964:	3c 23                	cmp    $0x23,%al
   7b966:	0f 85 9f 01 00 00    	jne    7bb0b <varlit_core::file::VarlitFile::mark_record_dead+0x47b>
   7b96c:	4c 89 ff             	mov    %r15,%rdi
   7b96f:	e8 0c d6 04 00       	call   c8f80 <core::ptr::drop_in_place<std::io::error::Error>>
   7b974:	eb aa                	jmp    7b920 <varlit_core::file::VarlitFile::mark_record_dead+0x290>
   7b976:	4d 85 ff             	test   %r15,%r15
   7b979:	0f 84 82 01 00 00    	je     7bb01 <varlit_core::file::VarlitFile::mark_record_dead+0x471>
   7b97f:	4c 01 fd             	add    %r15,%rbp
   7b982:	eb 9c                	jmp    7b920 <varlit_core::file::VarlitFile::mark_record_dead+0x290>
   7b984:	49 8b 86 f8 0a 00 00 	mov    0xaf8(%r14),%rax
   7b98b:	4c 89 e9             	mov    %r13,%rcx
   7b98e:	49 39 c5             	cmp    %rax,%r13
   7b991:	72 2c                	jb     7b9bf <varlit_core::file::VarlitFile::mark_record_dead+0x32f>
   7b993:	49 3b 8e a8 08 00 00 	cmp    0x8a8(%r14),%rcx
   7b99a:	73 23                	jae    7b9bf <varlit_core::file::VarlitFile::mark_record_dead+0x32f>
   7b99c:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7b9a3:	00 
   7b9a4:	48 89 ee             	mov    %rbp,%rsi
   7b9a7:	48 89 c2             	mov    %rax,%rdx
   7b9aa:	e8 91 71 02 00       	call   a2b40 <varlit_core::file::resident_index::ResidentIndex::extend_boundary_proof>
   7b9af:	4c 39 a4 24 20 01 00 	cmp    %r12,0x120(%rsp)
   7b9b6:	00 
   7b9b7:	0f 84 71 fd ff ff    	je     7b72e <varlit_core::file::VarlitFile::mark_record_dead+0x9e>
   7b9bd:	eb 27                	jmp    7b9e6 <varlit_core::file::VarlitFile::mark_record_dead+0x356>
   7b9bf:	49 83 c4 94          	add    $0xffffffffffffff94,%r12
   7b9c3:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
   7b9ca:	00 
   7b9cb:	48 8d 05 3a 83 fa ff 	lea    -0x57cc6(%rip),%rax        # 23d0c <anon.f589ecdd4f47334859919181fed1dd71.38.llvm.6437030484243405186>
   7b9d2:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
   7b9d9:	00 
   7b9da:	48 c7 84 24 30 01 00 	movq   $0x26,0x130(%rsp)
   7b9e1:	00 26 00 00 00 
   7b9e6:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   7b9ed:	00 
   7b9ee:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7b9f2:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
   7b9f9:	00 
   7b9fa:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
   7ba01:	00 
   7ba02:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
   7ba09:	00 
   7ba0a:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
   7ba11:	00 
   7ba12:	0f 10 84 24 40 01 00 	movups 0x140(%rsp),%xmm0
   7ba19:	00 
   7ba1a:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   7ba1e:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   7ba22:	48 89 73 18          	mov    %rsi,0x18(%rbx)
   7ba26:	48 89 03             	mov    %rax,(%rbx)
   7ba29:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   7ba2d:	e9 0f fe ff ff       	jmp    7b841 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7ba32:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
   7ba39:	00 
   7ba3a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   7ba41:	00 
   7ba42:	48 c7 84 24 98 00 00 	movq   $0x20,0x98(%rsp)
   7ba49:	00 20 00 00 00 
   7ba4e:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   7ba53:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   7ba5a:	00 
   7ba5b:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
   7ba60:	48 89 ea             	mov    %rbp,%rdx
   7ba63:	e8 38 f0 05 00       	call   daaa0 <varlit_core::native_layout::read_native_record_header>
   7ba68:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   7ba6d:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   7ba72:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
   7ba77:	8b 44 24 50          	mov    0x50(%rsp),%eax
   7ba7b:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   7ba80:	44 8b 7c 24 54       	mov    0x54(%rsp),%r15d
   7ba85:	8b 44 24 58          	mov    0x58(%rsp),%eax
   7ba89:	89 44 24 20          	mov    %eax,0x20(%rsp)
   7ba8d:	44 0f b7 5c 24 5c    	movzwl 0x5c(%rsp),%r11d
   7ba93:	0f b7 7c 24 5e       	movzwl 0x5e(%rsp),%edi
   7ba98:	4c 39 e2             	cmp    %r12,%rdx
   7ba9b:	0f 85 e6 00 00 00    	jne    7bb87 <varlit_core::file::VarlitFile::mark_record_dead+0x4f7>
   7baa1:	49 8d 54 24 98       	lea    -0x68(%r12),%rdx
   7baa6:	48 83 fd df          	cmp    $0xffffffffffffffdf,%rbp
   7baaa:	0f 87 65 04 00 00    	ja     7bf15 <varlit_core::file::VarlitFile::mark_record_dead+0x885>
   7bab0:	48 83 c5 20          	add    $0x20,%rbp
   7bab4:	80 7c 24 28 02       	cmpb   $0x2,0x28(%rsp)
   7bab9:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
   7babe:	0f 85 e2 00 00 00    	jne    7bba6 <varlit_core::file::VarlitFile::mark_record_dead+0x516>
   7bac4:	0f b6 44 24 78       	movzbl 0x78(%rsp),%eax
   7bac9:	38 44 24 10          	cmp    %al,0x10(%rsp)
   7bacd:	0f 85 d3 00 00 00    	jne    7bba6 <varlit_core::file::VarlitFile::mark_record_dead+0x516>
   7bad3:	f6 44 24 10 01       	testb  $0x1,0x10(%rsp)
   7bad8:	0f 85 c8 00 00 00    	jne    7bba6 <varlit_core::file::VarlitFile::mark_record_dead+0x516>
   7bade:	f6 44 24 70 01       	testb  $0x1,0x70(%rsp)
   7bae3:	0f 85 bd 00 00 00    	jne    7bba6 <varlit_core::file::VarlitFile::mark_record_dead+0x516>
   7bae9:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
   7baee:	31 c0                	xor    %eax,%eax
   7baf0:	31 c9                	xor    %ecx,%ecx
   7baf2:	31 f6                	xor    %esi,%esi
   7baf4:	45 31 c9             	xor    %r9d,%r9d
   7baf7:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
   7bafc:	e9 b3 01 00 00       	jmp    7bcb4 <varlit_core::file::VarlitFile::mark_record_dead+0x624>
   7bb01:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
   7bb08:	00 
   7bb09:	eb 0d                	jmp    7bb18 <varlit_core::file::VarlitFile::mark_record_dead+0x488>
   7bb0b:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
   7bb12:	00 
   7bb13:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   7bb18:	41 bd 14 00 00 00    	mov    $0x14,%r13d
   7bb1e:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   7bb23:	49 89 ef             	mov    %rbp,%r15
   7bb26:	49 c1 ef 20          	shr    $0x20,%r15
   7bb2a:	48 89 ee             	mov    %rbp,%rsi
   7bb2d:	31 ff                	xor    %edi,%edi
   7bb2f:	45 31 db             	xor    %r11d,%r11d
   7bb32:	4d 89 e8             	mov    %r13,%r8
   7bb35:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
   7bb3a:	45 31 c9             	xor    %r9d,%r9d
   7bb3d:	49 c1 e7 20          	shl    $0x20,%r15
   7bb41:	89 f1                	mov    %esi,%ecx
   7bb43:	4c 09 f9             	or     %r15,%rcx
   7bb46:	0f b7 d7             	movzwl %di,%edx
   7bb49:	48 c1 e2 30          	shl    $0x30,%rdx
   7bb4d:	41 0f b7 f3          	movzwl %r11w,%esi
   7bb51:	48 c1 e6 20          	shl    $0x20,%rsi
   7bb55:	48 09 d6             	or     %rdx,%rsi
   7bb58:	89 ea                	mov    %ebp,%edx
   7bb5a:	48 09 f2             	or     %rsi,%rdx
   7bb5d:	49 c1 e1 20          	shl    $0x20,%r9
   7bb61:	44 89 f6             	mov    %r14d,%esi
   7bb64:	4c 09 ce             	or     %r9,%rsi
   7bb67:	4c 89 23             	mov    %r12,(%rbx)
   7bb6a:	4c 89 53 08          	mov    %r10,0x8(%rbx)
   7bb6e:	4c 89 43 10          	mov    %r8,0x10(%rbx)
   7bb72:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
   7bb76:	48 89 53 20          	mov    %rdx,0x20(%rbx)
   7bb7a:	48 89 73 28          	mov    %rsi,0x28(%rbx)
   7bb7e:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7bb82:	e9 ba fc ff ff       	jmp    7b841 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7bb87:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
   7bb8c:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   7bb91:	4d 89 f1             	mov    %r14,%r9
   7bb94:	49 c1 e9 20          	shr    $0x20,%r9
   7bb98:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   7bb9d:	49 89 d4             	mov    %rdx,%r12
   7bba0:	8b 6c 24 20          	mov    0x20(%rsp),%ebp
   7bba4:	eb 97                	jmp    7bb3d <varlit_core::file::VarlitFile::mark_record_dead+0x4ad>
   7bba6:	4c 89 c1             	mov    %r8,%rcx
   7bba9:	48 01 e9             	add    %rbp,%rcx
   7bbac:	0f 82 72 03 00 00    	jb     7bf24 <varlit_core::file::VarlitFile::mark_record_dead+0x894>
   7bbb2:	4c 89 5c 24 78       	mov    %r11,0x78(%rsp)
   7bbb7:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
   7bbbc:	4c 89 44 24 70       	mov    %r8,0x70(%rsp)
   7bbc1:	0f 57 c0             	xorps  %xmm0,%xmm0
   7bbc4:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   7bbcb:	00 
   7bbcc:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   7bbd3:	00 
   7bbd4:	48 89 c8             	mov    %rcx,%rax
   7bbd7:	48 2b 44 24 08       	sub    0x8(%rsp),%rax
   7bbdc:	48 89 c2             	mov    %rax,%rdx
   7bbdf:	48 83 ea e0          	sub    $0xffffffffffffffe0,%rdx
   7bbe3:	73 17                	jae    7bbfc <varlit_core::file::VarlitFile::mark_record_dead+0x56c>
   7bbe5:	4c 39 ea             	cmp    %r13,%rdx
   7bbe8:	77 12                	ja     7bbfc <varlit_core::file::VarlitFile::mark_record_dead+0x56c>
   7bbea:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
   7bbef:	48 8d 34 04          	lea    (%rsp,%rax,1),%rsi
   7bbf3:	48 81 c6 20 01 00 00 	add    $0x120,%rsi
   7bbfa:	eb 47                	jmp    7bc43 <varlit_core::file::VarlitFile::mark_record_dead+0x5b3>
   7bbfc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   7bc01:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
   7bc08:	00 
   7bc09:	41 b8 20 00 00 00    	mov    $0x20,%r8d
   7bc0f:	49 8d b6 20 0d 00 00 	lea    0xd20(%r14),%rsi
   7bc16:	49 89 cd             	mov    %rcx,%r13
   7bc19:	48 89 ca             	mov    %rcx,%rdx
   7bc1c:	48 89 c1             	mov    %rax,%rcx
   7bc1f:	ff 15 2b 0c 15 00    	call   *0x150c2b(%rip)        # 1cc850 <_DYNAMIC+0x858>
   7bc25:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   7bc2a:	4c 39 e0             	cmp    %r12,%rax
   7bc2d:	0f 85 ba 01 00 00    	jne    7bded <varlit_core::file::VarlitFile::mark_record_dead+0x75d>
   7bc33:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
   7bc38:	4c 89 e9             	mov    %r13,%rcx
   7bc3b:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   7bc42:	00 
   7bc43:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   7bc48:	ba 20 00 00 00       	mov    $0x20,%edx
   7bc4d:	48 89 cd             	mov    %rcx,%rbp
   7bc50:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
   7bc55:	4d 89 e8             	mov    %r13,%r8
   7bc58:	e8 03 f7 05 00       	call   db360 <varlit_core::native_layout::decode_native_record_footer>
   7bc5d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   7bc62:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   7bc67:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   7bc6c:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   7bc71:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   7bc76:	44 8b 54 24 60       	mov    0x60(%rsp),%r10d
   7bc7b:	4c 39 e0             	cmp    %r12,%rax
   7bc7e:	0f 85 2c 01 00 00    	jne    7bdb0 <varlit_core::file::VarlitFile::mark_record_dead+0x720>
   7bc84:	45 85 d2             	test   %r10d,%r10d
   7bc87:	0f 94 c0             	sete   %al
   7bc8a:	44 0f b6 44 24 07    	movzbl 0x7(%rsp),%r8d
   7bc90:	41 08 c0             	or     %al,%r8b
   7bc93:	41 f6 c0 01          	test   $0x1,%r8b
   7bc97:	0f 84 7d 01 00 00    	je     7be1a <varlit_core::file::VarlitFile::mark_record_dead+0x78a>
   7bc9d:	4d 89 d1             	mov    %r10,%r9
   7bca0:	b8 01 00 00 00       	mov    $0x1,%eax
   7bca5:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
   7bcaa:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
   7bcaf:	4c 8b 5c 24 78       	mov    0x78(%rsp),%r11
   7bcb4:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   7bcb9:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   7bcc0:	00 
   7bcc1:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
   7bcc6:	48 89 ac 24 c0 00 00 	mov    %rbp,0xc0(%rsp)
   7bccd:	00 
   7bcce:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
   7bcd5:	00 
   7bcd6:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
   7bcdd:	00 
   7bcde:	48 89 b4 24 d8 00 00 	mov    %rsi,0xd8(%rsp)
   7bce5:	00 
   7bce6:	48 89 bc 24 e0 00 00 	mov    %rdi,0xe0(%rsp)
   7bced:	00 
   7bcee:	4c 89 94 24 e8 00 00 	mov    %r10,0xe8(%rsp)
   7bcf5:	00 
   7bcf6:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
   7bcfd:	00 
   7bcfe:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   7bd03:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
   7bd0a:	00 
   7bd0b:	4c 89 84 24 00 01 00 	mov    %r8,0x100(%rsp)
   7bd12:	00 
   7bd13:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
   7bd18:	44 89 ac 24 08 01 00 	mov    %r13d,0x108(%rsp)
   7bd1f:	00 
   7bd20:	44 89 bc 24 0c 01 00 	mov    %r15d,0x10c(%rsp)
   7bd27:	00 
   7bd28:	8b 44 24 20          	mov    0x20(%rsp),%eax
   7bd2c:	89 84 24 10 01 00 00 	mov    %eax,0x110(%rsp)
   7bd33:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
   7bd38:	44 89 8c 24 14 01 00 	mov    %r9d,0x114(%rsp)
   7bd3f:	00 
   7bd40:	66 44 89 9c 24 18 01 	mov    %r11w,0x118(%rsp)
   7bd47:	00 00 
   7bd49:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   7bd4e:	66 89 84 24 1a 01 00 	mov    %ax,0x11a(%rsp)
   7bd55:	00 
   7bd56:	c6 84 24 1c 01 00 00 	movb   $0x0,0x11c(%rsp)
   7bd5d:	00 
   7bd5e:	4c 8d bc 24 20 01 00 	lea    0x120(%rsp),%r15
   7bd65:	00 
   7bd66:	ba 98 02 00 00       	mov    $0x298,%edx
   7bd6b:	4c 89 ff             	mov    %r15,%rdi
   7bd6e:	4c 89 f6             	mov    %r14,%rsi
   7bd71:	ff 15 89 05 15 00    	call   *0x150589(%rip)        # 1cc300 <memcpy@GLIBC_2.14>
   7bd77:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   7bd7c:	48 8d 94 24 b8 00 00 	lea    0xb8(%rsp),%rdx
   7bd83:	00 
   7bd84:	4c 89 fe             	mov    %r15,%rsi
   7bd87:	e8 34 65 00 00       	call   822c0 <varlit_core::file::header_codec::validate_record_entry>
   7bd8c:	4c 39 64 24 38       	cmp    %r12,0x38(%rsp)
   7bd91:	75 32                	jne    7bdc5 <varlit_core::file::VarlitFile::mark_record_dead+0x735>
   7bd93:	41 81 fd ff fe ff ff 	cmp    $0xfffffeff,%r13d
   7bd9a:	0f 86 a6 00 00 00    	jbe    7be46 <varlit_core::file::VarlitFile::mark_record_dead+0x7b6>
   7bda0:	49 83 c4 9f          	add    $0xffffffffffffff9f,%r12
   7bda4:	4c 89 23             	mov    %r12,(%rbx)
   7bda7:	44 89 6b 08          	mov    %r13d,0x8(%rbx)
   7bdab:	e9 91 fa ff ff       	jmp    7b841 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7bdb0:	49 89 c0             	mov    %rax,%r8
   7bdb3:	44 8b 4c 24 64       	mov    0x64(%rsp),%r9d
   7bdb8:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   7bdbd:	4d 89 c4             	mov    %r8,%r12
   7bdc0:	4d 89 d6             	mov    %r10,%r14
   7bdc3:	eb 5c                	jmp    7be21 <varlit_core::file::VarlitFile::mark_record_dead+0x791>
   7bdc5:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   7bdca:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7bdce:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
   7bdd3:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
   7bdd8:	0f 10 54 24 58       	movups 0x58(%rsp),%xmm2
   7bddd:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
   7bde1:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
   7bde5:	0f 11 03             	movups %xmm0,(%rbx)
   7bde8:	e9 54 fa ff ff       	jmp    7b841 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7bded:	49 89 c0             	mov    %rax,%r8
   7bdf0:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   7bdf5:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   7bdfa:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   7bdff:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   7be04:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
   7be09:	4d 89 f1             	mov    %r14,%r9
   7be0c:	49 c1 e9 20          	shr    $0x20,%r9
   7be10:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   7be15:	4d 89 c4             	mov    %r8,%r12
   7be18:	eb 07                	jmp    7be21 <varlit_core::file::VarlitFile::mark_record_dead+0x791>
   7be1a:	49 83 c4 b3          	add    $0xffffffffffffffb3,%r12
   7be1e:	48 89 e9             	mov    %rbp,%rcx
   7be21:	49 89 fb             	mov    %rdi,%r11
   7be24:	49 c1 eb 20          	shr    $0x20,%r11
   7be28:	49 89 f8             	mov    %rdi,%r8
   7be2b:	49 c1 e8 30          	shr    $0x30,%r8
   7be2f:	49 89 f7             	mov    %rsi,%r15
   7be32:	49 c1 ef 20          	shr    $0x20,%r15
   7be36:	89 fd                	mov    %edi,%ebp
   7be38:	4c 89 c7             	mov    %r8,%rdi
   7be3b:	49 89 d0             	mov    %rdx,%r8
   7be3e:	49 89 ca             	mov    %rcx,%r10
   7be41:	e9 f7 fc ff ff       	jmp    7bb3d <varlit_core::file::VarlitFile::mark_record_dead+0x4ad>
   7be46:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
   7be4c:	74 4a                	je     7be98 <varlit_core::file::VarlitFile::mark_record_dead+0x808>
   7be4e:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   7be53:	48 83 fa e3          	cmp    $0xffffffffffffffe3,%rdx
   7be57:	0f 87 dc 00 00 00    	ja     7bf39 <varlit_core::file::VarlitFile::mark_record_dead+0x8a9>
   7be5d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   7be62:	89 c1                	mov    %eax,%ecx
   7be64:	83 c9 01             	or     $0x1,%ecx
   7be67:	39 c1                	cmp    %eax,%ecx
   7be69:	74 25                	je     7be90 <varlit_core::file::VarlitFile::mark_record_dead+0x800>
   7be6b:	48 83 c2 1c          	add    $0x1c,%rdx
   7be6f:	49 81 c6 e0 0b 00 00 	add    $0xbe0,%r14
   7be76:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   7be7d:	00 
   7be7e:	4c 89 f6             	mov    %r14,%rsi
   7be81:	e8 fa 2e 03 00       	call   aed80 <varlit_core::file::record_file::RecordFile::overwrite_record_mutable_flags>
   7be86:	4c 39 a4 24 20 01 00 	cmp    %r12,0x120(%rsp)
   7be8d:	00 
   7be8e:	75 48                	jne    7bed8 <varlit_core::file::VarlitFile::mark_record_dead+0x848>
   7be90:	4c 89 23             	mov    %r12,(%rbx)
   7be93:	e9 a9 f9 ff ff       	jmp    7b841 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7be98:	49 83 c4 a1          	add    $0xffffffffffffffa1,%r12
   7be9c:	4c 89 23             	mov    %r12,(%rbx)
   7be9f:	48 8d 05 39 65 fa ff 	lea    -0x59ac7(%rip),%rax        # 223df <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a40>
   7bea6:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7beaa:	48 c7 43 10 29 00 00 	movq   $0x29,0x10(%rbx)
   7beb1:	00 
   7beb2:	e9 8a f9 ff ff       	jmp    7b841 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7beb7:	48 8d 05 37 9f fa ff 	lea    -0x560c9(%rip),%rax        # 25df5 <anon.44dfe6286d6883d57c2709f00721256e.111.llvm.7670212196679453716>
   7bebe:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   7bec3:	41 bd 14 00 00 00    	mov    $0x14,%r13d
   7bec9:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   7bece:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
   7bed3:	e9 4b fc ff ff       	jmp    7bb23 <varlit_core::file::VarlitFile::mark_record_dead+0x493>
   7bed8:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   7bedf:	00 
   7bee0:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7bee4:	0f 10 84 24 20 01 00 	movups 0x120(%rsp),%xmm0
   7beeb:	00 
   7beec:	0f 10 8c 24 30 01 00 	movups 0x130(%rsp),%xmm1
   7bef3:	00 
   7bef4:	0f 10 94 24 40 01 00 	movups 0x140(%rsp),%xmm2
   7befb:	00 
   7befc:	e9 dc fe ff ff       	jmp    7bddd <varlit_core::file::VarlitFile::mark_record_dead+0x74d>
   7bf01:	41 bd 0e 00 00 00    	mov    $0xe,%r13d
   7bf07:	48 8d 05 10 9e fa ff 	lea    -0x561f0(%rip),%rax        # 25d1e <anon.44dfe6286d6883d57c2709f00721256e.28.llvm.7670212196679453716>
   7bf0e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   7bf13:	eb b9                	jmp    7bece <varlit_core::file::VarlitFile::mark_record_dead+0x83e>
   7bf15:	4c 8d 15 48 66 fa ff 	lea    -0x599b8(%rip),%r10        # 22564 <anon.48385641d07dc56499de4af04e4ddc4c.132.llvm.15324202487898183613+0x22>
   7bf1c:	41 b8 15 00 00 00    	mov    $0x15,%r8d
   7bf22:	eb 0d                	jmp    7bf31 <varlit_core::file::VarlitFile::mark_record_dead+0x8a1>
   7bf24:	4c 8d 15 a0 64 fa ff 	lea    -0x59b60(%rip),%r10        # 223cb <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a2c>
   7bf2b:	41 b8 14 00 00 00    	mov    $0x14,%r8d
   7bf31:	49 89 d4             	mov    %rdx,%r12
   7bf34:	e9 04 fc ff ff       	jmp    7bb3d <varlit_core::file::VarlitFile::mark_record_dead+0x4ad>
   7bf39:	49 83 c4 98          	add    $0xffffffffffffff98,%r12
   7bf3d:	4c 89 23             	mov    %r12,(%rbx)
   7bf40:	48 8d 05 84 64 fa ff 	lea    -0x59b7c(%rip),%rax        # 223cb <anon.a0ff4f46869377479ad462f429370715.5.llvm.5402889094323598768+0x1a2c>
   7bf47:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7bf4b:	48 c7 43 10 14 00 00 	movq   $0x14,0x10(%rbx)
   7bf52:	00 
   7bf53:	e9 e9 f8 ff ff       	jmp    7b841 <varlit_core::file::VarlitFile::mark_record_dead+0x1b1>
   7bf58:	cc                   	int3
   7bf59:	cc                   	int3
   7bf5a:	cc                   	int3
   7bf5b:	cc                   	int3
   7bf5c:	cc                   	int3
   7bf5d:	cc                   	int3
   7bf5e:	cc                   	int3
   7bf5f:	cc                   	int3

