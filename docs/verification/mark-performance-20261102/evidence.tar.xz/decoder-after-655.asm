00000000000c8bc0 <varlit_core::snapshot::SnapshotFile::read_exact_at>:
   c8bc0:	55                   	push   %rbp
   c8bc1:	41 57                	push   %r15
   c8bc3:	41 56                	push   %r14
   c8bc5:	41 55                	push   %r13
   c8bc7:	41 54                	push   %r12
   c8bc9:	53                   	push   %rbx
   c8bca:	50                   	push   %rax
   c8bcb:	49 89 cc             	mov    %rcx,%r12
   c8bce:	49 89 d7             	mov    %rdx,%r15
   c8bd1:	48 ba 15 00 00 00 00 	movabs $0x8000000000000015,%rdx
   c8bd8:	00 00 80 
   c8bdb:	48 8b 46 08          	mov    0x8(%rsi),%rax
   c8bdf:	4c 89 c1             	mov    %r8,%rcx
   c8be2:	4c 01 f9             	add    %r15,%rcx
   c8be5:	0f 82 07 01 00 00    	jb     c8cf2 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x132>
   c8beb:	4d 89 c6             	mov    %r8,%r14
   c8bee:	48 39 c1             	cmp    %rax,%rcx
   c8bf1:	76 18                	jbe    c8c0b <varlit_core::snapshot::SnapshotFile::read_exact_at+0x4b>
   c8bf3:	48 83 c2 02          	add    $0x2,%rdx
   c8bf7:	48 89 17             	mov    %rdx,(%rdi)
   c8bfa:	4c 89 7f 08          	mov    %r15,0x8(%rdi)
   c8bfe:	4c 89 77 10          	mov    %r14,0x10(%rdi)
   c8c02:	48 89 47 18          	mov    %rax,0x18(%rdi)
   c8c06:	e9 84 00 00 00       	jmp    c8c8f <varlit_core::snapshot::SnapshotFile::read_exact_at+0xcf>
   c8c0b:	48 89 3c 24          	mov    %rdi,(%rsp)
   c8c0f:	4d 85 f6             	test   %r14,%r14
   c8c12:	74 66                	je     c8c7a <varlit_core::snapshot::SnapshotFile::read_exact_at+0xba>
   c8c14:	4c 8b 2e             	mov    (%rsi),%r13
   c8c17:	49 83 c5 08          	add    $0x8,%r13
   c8c1b:	31 db                	xor    %ebx,%ebx
   c8c1d:	eb 06                	jmp    c8c25 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x65>
   c8c1f:	90                   	nop
   c8c20:	4c 39 f3             	cmp    %r14,%rbx
   c8c23:	73 55                	jae    c8c7a <varlit_core::snapshot::SnapshotFile::read_exact_at+0xba>
   c8c25:	48 89 d9             	mov    %rbx,%rcx
   c8c28:	4c 01 f9             	add    %r15,%rcx
   c8c2b:	0f 82 9b 00 00 00    	jb     c8ccc <varlit_core::snapshot::SnapshotFile::read_exact_at+0x10c>
   c8c31:	4c 89 f2             	mov    %r14,%rdx
   c8c34:	48 29 da             	sub    %rbx,%rdx
   c8c37:	49 8d 34 1c          	lea    (%r12,%rbx,1),%rsi
   c8c3b:	4c 89 ef             	mov    %r13,%rdi
   c8c3e:	ff 15 1c 3c 10 00    	call   *0x103c1c(%rip)        # 1cc860 <_DYNAMIC+0x868>
   c8c44:	48 89 d5             	mov    %rdx,%rbp
   c8c47:	48 83 f8 01          	cmp    $0x1,%rax
   c8c4b:	75 23                	jne    c8c70 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xb0>
   c8c4d:	48 89 ef             	mov    %rbp,%rdi
   c8c50:	e8 2b bf ff ff       	call   c4b80 <<std::io::error::Error>::kind>
   c8c55:	3c 23                	cmp    $0x23,%al
   c8c57:	75 58                	jne    c8cb1 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xf1>
   c8c59:	48 89 ef             	mov    %rbp,%rdi
   c8c5c:	e8 1f 03 00 00       	call   c8f80 <core::ptr::drop_in_place<std::io::error::Error>>
   c8c61:	eb bd                	jmp    c8c20 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x60>
   c8c63:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   c8c6a:	84 00 00 00 00 00 
   c8c70:	48 85 ed             	test   %rbp,%rbp
   c8c73:	74 2c                	je     c8ca1 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xe1>
   c8c75:	48 01 eb             	add    %rbp,%rbx
   c8c78:	eb a6                	jmp    c8c20 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x60>
   c8c7a:	48 b8 15 00 00 00 00 	movabs $0x8000000000000015,%rax
   c8c81:	00 00 80 
   c8c84:	48 83 c0 68          	add    $0x68,%rax
   c8c88:	48 8b 3c 24          	mov    (%rsp),%rdi
   c8c8c:	48 89 07             	mov    %rax,(%rdi)
   c8c8f:	48 89 f8             	mov    %rdi,%rax
   c8c92:	48 83 c4 08          	add    $0x8,%rsp
   c8c96:	5b                   	pop    %rbx
   c8c97:	41 5c                	pop    %r12
   c8c99:	41 5d                	pop    %r13
   c8c9b:	41 5e                	pop    %r14
   c8c9d:	41 5f                	pop    %r15
   c8c9f:	5d                   	pop    %rbp
   c8ca0:	c3                   	ret
   c8ca1:	48 b8 15 00 00 00 00 	movabs $0x8000000000000015,%rax
   c8ca8:	00 00 80 
   c8cab:	48 83 c0 f6          	add    $0xfffffffffffffff6,%rax
   c8caf:	eb d7                	jmp    c8c88 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xc8>
   c8cb1:	48 b8 15 00 00 00 00 	movabs $0x8000000000000015,%rax
   c8cb8:	00 00 80 
   c8cbb:	48 83 c0 f1          	add    $0xfffffffffffffff1,%rax
   c8cbf:	48 8b 3c 24          	mov    (%rsp),%rdi
   c8cc3:	48 89 07             	mov    %rax,(%rdi)
   c8cc6:	48 89 6f 08          	mov    %rbp,0x8(%rdi)
   c8cca:	eb c3                	jmp    c8c8f <varlit_core::snapshot::SnapshotFile::read_exact_at+0xcf>
   c8ccc:	48 8b 3c 24          	mov    (%rsp),%rdi
   c8cd0:	48 b8 15 00 00 00 00 	movabs $0x8000000000000015,%rax
   c8cd7:	00 00 80 
   c8cda:	48 89 07             	mov    %rax,(%rdi)
   c8cdd:	48 8d 05 11 d1 f5 ff 	lea    -0xa2eef(%rip),%rax        # 25df5 <anon.44dfe6286d6883d57c2709f00721256e.111.llvm.7670212196679453716>
   c8ce4:	48 89 47 08          	mov    %rax,0x8(%rdi)
   c8ce8:	48 c7 47 10 14 00 00 	movq   $0x14,0x10(%rdi)
   c8cef:	00 
   c8cf0:	eb 9d                	jmp    c8c8f <varlit_core::snapshot::SnapshotFile::read_exact_at+0xcf>
   c8cf2:	4c 8d 3d 25 d0 f5 ff 	lea    -0xa2fdb(%rip),%r15        # 25d1e <anon.44dfe6286d6883d57c2709f00721256e.28.llvm.7670212196679453716>
   c8cf9:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   c8cff:	e9 f3 fe ff ff       	jmp    c8bf7 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x37>
   c8d04:	cc                   	int3
   c8d05:	cc                   	int3
   c8d06:	cc                   	int3
   c8d07:	cc                   	int3
   c8d08:	cc                   	int3
   c8d09:	cc                   	int3
   c8d0a:	cc                   	int3
   c8d0b:	cc                   	int3
   c8d0c:	cc                   	int3
   c8d0d:	cc                   	int3
   c8d0e:	cc                   	int3
   c8d0f:	cc                   	int3

