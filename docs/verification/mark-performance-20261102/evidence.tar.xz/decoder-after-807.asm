00000000000da270 <varlit_core::native_layout::read_native_record_header>:
   da270:	55                   	push   %rbp
   da271:	41 57                	push   %r15
   da273:	41 56                	push   %r14
   da275:	41 55                	push   %r13
   da277:	41 54                	push   %r12
   da279:	53                   	push   %rbx
   da27a:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
   da281:	49 89 f6             	mov    %rsi,%r14
   da284:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   da289:	0f 57 c0             	xorps  %xmm0,%xmm0
   da28c:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   da293:	00 
   da294:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   da29b:	00 
   da29c:	41 bf 20 00 00 00    	mov    $0x20,%r15d
   da2a2:	4c 8d a4 24 d0 00 00 	lea    0xd0(%rsp),%r12
   da2a9:	00 
   da2aa:	4c 8d ac 24 a0 00 00 	lea    0xa0(%rsp),%r13
   da2b1:	00 
   da2b2:	48 8b 2d 8f 20 0f 00 	mov    0xf208f(%rip),%rbp        # 1cc348 <_DYNAMIC+0x350>
   da2b9:	48 8d 1d c8 d9 f4 ff 	lea    -0xb2638(%rip),%rbx        # 27c88 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x2e1>
   da2c0:	eb 1b                	jmp    da2dd <varlit_core::native_layout::read_native_record_header+0x6d>
   da2c2:	80 7a 0f 23          	cmpb   $0x23,0xf(%rdx)
   da2c6:	0f 85 4b 05 00 00    	jne    da817 <varlit_core::native_layout::read_native_record_header+0x5a7>
   da2cc:	4c 89 ef             	mov    %r13,%rdi
   da2cf:	e8 3c 11 ff ff       	call   cb410 <core::ptr::drop_in_place<std::io::error::Error>>
   da2d4:	4d 85 ff             	test   %r15,%r15
   da2d7:	0f 84 b6 00 00 00    	je     da393 <varlit_core::native_layout::read_native_record_header+0x123>
   da2dd:	4c 89 f7             	mov    %r14,%rdi
   da2e0:	4c 89 e6             	mov    %r12,%rsi
   da2e3:	4c 89 fa             	mov    %r15,%rdx
   da2e6:	ff d5                	call   *%rbp
   da2e8:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
   da2ef:	00 
   da2f0:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
   da2f7:	00 
   da2f8:	48 83 f8 01          	cmp    $0x1,%rax
   da2fc:	75 22                	jne    da320 <varlit_core::native_layout::read_native_record_header+0xb0>
   da2fe:	89 d0                	mov    %edx,%eax
   da300:	83 e0 03             	and    $0x3,%eax
   da303:	48 63 04 83          	movslq (%rbx,%rax,4),%rax
   da307:	48 01 d8             	add    %rbx,%rax
   da30a:	ff e0                	jmp    *%rax
   da30c:	80 7a 10 23          	cmpb   $0x23,0x10(%rdx)
   da310:	74 ba                	je     da2cc <varlit_core::native_layout::read_native_record_header+0x5c>
   da312:	e9 00 05 00 00       	jmp    da817 <varlit_core::native_layout::read_native_record_header+0x5a7>
   da317:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   da31e:	00 00 
   da320:	48 85 d2             	test   %rdx,%rdx
   da323:	0f 84 e7 04 00 00    	je     da810 <varlit_core::native_layout::read_native_record_header+0x5a0>
   da329:	4c 89 f8             	mov    %r15,%rax
   da32c:	48 29 d0             	sub    %rdx,%rax
   da32f:	0f 82 d8 06 00 00    	jb     daa0d <varlit_core::native_layout::read_native_record_header+0x79d>
   da335:	49 01 d4             	add    %rdx,%r12
   da338:	49 89 c7             	mov    %rax,%r15
   da33b:	4d 85 ff             	test   %r15,%r15
   da33e:	75 9d                	jne    da2dd <varlit_core::native_layout::read_native_record_header+0x6d>
   da340:	eb 51                	jmp    da393 <varlit_core::native_layout::read_native_record_header+0x123>
   da342:	48 89 d0             	mov    %rdx,%rax
   da345:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   da34c:	ff ff ff 
   da34f:	48 21 c8             	and    %rcx,%rax
   da352:	48 b9 00 00 00 00 04 	movabs $0x400000000,%rcx
   da359:	00 00 00 
   da35c:	48 39 c8             	cmp    %rcx,%rax
   da35f:	0f 84 67 ff ff ff    	je     da2cc <varlit_core::native_layout::read_native_record_header+0x5c>
   da365:	eb 23                	jmp    da38a <varlit_core::native_layout::read_native_record_header+0x11a>
   da367:	48 89 d0             	mov    %rdx,%rax
   da36a:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   da371:	ff ff ff 
   da374:	48 21 c8             	and    %rcx,%rax
   da377:	48 b9 00 00 00 00 23 	movabs $0x2300000000,%rcx
   da37e:	00 00 00 
   da381:	48 39 c8             	cmp    %rcx,%rax
   da384:	0f 84 42 ff ff ff    	je     da2cc <varlit_core::native_layout::read_native_record_header+0x5c>
   da38a:	48 85 d2             	test   %rdx,%rdx
   da38d:	0f 85 84 04 00 00    	jne    da817 <varlit_core::native_layout::read_native_record_header+0x5a7>
   da393:	49 bc 01 00 00 00 00 	movabs $0x8000000000000001,%r12
   da39a:	00 00 80 
   da39d:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
   da3a4:	00 
   da3a5:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   da3ac:	00 
   da3ad:	48 c7 84 24 90 00 00 	movq   $0x20,0x90(%rsp)
   da3b4:	00 20 00 00 00 
   da3b9:	41 be 38 00 00 00    	mov    $0x38,%r14d
   da3bf:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   da3c6:	00 
   da3c7:	4c 8d 3d ba dc 0e 00 	lea    0xedcba(%rip),%r15        # 1c8088 <anon.96378bedfb121199e70b9883f72b5729.61.llvm.1968423816126862537>
   da3ce:	4d 8d 6c 24 7c       	lea    0x7c(%r12),%r13
   da3d3:	48 8d 2d be d8 f4 ff 	lea    -0xb2742(%rip),%rbp        # 27c98 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x2f1>
   da3da:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
   da3e1:	00 
   da3e2:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   da3e7:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   da3ec:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   da3f3:	00 
   da3f4:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   da3f9:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   da400:	00 
   da401:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   da408:	00 
   da409:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   da40e:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   da415:	00 
   da416:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
   da41d:	00 
   da41e:	eb 11                	jmp    da431 <varlit_core::native_layout::read_native_record_header+0x1c1>
   da420:	49 83 c6 40          	add    $0x40,%r14
   da424:	49 81 fe f8 01 00 00 	cmp    $0x1f8,%r14
   da42b:	0f 84 65 04 00 00    	je     da896 <varlit_core::native_layout::read_native_record_header+0x626>
   da431:	4b 8b 54 3e c8       	mov    -0x38(%r14,%r15,1),%rdx
   da436:	4b 8b 4c 3e d0       	mov    -0x30(%r14,%r15,1),%rcx
   da43b:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   da442:	00 
   da443:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
   da44a:	00 
   da44b:	e8 90 d8 ff ff       	call   d7ce0 <varlit_core::native_layout::read_native_value>
   da450:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
   da457:	00 
   da458:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
   da45f:	00 
   da460:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
   da467:	00 
   da468:	4c 39 e8             	cmp    %r13,%rax
   da46b:	0f 85 c5 03 00 00    	jne    da836 <varlit_core::native_layout::read_native_record_header+0x5c6>
   da471:	43 0f b6 04 3e       	movzbl (%r14,%r15,1),%eax
   da476:	48 63 44 85 00       	movslq 0x0(%rbp,%rax,4),%rax
   da47b:	48 01 e8             	add    %rbp,%rax
   da47e:	ff e0                	jmp    *%rax
   da480:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   da484:	48 89 f0             	mov    %rsi,%rax
   da487:	48 c1 f8 3f          	sar    $0x3f,%rax
   da48b:	48 21 c8             	and    %rcx,%rax
   da48e:	48 ff c8             	dec    %rax
   da491:	48 83 f8 03          	cmp    $0x3,%rax
   da495:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   da49a:	0f 87 22 04 00 00    	ja     da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da4a0:	48 8d 0d 69 d8 f4 ff 	lea    -0xb2797(%rip),%rcx        # 27d10 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x369>
   da4a7:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   da4ab:	48 01 c8             	add    %rcx,%rax
   da4ae:	ff e0                	jmp    *%rax
   da4b0:	40 0f b6 cf          	movzbl %dil,%ecx
   da4b4:	e9 95 02 00 00       	jmp    da74e <varlit_core::native_layout::read_native_record_header+0x4de>
   da4b9:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   da4bd:	48 89 f0             	mov    %rsi,%rax
   da4c0:	48 c1 f8 3f          	sar    $0x3f,%rax
   da4c4:	48 21 c8             	and    %rcx,%rax
   da4c7:	48 ff c8             	dec    %rax
   da4ca:	48 83 f8 03          	cmp    $0x3,%rax
   da4ce:	0f 87 ee 03 00 00    	ja     da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da4d4:	b1 01                	mov    $0x1,%cl
   da4d6:	89 4c 24 1c          	mov    %ecx,0x1c(%rsp)
   da4da:	48 8d 0d 0f d8 f4 ff 	lea    -0xb27f1(%rip),%rcx        # 27cf0 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x349>
   da4e1:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   da4e5:	48 01 c8             	add    %rcx,%rax
   da4e8:	ff e0                	jmp    *%rax
   da4ea:	40 0f b6 c7          	movzbl %dil,%eax
   da4ee:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   da4f3:	48 85 f6             	test   %rsi,%rsi
   da4f6:	0f 8f 04 03 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da4fc:	e9 1f ff ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da501:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   da505:	48 89 f0             	mov    %rsi,%rax
   da508:	48 c1 f8 3f          	sar    $0x3f,%rax
   da50c:	48 21 c8             	and    %rcx,%rax
   da50f:	48 83 f8 04          	cmp    $0x4,%rax
   da513:	0f 84 23 01 00 00    	je     da63c <varlit_core::native_layout::read_native_record_header+0x3cc>
   da519:	48 83 f8 02          	cmp    $0x2,%rax
   da51d:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   da522:	0f 84 0a 01 00 00    	je     da632 <varlit_core::native_layout::read_native_record_header+0x3c2>
   da528:	48 83 f8 01          	cmp    $0x1,%rax
   da52c:	0f 85 90 03 00 00    	jne    da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da532:	40 0f b6 c7          	movzbl %dil,%eax
   da536:	e9 16 01 00 00       	jmp    da651 <varlit_core::native_layout::read_native_record_header+0x3e1>
   da53b:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   da53f:	48 89 f0             	mov    %rsi,%rax
   da542:	48 c1 f8 3f          	sar    $0x3f,%rax
   da546:	48 21 c8             	and    %rcx,%rax
   da549:	48 ff c8             	dec    %rax
   da54c:	48 83 f8 03          	cmp    $0x3,%rax
   da550:	0f 87 6c 03 00 00    	ja     da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da556:	b1 01                	mov    $0x1,%cl
   da558:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   da55c:	48 8d 0d 9d d7 f4 ff 	lea    -0xb2863(%rip),%rcx        # 27d00 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x359>
   da563:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   da567:	48 01 c8             	add    %rcx,%rax
   da56a:	ff e0                	jmp    *%rax
   da56c:	40 0f b6 c7          	movzbl %dil,%eax
   da570:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   da575:	48 85 f6             	test   %rsi,%rsi
   da578:	0f 8f 82 02 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da57e:	e9 9d fe ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da583:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   da587:	48 89 f0             	mov    %rsi,%rax
   da58a:	48 c1 f8 3f          	sar    $0x3f,%rax
   da58e:	48 21 c8             	and    %rcx,%rax
   da591:	48 83 f8 04          	cmp    $0x4,%rax
   da595:	0f 84 de 00 00 00    	je     da679 <varlit_core::native_layout::read_native_record_header+0x409>
   da59b:	48 83 f8 02          	cmp    $0x2,%rax
   da59f:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   da5a4:	0f 84 8d 00 00 00    	je     da637 <varlit_core::native_layout::read_native_record_header+0x3c7>
   da5aa:	48 83 f8 01          	cmp    $0x1,%rax
   da5ae:	0f 85 0e 03 00 00    	jne    da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da5b4:	40 0f b6 c7          	movzbl %dil,%eax
   da5b8:	e9 d1 00 00 00       	jmp    da68e <varlit_core::native_layout::read_native_record_header+0x41e>
   da5bd:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   da5c1:	48 89 f0             	mov    %rsi,%rax
   da5c4:	48 c1 f8 3f          	sar    $0x3f,%rax
   da5c8:	48 21 c8             	and    %rcx,%rax
   da5cb:	48 ff c8             	dec    %rax
   da5ce:	48 83 f8 03          	cmp    $0x3,%rax
   da5d2:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
   da5d7:	0f 87 e5 02 00 00    	ja     da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da5dd:	48 8d 0d fc d6 f4 ff 	lea    -0xb2904(%rip),%rcx        # 27ce0 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x339>
   da5e4:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   da5e8:	48 01 c8             	add    %rcx,%rax
   da5eb:	ff e0                	jmp    *%rax
   da5ed:	40 0f b6 cf          	movzbl %dil,%ecx
   da5f1:	e9 af 01 00 00       	jmp    da7a5 <varlit_core::native_layout::read_native_record_header+0x535>
   da5f6:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   da5fa:	48 89 f0             	mov    %rsi,%rax
   da5fd:	48 c1 f8 3f          	sar    $0x3f,%rax
   da601:	48 21 c8             	and    %rcx,%rax
   da604:	48 ff c8             	dec    %rax
   da607:	48 83 f8 03          	cmp    $0x3,%rax
   da60b:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   da612:	00 
   da613:	0f 87 a9 02 00 00    	ja     da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da619:	48 8d 0d b0 d6 f4 ff 	lea    -0xb2950(%rip),%rcx        # 27cd0 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x329>
   da620:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   da624:	48 01 c8             	add    %rcx,%rax
   da627:	ff e0                	jmp    *%rax
   da629:	40 0f b6 df          	movzbl %dil,%ebx
   da62d:	e9 a0 01 00 00       	jmp    da7d2 <varlit_core::native_layout::read_native_record_header+0x562>
   da632:	0f b7 c7             	movzwl %di,%eax
   da635:	eb 1a                	jmp    da651 <varlit_core::native_layout::read_native_record_header+0x3e1>
   da637:	0f b7 c7             	movzwl %di,%eax
   da63a:	eb 52                	jmp    da68e <varlit_core::native_layout::read_native_record_header+0x41e>
   da63c:	48 89 f8             	mov    %rdi,%rax
   da63f:	48 81 ff ff ff 00 00 	cmp    $0xffff,%rdi
   da646:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   da64b:	0f 87 71 02 00 00    	ja     da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da651:	48 81 e1 00 00 ff ff 	and    $0xffffffffffff0000,%rcx
   da658:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   da65d:	48 09 c1             	or     %rax,%rcx
   da660:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   da665:	b0 01                	mov    $0x1,%al
   da667:	89 44 24 20          	mov    %eax,0x20(%rsp)
   da66b:	48 85 f6             	test   %rsi,%rsi
   da66e:	0f 8f 8c 01 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da674:	e9 a7 fd ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da679:	48 89 f8             	mov    %rdi,%rax
   da67c:	48 81 ff ff ff 00 00 	cmp    $0xffff,%rdi
   da683:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   da688:	0f 87 34 02 00 00    	ja     da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da68e:	48 81 e1 00 00 ff ff 	and    $0xffffffffffff0000,%rcx
   da695:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   da69a:	48 09 c1             	or     %rax,%rcx
   da69d:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
   da6a2:	b0 01                	mov    $0x1,%al
   da6a4:	89 44 24 28          	mov    %eax,0x28(%rsp)
   da6a8:	48 85 f6             	test   %rsi,%rsi
   da6ab:	0f 8f 4f 01 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da6b1:	e9 6a fd ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da6b6:	89 f8                	mov    %edi,%eax
   da6b8:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   da6bd:	48 85 f6             	test   %rsi,%rsi
   da6c0:	0f 8f 3a 01 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da6c6:	e9 55 fd ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da6cb:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
   da6d0:	48 85 f6             	test   %rsi,%rsi
   da6d3:	0f 8f 27 01 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da6d9:	e9 42 fd ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da6de:	0f b7 c7             	movzwl %di,%eax
   da6e1:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   da6e6:	48 85 f6             	test   %rsi,%rsi
   da6e9:	0f 8f 11 01 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da6ef:	e9 2c fd ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da6f4:	89 f8                	mov    %edi,%eax
   da6f6:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   da6fb:	48 85 f6             	test   %rsi,%rsi
   da6fe:	0f 8f fc 00 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da704:	e9 17 fd ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da709:	89 f9                	mov    %edi,%ecx
   da70b:	eb 41                	jmp    da74e <varlit_core::native_layout::read_native_record_header+0x4de>
   da70d:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
   da712:	48 85 f6             	test   %rsi,%rsi
   da715:	0f 8f e5 00 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da71b:	e9 00 fd ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da720:	48 89 f8             	mov    %rdi,%rax
   da723:	48 c1 e8 20          	shr    $0x20,%rax
   da727:	48 89 f9             	mov    %rdi,%rcx
   da72a:	74 22                	je     da74e <varlit_core::native_layout::read_native_record_header+0x4de>
   da72c:	e9 91 01 00 00       	jmp    da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da731:	0f b7 c7             	movzwl %di,%eax
   da734:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   da739:	48 85 f6             	test   %rsi,%rsi
   da73c:	0f 8f be 00 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da742:	e9 d9 fc ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da747:	89 f9                	mov    %edi,%ecx
   da749:	eb 5a                	jmp    da7a5 <varlit_core::native_layout::read_native_record_header+0x535>
   da74b:	0f b7 cf             	movzwl %di,%ecx
   da74e:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
   da755:	ff ff ff 
   da758:	48 21 c2             	and    %rax,%rdx
   da75b:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   da760:	48 09 ca             	or     %rcx,%rdx
   da763:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
   da768:	b0 01                	mov    $0x1,%al
   da76a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   da76e:	48 85 f6             	test   %rsi,%rsi
   da771:	0f 8f 89 00 00 00    	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da777:	e9 a4 fc ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da77c:	89 fb                	mov    %edi,%ebx
   da77e:	eb 52                	jmp    da7d2 <varlit_core::native_layout::read_native_record_header+0x562>
   da780:	48 89 f8             	mov    %rdi,%rax
   da783:	48 c1 e8 20          	shr    $0x20,%rax
   da787:	48 89 f9             	mov    %rdi,%rcx
   da78a:	74 19                	je     da7a5 <varlit_core::native_layout::read_native_record_header+0x535>
   da78c:	e9 31 01 00 00       	jmp    da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da791:	48 89 f8             	mov    %rdi,%rax
   da794:	48 c1 e8 20          	shr    $0x20,%rax
   da798:	48 89 fb             	mov    %rdi,%rbx
   da79b:	74 35                	je     da7d2 <varlit_core::native_layout::read_native_record_header+0x562>
   da79d:	e9 20 01 00 00       	jmp    da8c2 <varlit_core::native_layout::read_native_record_header+0x652>
   da7a2:	0f b7 cf             	movzwl %di,%ecx
   da7a5:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
   da7ac:	ff ff ff 
   da7af:	48 21 c2             	and    %rax,%rdx
   da7b2:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   da7b7:	48 09 ca             	or     %rcx,%rdx
   da7ba:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
   da7bf:	b0 01                	mov    $0x1,%al
   da7c1:	89 44 24 18          	mov    %eax,0x18(%rsp)
   da7c5:	48 85 f6             	test   %rsi,%rsi
   da7c8:	7f 36                	jg     da800 <varlit_core::native_layout::read_native_record_header+0x590>
   da7ca:	e9 51 fc ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da7cf:	0f b7 df             	movzwl %di,%ebx
   da7d2:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
   da7d9:	ff ff ff 
   da7dc:	48 21 c2             	and    %rax,%rdx
   da7df:	48 09 da             	or     %rbx,%rdx
   da7e2:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
   da7e9:	00 
   da7ea:	b0 01                	mov    $0x1,%al
   da7ec:	89 44 24 14          	mov    %eax,0x14(%rsp)
   da7f0:	48 85 f6             	test   %rsi,%rsi
   da7f3:	0f 8e 27 fc ff ff    	jle    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da7f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   da800:	ba 01 00 00 00       	mov    $0x1,%edx
   da805:	ff 15 dd 1a 0f 00    	call   *0xf1add(%rip)        # 1cc2e8 <_DYNAMIC+0x2f0>
   da80b:	e9 10 fc ff ff       	jmp    da420 <varlit_core::native_layout::read_native_record_header+0x1b0>
   da810:	48 8d 15 19 d1 0e 00 	lea    0xed119(%rip),%rdx        # 1c7930 <anon.08630c77ddc8e20740d549a4826ccb7c.88.llvm.810036314814969787>
   da817:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
   da81e:	00 00 80 
   da821:	48 83 c0 05          	add    $0x5,%rax
   da825:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   da82a:	48 89 03             	mov    %rax,(%rbx)
   da82d:	48 89 53 08          	mov    %rdx,0x8(%rbx)
   da831:	e9 ba 00 00 00       	jmp    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   da836:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   da83d:	00 
   da83e:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
   da845:	00 
   da846:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   da84b:	48 89 53 30          	mov    %rdx,0x30(%rbx)
   da84f:	0f 10 84 24 b8 00 00 	movups 0xb8(%rsp),%xmm0
   da856:	00 
   da857:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   da85b:	48 89 73 08          	mov    %rsi,0x8(%rbx)
   da85f:	48 89 7b 10          	mov    %rdi,0x10(%rbx)
   da863:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
   da867:	48 89 03             	mov    %rax,(%rbx)
   da86a:	e9 81 00 00 00       	jmp    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   da86f:	49 83 c4 1d          	add    $0x1d,%r12
   da873:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   da878:	4c 89 23             	mov    %r12,(%rbx)
   da87b:	48 8d 05 47 db f4 ff 	lea    -0xb24b9(%rip),%rax        # 283c9 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0xa22>
   da882:	48 89 43 08          	mov    %rax,0x8(%rbx)
   da886:	b8 2d 00 00 00       	mov    $0x2d,%eax
   da88b:	48 89 43 10          	mov    %rax,0x10(%rbx)
   da88f:	48 85 f6             	test   %rsi,%rsi
   da892:	7f 51                	jg     da8e5 <varlit_core::native_layout::read_native_record_header+0x675>
   da894:	eb 5a                	jmp    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   da896:	48 83 bc 24 90 00 00 	cmpq   $0x0,0x90(%rsp)
   da89d:	00 00 
   da89f:	74 64                	je     da905 <varlit_core::native_layout::read_native_record_header+0x695>
   da8a1:	49 83 c4 1d          	add    $0x1d,%r12
   da8a5:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   da8aa:	4c 89 23             	mov    %r12,(%rbx)
   da8ad:	48 8d 05 51 dc f4 ff 	lea    -0xb23af(%rip),%rax        # 28505 <anon.96378bedfb121199e70b9883f72b5729.60.llvm.1968423816126862537+0x15>
   da8b4:	48 89 43 08          	mov    %rax,0x8(%rbx)
   da8b8:	48 c7 43 10 36 00 00 	movq   $0x36,0x10(%rbx)
   da8bf:	00 
   da8c0:	eb 2e                	jmp    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   da8c2:	4b 8b 4c 3e f0       	mov    -0x10(%r14,%r15,1),%rcx
   da8c7:	4b 8b 44 3e f8       	mov    -0x8(%r14,%r15,1),%rax
   da8cc:	49 83 c4 6d          	add    $0x6d,%r12
   da8d0:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   da8d5:	4c 89 23             	mov    %r12,(%rbx)
   da8d8:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   da8dc:	48 89 43 10          	mov    %rax,0x10(%rbx)
   da8e0:	48 85 f6             	test   %rsi,%rsi
   da8e3:	7e 0b                	jle    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   da8e5:	ba 01 00 00 00       	mov    $0x1,%edx
   da8ea:	ff 15 f8 19 0f 00    	call   *0xf19f8(%rip)        # 1cc2e8 <_DYNAMIC+0x2f0>
   da8f0:	48 89 d8             	mov    %rbx,%rax
   da8f3:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
   da8fa:	5b                   	pop    %rbx
   da8fb:	41 5c                	pop    %r12
   da8fd:	41 5d                	pop    %r13
   da8ff:	41 5e                	pop    %r14
   da901:	41 5f                	pop    %r15
   da903:	5d                   	pop    %rbp
   da904:	c3                   	ret
   da905:	f6 44 24 2c 01       	testb  $0x1,0x2c(%rsp)
   da90a:	0f 84 91 00 00 00    	je     da9a1 <varlit_core::native_layout::read_native_record_header+0x731>
   da910:	f6 44 24 28 01       	testb  $0x1,0x28(%rsp)
   da915:	0f 84 aa 00 00 00    	je     da9c5 <varlit_core::native_layout::read_native_record_header+0x755>
   da91b:	f6 44 24 20 01       	testb  $0x1,0x20(%rsp)
   da920:	0f 84 c3 00 00 00    	je     da9e9 <varlit_core::native_layout::read_native_record_header+0x779>
   da926:	f6 44 24 24 01       	testb  $0x1,0x24(%rsp)
   da92b:	0f 84 f2 00 00 00    	je     daa23 <varlit_core::native_layout::read_native_record_header+0x7b3>
   da931:	f6 44 24 1c 01       	testb  $0x1,0x1c(%rsp)
   da936:	0f 84 ff 00 00 00    	je     daa3b <varlit_core::native_layout::read_native_record_header+0x7cb>
   da93c:	f6 44 24 18 01       	testb  $0x1,0x18(%rsp)
   da941:	0f 84 18 01 00 00    	je     daa5f <varlit_core::native_layout::read_native_record_header+0x7ef>
   da947:	f6 44 24 14 01       	testb  $0x1,0x14(%rsp)
   da94c:	0f 84 25 01 00 00    	je     daa77 <varlit_core::native_layout::read_native_record_header+0x807>
   da952:	48 89 d8             	mov    %rbx,%rax
   da955:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   da95a:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   da95f:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   da963:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   da968:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   da96c:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   da971:	89 4b 18             	mov    %ecx,0x18(%rbx)
   da974:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   da979:	89 4b 1c             	mov    %ecx,0x1c(%rbx)
   da97c:	89 43 20             	mov    %eax,0x20(%rbx)
   da97f:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   da984:	66 89 43 24          	mov    %ax,0x24(%rbx)
   da988:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   da98d:	66 89 43 26          	mov    %ax,0x26(%rbx)
   da991:	48 c7 43 28 20 00 00 	movq   $0x20,0x28(%rbx)
   da998:	00 
   da999:	4c 89 2b             	mov    %r13,(%rbx)
   da99c:	e9 4f ff ff ff       	jmp    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   da9a1:	49 83 c4 6b          	add    $0x6b,%r12
   da9a5:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   da9aa:	4c 89 23             	mov    %r12,(%rbx)
   da9ad:	48 8d 05 14 f5 f3 ff 	lea    -0xc0aec(%rip),%rax        # 19ec8 <anon.96378bedfb121199e70b9883f72b5729.54.llvm.1968423816126862537>
   da9b4:	48 89 43 08          	mov    %rax,0x8(%rbx)
   da9b8:	48 c7 43 10 08 00 00 	movq   $0x8,0x10(%rbx)
   da9bf:	00 
   da9c0:	e9 2b ff ff ff       	jmp    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   da9c5:	49 83 c4 6b          	add    $0x6b,%r12
   da9c9:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   da9ce:	4c 89 23             	mov    %r12,(%rbx)
   da9d1:	48 8d 05 f4 da f4 ff 	lea    -0xb250c(%rip),%rax        # 284cc <anon.96378bedfb121199e70b9883f72b5729.55.llvm.1968423816126862537>
   da9d8:	48 89 43 08          	mov    %rax,0x8(%rbx)
   da9dc:	48 c7 43 10 0d 00 00 	movq   $0xd,0x10(%rbx)
   da9e3:	00 
   da9e4:	e9 07 ff ff ff       	jmp    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   da9e9:	49 83 c4 6b          	add    $0x6b,%r12
   da9ed:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   da9f2:	4c 89 23             	mov    %r12,(%rbx)
   da9f5:	48 8d 05 94 da f4 ff 	lea    -0xb256c(%rip),%rax        # 28490 <anon.96378bedfb121199e70b9883f72b5729.46.llvm.1968423816126862537>
   da9fc:	48 89 43 08          	mov    %rax,0x8(%rbx)
   daa00:	48 c7 43 10 05 00 00 	movq   $0x5,0x10(%rbx)
   daa07:	00 
   daa08:	e9 e3 fe ff ff       	jmp    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   daa0d:	48 8d 0d 34 cf 0e 00 	lea    0xecf34(%rip),%rcx        # 1c7948 <anon.08630c77ddc8e20740d549a4826ccb7c.89.llvm.810036314814969787>
   daa14:	48 89 d7             	mov    %rdx,%rdi
   daa17:	4c 89 fe             	mov    %r15,%rsi
   daa1a:	4c 89 fa             	mov    %r15,%rdx
   daa1d:	ff 15 8d 19 0f 00    	call   *0xf198d(%rip)        # 1cc3b0 <_DYNAMIC+0x3b8>
   daa23:	49 83 c4 6b          	add    $0x6b,%r12
   daa27:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   daa2c:	4c 89 23             	mov    %r12,(%rbx)
   daa2f:	48 8d 05 4a f3 f3 ff 	lea    -0xc0cb6(%rip),%rax        # 19d80 <anon.96378bedfb121199e70b9883f72b5729.57.llvm.1968423816126862537>
   daa36:	e9 79 ff ff ff       	jmp    da9b4 <varlit_core::native_layout::read_native_record_header+0x744>
   daa3b:	49 83 c4 6b          	add    $0x6b,%r12
   daa3f:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   daa44:	4c 89 23             	mov    %r12,(%rbx)
   daa47:	48 8d 05 97 da f4 ff 	lea    -0xb2569(%rip),%rax        # 284e5 <anon.96378bedfb121199e70b9883f72b5729.58.llvm.1968423816126862537>
   daa4e:	48 89 43 08          	mov    %rax,0x8(%rbx)
   daa52:	48 c7 43 10 0b 00 00 	movq   $0xb,0x10(%rbx)
   daa59:	00 
   daa5a:	e9 91 fe ff ff       	jmp    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   daa5f:	49 83 c4 6b          	add    $0x6b,%r12
   daa63:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   daa68:	4c 89 23             	mov    %r12,(%rbx)
   daa6b:	48 8d 05 86 f3 f3 ff 	lea    -0xc0c7a(%rip),%rax        # 19df8 <anon.96378bedfb121199e70b9883f72b5729.59.llvm.1968423816126862537>
   daa72:	e9 3d ff ff ff       	jmp    da9b4 <varlit_core::native_layout::read_native_record_header+0x744>
   daa77:	49 83 c4 6b          	add    $0x6b,%r12
   daa7b:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   daa80:	4c 89 23             	mov    %r12,(%rbx)
   daa83:	48 8d 05 66 da f4 ff 	lea    -0xb259a(%rip),%rax        # 284f0 <anon.96378bedfb121199e70b9883f72b5729.60.llvm.1968423816126862537>
   daa8a:	48 89 43 08          	mov    %rax,0x8(%rbx)
   daa8e:	48 c7 43 10 15 00 00 	movq   $0x15,0x10(%rbx)
   daa95:	00 
   daa96:	e9 55 fe ff ff       	jmp    da8f0 <varlit_core::native_layout::read_native_record_header+0x680>
   daa9b:	cc                   	int3
   daa9c:	cc                   	int3
   daa9d:	cc                   	int3
   daa9e:	cc                   	int3
   daa9f:	cc                   	int3

