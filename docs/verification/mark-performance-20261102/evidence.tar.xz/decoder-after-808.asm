00000000000daaa0 <varlit_core::native_layout::read_native_record_header>:
   daaa0:	55                   	push   %rbp
   daaa1:	41 57                	push   %r15
   daaa3:	41 56                	push   %r14
   daaa5:	41 55                	push   %r13
   daaa7:	41 54                	push   %r12
   daaa9:	53                   	push   %rbx
   daaaa:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
   daab1:	48 89 fb             	mov    %rdi,%rbx
   daab4:	49 bc 01 00 00 00 00 	movabs $0x8000000000000001,%r12
   daabb:	00 00 80 
   daabe:	48 8b 0e             	mov    (%rsi),%rcx
   daac1:	48 8b 46 08          	mov    0x8(%rsi),%rax
   daac5:	48 83 f8 1f          	cmp    $0x1f,%rax
   daac9:	77 25                	ja     daaf0 <varlit_core::native_layout::read_native_record_header+0x50>
   daacb:	48 01 c1             	add    %rax,%rcx
   daace:	48 89 0e             	mov    %rcx,(%rsi)
   daad1:	48 c7 46 08 00 00 00 	movq   $0x0,0x8(%rsi)
   daad8:	00 
   daad9:	49 83 c4 05          	add    $0x5,%r12
   daadd:	4c 89 23             	mov    %r12,(%rbx)
   daae0:	48 8d 05 99 d4 0e 00 	lea    0xed499(%rip),%rax        # 1c7f80 <anon.96378bedfb121199e70b9883f72b5729.2.llvm.1968423816126862537+0x18>
   daae7:	48 89 43 08          	mov    %rax,0x8(%rbx)
   daaeb:	e9 43 05 00 00       	jmp    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   daaf0:	48 8d 51 20          	lea    0x20(%rcx),%rdx
   daaf4:	48 83 c0 e0          	add    $0xffffffffffffffe0,%rax
   daaf8:	0f 10 01             	movups (%rcx),%xmm0
   daafb:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   daaff:	0f 29 8c 24 e0 00 00 	movaps %xmm1,0xe0(%rsp)
   dab06:	00 
   dab07:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   dab0e:	00 
   dab0f:	48 89 16             	mov    %rdx,(%rsi)
   dab12:	48 89 46 08          	mov    %rax,0x8(%rsi)
   dab16:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
   dab1d:	00 
   dab1e:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   dab25:	00 
   dab26:	48 c7 84 24 90 00 00 	movq   $0x20,0x90(%rsp)
   dab2d:	00 20 00 00 00 
   dab32:	bd 38 00 00 00       	mov    $0x38,%ebp
   dab37:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   dab3e:	00 
   dab3f:	4c 8d 35 42 d5 0e 00 	lea    0xed542(%rip),%r14        # 1c8088 <anon.96378bedfb121199e70b9883f72b5729.61.llvm.1968423816126862537>
   dab46:	4d 8d 6c 24 7c       	lea    0x7c(%r12),%r13
   dab4b:	4c 8d 3d ce d1 f4 ff 	lea    -0xb2e32(%rip),%r15        # 27d20 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x379>
   dab52:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   dab57:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   dab5e:	00 
   dab5f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   dab64:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   dab69:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   dab70:	00 
   dab71:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   dab76:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   dab7d:	00 
   dab7e:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   dab85:	00 
   dab86:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   dab8b:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
   dab92:	00 
   dab93:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   dab9a:	00 
   dab9b:	eb 14                	jmp    dabb1 <varlit_core::native_layout::read_native_record_header+0x111>
   dab9d:	0f 1f 00             	nopl   (%rax)
   daba0:	48 83 c5 40          	add    $0x40,%rbp
   daba4:	48 81 fd f8 01 00 00 	cmp    $0x1f8,%rbp
   dabab:	0f 84 32 04 00 00    	je     dafe3 <varlit_core::native_layout::read_native_record_header+0x543>
   dabb1:	4a 8b 54 35 c8       	mov    -0x38(%rbp,%r14,1),%rdx
   dabb6:	4a 8b 4c 35 d0       	mov    -0x30(%rbp,%r14,1),%rcx
   dabbb:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   dabc2:	00 
   dabc3:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
   dabca:	00 
   dabcb:	e8 10 d1 ff ff       	call   d7ce0 <varlit_core::native_layout::read_native_value>
   dabd0:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
   dabd7:	00 
   dabd8:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
   dabdf:	00 
   dabe0:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
   dabe7:	00 
   dabe8:	4c 39 e8             	cmp    %r13,%rax
   dabeb:	0f 85 9f 03 00 00    	jne    daf90 <varlit_core::native_layout::read_native_record_header+0x4f0>
   dabf1:	42 0f b6 44 35 00    	movzbl 0x0(%rbp,%r14,1),%eax
   dabf7:	49 63 04 87          	movslq (%r15,%rax,4),%rax
   dabfb:	4c 01 f8             	add    %r15,%rax
   dabfe:	ff e0                	jmp    *%rax
   dac00:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   dac04:	48 89 f0             	mov    %rsi,%rax
   dac07:	48 c1 f8 3f          	sar    $0x3f,%rax
   dac0b:	48 21 c8             	and    %rcx,%rax
   dac0e:	48 ff c8             	dec    %rax
   dac11:	48 83 f8 03          	cmp    $0x3,%rax
   dac15:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   dac1a:	0f 87 ea 03 00 00    	ja     db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   dac20:	48 8d 0d 71 d1 f4 ff 	lea    -0xb2e8f(%rip),%rcx        # 27d98 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x3f1>
   dac27:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   dac2b:	48 01 c8             	add    %rcx,%rax
   dac2e:	ff e0                	jmp    *%rax
   dac30:	40 0f b6 cf          	movzbl %dil,%ecx
   dac34:	e9 95 02 00 00       	jmp    daece <varlit_core::native_layout::read_native_record_header+0x42e>
   dac39:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   dac3d:	48 89 f0             	mov    %rsi,%rax
   dac40:	48 c1 f8 3f          	sar    $0x3f,%rax
   dac44:	48 21 c8             	and    %rcx,%rax
   dac47:	48 ff c8             	dec    %rax
   dac4a:	48 83 f8 03          	cmp    $0x3,%rax
   dac4e:	0f 87 b6 03 00 00    	ja     db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   dac54:	b1 01                	mov    $0x1,%cl
   dac56:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   dac5a:	48 8d 0d 17 d1 f4 ff 	lea    -0xb2ee9(%rip),%rcx        # 27d78 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x3d1>
   dac61:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   dac65:	48 01 c8             	add    %rcx,%rax
   dac68:	ff e0                	jmp    *%rax
   dac6a:	40 0f b6 c7          	movzbl %dil,%eax
   dac6e:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   dac73:	48 85 f6             	test   %rsi,%rsi
   dac76:	0f 8f 04 03 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   dac7c:	e9 1f ff ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   dac81:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   dac85:	48 89 f0             	mov    %rsi,%rax
   dac88:	48 c1 f8 3f          	sar    $0x3f,%rax
   dac8c:	48 21 c8             	and    %rcx,%rax
   dac8f:	48 83 f8 04          	cmp    $0x4,%rax
   dac93:	0f 84 23 01 00 00    	je     dadbc <varlit_core::native_layout::read_native_record_header+0x31c>
   dac99:	48 83 f8 02          	cmp    $0x2,%rax
   dac9d:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   daca2:	0f 84 0a 01 00 00    	je     dadb2 <varlit_core::native_layout::read_native_record_header+0x312>
   daca8:	48 83 f8 01          	cmp    $0x1,%rax
   dacac:	0f 85 58 03 00 00    	jne    db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   dacb2:	40 0f b6 c7          	movzbl %dil,%eax
   dacb6:	e9 16 01 00 00       	jmp    dadd1 <varlit_core::native_layout::read_native_record_header+0x331>
   dacbb:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   dacbf:	48 89 f0             	mov    %rsi,%rax
   dacc2:	48 c1 f8 3f          	sar    $0x3f,%rax
   dacc6:	48 21 c8             	and    %rcx,%rax
   dacc9:	48 ff c8             	dec    %rax
   daccc:	48 83 f8 03          	cmp    $0x3,%rax
   dacd0:	0f 87 34 03 00 00    	ja     db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   dacd6:	b1 01                	mov    $0x1,%cl
   dacd8:	89 4c 24 1c          	mov    %ecx,0x1c(%rsp)
   dacdc:	48 8d 0d a5 d0 f4 ff 	lea    -0xb2f5b(%rip),%rcx        # 27d88 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x3e1>
   dace3:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   dace7:	48 01 c8             	add    %rcx,%rax
   dacea:	ff e0                	jmp    *%rax
   dacec:	40 0f b6 c7          	movzbl %dil,%eax
   dacf0:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   dacf5:	48 85 f6             	test   %rsi,%rsi
   dacf8:	0f 8f 82 02 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   dacfe:	e9 9d fe ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   dad03:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   dad07:	48 89 f0             	mov    %rsi,%rax
   dad0a:	48 c1 f8 3f          	sar    $0x3f,%rax
   dad0e:	48 21 c8             	and    %rcx,%rax
   dad11:	48 83 f8 04          	cmp    $0x4,%rax
   dad15:	0f 84 de 00 00 00    	je     dadf9 <varlit_core::native_layout::read_native_record_header+0x359>
   dad1b:	48 83 f8 02          	cmp    $0x2,%rax
   dad1f:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   dad24:	0f 84 8d 00 00 00    	je     dadb7 <varlit_core::native_layout::read_native_record_header+0x317>
   dad2a:	48 83 f8 01          	cmp    $0x1,%rax
   dad2e:	0f 85 d6 02 00 00    	jne    db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   dad34:	40 0f b6 c7          	movzbl %dil,%eax
   dad38:	e9 d1 00 00 00       	jmp    dae0e <varlit_core::native_layout::read_native_record_header+0x36e>
   dad3d:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   dad41:	48 89 f0             	mov    %rsi,%rax
   dad44:	48 c1 f8 3f          	sar    $0x3f,%rax
   dad48:	48 21 c8             	and    %rcx,%rax
   dad4b:	48 ff c8             	dec    %rax
   dad4e:	48 83 f8 03          	cmp    $0x3,%rax
   dad52:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
   dad57:	0f 87 ad 02 00 00    	ja     db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   dad5d:	48 8d 0d 04 d0 f4 ff 	lea    -0xb2ffc(%rip),%rcx        # 27d68 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x3c1>
   dad64:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   dad68:	48 01 c8             	add    %rcx,%rax
   dad6b:	ff e0                	jmp    *%rax
   dad6d:	40 0f b6 cf          	movzbl %dil,%ecx
   dad71:	e9 af 01 00 00       	jmp    daf25 <varlit_core::native_layout::read_native_record_header+0x485>
   dad76:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
   dad7a:	48 89 f0             	mov    %rsi,%rax
   dad7d:	48 c1 f8 3f          	sar    $0x3f,%rax
   dad81:	48 21 c8             	and    %rcx,%rax
   dad84:	48 ff c8             	dec    %rax
   dad87:	48 83 f8 03          	cmp    $0x3,%rax
   dad8b:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   dad92:	00 
   dad93:	0f 87 71 02 00 00    	ja     db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   dad99:	48 8d 0d b8 cf f4 ff 	lea    -0xb3048(%rip),%rcx        # 27d58 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x3b1>
   dada0:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   dada4:	48 01 c8             	add    %rcx,%rax
   dada7:	ff e0                	jmp    *%rax
   dada9:	40 0f b6 cf          	movzbl %dil,%ecx
   dadad:	e9 a0 01 00 00       	jmp    daf52 <varlit_core::native_layout::read_native_record_header+0x4b2>
   dadb2:	0f b7 c7             	movzwl %di,%eax
   dadb5:	eb 1a                	jmp    dadd1 <varlit_core::native_layout::read_native_record_header+0x331>
   dadb7:	0f b7 c7             	movzwl %di,%eax
   dadba:	eb 52                	jmp    dae0e <varlit_core::native_layout::read_native_record_header+0x36e>
   dadbc:	48 89 f8             	mov    %rdi,%rax
   dadbf:	48 81 ff ff ff 00 00 	cmp    $0xffff,%rdi
   dadc6:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   dadcb:	0f 87 39 02 00 00    	ja     db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   dadd1:	48 81 e1 00 00 ff ff 	and    $0xffffffffffff0000,%rcx
   dadd8:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   daddd:	48 09 c1             	or     %rax,%rcx
   dade0:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   dade5:	b0 01                	mov    $0x1,%al
   dade7:	89 44 24 18          	mov    %eax,0x18(%rsp)
   dadeb:	48 85 f6             	test   %rsi,%rsi
   dadee:	0f 8f 8c 01 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   dadf4:	e9 a7 fd ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   dadf9:	48 89 f8             	mov    %rdi,%rax
   dadfc:	48 81 ff ff ff 00 00 	cmp    $0xffff,%rdi
   dae03:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   dae08:	0f 87 fc 01 00 00    	ja     db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   dae0e:	48 81 e1 00 00 ff ff 	and    $0xffffffffffff0000,%rcx
   dae15:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   dae1a:	48 09 c1             	or     %rax,%rcx
   dae1d:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
   dae22:	b0 01                	mov    $0x1,%al
   dae24:	89 44 24 20          	mov    %eax,0x20(%rsp)
   dae28:	48 85 f6             	test   %rsi,%rsi
   dae2b:	0f 8f 4f 01 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   dae31:	e9 6a fd ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   dae36:	89 f8                	mov    %edi,%eax
   dae38:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   dae3d:	48 85 f6             	test   %rsi,%rsi
   dae40:	0f 8f 3a 01 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   dae46:	e9 55 fd ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   dae4b:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
   dae50:	48 85 f6             	test   %rsi,%rsi
   dae53:	0f 8f 27 01 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   dae59:	e9 42 fd ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   dae5e:	0f b7 c7             	movzwl %di,%eax
   dae61:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   dae66:	48 85 f6             	test   %rsi,%rsi
   dae69:	0f 8f 11 01 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   dae6f:	e9 2c fd ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   dae74:	89 f8                	mov    %edi,%eax
   dae76:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   dae7b:	48 85 f6             	test   %rsi,%rsi
   dae7e:	0f 8f fc 00 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   dae84:	e9 17 fd ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   dae89:	89 f9                	mov    %edi,%ecx
   dae8b:	eb 41                	jmp    daece <varlit_core::native_layout::read_native_record_header+0x42e>
   dae8d:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   dae92:	48 85 f6             	test   %rsi,%rsi
   dae95:	0f 8f e5 00 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   dae9b:	e9 00 fd ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   daea0:	48 89 f8             	mov    %rdi,%rax
   daea3:	48 c1 e8 20          	shr    $0x20,%rax
   daea7:	48 89 f9             	mov    %rdi,%rcx
   daeaa:	74 22                	je     daece <varlit_core::native_layout::read_native_record_header+0x42e>
   daeac:	e9 59 01 00 00       	jmp    db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   daeb1:	0f b7 c7             	movzwl %di,%eax
   daeb4:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   daeb9:	48 85 f6             	test   %rsi,%rsi
   daebc:	0f 8f be 00 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   daec2:	e9 d9 fc ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   daec7:	89 f9                	mov    %edi,%ecx
   daec9:	eb 5a                	jmp    daf25 <varlit_core::native_layout::read_native_record_header+0x485>
   daecb:	0f b7 cf             	movzwl %di,%ecx
   daece:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
   daed5:	ff ff ff 
   daed8:	48 21 c2             	and    %rax,%rdx
   daedb:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   daee0:	48 09 ca             	or     %rcx,%rdx
   daee3:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
   daee8:	b0 01                	mov    $0x1,%al
   daeea:	89 44 24 24          	mov    %eax,0x24(%rsp)
   daeee:	48 85 f6             	test   %rsi,%rsi
   daef1:	0f 8f 89 00 00 00    	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   daef7:	e9 a4 fc ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   daefc:	89 f9                	mov    %edi,%ecx
   daefe:	eb 52                	jmp    daf52 <varlit_core::native_layout::read_native_record_header+0x4b2>
   daf00:	48 89 f8             	mov    %rdi,%rax
   daf03:	48 c1 e8 20          	shr    $0x20,%rax
   daf07:	48 89 f9             	mov    %rdi,%rcx
   daf0a:	74 19                	je     daf25 <varlit_core::native_layout::read_native_record_header+0x485>
   daf0c:	e9 f9 00 00 00       	jmp    db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   daf11:	48 89 f8             	mov    %rdi,%rax
   daf14:	48 c1 e8 20          	shr    $0x20,%rax
   daf18:	48 89 f9             	mov    %rdi,%rcx
   daf1b:	74 35                	je     daf52 <varlit_core::native_layout::read_native_record_header+0x4b2>
   daf1d:	e9 e8 00 00 00       	jmp    db00a <varlit_core::native_layout::read_native_record_header+0x56a>
   daf22:	0f b7 cf             	movzwl %di,%ecx
   daf25:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
   daf2c:	ff ff ff 
   daf2f:	48 21 c2             	and    %rax,%rdx
   daf32:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   daf37:	48 09 ca             	or     %rcx,%rdx
   daf3a:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
   daf3f:	b0 01                	mov    $0x1,%al
   daf41:	89 44 24 10          	mov    %eax,0x10(%rsp)
   daf45:	48 85 f6             	test   %rsi,%rsi
   daf48:	7f 36                	jg     daf80 <varlit_core::native_layout::read_native_record_header+0x4e0>
   daf4a:	e9 51 fc ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   daf4f:	0f b7 cf             	movzwl %di,%ecx
   daf52:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
   daf59:	ff ff ff 
   daf5c:	48 21 c2             	and    %rax,%rdx
   daf5f:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   daf64:	48 09 ca             	or     %rcx,%rdx
   daf67:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
   daf6e:	00 
   daf6f:	b0 01                	mov    $0x1,%al
   daf71:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   daf75:	48 85 f6             	test   %rsi,%rsi
   daf78:	0f 8e 22 fc ff ff    	jle    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   daf7e:	66 90                	xchg   %ax,%ax
   daf80:	ba 01 00 00 00       	mov    $0x1,%edx
   daf85:	ff 15 5d 13 0f 00    	call   *0xf135d(%rip)        # 1cc2e8 <_DYNAMIC+0x2f0>
   daf8b:	e9 10 fc ff ff       	jmp    daba0 <varlit_core::native_layout::read_native_record_header+0x100>
   daf90:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   daf97:	00 
   daf98:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
   daf9f:	00 
   dafa0:	48 89 53 30          	mov    %rdx,0x30(%rbx)
   dafa4:	0f 10 84 24 b8 00 00 	movups 0xb8(%rsp),%xmm0
   dafab:	00 
   dafac:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   dafb0:	48 89 73 08          	mov    %rsi,0x8(%rbx)
   dafb4:	48 89 7b 10          	mov    %rdi,0x10(%rbx)
   dafb8:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
   dafbc:	48 89 03             	mov    %rax,(%rbx)
   dafbf:	eb 72                	jmp    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   dafc1:	49 83 c4 1d          	add    $0x1d,%r12
   dafc5:	4c 89 23             	mov    %r12,(%rbx)
   dafc8:	48 8d 05 fa d3 f4 ff 	lea    -0xb2c06(%rip),%rax        # 283c9 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0xa22>
   dafcf:	48 89 43 08          	mov    %rax,0x8(%rbx)
   dafd3:	b8 2d 00 00 00       	mov    $0x2d,%eax
   dafd8:	48 89 43 10          	mov    %rax,0x10(%rbx)
   dafdc:	48 85 f6             	test   %rsi,%rsi
   dafdf:	7f 47                	jg     db028 <varlit_core::native_layout::read_native_record_header+0x588>
   dafe1:	eb 50                	jmp    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   dafe3:	48 83 bc 24 90 00 00 	cmpq   $0x0,0x90(%rsp)
   dafea:	00 00 
   dafec:	74 5a                	je     db048 <varlit_core::native_layout::read_native_record_header+0x5a8>
   dafee:	49 83 c4 1d          	add    $0x1d,%r12
   daff2:	4c 89 23             	mov    %r12,(%rbx)
   daff5:	48 8d 05 09 d5 f4 ff 	lea    -0xb2af7(%rip),%rax        # 28505 <anon.96378bedfb121199e70b9883f72b5729.60.llvm.1968423816126862537+0x15>
   daffc:	48 89 43 08          	mov    %rax,0x8(%rbx)
   db000:	48 c7 43 10 36 00 00 	movq   $0x36,0x10(%rbx)
   db007:	00 
   db008:	eb 29                	jmp    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   db00a:	4a 8b 4c 35 f0       	mov    -0x10(%rbp,%r14,1),%rcx
   db00f:	4a 8b 44 35 f8       	mov    -0x8(%rbp,%r14,1),%rax
   db014:	49 83 c4 6d          	add    $0x6d,%r12
   db018:	4c 89 23             	mov    %r12,(%rbx)
   db01b:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   db01f:	48 89 43 10          	mov    %rax,0x10(%rbx)
   db023:	48 85 f6             	test   %rsi,%rsi
   db026:	7e 0b                	jle    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   db028:	ba 01 00 00 00       	mov    $0x1,%edx
   db02d:	ff 15 b5 12 0f 00    	call   *0xf12b5(%rip)        # 1cc2e8 <_DYNAMIC+0x2f0>
   db033:	48 89 d8             	mov    %rbx,%rax
   db036:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
   db03d:	5b                   	pop    %rbx
   db03e:	41 5c                	pop    %r12
   db040:	41 5d                	pop    %r13
   db042:	41 5e                	pop    %r14
   db044:	41 5f                	pop    %r15
   db046:	5d                   	pop    %rbp
   db047:	c3                   	ret
   db048:	f6 44 24 24 01       	testb  $0x1,0x24(%rsp)
   db04d:	0f 84 8e 00 00 00    	je     db0e1 <varlit_core::native_layout::read_native_record_header+0x641>
   db053:	f6 44 24 20 01       	testb  $0x1,0x20(%rsp)
   db058:	0f 84 a2 00 00 00    	je     db100 <varlit_core::native_layout::read_native_record_header+0x660>
   db05e:	f6 44 24 18 01       	testb  $0x1,0x18(%rsp)
   db063:	0f 84 b6 00 00 00    	je     db11f <varlit_core::native_layout::read_native_record_header+0x67f>
   db069:	f6 44 24 1c 01       	testb  $0x1,0x1c(%rsp)
   db06e:	0f 84 ca 00 00 00    	je     db13e <varlit_core::native_layout::read_native_record_header+0x69e>
   db074:	f6 44 24 14 01       	testb  $0x1,0x14(%rsp)
   db079:	0f 84 cf 00 00 00    	je     db14e <varlit_core::native_layout::read_native_record_header+0x6ae>
   db07f:	f6 44 24 10 01       	testb  $0x1,0x10(%rsp)
   db084:	0f 84 e3 00 00 00    	je     db16d <varlit_core::native_layout::read_native_record_header+0x6cd>
   db08a:	f6 44 24 0c 01       	testb  $0x1,0xc(%rsp)
   db08f:	0f 84 eb 00 00 00    	je     db180 <varlit_core::native_layout::read_native_record_header+0x6e0>
   db095:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   db09a:	48 89 43 08          	mov    %rax,0x8(%rbx)
   db09e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   db0a3:	48 89 43 10          	mov    %rax,0x10(%rbx)
   db0a7:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   db0ac:	89 43 18             	mov    %eax,0x18(%rbx)
   db0af:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   db0b4:	89 43 1c             	mov    %eax,0x1c(%rbx)
   db0b7:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   db0bc:	89 43 20             	mov    %eax,0x20(%rbx)
   db0bf:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   db0c4:	66 89 43 24          	mov    %ax,0x24(%rbx)
   db0c8:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   db0cd:	66 89 43 26          	mov    %ax,0x26(%rbx)
   db0d1:	48 c7 43 28 20 00 00 	movq   $0x20,0x28(%rbx)
   db0d8:	00 
   db0d9:	4c 89 2b             	mov    %r13,(%rbx)
   db0dc:	e9 52 ff ff ff       	jmp    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   db0e1:	49 83 c4 6b          	add    $0x6b,%r12
   db0e5:	4c 89 23             	mov    %r12,(%rbx)
   db0e8:	48 8d 05 d9 ed f3 ff 	lea    -0xc1227(%rip),%rax        # 19ec8 <anon.96378bedfb121199e70b9883f72b5729.54.llvm.1968423816126862537>
   db0ef:	48 89 43 08          	mov    %rax,0x8(%rbx)
   db0f3:	48 c7 43 10 08 00 00 	movq   $0x8,0x10(%rbx)
   db0fa:	00 
   db0fb:	e9 33 ff ff ff       	jmp    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   db100:	49 83 c4 6b          	add    $0x6b,%r12
   db104:	4c 89 23             	mov    %r12,(%rbx)
   db107:	48 8d 05 be d3 f4 ff 	lea    -0xb2c42(%rip),%rax        # 284cc <anon.96378bedfb121199e70b9883f72b5729.55.llvm.1968423816126862537>
   db10e:	48 89 43 08          	mov    %rax,0x8(%rbx)
   db112:	48 c7 43 10 0d 00 00 	movq   $0xd,0x10(%rbx)
   db119:	00 
   db11a:	e9 14 ff ff ff       	jmp    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   db11f:	49 83 c4 6b          	add    $0x6b,%r12
   db123:	4c 89 23             	mov    %r12,(%rbx)
   db126:	48 8d 05 63 d3 f4 ff 	lea    -0xb2c9d(%rip),%rax        # 28490 <anon.96378bedfb121199e70b9883f72b5729.46.llvm.1968423816126862537>
   db12d:	48 89 43 08          	mov    %rax,0x8(%rbx)
   db131:	48 c7 43 10 05 00 00 	movq   $0x5,0x10(%rbx)
   db138:	00 
   db139:	e9 f5 fe ff ff       	jmp    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   db13e:	49 83 c4 6b          	add    $0x6b,%r12
   db142:	4c 89 23             	mov    %r12,(%rbx)
   db145:	48 8d 05 34 ec f3 ff 	lea    -0xc13cc(%rip),%rax        # 19d80 <anon.96378bedfb121199e70b9883f72b5729.57.llvm.1968423816126862537>
   db14c:	eb a1                	jmp    db0ef <varlit_core::native_layout::read_native_record_header+0x64f>
   db14e:	49 83 c4 6b          	add    $0x6b,%r12
   db152:	4c 89 23             	mov    %r12,(%rbx)
   db155:	48 8d 05 89 d3 f4 ff 	lea    -0xb2c77(%rip),%rax        # 284e5 <anon.96378bedfb121199e70b9883f72b5729.58.llvm.1968423816126862537>
   db15c:	48 89 43 08          	mov    %rax,0x8(%rbx)
   db160:	48 c7 43 10 0b 00 00 	movq   $0xb,0x10(%rbx)
   db167:	00 
   db168:	e9 c6 fe ff ff       	jmp    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   db16d:	49 83 c4 6b          	add    $0x6b,%r12
   db171:	4c 89 23             	mov    %r12,(%rbx)
   db174:	48 8d 05 7d ec f3 ff 	lea    -0xc1383(%rip),%rax        # 19df8 <anon.96378bedfb121199e70b9883f72b5729.59.llvm.1968423816126862537>
   db17b:	e9 6f ff ff ff       	jmp    db0ef <varlit_core::native_layout::read_native_record_header+0x64f>
   db180:	49 83 c4 6b          	add    $0x6b,%r12
   db184:	4c 89 23             	mov    %r12,(%rbx)
   db187:	48 8d 05 62 d3 f4 ff 	lea    -0xb2c9e(%rip),%rax        # 284f0 <anon.96378bedfb121199e70b9883f72b5729.60.llvm.1968423816126862537>
   db18e:	48 89 43 08          	mov    %rax,0x8(%rbx)
   db192:	48 c7 43 10 15 00 00 	movq   $0x15,0x10(%rbx)
   db199:	00 
   db19a:	e9 94 fe ff ff       	jmp    db033 <varlit_core::native_layout::read_native_record_header+0x593>
   db19f:	cc                   	int3

