00000000000db360 <varlit_core::native_layout::decode_native_record_footer>:
   db360:	55                   	push   %rbp
   db361:	41 57                	push   %r15
   db363:	41 56                	push   %r14
   db365:	41 55                	push   %r13
   db367:	41 54                	push   %r12
   db369:	53                   	push   %rbx
   db36a:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
   db371:	48 89 f5             	mov    %rsi,%rbp
   db374:	48 89 f8             	mov    %rdi,%rax
   db377:	48 be 30 00 00 00 00 	movabs $0x8000000000000030,%rsi
   db37e:	00 00 80 
   db381:	48 83 fa 20          	cmp    $0x20,%rdx
   db385:	0f 85 54 03 00 00    	jne    db6df <varlit_core::native_layout::decode_native_record_footer+0x37f>
   db38b:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   db390:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
   db395:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   db39a:	31 db                	xor    %ebx,%ebx
   db39c:	41 bd 20 00 00 00    	mov    $0x20,%r13d
   db3a2:	4c 8d 3d 9f ce 0e 00 	lea    0xece9f(%rip),%r15        # 1c8248 <anon.96378bedfb121199e70b9883f72b5729.70.llvm.1968423816126862537>
   db3a9:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
   db3b0:	00 00 00 00 00 
   db3b5:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   db3bc:	00 00 00 00 00 
   db3c1:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   db3c8:	00 00 
   db3ca:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   db3d1:	00 00 
   db3d3:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   db3d7:	49 89 de             	mov    %rbx,%r14
   db3da:	48 83 c3 40          	add    $0x40,%rbx
   db3de:	66 90                	xchg   %ax,%ax
   db3e0:	45 0f b6 67 38       	movzbl 0x38(%r15),%r12d
   db3e5:	41 83 fc 07          	cmp    $0x7,%r12d
   db3e9:	75 68                	jne    db453 <varlit_core::native_layout::decode_native_record_footer+0xf3>
   db3eb:	41 80 7f 10 00       	cmpb   $0x0,0x10(%r15)
   db3f0:	0f 85 d0 02 00 00    	jne    db6c6 <varlit_core::native_layout::decode_native_record_footer+0x366>
   db3f6:	49 83 3f 00          	cmpq   $0x0,(%r15)
   db3fa:	0f 85 c6 02 00 00    	jne    db6c6 <varlit_core::native_layout::decode_native_record_footer+0x366>
   db400:	4d 8b 67 20          	mov    0x20(%r15),%r12
   db404:	4d 39 67 08          	cmp    %r12,0x8(%r15)
   db408:	0f 85 b8 02 00 00    	jne    db6c6 <varlit_core::native_layout::decode_native_record_footer+0x366>
   db40e:	4d 29 e5             	sub    %r12,%r13
   db411:	0f 82 af 02 00 00    	jb     db6c6 <varlit_core::native_layout::decode_native_record_footer+0x366>
   db417:	49 8b 77 18          	mov    0x18(%r15),%rsi
   db41b:	48 89 ef             	mov    %rbp,%rdi
   db41e:	4c 89 e2             	mov    %r12,%rdx
   db421:	ff 15 29 12 0f 00    	call   *0xf1229(%rip)        # 1cc650 <bcmp@GLIBC_2.2.5>
   db427:	85 c0                	test   %eax,%eax
   db429:	0f 85 97 02 00 00    	jne    db6c6 <varlit_core::native_layout::decode_native_record_footer+0x366>
   db42f:	49 83 c6 40          	add    $0x40,%r14
   db433:	4c 01 e5             	add    %r12,%rbp
   db436:	48 8d 05 0b ce 0e 00 	lea    0xece0b(%rip),%rax        # 1c8248 <anon.96378bedfb121199e70b9883f72b5729.70.llvm.1968423816126862537>
   db43d:	4e 8d 3c 30          	lea    (%rax,%r14,1),%r15
   db441:	48 83 c3 40          	add    $0x40,%rbx
   db445:	48 81 fb 00 02 00 00 	cmp    $0x200,%rbx
   db44c:	75 92                	jne    db3e0 <varlit_core::native_layout::decode_native_record_footer+0x80>
   db44e:	e9 6e 02 00 00       	jmp    db6c1 <varlit_core::native_layout::decode_native_record_footer+0x361>
   db453:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
   db45a:	00 
   db45b:	48 89 ac 24 90 00 00 	mov    %rbp,0x90(%rsp)
   db462:	00 
   db463:	49 8b 17             	mov    (%r15),%rdx
   db466:	49 8b 4f 08          	mov    0x8(%r15),%rcx
   db46a:	41 0f b6 6f 10       	movzbl 0x10(%r15),%ebp
   db46f:	4d 8b 77 18          	mov    0x18(%r15),%r14
   db473:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   db47a:	00 
   db47b:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   db482:	00 
   db483:	e8 58 c8 ff ff       	call   d7ce0 <varlit_core::native_layout::read_native_value>
   db488:	49 bd 30 00 00 00 00 	movabs $0x8000000000000030,%r13
   db48f:	00 00 80 
   db492:	49 8d 45 4d          	lea    0x4d(%r13),%rax
   db496:	48 39 84 24 a0 00 00 	cmp    %rax,0xa0(%rsp)
   db49d:	00 
   db49e:	0f 85 d1 02 00 00    	jne    db775 <varlit_core::native_layout::decode_native_record_footer+0x415>
   db4a4:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
   db4ab:	00 
   db4ac:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
   db4b3:	00 
   db4b4:	44 89 e0             	mov    %r12d,%eax
   db4b7:	48 8d 0d fa c8 f4 ff 	lea    -0xb3706(%rip),%rcx        # 27db8 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x411>
   db4be:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   db4c2:	48 01 c8             	add    %rcx,%rax
   db4c5:	ff e0                	jmp    *%rax
   db4c7:	40 80 fd 01          	cmp    $0x1,%bpl
   db4cb:	0f 85 34 04 00 00    	jne    db905 <varlit_core::native_layout::decode_native_record_footer+0x5a5>
   db4d1:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
   db4d5:	48 83 c1 d1          	add    $0xffffffffffffffd1,%rcx
   db4d9:	48 89 f0             	mov    %rsi,%rax
   db4dc:	48 c1 f8 3f          	sar    $0x3f,%rax
   db4e0:	48 21 c8             	and    %rcx,%rax
   db4e3:	48 ff c8             	dec    %rax
   db4e6:	48 83 f8 03          	cmp    $0x3,%rax
   db4ea:	0f 87 ec 03 00 00    	ja     db8dc <varlit_core::native_layout::decode_native_record_footer+0x57c>
   db4f0:	48 8d 15 29 c9 f4 ff 	lea    -0xb36d7(%rip),%rdx        # 27e20 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x479>
   db4f7:	48 63 0c 82          	movslq (%rdx,%rax,4),%rcx
   db4fb:	48 01 d1             	add    %rdx,%rcx
   db4fe:	48 89 f8             	mov    %rdi,%rax
   db501:	ff e1                	jmp    *%rcx
   db503:	40 0f b6 c7          	movzbl %dil,%eax
   db507:	e9 09 01 00 00       	jmp    db615 <varlit_core::native_layout::decode_native_record_footer+0x2b5>
   db50c:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
   db510:	48 83 c1 d1          	add    $0xffffffffffffffd1,%rcx
   db514:	48 89 f0             	mov    %rsi,%rax
   db517:	48 c1 f8 3f          	sar    $0x3f,%rax
   db51b:	48 21 c8             	and    %rcx,%rax
   db51e:	48 ff c8             	dec    %rax
   db521:	48 83 f8 03          	cmp    $0x3,%rax
   db525:	0f 87 5c 04 00 00    	ja     db987 <varlit_core::native_layout::decode_native_record_footer+0x627>
   db52b:	b1 01                	mov    $0x1,%cl
   db52d:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
   db534:	00 
   db535:	48 8d 0d d4 c8 f4 ff 	lea    -0xb372c(%rip),%rcx        # 27e10 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x469>
   db53c:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   db540:	48 01 c8             	add    %rcx,%rax
   db543:	ff e0                	jmp    *%rax
   db545:	40 0f b6 c7          	movzbl %dil,%eax
   db549:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   db54e:	e9 36 01 00 00       	jmp    db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db553:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
   db557:	48 83 c1 d1          	add    $0xffffffffffffffd1,%rcx
   db55b:	48 89 f0             	mov    %rsi,%rax
   db55e:	48 c1 f8 3f          	sar    $0x3f,%rax
   db562:	48 21 c8             	and    %rcx,%rax
   db565:	48 ff c8             	dec    %rax
   db568:	48 83 f8 03          	cmp    $0x3,%rax
   db56c:	0f 87 f0 03 00 00    	ja     db962 <varlit_core::native_layout::decode_native_record_footer+0x602>
   db572:	48 8d 0d 77 c8 f4 ff 	lea    -0xb3789(%rip),%rcx        # 27df0 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x449>
   db579:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   db57d:	48 01 c8             	add    %rcx,%rax
   db580:	48 89 f9             	mov    %rdi,%rcx
   db583:	ff e0                	jmp    *%rax
   db585:	40 0f b6 cf          	movzbl %dil,%ecx
   db589:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
   db58e:	e9 f6 00 00 00       	jmp    db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db593:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
   db597:	48 83 c1 d1          	add    $0xffffffffffffffd1,%rcx
   db59b:	48 89 f0             	mov    %rsi,%rax
   db59e:	48 c1 f8 3f          	sar    $0x3f,%rax
   db5a2:	48 21 c8             	and    %rcx,%rax
   db5a5:	48 83 f8 04          	cmp    $0x4,%rax
   db5a9:	74 74                	je     db61f <varlit_core::native_layout::decode_native_record_footer+0x2bf>
   db5ab:	48 83 f8 02          	cmp    $0x2,%rax
   db5af:	74 7b                	je     db62c <varlit_core::native_layout::decode_native_record_footer+0x2cc>
   db5b1:	48 83 f8 01          	cmp    $0x1,%rax
   db5b5:	0f 85 d5 02 00 00    	jne    db890 <varlit_core::native_layout::decode_native_record_footer+0x530>
   db5bb:	40 0f b6 c7          	movzbl %dil,%eax
   db5bf:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   db5c3:	b0 01                	mov    $0x1,%al
   db5c5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   db5ca:	e9 ba 00 00 00       	jmp    db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db5cf:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
   db5d3:	48 83 c1 d1          	add    $0xffffffffffffffd1,%rcx
   db5d7:	48 89 f0             	mov    %rsi,%rax
   db5da:	48 c1 f8 3f          	sar    $0x3f,%rax
   db5de:	48 21 c8             	and    %rcx,%rax
   db5e1:	48 ff c8             	dec    %rax
   db5e4:	48 83 f8 03          	cmp    $0x3,%rax
   db5e8:	0f 87 4f 03 00 00    	ja     db93d <varlit_core::native_layout::decode_native_record_footer+0x5dd>
   db5ee:	b1 01                	mov    $0x1,%cl
   db5f0:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
   db5f7:	00 
   db5f8:	48 8d 0d 01 c8 f4 ff 	lea    -0xb37ff(%rip),%rcx        # 27e00 <anon.4307e3c29df9d9703651c40ac3128397.106.llvm.3723115464131915463+0x459>
   db5ff:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   db603:	48 01 c8             	add    %rcx,%rax
   db606:	ff e0                	jmp    *%rax
   db608:	40 0f b6 c7          	movzbl %dil,%eax
   db60c:	eb 76                	jmp    db684 <varlit_core::native_layout::decode_native_record_footer+0x324>
   db60e:	0f b7 c7             	movzwl %di,%eax
   db611:	eb 02                	jmp    db615 <varlit_core::native_layout::decode_native_record_footer+0x2b5>
   db613:	89 f8                	mov    %edi,%eax
   db615:	4c 39 f0             	cmp    %r14,%rax
   db618:	74 6f                	je     db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db61a:	e9 e6 02 00 00       	jmp    db905 <varlit_core::native_layout::decode_native_record_footer+0x5a5>
   db61f:	48 81 ff ff ff 00 00 	cmp    $0xffff,%rdi
   db626:	0f 87 64 02 00 00    	ja     db890 <varlit_core::native_layout::decode_native_record_footer+0x530>
   db62c:	b0 01                	mov    $0x1,%al
   db62e:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   db633:	89 f8                	mov    %edi,%eax
   db635:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   db639:	eb 4e                	jmp    db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db63b:	89 f8                	mov    %edi,%eax
   db63d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   db642:	eb 45                	jmp    db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db644:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   db649:	eb 3e                	jmp    db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db64b:	89 f8                	mov    %edi,%eax
   db64d:	eb 35                	jmp    db684 <varlit_core::native_layout::decode_native_record_footer+0x324>
   db64f:	48 89 f8             	mov    %rdi,%rax
   db652:	48 c1 e8 20          	shr    $0x20,%rax
   db656:	48 89 f9             	mov    %rdi,%rcx
   db659:	0f 85 a6 02 00 00    	jne    db905 <varlit_core::native_layout::decode_native_record_footer+0x5a5>
   db65f:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
   db664:	eb 23                	jmp    db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db666:	0f b7 c7             	movzwl %di,%eax
   db669:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   db66e:	eb 19                	jmp    db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db670:	0f b7 cf             	movzwl %di,%ecx
   db673:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
   db678:	eb 0f                	jmp    db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db67a:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   db67f:	eb 08                	jmp    db689 <varlit_core::native_layout::decode_native_record_footer+0x329>
   db681:	0f b7 c7             	movzwl %di,%eax
   db684:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   db689:	48 85 f6             	test   %rsi,%rsi
   db68c:	7e 0b                	jle    db699 <varlit_core::native_layout::decode_native_record_footer+0x339>
   db68e:	ba 01 00 00 00       	mov    $0x1,%edx
   db693:	ff 15 4f 0c 0f 00    	call   *0xf0c4f(%rip)        # 1cc2e8 <_DYNAMIC+0x2f0>
   db699:	48 8b ac 24 90 00 00 	mov    0x90(%rsp),%rbp
   db6a0:	00 
   db6a1:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   db6a8:	00 
   db6a9:	48 8d 05 98 cb 0e 00 	lea    0xecb98(%rip),%rax        # 1c8248 <anon.96378bedfb121199e70b9883f72b5729.70.llvm.1968423816126862537>
   db6b0:	4c 8d 3c 18          	lea    (%rax,%rbx,1),%r15
   db6b4:	48 81 fb c0 01 00 00 	cmp    $0x1c0,%rbx
   db6bb:	0f 85 16 fd ff ff    	jne    db3d7 <varlit_core::native_layout::decode_native_record_footer+0x77>
   db6c1:	4d 85 ed             	test   %r13,%r13
   db6c4:	74 32                	je     db6f8 <varlit_core::native_layout::decode_native_record_footer+0x398>
   db6c6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   db6cb:	48 b9 30 00 00 00 00 	movabs $0x8000000000000030,%rcx
   db6d2:	00 00 80 
   db6d5:	48 89 08             	mov    %rcx,(%rax)
   db6d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   db6dd:	eb 03                	jmp    db6e2 <varlit_core::native_layout::decode_native_record_footer+0x382>
   db6df:	48 89 30             	mov    %rsi,(%rax)
   db6e2:	48 89 48 08          	mov    %rcx,0x8(%rax)
   db6e6:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
   db6ed:	5b                   	pop    %rbx
   db6ee:	41 5c                	pop    %r12
   db6f0:	41 5d                	pop    %r13
   db6f2:	41 5e                	pop    %r14
   db6f4:	41 5f                	pop    %r15
   db6f6:	5d                   	pop    %rbp
   db6f7:	c3                   	ret
   db6f8:	f6 44 24 30 01       	testb  $0x1,0x30(%rsp)
   db6fd:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   db702:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
   db707:	49 b9 30 00 00 00 00 	movabs $0x8000000000000030,%r9
   db70e:	00 00 80 
   db711:	74 3b                	je     db74e <varlit_core::native_layout::decode_native_record_footer+0x3ee>
   db713:	44 8b 5c 24 1c       	mov    0x1c(%rsp),%r11d
   db718:	66 41 83 fb 04       	cmp    $0x4,%r11w
   db71d:	73 2f                	jae    db74e <varlit_core::native_layout::decode_native_record_footer+0x3ee>
   db71f:	f6 84 24 88 00 00 00 	testb  $0x1,0x88(%rsp)
   db726:	01 
   db727:	74 2e                	je     db757 <varlit_core::native_layout::decode_native_record_footer+0x3f7>
   db729:	48 89 c7             	mov    %rax,%rdi
   db72c:	41 f6 c3 01          	test   $0x1,%r11b
   db730:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
   db735:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
   db73a:	0f 85 bf 00 00 00    	jne    db7ff <varlit_core::native_layout::decode_native_record_footer+0x49f>
   db740:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
   db746:	0f 85 35 01 00 00    	jne    db881 <varlit_core::native_layout::decode_native_record_footer+0x521>
   db74c:	eb 20                	jmp    db76e <varlit_core::native_layout::decode_native_record_footer+0x40e>
   db74e:	4c 89 08             	mov    %r9,(%rax)
   db751:	4c 89 40 08          	mov    %r8,0x8(%rax)
   db755:	eb 8f                	jmp    db6e6 <varlit_core::native_layout::decode_native_record_footer+0x386>
   db757:	48 89 c7             	mov    %rax,%rdi
   db75a:	41 f6 c3 01          	test   $0x1,%r11b
   db75e:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
   db763:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
   db768:	0f 85 13 01 00 00    	jne    db881 <varlit_core::native_layout::decode_native_record_footer+0x521>
   db76e:	31 c0                	xor    %eax,%eax
   db770:	e9 a4 00 00 00       	jmp    db819 <varlit_core::native_layout::decode_native_record_footer+0x4b9>
   db775:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   db77c:	00 
   db77d:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   db782:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
   db789:	00 
   db78a:	0f 10 8c 24 b0 00 00 	movups 0xb0(%rsp),%xmm1
   db791:	00 
   db792:	0f 10 94 24 c0 00 00 	movups 0xc0(%rsp),%xmm2
   db799:	00 
   db79a:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
   db79f:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
   db7a4:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   db7a9:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   db7ae:	e8 9d 12 00 00       	call   dca50 <core::ptr::drop_in_place<varlit_core::error::Error>>
   db7b3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   db7b8:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   db7bf:	00 
   db7c0:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   db7c7:	00 
   db7c8:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   db7cd:	48 89 41 30          	mov    %rax,0x30(%rcx)
   db7d1:	0f 10 84 24 c0 00 00 	movups 0xc0(%rsp),%xmm0
   db7d8:	00 
   db7d9:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
   db7dd:	48 8d 84 24 a8 00 00 	lea    0xa8(%rsp),%rax
   db7e4:	00 
   db7e5:	0f 10 00             	movups (%rax),%xmm0
   db7e8:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
   db7ec:	48 8b 40 10          	mov    0x10(%rax),%rax
   db7f0:	48 89 41 18          	mov    %rax,0x18(%rcx)
   db7f4:	48 89 c8             	mov    %rcx,%rax
   db7f7:	4c 89 29             	mov    %r13,(%rcx)
   db7fa:	e9 e7 fe ff ff       	jmp    db6e6 <varlit_core::native_layout::decode_native_record_footer+0x386>
   db7ff:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
   db804:	48 85 db             	test   %rbx,%rbx
   db807:	0f 95 c1             	setne  %cl
   db80a:	48 39 f3             	cmp    %rsi,%rbx
   db80d:	0f 92 c2             	setb   %dl
   db810:	b8 01 00 00 00       	mov    $0x1,%eax
   db815:	84 d1                	test   %dl,%cl
   db817:	74 68                	je     db881 <varlit_core::native_layout::decode_native_record_footer+0x521>
   db819:	f6 84 24 80 00 00 00 	testb  $0x1,0x80(%rsp)
   db820:	01 
   db821:	74 11                	je     db834 <varlit_core::native_layout::decode_native_record_footer+0x4d4>
   db823:	66 41 83 fb 02       	cmp    $0x2,%r11w
   db828:	73 15                	jae    db83f <varlit_core::native_layout::decode_native_record_footer+0x4df>
   db82a:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
   db830:	75 4f                	jne    db881 <varlit_core::native_layout::decode_native_record_footer+0x521>
   db832:	eb 07                	jmp    db83b <varlit_core::native_layout::decode_native_record_footer+0x4db>
   db834:	66 41 83 fb 02       	cmp    $0x2,%r11w
   db839:	73 46                	jae    db881 <varlit_core::native_layout::decode_native_record_footer+0x521>
   db83b:	31 c9                	xor    %ecx,%ecx
   db83d:	eb 1f                	jmp    db85e <varlit_core::native_layout::decode_native_record_footer+0x4fe>
   db83f:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
   db844:	4d 85 db             	test   %r11,%r11
   db847:	0f 95 c2             	setne  %dl
   db84a:	49 39 f3             	cmp    %rsi,%r11
   db84d:	40 0f 92 c6          	setb   %sil
   db851:	b9 01 00 00 00       	mov    $0x1,%ecx
   db856:	40 84 f2             	test   %sil,%dl
   db859:	4c 89 da             	mov    %r11,%rdx
   db85c:	74 23                	je     db881 <varlit_core::native_layout::decode_native_record_footer+0x521>
   db85e:	48 89 47 08          	mov    %rax,0x8(%rdi)
   db862:	48 89 f8             	mov    %rdi,%rax
   db865:	48 89 5f 10          	mov    %rbx,0x10(%rdi)
   db869:	48 89 4f 18          	mov    %rcx,0x18(%rdi)
   db86d:	48 89 57 20          	mov    %rdx,0x20(%rdi)
   db871:	44 89 57 28          	mov    %r10d,0x28(%rdi)
   db875:	49 83 c1 4d          	add    $0x4d,%r9
   db879:	4c 89 0f             	mov    %r9,(%rdi)
   db87c:	e9 65 fe ff ff       	jmp    db6e6 <varlit_core::native_layout::decode_native_record_footer+0x386>
   db881:	48 89 f8             	mov    %rdi,%rax
   db884:	4c 89 0f             	mov    %r9,(%rdi)
   db887:	4c 89 47 08          	mov    %r8,0x8(%rdi)
   db88b:	e9 56 fe ff ff       	jmp    db6e6 <varlit_core::native_layout::decode_native_record_footer+0x386>
   db890:	49 89 fe             	mov    %rdi,%r14
   db893:	49 89 f4             	mov    %rsi,%r12
   db896:	49 8b 47 28          	mov    0x28(%r15),%rax
   db89a:	49 8b 5f 30          	mov    0x30(%r15),%rbx
   db89e:	49 8d 4d 3e          	lea    0x3e(%r13),%rcx
   db8a2:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
   db8a7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   db8ac:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   db8b1:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   db8b6:	e8 95 11 00 00       	call   dca50 <core::ptr::drop_in_place<varlit_core::error::Error>>
   db8bb:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   db8c0:	4c 89 28             	mov    %r13,(%rax)
   db8c3:	49 89 c7             	mov    %rax,%r15
   db8c6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   db8cb:	48 89 48 08          	mov    %rcx,0x8(%rax)
   db8cf:	b8 10 00 00 00       	mov    $0x10,%eax
   db8d4:	4c 89 e6             	mov    %r12,%rsi
   db8d7:	4c 89 f7             	mov    %r14,%rdi
   db8da:	eb 3e                	jmp    db91a <varlit_core::native_layout::decode_native_record_footer+0x5ba>
   db8dc:	49 89 fe             	mov    %rdi,%r14
   db8df:	49 89 f4             	mov    %rsi,%r12
   db8e2:	41 0f 10 47 28       	movups 0x28(%r15),%xmm0
   db8e7:	49 8d 45 3e          	lea    0x3e(%r13),%rax
   db8eb:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   db8f0:	0f 11 44 24 48       	movups %xmm0,0x48(%rsp)
   db8f5:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   db8fa:	e8 51 11 00 00       	call   dca50 <core::ptr::drop_in_place<varlit_core::error::Error>>
   db8ff:	4c 89 e6             	mov    %r12,%rsi
   db902:	4c 89 f7             	mov    %r14,%rdi
   db905:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   db90a:	49 89 c7             	mov    %rax,%r15
   db90d:	4c 89 28             	mov    %r13,(%rax)
   db910:	b8 08 00 00 00       	mov    $0x8,%eax
   db915:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   db91a:	49 89 1c 07          	mov    %rbx,(%r15,%rax,1)
   db91e:	4c 89 f8             	mov    %r15,%rax
   db921:	48 85 f6             	test   %rsi,%rsi
   db924:	0f 8e bc fd ff ff    	jle    db6e6 <varlit_core::native_layout::decode_native_record_footer+0x386>
   db92a:	ba 01 00 00 00       	mov    $0x1,%edx
   db92f:	ff 15 b3 09 0f 00    	call   *0xf09b3(%rip)        # 1cc2e8 <_DYNAMIC+0x2f0>
   db935:	4c 89 f8             	mov    %r15,%rax
   db938:	e9 a9 fd ff ff       	jmp    db6e6 <varlit_core::native_layout::decode_native_record_footer+0x386>
   db93d:	49 89 fe             	mov    %rdi,%r14
   db940:	49 89 f4             	mov    %rsi,%r12
   db943:	41 0f 10 47 28       	movups 0x28(%r15),%xmm0
   db948:	49 8d 45 3e          	lea    0x3e(%r13),%rax
   db94c:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   db951:	0f 11 44 24 48       	movups %xmm0,0x48(%rsp)
   db956:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   db95b:	e8 f0 10 00 00       	call   dca50 <core::ptr::drop_in_place<varlit_core::error::Error>>
   db960:	eb 48                	jmp    db9aa <varlit_core::native_layout::decode_native_record_footer+0x64a>
   db962:	49 89 fe             	mov    %rdi,%r14
   db965:	49 89 f4             	mov    %rsi,%r12
   db968:	41 0f 10 47 28       	movups 0x28(%r15),%xmm0
   db96d:	49 8d 45 3e          	lea    0x3e(%r13),%rax
   db971:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   db976:	0f 11 44 24 48       	movups %xmm0,0x48(%rsp)
   db97b:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   db980:	e8 cb 10 00 00       	call   dca50 <core::ptr::drop_in_place<varlit_core::error::Error>>
   db985:	eb 23                	jmp    db9aa <varlit_core::native_layout::decode_native_record_footer+0x64a>
   db987:	49 89 fe             	mov    %rdi,%r14
   db98a:	49 89 f4             	mov    %rsi,%r12
   db98d:	41 0f 10 47 28       	movups 0x28(%r15),%xmm0
   db992:	49 8d 45 3e          	lea    0x3e(%r13),%rax
   db996:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   db99b:	0f 11 44 24 48       	movups %xmm0,0x48(%rsp)
   db9a0:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   db9a5:	e8 a6 10 00 00       	call   dca50 <core::ptr::drop_in_place<varlit_core::error::Error>>
   db9aa:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   db9af:	49 89 c7             	mov    %rax,%r15
   db9b2:	4c 89 28             	mov    %r13,(%rax)
   db9b5:	b8 08 00 00 00       	mov    $0x8,%eax
   db9ba:	4c 89 e6             	mov    %r12,%rsi
   db9bd:	4c 89 f7             	mov    %r14,%rdi
   db9c0:	e9 50 ff ff ff       	jmp    db915 <varlit_core::native_layout::decode_native_record_footer+0x5b5>
   db9c5:	48 89 c3             	mov    %rax,%rbx
   db9c8:	4d 85 e4             	test   %r12,%r12
   db9cb:	7e 11                	jle    db9de <varlit_core::native_layout::decode_native_record_footer+0x67e>
   db9cd:	ba 01 00 00 00       	mov    $0x1,%edx
   db9d2:	4c 89 f7             	mov    %r14,%rdi
   db9d5:	4c 89 e6             	mov    %r12,%rsi
   db9d8:	ff 15 0a 09 0f 00    	call   *0xf090a(%rip)        # 1cc2e8 <_DYNAMIC+0x2f0>
   db9de:	48 89 df             	mov    %rbx,%rdi
   db9e1:	e8 da 90 0e 00       	call   1c4ac0 <_Unwind_Resume@plt>
   db9e6:	cc                   	int3
   db9e7:	cc                   	int3
   db9e8:	cc                   	int3
   db9e9:	cc                   	int3
   db9ea:	cc                   	int3
   db9eb:	cc                   	int3
   db9ec:	cc                   	int3
   db9ed:	cc                   	int3
   db9ee:	cc                   	int3
   db9ef:	cc                   	int3

