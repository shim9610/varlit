00000000000b9190 <varlit_core::snapshot::SnapshotFile::read_exact_at>:
   b9190:	55                   	push   %rbp
   b9191:	41 57                	push   %r15
   b9193:	41 56                	push   %r14
   b9195:	41 55                	push   %r13
   b9197:	41 54                	push   %r12
   b9199:	53                   	push   %rbx
   b919a:	50                   	push   %rax
   b919b:	49 89 cc             	mov    %rcx,%r12
   b919e:	49 89 d7             	mov    %rdx,%r15
   b91a1:	48 ba 15 00 00 00 00 	movabs $0x8000000000000015,%rdx
   b91a8:	00 00 80 
   b91ab:	48 8b 46 08          	mov    0x8(%rsi),%rax
   b91af:	4c 89 c1             	mov    %r8,%rcx
   b91b2:	4c 01 f9             	add    %r15,%rcx
   b91b5:	0f 82 07 01 00 00    	jb     b92c2 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x132>
   b91bb:	4d 89 c6             	mov    %r8,%r14
   b91be:	48 39 c1             	cmp    %rax,%rcx
   b91c1:	76 18                	jbe    b91db <varlit_core::snapshot::SnapshotFile::read_exact_at+0x4b>
   b91c3:	48 83 c2 02          	add    $0x2,%rdx
   b91c7:	48 89 17             	mov    %rdx,(%rdi)
   b91ca:	4c 89 7f 08          	mov    %r15,0x8(%rdi)
   b91ce:	4c 89 77 10          	mov    %r14,0x10(%rdi)
   b91d2:	48 89 47 18          	mov    %rax,0x18(%rdi)
   b91d6:	e9 84 00 00 00       	jmp    b925f <varlit_core::snapshot::SnapshotFile::read_exact_at+0xcf>
   b91db:	48 89 3c 24          	mov    %rdi,(%rsp)
   b91df:	4d 85 f6             	test   %r14,%r14
   b91e2:	74 66                	je     b924a <varlit_core::snapshot::SnapshotFile::read_exact_at+0xba>
   b91e4:	4c 8b 2e             	mov    (%rsi),%r13
   b91e7:	49 83 c5 08          	add    $0x8,%r13
   b91eb:	31 db                	xor    %ebx,%ebx
   b91ed:	eb 06                	jmp    b91f5 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x65>
   b91ef:	90                   	nop
   b91f0:	4c 39 f3             	cmp    %r14,%rbx
   b91f3:	73 55                	jae    b924a <varlit_core::snapshot::SnapshotFile::read_exact_at+0xba>
   b91f5:	48 89 d9             	mov    %rbx,%rcx
   b91f8:	4c 01 f9             	add    %r15,%rcx
   b91fb:	0f 82 9b 00 00 00    	jb     b929c <varlit_core::snapshot::SnapshotFile::read_exact_at+0x10c>
   b9201:	4c 89 f2             	mov    %r14,%rdx
   b9204:	48 29 da             	sub    %rbx,%rdx
   b9207:	49 8d 34 1c          	lea    (%r12,%rbx,1),%rsi
   b920b:	4c 89 ef             	mov    %r13,%rdi
   b920e:	ff 15 cc 3a 11 00    	call   *0x113acc(%rip)        # 1ccce0 <_DYNAMIC+0x868>
   b9214:	48 89 d5             	mov    %rdx,%rbp
   b9217:	48 83 f8 01          	cmp    $0x1,%rax
   b921b:	75 23                	jne    b9240 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xb0>
   b921d:	48 89 ef             	mov    %rbp,%rdi
   b9220:	e8 2b bf ff ff       	call   b5150 <<std::io::error::Error>::kind>
   b9225:	3c 23                	cmp    $0x23,%al
   b9227:	75 58                	jne    b9281 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xf1>
   b9229:	48 89 ef             	mov    %rbp,%rdi
   b922c:	e8 1f 03 00 00       	call   b9550 <core::ptr::drop_in_place<std::io::error::Error>>
   b9231:	eb bd                	jmp    b91f0 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x60>
   b9233:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   b923a:	84 00 00 00 00 00 
   b9240:	48 85 ed             	test   %rbp,%rbp
   b9243:	74 2c                	je     b9271 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xe1>
   b9245:	48 01 eb             	add    %rbp,%rbx
   b9248:	eb a6                	jmp    b91f0 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x60>
   b924a:	48 b8 15 00 00 00 00 	movabs $0x8000000000000015,%rax
   b9251:	00 00 80 
   b9254:	48 83 c0 68          	add    $0x68,%rax
   b9258:	48 8b 3c 24          	mov    (%rsp),%rdi
   b925c:	48 89 07             	mov    %rax,(%rdi)
   b925f:	48 89 f8             	mov    %rdi,%rax
   b9262:	48 83 c4 08          	add    $0x8,%rsp
   b9266:	5b                   	pop    %rbx
   b9267:	41 5c                	pop    %r12
   b9269:	41 5d                	pop    %r13
   b926b:	41 5e                	pop    %r14
   b926d:	41 5f                	pop    %r15
   b926f:	5d                   	pop    %rbp
   b9270:	c3                   	ret
   b9271:	48 b8 15 00 00 00 00 	movabs $0x8000000000000015,%rax
   b9278:	00 00 80 
   b927b:	48 83 c0 f6          	add    $0xfffffffffffffff6,%rax
   b927f:	eb d7                	jmp    b9258 <varlit_core::snapshot::SnapshotFile::read_exact_at+0xc8>
   b9281:	48 b8 15 00 00 00 00 	movabs $0x8000000000000015,%rax
   b9288:	00 00 80 
   b928b:	48 83 c0 f1          	add    $0xfffffffffffffff1,%rax
   b928f:	48 8b 3c 24          	mov    (%rsp),%rdi
   b9293:	48 89 07             	mov    %rax,(%rdi)
   b9296:	48 89 6f 08          	mov    %rbp,0x8(%rdi)
   b929a:	eb c3                	jmp    b925f <varlit_core::snapshot::SnapshotFile::read_exact_at+0xcf>
   b929c:	48 8b 3c 24          	mov    (%rsp),%rdi
   b92a0:	48 b8 15 00 00 00 00 	movabs $0x8000000000000015,%rax
   b92a7:	00 00 80 
   b92aa:	48 89 07             	mov    %rax,(%rdi)
   b92ad:	48 8d 05 ed b7 f6 ff 	lea    -0x94813(%rip),%rax        # 24aa1 <anon.44dfe6286d6883d57c2709f00721256e.111.llvm.7670212196679453716>
   b92b4:	48 89 47 08          	mov    %rax,0x8(%rdi)
   b92b8:	48 c7 47 10 14 00 00 	movq   $0x14,0x10(%rdi)
   b92bf:	00 
   b92c0:	eb 9d                	jmp    b925f <varlit_core::snapshot::SnapshotFile::read_exact_at+0xcf>
   b92c2:	4c 8d 3d 01 b7 f6 ff 	lea    -0x948ff(%rip),%r15        # 249ca <anon.44dfe6286d6883d57c2709f00721256e.28.llvm.7670212196679453716>
   b92c9:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   b92cf:	e9 f3 fe ff ff       	jmp    b91c7 <varlit_core::snapshot::SnapshotFile::read_exact_at+0x37>
   b92d4:	cc                   	int3
   b92d5:	cc                   	int3
   b92d6:	cc                   	int3
   b92d7:	cc                   	int3
   b92d8:	cc                   	int3
   b92d9:	cc                   	int3
   b92da:	cc                   	int3
   b92db:	cc                   	int3
   b92dc:	cc                   	int3
   b92dd:	cc                   	int3
   b92de:	cc                   	int3
   b92df:	cc                   	int3

