0000000000068570 <varlit_core::native_layout::read_native_record_header>:
   68570:	55                   	push   %rbp
   68571:	41 57                	push   %r15
   68573:	41 56                	push   %r14
   68575:	41 55                	push   %r13
   68577:	41 54                	push   %r12
   68579:	53                   	push   %rbx
   6857a:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
   68581:	49 89 f6             	mov    %rsi,%r14
   68584:	48 89 3c 24          	mov    %rdi,(%rsp)
   68588:	0f 57 c0             	xorps  %xmm0,%xmm0
   6858b:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   68592:	00 
   68593:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   6859a:	00 
   6859b:	41 bf 20 00 00 00    	mov    $0x20,%r15d
   685a1:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
   685a8:	00 
   685a9:	48 8b 1d 18 42 16 00 	mov    0x164218(%rip),%rbx        # 1cc7c8 <_DYNAMIC+0x350>
   685b0:	4c 8d 2d bd 69 fb ff 	lea    -0x49643(%rip),%r13        # 1ef74 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xed4>
   685b7:	48 bd 00 00 00 00 23 	movabs $0x2300000000,%rbp
   685be:	00 00 00 
   685c1:	eb 34                	jmp    685f7 <varlit_core::native_layout::read_native_record_header+0x87>
   685c3:	48 89 d0             	mov    %rdx,%rax
   685c6:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   685cd:	ff ff ff 
   685d0:	48 21 c8             	and    %rcx,%rax
   685d3:	48 b9 00 00 00 00 04 	movabs $0x400000000,%rcx
   685da:	00 00 00 
   685dd:	48 39 c8             	cmp    %rcx,%rax
   685e0:	0f 85 80 00 00 00    	jne    68666 <varlit_core::native_layout::read_native_record_header+0xf6>
   685e6:	48 89 d7             	mov    %rdx,%rdi
   685e9:	e8 b2 93 00 00       	call   719a0 <core::ptr::drop_in_place<std::io::error::Error>>
   685ee:	4d 85 ff             	test   %r15,%r15
   685f1:	0f 84 92 00 00 00    	je     68689 <varlit_core::native_layout::read_native_record_header+0x119>
   685f7:	4c 89 f7             	mov    %r14,%rdi
   685fa:	4c 89 e6             	mov    %r12,%rsi
   685fd:	4c 89 fa             	mov    %r15,%rdx
   68600:	ff d3                	call   *%rbx
   68602:	48 83 f8 01          	cmp    $0x1,%rax
   68606:	75 18                	jne    68620 <varlit_core::native_layout::read_native_record_header+0xb0>
   68608:	89 d0                	mov    %edx,%eax
   6860a:	83 e0 03             	and    $0x3,%eax
   6860d:	49 63 44 85 00       	movslq 0x0(%r13,%rax,4),%rax
   68612:	4c 01 e8             	add    %r13,%rax
   68615:	ff e0                	jmp    *%rax
   68617:	80 7a 10 23          	cmpb   $0x23,0x10(%rdx)
   6861b:	74 c9                	je     685e6 <varlit_core::native_layout::read_native_record_header+0x76>
   6861d:	eb 4c                	jmp    6866b <varlit_core::native_layout::read_native_record_header+0xfb>
   6861f:	90                   	nop
   68620:	48 85 d2             	test   %rdx,%rdx
   68623:	74 38                	je     6865d <varlit_core::native_layout::read_native_record_header+0xed>
   68625:	4c 89 f8             	mov    %r15,%rax
   68628:	48 29 d0             	sub    %rdx,%rax
   6862b:	0f 82 d7 00 00 00    	jb     68708 <varlit_core::native_layout::read_native_record_header+0x198>
   68631:	49 01 d4             	add    %rdx,%r12
   68634:	49 89 c7             	mov    %rax,%r15
   68637:	4d 85 ff             	test   %r15,%r15
   6863a:	75 bb                	jne    685f7 <varlit_core::native_layout::read_native_record_header+0x87>
   6863c:	eb 4b                	jmp    68689 <varlit_core::native_layout::read_native_record_header+0x119>
   6863e:	48 89 d0             	mov    %rdx,%rax
   68641:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   68648:	ff ff ff 
   6864b:	48 21 c8             	and    %rcx,%rax
   6864e:	48 39 e8             	cmp    %rbp,%rax
   68651:	74 93                	je     685e6 <varlit_core::native_layout::read_native_record_header+0x76>
   68653:	eb 11                	jmp    68666 <varlit_core::native_layout::read_native_record_header+0xf6>
   68655:	80 7a 0f 23          	cmpb   $0x23,0xf(%rdx)
   68659:	74 8b                	je     685e6 <varlit_core::native_layout::read_native_record_header+0x76>
   6865b:	eb 0e                	jmp    6866b <varlit_core::native_layout::read_native_record_header+0xfb>
   6865d:	48 8d 15 ec e6 15 00 	lea    0x15e6ec(%rip),%rdx        # 1c6d50 <anon.a0ff4f46869377479ad462f429370715.2.llvm.5402889094323598768>
   68664:	eb 05                	jmp    6866b <varlit_core::native_layout::read_native_record_header+0xfb>
   68666:	48 85 d2             	test   %rdx,%rdx
   68669:	74 1e                	je     68689 <varlit_core::native_layout::read_native_record_header+0x119>
   6866b:	48 b8 6c 00 00 00 00 	movabs $0x800000000000006c,%rax
   68672:	00 00 80 
   68675:	48 83 c0 9a          	add    $0xffffffffffffff9a,%rax
   68679:	48 8b 1c 24          	mov    (%rsp),%rbx
   6867d:	48 89 03             	mov    %rax,(%rbx)
   68680:	48 89 53 08          	mov    %rdx,0x8(%rbx)
   68684:	e9 94 07 00 00       	jmp    68e1d <varlit_core::native_layout::read_native_record_header+0x8ad>
   68689:	41 bc 20 00 00 00    	mov    $0x20,%r12d
   6868f:	48 8d 9c 24 a0 00 00 	lea    0xa0(%rsp),%rbx
   68696:	00 
   68697:	41 b9 38 00 00 00    	mov    $0x38,%r9d
   6869d:	48 bd 6c 00 00 00 00 	movabs $0x800000000000006c,%rbp
   686a4:	00 00 80 
   686a7:	c7 44 24 64 00 00 00 	movl   $0x0,0x64(%rsp)
   686ae:	00 
   686af:	4c 8d 15 9a e0 15 00 	lea    0x15e09a(%rip),%r10        # 1c6750 <__frame_dummy_init_array_entry+0x710>
   686b6:	4b 8b 44 11 c8       	mov    -0x38(%r9,%r10,1),%rax
   686bb:	4f 8b 74 11 d0       	mov    -0x30(%r9,%r10,1),%r14
   686c0:	48 8d 0d bd 68 fb ff 	lea    -0x49743(%rip),%rcx        # 1ef84 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xee4>
   686c7:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   686cb:	48 01 c8             	add    %rcx,%rax
   686ce:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
   686d5:	00 
   686d6:	c7 44 24 6c 00 00 00 	movl   $0x0,0x6c(%rsp)
   686dd:	00 
   686de:	c7 44 24 70 00 00 00 	movl   $0x0,0x70(%rsp)
   686e5:	00 
   686e6:	89 4c 24 1c          	mov    %ecx,0x1c(%rsp)
   686ea:	c7 44 24 74 00 00 00 	movl   $0x0,0x74(%rsp)
   686f1:	00 
   686f2:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
   686f6:	c7 44 24 78 00 00 00 	movl   $0x0,0x78(%rsp)
   686fd:	00 
   686fe:	c7 44 24 7c 00 00 00 	movl   $0x0,0x7c(%rsp)
   68705:	00 
   68706:	ff e0                	jmp    *%rax
   68708:	48 8d 0d 59 e6 15 00 	lea    0x15e659(%rip),%rcx        # 1c6d68 <anon.a0ff4f46869377479ad462f429370715.4.llvm.5402889094323598768>
   6870f:	48 89 d7             	mov    %rdx,%rdi
   68712:	4c 89 fe             	mov    %r15,%rsi
   68715:	4c 89 fa             	mov    %r15,%rdx
   68718:	ff 15 12 41 16 00    	call   *0x164112(%rip)        # 1cc830 <_DYNAMIC+0x3b8>
   6871e:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
   68725:	00 
   68726:	4c 89 8c 24 98 00 00 	mov    %r9,0x98(%rsp)
   6872d:	00 
   6872e:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   68734:	31 ed                	xor    %ebp,%ebp
   68736:	4d 85 f6             	test   %r14,%r14
   68739:	0f 85 89 00 00 00    	jne    687c8 <varlit_core::native_layout::read_native_record_header+0x258>
   6873f:	49 89 dc             	mov    %rbx,%r12
   68742:	49 89 ee             	mov    %rbp,%r14
   68745:	4c 89 ef             	mov    %r13,%rdi
   68748:	48 89 de             	mov    %rbx,%rsi
   6874b:	48 89 ea             	mov    %rbp,%rdx
   6874e:	ff 15 2c 40 16 00    	call   *0x16402c(%rip)        # 1cc780 <memcpy@GLIBC_2.14>
   68754:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
   68759:	48 bd 6c 00 00 00 00 	movabs $0x800000000000006c,%rbp
   68760:	00 00 80 
   68763:	4c 8b 8c 24 98 00 00 	mov    0x98(%rsp),%r9
   6876a:	00 
   6876b:	4c 8d 15 de df 15 00 	lea    0x15dfde(%rip),%r10        # 1c6750 <__frame_dummy_init_array_entry+0x710>
   68772:	44 89 e9             	mov    %r13d,%ecx
   68775:	44 89 e8             	mov    %r13d,%eax
   68778:	c1 e8 08             	shr    $0x8,%eax
   6877b:	4c 89 ee             	mov    %r13,%rsi
   6877e:	48 c1 ee 10          	shr    $0x10,%rsi
   68782:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
   68789:	ff ff ff 
   6878c:	49 21 d5             	and    %rdx,%r13
   6878f:	c1 e0 08             	shl    $0x8,%eax
   68792:	0f b6 c9             	movzbl %cl,%ecx
   68795:	09 c8                	or     %ecx,%eax
   68797:	c1 e6 10             	shl    $0x10,%esi
   6879a:	0f b7 d0             	movzwl %ax,%edx
   6879d:	09 f2                	or     %esi,%edx
   6879f:	4d 89 ef             	mov    %r13,%r15
   687a2:	49 09 d7             	or     %rdx,%r15
   687a5:	43 0f b6 34 11       	movzbl (%r9,%r10,1),%esi
   687aa:	4c 8d 05 e7 67 fb ff 	lea    -0x49819(%rip),%r8        # 1ef98 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xef8>
   687b1:	49 63 3c b0          	movslq (%r8,%rsi,4),%rdi
   687b5:	4c 01 c7             	add    %r8,%rdi
   687b8:	4c 89 e3             	mov    %r12,%rbx
   687bb:	48 89 d6             	mov    %rdx,%rsi
   687be:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
   687c5:	00 
   687c6:	ff e7                	jmp    *%rdi
   687c8:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   687cd:	ba 01 00 00 00       	mov    $0x1,%edx
   687d2:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   687d8:	41 b9 01 00 00 00    	mov    $0x1,%r9d
   687de:	31 f6                	xor    %esi,%esi
   687e0:	4c 89 f1             	mov    %r14,%rcx
   687e3:	e8 08 6a 00 00       	call   6f1f0 <alloc::raw_vec::RawVecInner<A>::finish_grow>
   687e8:	83 7c 24 20 01       	cmpl   $0x1,0x20(%rsp)
   687ed:	74 6e                	je     6885d <varlit_core::native_layout::read_native_record_header+0x2ed>
   687ef:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
   687f4:	4c 89 e8             	mov    %r13,%rax
   687f7:	49 83 fe 01          	cmp    $0x1,%r14
   687fb:	48 bd 6c 00 00 00 00 	movabs $0x800000000000006c,%rbp
   68802:	00 00 80 
   68805:	74 16                	je     6881d <varlit_core::native_layout::read_native_record_header+0x2ad>
   68807:	49 8d 56 ff          	lea    -0x1(%r14),%rdx
   6880b:	4c 89 ef             	mov    %r13,%rdi
   6880e:	31 f6                	xor    %esi,%esi
   68810:	ff 15 aa 3f 16 00    	call   *0x163faa(%rip)        # 1cc7c0 <memset@GLIBC_2.2.5>
   68816:	4b 8d 04 2e          	lea    (%r14,%r13,1),%rax
   6881a:	48 ff c8             	dec    %rax
   6881d:	c6 00 00             	movb   $0x0,(%rax)
   68820:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   68827:	00 
   68828:	4c 29 f0             	sub    %r14,%rax
   6882b:	72 50                	jb     6887d <varlit_core::native_layout::read_native_record_header+0x30d>
   6882d:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   68834:	00 
   68835:	4e 8d 24 33          	lea    (%rbx,%r14,1),%r12
   68839:	49 83 fe 01          	cmp    $0x1,%r14
   6883d:	75 16                	jne    68855 <varlit_core::native_layout::read_native_record_header+0x2e5>
   6883f:	0f b6 03             	movzbl (%rbx),%eax
   68842:	41 88 45 00          	mov    %al,0x0(%r13)
   68846:	b8 01 00 00 00       	mov    $0x1,%eax
   6884b:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   68850:	e9 0e ff ff ff       	jmp    68763 <varlit_core::native_layout::read_native_record_header+0x1f3>
   68855:	4c 89 f5             	mov    %r14,%rbp
   68858:	e9 e8 fe ff ff       	jmp    68745 <varlit_core::native_layout::read_native_record_header+0x1d5>
   6885d:	48 bd 6c 00 00 00 00 	movabs $0x800000000000006c,%rbp
   68864:	00 00 80 
   68867:	48 83 c5 aa          	add    $0xffffffffffffffaa,%rbp
   6886b:	48 8d 05 a5 69 fb ff 	lea    -0x4965b(%rip),%rax        # 1f217 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0x1177>
   68872:	41 bf 18 00 00 00    	mov    $0x18,%r15d
   68878:	e9 f9 03 00 00       	jmp    68c76 <varlit_core::native_layout::read_native_record_header+0x706>
   6887d:	ba 01 00 00 00       	mov    $0x1,%edx
   68882:	4c 89 ef             	mov    %r13,%rdi
   68885:	4c 89 f6             	mov    %r14,%rsi
   68888:	ff 15 da 3e 16 00    	call   *0x163eda(%rip)        # 1cc768 <_DYNAMIC+0x2f0>
   6888e:	48 83 c5 9a          	add    $0xffffffffffffff9a,%rbp
   68892:	48 8d 05 9f de 15 00 	lea    0x15de9f(%rip),%rax        # 1c6738 <__frame_dummy_init_array_entry+0x6f8>
   68899:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
   6889e:	e9 d3 03 00 00       	jmp    68c76 <varlit_core::native_layout::read_native_record_header+0x706>
   688a3:	49 ff cc             	dec    %r12
   688a6:	0f b6 0b             	movzbl (%rbx),%ecx
   688a9:	48 ff c3             	inc    %rbx
   688ac:	4c 8d 75 94          	lea    -0x6c(%rbp),%r14
   688b0:	45 31 ed             	xor    %r13d,%r13d
   688b3:	31 c0                	xor    %eax,%eax
   688b5:	c1 e0 08             	shl    $0x8,%eax
   688b8:	0f b6 c9             	movzbl %cl,%ecx
   688bb:	09 c8                	or     %ecx,%eax
   688bd:	31 d2                	xor    %edx,%edx
   688bf:	c1 e2 10             	shl    $0x10,%edx
   688c2:	44 0f b7 f8          	movzwl %ax,%r15d
   688c6:	41 09 d7             	or     %edx,%r15d
   688c9:	43 0f b6 14 11       	movzbl (%r9,%r10,1),%edx
   688ce:	48 8d 35 c3 66 fb ff 	lea    -0x4993d(%rip),%rsi        # 1ef98 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xef8>
   688d5:	48 63 3c 96          	movslq (%rsi,%rdx,4),%rdi
   688d9:	48 01 f7             	add    %rsi,%rdi
   688dc:	44 89 fa             	mov    %r15d,%edx
   688df:	4c 89 fe             	mov    %r15,%rsi
   688e2:	ff e7                	jmp    *%rdi
   688e4:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
   688e9:	49 83 fc 02          	cmp    $0x2,%r12
   688ed:	0f 82 78 03 00 00    	jb     68c6b <varlit_core::native_layout::read_native_record_header+0x6fb>
   688f3:	49 83 c4 fe          	add    $0xfffffffffffffffe,%r12
   688f7:	0f b7 03             	movzwl (%rbx),%eax
   688fa:	48 83 c3 02          	add    $0x2,%rbx
   688fe:	89 c1                	mov    %eax,%ecx
   68900:	c1 e8 08             	shr    $0x8,%eax
   68903:	4c 8d 75 95          	lea    -0x6b(%rbp),%r14
   68907:	45 31 ed             	xor    %r13d,%r13d
   6890a:	c1 e0 08             	shl    $0x8,%eax
   6890d:	0f b6 c9             	movzbl %cl,%ecx
   68910:	09 c8                	or     %ecx,%eax
   68912:	31 d2                	xor    %edx,%edx
   68914:	c1 e2 10             	shl    $0x10,%edx
   68917:	44 0f b7 f8          	movzwl %ax,%r15d
   6891b:	41 09 d7             	or     %edx,%r15d
   6891e:	43 0f b6 14 11       	movzbl (%r9,%r10,1),%edx
   68923:	48 8d 35 6e 66 fb ff 	lea    -0x49992(%rip),%rsi        # 1ef98 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xef8>
   6892a:	48 63 3c 96          	movslq (%rsi,%rdx,4),%rdi
   6892e:	48 01 f7             	add    %rsi,%rdi
   68931:	44 89 fa             	mov    %r15d,%edx
   68934:	4c 89 fe             	mov    %r15,%rsi
   68937:	ff e7                	jmp    *%rdi
   68939:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
   6893e:	49 83 fc 04          	cmp    $0x4,%r12
   68942:	0f 82 23 03 00 00    	jb     68c6b <varlit_core::native_layout::read_native_record_header+0x6fb>
   68948:	49 83 c4 fc          	add    $0xfffffffffffffffc,%r12
   6894c:	8b 13                	mov    (%rbx),%edx
   6894e:	48 83 c3 04          	add    $0x4,%rbx
   68952:	89 d1                	mov    %edx,%ecx
   68954:	89 d0                	mov    %edx,%eax
   68956:	c1 e8 08             	shr    $0x8,%eax
   68959:	c1 ea 10             	shr    $0x10,%edx
   6895c:	4c 8d 75 96          	lea    -0x6a(%rbp),%r14
   68960:	45 31 ed             	xor    %r13d,%r13d
   68963:	c1 e0 08             	shl    $0x8,%eax
   68966:	0f b6 c9             	movzbl %cl,%ecx
   68969:	09 c8                	or     %ecx,%eax
   6896b:	c1 e2 10             	shl    $0x10,%edx
   6896e:	44 0f b7 f8          	movzwl %ax,%r15d
   68972:	41 09 d7             	or     %edx,%r15d
   68975:	43 0f b6 14 11       	movzbl (%r9,%r10,1),%edx
   6897a:	48 8d 35 17 66 fb ff 	lea    -0x499e9(%rip),%rsi        # 1ef98 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xef8>
   68981:	48 63 3c 96          	movslq (%rsi,%rdx,4),%rdi
   68985:	48 01 f7             	add    %rsi,%rdi
   68988:	44 89 fa             	mov    %r15d,%edx
   6898b:	4c 89 fe             	mov    %r15,%rsi
   6898e:	ff e7                	jmp    *%rdi
   68990:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
   68995:	49 83 fc 08          	cmp    $0x8,%r12
   68999:	0f 82 cc 02 00 00    	jb     68c6b <varlit_core::native_layout::read_native_record_header+0x6fb>
   6899f:	49 83 c4 f8          	add    $0xfffffffffffffff8,%r12
   689a3:	4c 8b 2b             	mov    (%rbx),%r13
   689a6:	48 83 c3 08          	add    $0x8,%rbx
   689aa:	44 89 e9             	mov    %r13d,%ecx
   689ad:	44 89 e8             	mov    %r13d,%eax
   689b0:	c1 e8 08             	shr    $0x8,%eax
   689b3:	4c 89 ee             	mov    %r13,%rsi
   689b6:	48 c1 ee 10          	shr    $0x10,%rsi
   689ba:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
   689c1:	ff ff ff 
   689c4:	49 21 d5             	and    %rdx,%r13
   689c7:	4c 8d 75 97          	lea    -0x69(%rbp),%r14
   689cb:	c1 e0 08             	shl    $0x8,%eax
   689ce:	0f b6 c9             	movzbl %cl,%ecx
   689d1:	09 c8                	or     %ecx,%eax
   689d3:	c1 e6 10             	shl    $0x10,%esi
   689d6:	0f b7 d0             	movzwl %ax,%edx
   689d9:	09 f2                	or     %esi,%edx
   689db:	4d 89 ef             	mov    %r13,%r15
   689de:	49 09 d7             	or     %rdx,%r15
   689e1:	43 0f b6 34 11       	movzbl (%r9,%r10,1),%esi
   689e6:	4c 8d 05 ab 65 fb ff 	lea    -0x49a55(%rip),%r8        # 1ef98 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xef8>
   689ed:	49 63 3c b0          	movslq (%r8,%rsi,4),%rdi
   689f1:	4c 01 c7             	add    %r8,%rdi
   689f4:	48 89 d6             	mov    %rdx,%rsi
   689f7:	ff e7                	jmp    *%rdi
   689f9:	49 8d 3c 2e          	lea    (%r14,%rbp,1),%rdi
   689fd:	48 83 c7 95          	add    $0xffffffffffffff95,%rdi
   68a01:	4c 89 f6             	mov    %r14,%rsi
   68a04:	48 c1 fe 3f          	sar    $0x3f,%rsi
   68a08:	48 21 fe             	and    %rdi,%rsi
   68a0b:	48 ff ce             	dec    %rsi
   68a0e:	48 83 fe 03          	cmp    $0x3,%rsi
   68a12:	0f 87 d2 03 00 00    	ja     68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68a18:	40 b7 01             	mov    $0x1,%dil
   68a1b:	89 7c 24 7c          	mov    %edi,0x7c(%rsp)
   68a1f:	48 8d 3d ea 65 fb ff 	lea    -0x49a16(%rip),%rdi        # 1f010 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xf70>
   68a26:	48 63 34 b7          	movslq (%rdi,%rsi,4),%rsi
   68a2a:	48 01 fe             	add    %rdi,%rsi
   68a2d:	ff e6                	jmp    *%rsi
   68a2f:	0f b6 c1             	movzbl %cl,%eax
   68a32:	89 44 24 14          	mov    %eax,0x14(%rsp)
   68a36:	4d 85 f6             	test   %r14,%r14
   68a39:	0f 8f d5 01 00 00    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68a3f:	e9 ee 01 00 00       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68a44:	49 8d 3c 2e          	lea    (%r14,%rbp,1),%rdi
   68a48:	48 83 c7 95          	add    $0xffffffffffffff95,%rdi
   68a4c:	4c 89 f6             	mov    %r14,%rsi
   68a4f:	48 c1 fe 3f          	sar    $0x3f,%rsi
   68a53:	48 21 fe             	and    %rdi,%rsi
   68a56:	48 ff ce             	dec    %rsi
   68a59:	48 83 fe 03          	cmp    $0x3,%rsi
   68a5d:	0f 87 87 03 00 00    	ja     68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68a63:	40 b7 01             	mov    $0x1,%dil
   68a66:	89 7c 24 68          	mov    %edi,0x68(%rsp)
   68a6a:	48 8d 3d 6f 65 fb ff 	lea    -0x49a91(%rip),%rdi        # 1efe0 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xf40>
   68a71:	48 63 34 b7          	movslq (%rdi,%rsi,4),%rsi
   68a75:	48 01 fe             	add    %rdi,%rsi
   68a78:	ff e6                	jmp    *%rsi
   68a7a:	0f b6 c1             	movzbl %cl,%eax
   68a7d:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   68a81:	4d 85 f6             	test   %r14,%r14
   68a84:	0f 8f 8a 01 00 00    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68a8a:	e9 a3 01 00 00       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68a8f:	49 8d 3c 2e          	lea    (%r14,%rbp,1),%rdi
   68a93:	48 83 c7 95          	add    $0xffffffffffffff95,%rdi
   68a97:	4c 89 f2             	mov    %r14,%rdx
   68a9a:	48 c1 fa 3f          	sar    $0x3f,%rdx
   68a9e:	48 21 fa             	and    %rdi,%rdx
   68aa1:	48 ff ca             	dec    %rdx
   68aa4:	48 83 fa 03          	cmp    $0x3,%rdx
   68aa8:	0f 87 3c 03 00 00    	ja     68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68aae:	40 b7 01             	mov    $0x1,%dil
   68ab1:	89 7c 24 70          	mov    %edi,0x70(%rsp)
   68ab5:	48 8d 3d 44 65 fb ff 	lea    -0x49abc(%rip),%rdi        # 1f000 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xf60>
   68abc:	48 63 14 97          	movslq (%rdi,%rdx,4),%rdx
   68ac0:	48 01 fa             	add    %rdi,%rdx
   68ac3:	ff e2                	jmp    *%rdx
   68ac5:	0f b6 c1             	movzbl %cl,%eax
   68ac8:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   68acf:	00 
   68ad0:	4d 85 f6             	test   %r14,%r14
   68ad3:	0f 8f 3b 01 00 00    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68ad9:	e9 54 01 00 00       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68ade:	49 8d 3c 2e          	lea    (%r14,%rbp,1),%rdi
   68ae2:	48 83 c7 95          	add    $0xffffffffffffff95,%rdi
   68ae6:	4c 89 f2             	mov    %r14,%rdx
   68ae9:	48 c1 fa 3f          	sar    $0x3f,%rdx
   68aed:	48 21 fa             	and    %rdi,%rdx
   68af0:	48 ff ca             	dec    %rdx
   68af3:	48 83 fa 03          	cmp    $0x3,%rdx
   68af7:	0f 87 ed 02 00 00    	ja     68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68afd:	40 b7 01             	mov    $0x1,%dil
   68b00:	89 7c 24 6c          	mov    %edi,0x6c(%rsp)
   68b04:	48 8d 3d e5 64 fb ff 	lea    -0x49b1b(%rip),%rdi        # 1eff0 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xf50>
   68b0b:	48 63 14 97          	movslq (%rdi,%rdx,4),%rdx
   68b0f:	48 01 fa             	add    %rdi,%rdx
   68b12:	ff e2                	jmp    *%rdx
   68b14:	0f b6 c1             	movzbl %cl,%eax
   68b17:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   68b1e:	00 
   68b1f:	4d 85 f6             	test   %r14,%r14
   68b22:	0f 8f ec 00 00 00    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68b28:	e9 05 01 00 00       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68b2d:	49 8d 34 2e          	lea    (%r14,%rbp,1),%rsi
   68b31:	48 83 c6 95          	add    $0xffffffffffffff95,%rsi
   68b35:	4c 89 f2             	mov    %r14,%rdx
   68b38:	48 c1 fa 3f          	sar    $0x3f,%rdx
   68b3c:	48 21 f2             	and    %rsi,%rdx
   68b3f:	40 b6 01             	mov    $0x1,%sil
   68b42:	89 74 24 78          	mov    %esi,0x78(%rsp)
   68b46:	48 83 fa 04          	cmp    $0x4,%rdx
   68b4a:	0f 84 50 01 00 00    	je     68ca0 <varlit_core::native_layout::read_native_record_header+0x730>
   68b50:	48 83 fa 02          	cmp    $0x2,%rdx
   68b54:	0f 84 53 01 00 00    	je     68cad <varlit_core::native_layout::read_native_record_header+0x73d>
   68b5a:	48 83 fa 01          	cmp    $0x1,%rdx
   68b5e:	0f 85 86 02 00 00    	jne    68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68b64:	0f b6 c1             	movzbl %cl,%eax
   68b67:	89 44 24 18          	mov    %eax,0x18(%rsp)
   68b6b:	4d 85 f6             	test   %r14,%r14
   68b6e:	0f 8f a0 00 00 00    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68b74:	e9 b9 00 00 00       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68b79:	49 8d 34 2e          	lea    (%r14,%rbp,1),%rsi
   68b7d:	48 83 c6 95          	add    $0xffffffffffffff95,%rsi
   68b81:	4c 89 f2             	mov    %r14,%rdx
   68b84:	48 c1 fa 3f          	sar    $0x3f,%rdx
   68b88:	48 21 f2             	and    %rsi,%rdx
   68b8b:	40 b6 01             	mov    $0x1,%sil
   68b8e:	89 74 24 74          	mov    %esi,0x74(%rsp)
   68b92:	48 83 fa 04          	cmp    $0x4,%rdx
   68b96:	0f 84 23 01 00 00    	je     68cbf <varlit_core::native_layout::read_native_record_header+0x74f>
   68b9c:	48 83 fa 02          	cmp    $0x2,%rdx
   68ba0:	0f 84 26 01 00 00    	je     68ccc <varlit_core::native_layout::read_native_record_header+0x75c>
   68ba6:	48 83 fa 01          	cmp    $0x1,%rdx
   68baa:	0f 85 3a 02 00 00    	jne    68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68bb0:	0f b6 c1             	movzbl %cl,%eax
   68bb3:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   68bb7:	4d 85 f6             	test   %r14,%r14
   68bba:	7f 58                	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68bbc:	eb 74                	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68bbe:	49 8d 3c 2e          	lea    (%r14,%rbp,1),%rdi
   68bc2:	48 83 c7 95          	add    $0xffffffffffffff95,%rdi
   68bc6:	4c 89 f6             	mov    %r14,%rsi
   68bc9:	48 c1 fe 3f          	sar    $0x3f,%rsi
   68bcd:	48 21 fe             	and    %rdi,%rsi
   68bd0:	48 ff ce             	dec    %rsi
   68bd3:	48 83 fe 03          	cmp    $0x3,%rsi
   68bd7:	0f 87 0d 02 00 00    	ja     68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68bdd:	40 b7 01             	mov    $0x1,%dil
   68be0:	89 7c 24 64          	mov    %edi,0x64(%rsp)
   68be4:	48 8d 3d e5 63 fb ff 	lea    -0x49c1b(%rip),%rdi        # 1efd0 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xf30>
   68beb:	48 63 34 b7          	movslq (%rdi,%rsi,4),%rsi
   68bef:	48 01 fe             	add    %rdi,%rsi
   68bf2:	ff e6                	jmp    *%rsi
   68bf4:	0f b6 c1             	movzbl %cl,%eax
   68bf7:	89 44 24 10          	mov    %eax,0x10(%rsp)
   68bfb:	4d 85 f6             	test   %r14,%r14
   68bfe:	7f 14                	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68c00:	eb 30                	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68c02:	4d 85 ed             	test   %r13,%r13
   68c05:	0f 85 df 01 00 00    	jne    68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68c0b:	89 54 24 14          	mov    %edx,0x14(%rsp)
   68c0f:	4d 85 f6             	test   %r14,%r14
   68c12:	7e 1e                	jle    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68c14:	ba 01 00 00 00       	mov    $0x1,%edx
   68c19:	4c 89 ff             	mov    %r15,%rdi
   68c1c:	4c 89 f6             	mov    %r14,%rsi
   68c1f:	4d 89 ce             	mov    %r9,%r14
   68c22:	ff 15 40 3b 16 00    	call   *0x163b40(%rip)        # 1cc768 <_DYNAMIC+0x2f0>
   68c28:	4c 8d 15 21 db 15 00 	lea    0x15db21(%rip),%r10        # 1c6750 <__frame_dummy_init_array_entry+0x710>
   68c2f:	4d 89 f1             	mov    %r14,%r9
   68c32:	49 83 c1 40          	add    $0x40,%r9
   68c36:	49 81 f9 f8 01 00 00 	cmp    $0x1f8,%r9
   68c3d:	0f 84 ef 01 00 00    	je     68e32 <varlit_core::native_layout::read_native_record_header+0x8c2>
   68c43:	4b 8b 44 11 c8       	mov    -0x38(%r9,%r10,1),%rax
   68c48:	4f 8b 74 11 d0       	mov    -0x30(%r9,%r10,1),%r14
   68c4d:	48 8d 0d 30 63 fb ff 	lea    -0x49cd0(%rip),%rcx        # 1ef84 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0xee4>
   68c54:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   68c58:	48 01 c8             	add    %rcx,%rax
   68c5b:	ff e0                	jmp    *%rax
   68c5d:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
   68c62:	4d 85 e4             	test   %r12,%r12
   68c65:	0f 85 38 fc ff ff    	jne    688a3 <varlit_core::native_layout::read_native_record_header+0x333>
   68c6b:	48 83 c5 9a          	add    $0xffffffffffffff9a,%rbp
   68c6f:	48 8d 05 c2 da 15 00 	lea    0x15dac2(%rip),%rax        # 1c6738 <__frame_dummy_init_array_entry+0x6f8>
   68c76:	48 8b 1c 24          	mov    (%rsp),%rbx
   68c7a:	48 89 2b             	mov    %rbp,(%rbx)
   68c7d:	48 89 43 08          	mov    %rax,0x8(%rbx)
   68c81:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
   68c85:	4c 89 73 18          	mov    %r14,0x18(%rbx)
   68c89:	e9 8f 01 00 00       	jmp    68e1d <varlit_core::native_layout::read_native_record_header+0x8ad>
   68c8e:	0f b7 c0             	movzwl %ax,%eax
   68c91:	89 44 24 14          	mov    %eax,0x14(%rsp)
   68c95:	4d 85 f6             	test   %r14,%r14
   68c98:	0f 8f 76 ff ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68c9e:	eb 92                	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68ca0:	49 81 ff ff ff 00 00 	cmp    $0xffff,%r15
   68ca7:	0f 87 3d 01 00 00    	ja     68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68cad:	89 44 24 18          	mov    %eax,0x18(%rsp)
   68cb1:	4d 85 f6             	test   %r14,%r14
   68cb4:	0f 8f 5a ff ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68cba:	e9 73 ff ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68cbf:	49 81 ff ff ff 00 00 	cmp    $0xffff,%r15
   68cc6:	0f 87 1e 01 00 00    	ja     68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68ccc:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   68cd0:	4d 85 f6             	test   %r14,%r14
   68cd3:	0f 8f 3b ff ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68cd9:	e9 54 ff ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68cde:	4d 85 ed             	test   %r13,%r13
   68ce1:	0f 85 03 01 00 00    	jne    68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68ce7:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   68ceb:	4d 85 f6             	test   %r14,%r14
   68cee:	0f 8f 20 ff ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68cf4:	e9 39 ff ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68cf9:	0f b7 c0             	movzwl %ax,%eax
   68cfc:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   68d00:	4d 85 f6             	test   %r14,%r14
   68d03:	0f 8f 0b ff ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68d09:	e9 24 ff ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68d0e:	48 89 b4 24 80 00 00 	mov    %rsi,0x80(%rsp)
   68d15:	00 
   68d16:	4d 85 f6             	test   %r14,%r14
   68d19:	0f 8f f5 fe ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68d1f:	e9 0e ff ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68d24:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
   68d2b:	00 
   68d2c:	4d 85 f6             	test   %r14,%r14
   68d2f:	0f 8f df fe ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68d35:	e9 f8 fe ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68d3a:	48 89 b4 24 88 00 00 	mov    %rsi,0x88(%rsp)
   68d41:	00 
   68d42:	4d 85 f6             	test   %r14,%r14
   68d45:	0f 8f c9 fe ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68d4b:	e9 e2 fe ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68d50:	0f b7 c0             	movzwl %ax,%eax
   68d53:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   68d5a:	00 
   68d5b:	4d 85 f6             	test   %r14,%r14
   68d5e:	0f 8f b0 fe ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68d64:	e9 c9 fe ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68d69:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
   68d70:	00 
   68d71:	4d 85 f6             	test   %r14,%r14
   68d74:	0f 8f 9a fe ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68d7a:	e9 b3 fe ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68d7f:	0f b7 c0             	movzwl %ax,%eax
   68d82:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   68d89:	00 
   68d8a:	4d 85 f6             	test   %r14,%r14
   68d8d:	0f 8f 81 fe ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68d93:	e9 9a fe ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68d98:	4d 85 ed             	test   %r13,%r13
   68d9b:	75 4d                	jne    68dea <varlit_core::native_layout::read_native_record_header+0x87a>
   68d9d:	89 54 24 10          	mov    %edx,0x10(%rsp)
   68da1:	4d 85 f6             	test   %r14,%r14
   68da4:	0f 8f 6a fe ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68daa:	e9 83 fe ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68daf:	0f b7 c0             	movzwl %ax,%eax
   68db2:	89 44 24 10          	mov    %eax,0x10(%rsp)
   68db6:	4d 85 f6             	test   %r14,%r14
   68db9:	0f 8f 55 fe ff ff    	jg     68c14 <varlit_core::native_layout::read_native_record_header+0x6a4>
   68dbf:	e9 6e fe ff ff       	jmp    68c32 <varlit_core::native_layout::read_native_record_header+0x6c2>
   68dc4:	48 83 c5 b2          	add    $0xffffffffffffffb2,%rbp
   68dc8:	48 8b 1c 24          	mov    (%rsp),%rbx
   68dcc:	48 89 2b             	mov    %rbp,(%rbx)
   68dcf:	48 8d 05 f1 64 fb ff 	lea    -0x49b0f(%rip),%rax        # 1f2c7 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0x1227>
   68dd6:	48 89 43 08          	mov    %rax,0x8(%rbx)
   68dda:	b8 2d 00 00 00       	mov    $0x2d,%eax
   68ddf:	48 89 43 10          	mov    %rax,0x10(%rbx)
   68de3:	4d 85 f6             	test   %r14,%r14
   68de6:	7f 24                	jg     68e0c <varlit_core::native_layout::read_native_record_header+0x89c>
   68de8:	eb 33                	jmp    68e1d <varlit_core::native_layout::read_native_record_header+0x8ad>
   68dea:	4b 8b 4c 11 f0       	mov    -0x10(%r9,%r10,1),%rcx
   68def:	4b 8b 44 11 f8       	mov    -0x8(%r9,%r10,1),%rax
   68df4:	48 83 c5 02          	add    $0x2,%rbp
   68df8:	48 8b 1c 24          	mov    (%rsp),%rbx
   68dfc:	48 89 2b             	mov    %rbp,(%rbx)
   68dff:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   68e03:	48 89 43 10          	mov    %rax,0x10(%rbx)
   68e07:	4d 85 f6             	test   %r14,%r14
   68e0a:	7e 11                	jle    68e1d <varlit_core::native_layout::read_native_record_header+0x8ad>
   68e0c:	ba 01 00 00 00       	mov    $0x1,%edx
   68e11:	4c 89 ff             	mov    %r15,%rdi
   68e14:	4c 89 f6             	mov    %r14,%rsi
   68e17:	ff 15 4b 39 16 00    	call   *0x16394b(%rip)        # 1cc768 <_DYNAMIC+0x2f0>
   68e1d:	48 89 d8             	mov    %rbx,%rax
   68e20:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
   68e27:	5b                   	pop    %rbx
   68e28:	41 5c                	pop    %r12
   68e2a:	41 5d                	pop    %r13
   68e2c:	41 5e                	pop    %r14
   68e2e:	41 5f                	pop    %r15
   68e30:	5d                   	pop    %rbp
   68e31:	c3                   	ret
   68e32:	4d 85 e4             	test   %r12,%r12
   68e35:	74 20                	je     68e57 <varlit_core::native_layout::read_native_record_header+0x8e7>
   68e37:	48 83 c5 b2          	add    $0xffffffffffffffb2,%rbp
   68e3b:	48 8b 1c 24          	mov    (%rsp),%rbx
   68e3f:	48 89 2b             	mov    %rbp,(%rbx)
   68e42:	48 8d 05 ab 64 fb ff 	lea    -0x49b55(%rip),%rax        # 1f2f4 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0x1254>
   68e49:	48 89 43 08          	mov    %rax,0x8(%rbx)
   68e4d:	48 c7 43 10 36 00 00 	movq   $0x36,0x10(%rbx)
   68e54:	00 
   68e55:	eb c6                	jmp    68e1d <varlit_core::native_layout::read_native_record_header+0x8ad>
   68e57:	48 8d 05 0a 10 fb ff 	lea    -0x4eff6(%rip),%rax        # 19e68 <anon.17b082cb49e65867434834b0b59514e7.53.llvm.178743251253153762>
   68e5e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   68e63:	48 c7 44 24 30 08 00 	movq   $0x8,0x30(%rsp)
   68e6a:	00 00 
   68e6c:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
   68e71:	f6 44 24 7c 01       	testb  $0x1,0x7c(%rsp)
   68e76:	48 8b 1c 24          	mov    (%rsp),%rbx
   68e7a:	0f 84 78 01 00 00    	je     68ff8 <varlit_core::native_layout::read_native_record_header+0xa88>
   68e80:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   68e85:	e8 86 03 00 00       	call   69210 <core::ptr::drop_in_place<varlit_core::error::Error>>
   68e8a:	48 8d 05 fd 63 fb ff 	lea    -0x49c03(%rip),%rax        # 1f28e <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0x11ee>
   68e91:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   68e96:	48 c7 44 24 30 0d 00 	movq   $0xd,0x30(%rsp)
   68e9d:	00 00 
   68e9f:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
   68ea4:	f6 44 24 78 01       	testb  $0x1,0x78(%rsp)
   68ea9:	0f 84 84 01 00 00    	je     69033 <varlit_core::native_layout::read_native_record_header+0xac3>
   68eaf:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   68eb4:	e8 57 03 00 00       	call   69210 <core::ptr::drop_in_place<varlit_core::error::Error>>
   68eb9:	48 8d 05 c3 63 fb ff 	lea    -0x49c3d(%rip),%rax        # 1f283 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0x11e3>
   68ec0:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   68ec5:	48 c7 44 24 30 05 00 	movq   $0x5,0x30(%rsp)
   68ecc:	00 00 
   68ece:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
   68ed3:	f6 44 24 74 01       	testb  $0x1,0x74(%rsp)
   68ed8:	0f 84 9c 01 00 00    	je     6907a <varlit_core::native_layout::read_native_record_header+0xb0a>
   68ede:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
   68ee3:	4c 89 f7             	mov    %r14,%rdi
   68ee6:	e8 25 03 00 00       	call   69210 <core::ptr::drop_in_place<varlit_core::error::Error>>
   68eeb:	48 8d 05 2e 0e fb ff 	lea    -0x4f1d2(%rip),%rax        # 19d20 <anon.17b082cb49e65867434834b0b59514e7.56.llvm.178743251253153762>
   68ef2:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   68ef7:	48 c7 44 24 30 08 00 	movq   $0x8,0x30(%rsp)
   68efe:	00 00 
   68f00:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
   68f05:	f6 44 24 70 01       	testb  $0x1,0x70(%rsp)
   68f0a:	0f 84 b1 01 00 00    	je     690c1 <varlit_core::native_layout::read_native_record_header+0xb51>
   68f10:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   68f15:	e8 f6 02 00 00       	call   69210 <core::ptr::drop_in_place<varlit_core::error::Error>>
   68f1a:	48 8d 05 86 63 fb ff 	lea    -0x49c7a(%rip),%rax        # 1f2a7 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0x1207>
   68f21:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   68f26:	48 c7 44 24 30 0b 00 	movq   $0xb,0x30(%rsp)
   68f2d:	00 00 
   68f2f:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
   68f34:	f6 44 24 6c 01       	testb  $0x1,0x6c(%rsp)
   68f39:	0f 84 82 01 00 00    	je     690c1 <varlit_core::native_layout::read_native_record_header+0xb51>
   68f3f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   68f44:	e8 c7 02 00 00       	call   69210 <core::ptr::drop_in_place<varlit_core::error::Error>>
   68f49:	48 8d 05 48 0e fb ff 	lea    -0x4f1b8(%rip),%rax        # 19d98 <anon.17b082cb49e65867434834b0b59514e7.58.llvm.178743251253153762>
   68f50:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   68f55:	48 c7 44 24 30 08 00 	movq   $0x8,0x30(%rsp)
   68f5c:	00 00 
   68f5e:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
   68f63:	f6 44 24 68 01       	testb  $0x1,0x68(%rsp)
   68f68:	0f 84 79 01 00 00    	je     690e7 <varlit_core::native_layout::read_native_record_header+0xb77>
   68f6e:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   68f73:	e8 98 02 00 00       	call   69210 <core::ptr::drop_in_place<varlit_core::error::Error>>
   68f78:	48 8d 05 33 63 fb ff 	lea    -0x49ccd(%rip),%rax        # 1f2b2 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0x1212>
   68f7f:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   68f84:	48 c7 44 24 30 15 00 	movq   $0x15,0x30(%rsp)
   68f8b:	00 00 
   68f8d:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
   68f92:	f6 44 24 64 01       	testb  $0x1,0x64(%rsp)
   68f97:	0f 84 82 01 00 00    	je     6911f <varlit_core::native_layout::read_native_record_header+0xbaf>
   68f9d:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   68fa2:	e8 69 02 00 00       	call   69210 <core::ptr::drop_in_place<varlit_core::error::Error>>
   68fa7:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   68fae:	00 
   68faf:	48 89 43 08          	mov    %rax,0x8(%rbx)
   68fb3:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
   68fba:	00 
   68fbb:	48 89 43 10          	mov    %rax,0x10(%rbx)
   68fbf:	8b 44 24 14          	mov    0x14(%rsp),%eax
   68fc3:	89 43 18             	mov    %eax,0x18(%rbx)
   68fc6:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   68fca:	89 43 1c             	mov    %eax,0x1c(%rbx)
   68fcd:	8b 44 24 10          	mov    0x10(%rsp),%eax
   68fd1:	89 43 20             	mov    %eax,0x20(%rbx)
   68fd4:	8b 44 24 18          	mov    0x18(%rsp),%eax
   68fd8:	66 89 43 24          	mov    %ax,0x24(%rbx)
   68fdc:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
   68fe0:	66 89 43 26          	mov    %ax,0x26(%rbx)
   68fe4:	48 c7 43 28 20 00 00 	movq   $0x20,0x28(%rbx)
   68feb:	00 
   68fec:	48 83 c5 11          	add    $0x11,%rbp
   68ff0:	48 89 2b             	mov    %rbp,(%rbx)
   68ff3:	e9 25 fe ff ff       	jmp    68e1d <varlit_core::native_layout::read_native_record_header+0x8ad>
   68ff8:	8b 44 24 2c          	mov    0x2c(%rsp),%eax
   68ffc:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   69001:	8b 54 24 38          	mov    0x38(%rsp),%edx
   69005:	0f 10 44 24 3c       	movups 0x3c(%rsp),%xmm0
   6900a:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
   6900f:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   69013:	0f 11 43 1c          	movups %xmm0,0x1c(%rbx)
   69017:	89 43 0c             	mov    %eax,0xc(%rbx)
   6901a:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   6901e:	89 53 18             	mov    %edx,0x18(%rbx)
   69021:	48 89 2b             	mov    %rbp,(%rbx)
   69024:	48 8d 05 3d 0e fb ff 	lea    -0x4f1c3(%rip),%rax        # 19e68 <anon.17b082cb49e65867434834b0b59514e7.53.llvm.178743251253153762>
   6902b:	89 43 08             	mov    %eax,0x8(%rbx)
   6902e:	e9 ea fd ff ff       	jmp    68e1d <varlit_core::native_layout::read_native_record_header+0x8ad>
   69033:	8b 44 24 2a          	mov    0x2a(%rsp),%eax
   69037:	0f b7 4c 24 2e       	movzwl 0x2e(%rsp),%ecx
   6903c:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   69041:	0f b7 74 24 38       	movzwl 0x38(%rsp),%esi
   69046:	0f 10 44 24 3a       	movups 0x3a(%rsp),%xmm0
   6904b:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
   69050:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   69054:	0f 11 43 1a          	movups %xmm0,0x1a(%rbx)
   69058:	89 43 0a             	mov    %eax,0xa(%rbx)
   6905b:	66 89 4b 0e          	mov    %cx,0xe(%rbx)
   6905f:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   69063:	66 89 73 18          	mov    %si,0x18(%rbx)
   69067:	48 89 2b             	mov    %rbp,(%rbx)
   6906a:	48 8d 05 1d 62 fb ff 	lea    -0x49de3(%rip),%rax        # 1f28e <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0x11ee>
   69071:	66 89 43 08          	mov    %ax,0x8(%rbx)
   69075:	e9 a3 fd ff ff       	jmp    68e1d <varlit_core::native_layout::read_native_record_header+0x8ad>
   6907a:	8b 44 24 2a          	mov    0x2a(%rsp),%eax
   6907e:	0f b7 4c 24 2e       	movzwl 0x2e(%rsp),%ecx
   69083:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   69088:	0f b7 74 24 38       	movzwl 0x38(%rsp),%esi
   6908d:	0f 10 44 24 3a       	movups 0x3a(%rsp),%xmm0
   69092:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
   69097:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   6909b:	0f 11 43 1a          	movups %xmm0,0x1a(%rbx)
   6909f:	89 43 0a             	mov    %eax,0xa(%rbx)
   690a2:	66 89 4b 0e          	mov    %cx,0xe(%rbx)
   690a6:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   690aa:	66 89 73 18          	mov    %si,0x18(%rbx)
   690ae:	48 89 2b             	mov    %rbp,(%rbx)
   690b1:	48 8d 05 cb 61 fb ff 	lea    -0x49e35(%rip),%rax        # 1f283 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0x11e3>
   690b8:	66 89 43 08          	mov    %ax,0x8(%rbx)
   690bc:	e9 5c fd ff ff       	jmp    68e1d <varlit_core::native_layout::read_native_record_header+0x8ad>
   690c1:	49 8b 4e 30          	mov    0x30(%r14),%rcx
   690c5:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
   690c9:	41 0f 10 46 10       	movups 0x10(%r14),%xmm0
   690ce:	41 0f 10 4e 20       	movups 0x20(%r14),%xmm1
   690d3:	0f 11 4b 20          	movups %xmm1,0x20(%rbx)
   690d7:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
   690db:	48 89 2b             	mov    %rbp,(%rbx)
   690de:	48 89 43 08          	mov    %rax,0x8(%rbx)
   690e2:	e9 36 fd ff ff       	jmp    68e1d <varlit_core::native_layout::read_native_record_header+0x8ad>
   690e7:	8b 44 24 2c          	mov    0x2c(%rsp),%eax
   690eb:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   690f0:	8b 54 24 38          	mov    0x38(%rsp),%edx
   690f4:	0f 10 44 24 3c       	movups 0x3c(%rsp),%xmm0
   690f9:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
   690fe:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   69102:	0f 11 43 1c          	movups %xmm0,0x1c(%rbx)
   69106:	89 43 0c             	mov    %eax,0xc(%rbx)
   69109:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   6910d:	89 53 18             	mov    %edx,0x18(%rbx)
   69110:	48 89 2b             	mov    %rbp,(%rbx)
   69113:	48 8d 05 7e 0c fb ff 	lea    -0x4f382(%rip),%rax        # 19d98 <anon.17b082cb49e65867434834b0b59514e7.58.llvm.178743251253153762>
   6911a:	e9 0c ff ff ff       	jmp    6902b <varlit_core::native_layout::read_native_record_header+0xabb>
   6911f:	8b 44 24 2c          	mov    0x2c(%rsp),%eax
   69123:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   69128:	8b 54 24 38          	mov    0x38(%rsp),%edx
   6912c:	0f 10 44 24 3c       	movups 0x3c(%rsp),%xmm0
   69131:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
   69136:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   6913a:	0f 11 43 1c          	movups %xmm0,0x1c(%rbx)
   6913e:	89 43 0c             	mov    %eax,0xc(%rbx)
   69141:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   69145:	89 53 18             	mov    %edx,0x18(%rbx)
   69148:	48 89 2b             	mov    %rbp,(%rbx)
   6914b:	48 8d 05 60 61 fb ff 	lea    -0x49ea0(%rip),%rax        # 1f2b2 <anon.c1d61040c3de6bce1f67212abab3e5fc.5.llvm.4958313821251285627+0x1212>
   69152:	e9 d4 fe ff ff       	jmp    6902b <varlit_core::native_layout::read_native_record_header+0xabb>
   69157:	cc                   	int3
   69158:	cc                   	int3
   69159:	cc                   	int3
   6915a:	cc                   	int3
   6915b:	cc                   	int3
   6915c:	cc                   	int3
   6915d:	cc                   	int3
   6915e:	cc                   	int3
   6915f:	cc                   	int3

