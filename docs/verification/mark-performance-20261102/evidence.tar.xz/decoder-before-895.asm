00000000000e6b80 <varlit_core::native_layout::read_native_record_header>:
   e6b80:	55                   	push   %rbp
   e6b81:	41 57                	push   %r15
   e6b83:	41 56                	push   %r14
   e6b85:	41 55                	push   %r13
   e6b87:	41 54                	push   %r12
   e6b89:	53                   	push   %rbx
   e6b8a:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
   e6b91:	49 89 f6             	mov    %rsi,%r14
   e6b94:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   e6b99:	0f 57 c0             	xorps  %xmm0,%xmm0
   e6b9c:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   e6ba3:	00 
   e6ba4:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   e6bab:	00 
   e6bac:	41 bf 20 00 00 00    	mov    $0x20,%r15d
   e6bb2:	4c 8d a4 24 d0 00 00 	lea    0xd0(%rsp),%r12
   e6bb9:	00 
   e6bba:	4c 8d 6c 24 18       	lea    0x18(%rsp),%r13
   e6bbf:	48 8b 2d 02 5c 0e 00 	mov    0xe5c02(%rip),%rbp        # 1cc7c8 <_DYNAMIC+0x350>
   e6bc6:	48 8d 1d 33 39 f4 ff 	lea    -0xbc6cd(%rip),%rbx        # 2a500 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x1439>
   e6bcd:	eb 1b                	jmp    e6bea <varlit_core::native_layout::read_native_record_header+0x6a>
   e6bcf:	80 7a 0f 23          	cmpb   $0x23,0xf(%rdx)
   e6bd3:	0f 85 7e 05 00 00    	jne    e7157 <varlit_core::native_layout::read_native_record_header+0x5d7>
   e6bd9:	4c 89 ef             	mov    %r13,%rdi
   e6bdc:	e8 4f 4b fd ff       	call   bb730 <core::ptr::drop_in_place<std::io::error::Error>>
   e6be1:	4d 85 ff             	test   %r15,%r15
   e6be4:	0f 84 a9 00 00 00    	je     e6c93 <varlit_core::native_layout::read_native_record_header+0x113>
   e6bea:	4c 89 f7             	mov    %r14,%rdi
   e6bed:	4c 89 e6             	mov    %r12,%rsi
   e6bf0:	4c 89 fa             	mov    %r15,%rdx
   e6bf3:	ff d5                	call   *%rbp
   e6bf5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   e6bfa:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   e6bff:	48 83 f8 01          	cmp    $0x1,%rax
   e6c03:	75 1b                	jne    e6c20 <varlit_core::native_layout::read_native_record_header+0xa0>
   e6c05:	89 d0                	mov    %edx,%eax
   e6c07:	83 e0 03             	and    $0x3,%eax
   e6c0a:	48 63 04 83          	movslq (%rbx,%rax,4),%rax
   e6c0e:	48 01 d8             	add    %rbx,%rax
   e6c11:	ff e0                	jmp    *%rax
   e6c13:	80 7a 10 23          	cmpb   $0x23,0x10(%rdx)
   e6c17:	74 c0                	je     e6bd9 <varlit_core::native_layout::read_native_record_header+0x59>
   e6c19:	e9 39 05 00 00       	jmp    e7157 <varlit_core::native_layout::read_native_record_header+0x5d7>
   e6c1e:	66 90                	xchg   %ax,%ax
   e6c20:	48 85 d2             	test   %rdx,%rdx
   e6c23:	0f 84 27 05 00 00    	je     e7150 <varlit_core::native_layout::read_native_record_header+0x5d0>
   e6c29:	4c 89 f8             	mov    %r15,%rax
   e6c2c:	48 29 d0             	sub    %rdx,%rax
   e6c2f:	0f 82 9b 08 00 00    	jb     e74d0 <varlit_core::native_layout::read_native_record_header+0x950>
   e6c35:	49 01 d4             	add    %rdx,%r12
   e6c38:	49 89 c7             	mov    %rax,%r15
   e6c3b:	4d 85 ff             	test   %r15,%r15
   e6c3e:	75 aa                	jne    e6bea <varlit_core::native_layout::read_native_record_header+0x6a>
   e6c40:	eb 51                	jmp    e6c93 <varlit_core::native_layout::read_native_record_header+0x113>
   e6c42:	48 89 d0             	mov    %rdx,%rax
   e6c45:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   e6c4c:	ff ff ff 
   e6c4f:	48 21 c8             	and    %rcx,%rax
   e6c52:	48 b9 00 00 00 00 04 	movabs $0x400000000,%rcx
   e6c59:	00 00 00 
   e6c5c:	48 39 c8             	cmp    %rcx,%rax
   e6c5f:	0f 84 74 ff ff ff    	je     e6bd9 <varlit_core::native_layout::read_native_record_header+0x59>
   e6c65:	eb 23                	jmp    e6c8a <varlit_core::native_layout::read_native_record_header+0x10a>
   e6c67:	48 89 d0             	mov    %rdx,%rax
   e6c6a:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   e6c71:	ff ff ff 
   e6c74:	48 21 c8             	and    %rcx,%rax
   e6c77:	48 b9 00 00 00 00 23 	movabs $0x2300000000,%rcx
   e6c7e:	00 00 00 
   e6c81:	48 39 c8             	cmp    %rcx,%rax
   e6c84:	0f 84 4f ff ff ff    	je     e6bd9 <varlit_core::native_layout::read_native_record_header+0x59>
   e6c8a:	48 85 d2             	test   %rdx,%rdx
   e6c8d:	0f 85 c4 04 00 00    	jne    e7157 <varlit_core::native_layout::read_native_record_header+0x5d7>
   e6c93:	49 bc 6c 00 00 00 00 	movabs $0x800000000000006c,%r12
   e6c9a:	00 00 80 
   e6c9d:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
   e6ca4:	00 
   e6ca5:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   e6cac:	00 
   e6cad:	48 c7 84 24 c8 00 00 	movq   $0x20,0xc8(%rsp)
   e6cb4:	00 20 00 00 00 
   e6cb9:	41 be 38 00 00 00    	mov    $0x38,%r14d
   e6cbf:	c7 44 24 64 00 00 00 	movl   $0x0,0x64(%rsp)
   e6cc6:	00 
   e6cc7:	4c 8d 3d 2a 1b 0e 00 	lea    0xe1b2a(%rip),%r15        # 1c87f8 <anon.17b082cb49e65867434834b0b59514e7.60.llvm.178743251253153762>
   e6cce:	4d 8d 6c 24 11       	lea    0x11(%r12),%r13
   e6cd3:	48 8d 2d 36 38 f4 ff 	lea    -0xbc7ca(%rip),%rbp        # 2a510 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x1449>
   e6cda:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   e6ce1:	00 
   e6ce2:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
   e6ce9:	00 
   e6cea:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   e6cf1:	00 
   e6cf2:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   e6cf7:	c7 44 24 5c 00 00 00 	movl   $0x0,0x5c(%rsp)
   e6cfe:	00 
   e6cff:	c7 44 24 54 00 00 00 	movl   $0x0,0x54(%rsp)
   e6d06:	00 
   e6d07:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
   e6d0e:	00 
   e6d0f:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   e6d16:	00 
   e6d17:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
   e6d1e:	00 
   e6d1f:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   e6d26:	00 
   e6d27:	eb 18                	jmp    e6d41 <varlit_core::native_layout::read_native_record_header+0x1c1>
   e6d29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   e6d30:	49 83 c6 40          	add    $0x40,%r14
   e6d34:	49 81 fe f8 01 00 00 	cmp    $0x1f8,%r14
   e6d3b:	0f 84 8c 04 00 00    	je     e71cd <varlit_core::native_layout::read_native_record_header+0x64d>
   e6d41:	4b 8b 54 3e c8       	mov    -0x38(%r14,%r15,1),%rdx
   e6d46:	4b 8b 4c 3e d0       	mov    -0x30(%r14,%r15,1),%rcx
   e6d4b:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   e6d50:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
   e6d57:	00 
   e6d58:	e8 93 d8 ff ff       	call   e45f0 <varlit_core::native_layout::read_native_value>
   e6d5d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   e6d62:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   e6d67:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   e6d6c:	4c 39 e8             	cmp    %r13,%rax
   e6d6f:	0f 85 01 04 00 00    	jne    e7176 <varlit_core::native_layout::read_native_record_header+0x5f6>
   e6d75:	43 0f b6 04 3e       	movzbl (%r14,%r15,1),%eax
   e6d7a:	48 63 44 85 00       	movslq 0x0(%rbp,%rax,4),%rax
   e6d7f:	48 01 e8             	add    %rbp,%rax
   e6d82:	ff e0                	jmp    *%rax
   e6d84:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e6d88:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e6d8c:	48 89 f0             	mov    %rsi,%rax
   e6d8f:	48 c1 f8 3f          	sar    $0x3f,%rax
   e6d93:	48 21 c8             	and    %rcx,%rax
   e6d96:	48 ff c8             	dec    %rax
   e6d99:	48 83 f8 03          	cmp    $0x3,%rax
   e6d9d:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
   e6da4:	00 
   e6da5:	0f 87 4e 04 00 00    	ja     e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e6dab:	48 8d 0d d6 37 f4 ff 	lea    -0xbc82a(%rip),%rcx        # 2a588 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x14c1>
   e6db2:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e6db6:	48 01 c8             	add    %rcx,%rax
   e6db9:	ff e0                	jmp    *%rax
   e6dbb:	40 0f b6 cf          	movzbl %dil,%ecx
   e6dbf:	e9 bd 02 00 00       	jmp    e7081 <varlit_core::native_layout::read_native_record_header+0x501>
   e6dc4:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e6dc8:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e6dcc:	48 89 f0             	mov    %rsi,%rax
   e6dcf:	48 c1 f8 3f          	sar    $0x3f,%rax
   e6dd3:	48 21 c8             	and    %rcx,%rax
   e6dd6:	48 ff c8             	dec    %rax
   e6dd9:	48 83 f8 03          	cmp    $0x3,%rax
   e6ddd:	0f 87 16 04 00 00    	ja     e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e6de3:	b1 01                	mov    $0x1,%cl
   e6de5:	89 4c 24 54          	mov    %ecx,0x54(%rsp)
   e6de9:	48 8d 0d 78 37 f4 ff 	lea    -0xbc888(%rip),%rcx        # 2a568 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x14a1>
   e6df0:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e6df4:	48 01 c8             	add    %rcx,%rax
   e6df7:	ff e0                	jmp    *%rax
   e6df9:	40 0f b6 c7          	movzbl %dil,%eax
   e6dfd:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   e6e02:	48 85 f6             	test   %rsi,%rsi
   e6e05:	0f 8f 35 03 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e6e0b:	e9 20 ff ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e6e10:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e6e14:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e6e18:	48 89 f0             	mov    %rsi,%rax
   e6e1b:	48 c1 f8 3f          	sar    $0x3f,%rax
   e6e1f:	48 21 c8             	and    %rcx,%rax
   e6e22:	48 83 f8 04          	cmp    $0x4,%rax
   e6e26:	0f 84 3c 01 00 00    	je     e6f68 <varlit_core::native_layout::read_native_record_header+0x3e8>
   e6e2c:	48 83 f8 02          	cmp    $0x2,%rax
   e6e30:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   e6e37:	00 
   e6e38:	0f 84 20 01 00 00    	je     e6f5e <varlit_core::native_layout::read_native_record_header+0x3de>
   e6e3e:	48 83 f8 01          	cmp    $0x1,%rax
   e6e42:	0f 85 b1 03 00 00    	jne    e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e6e48:	40 0f b6 c7          	movzbl %dil,%eax
   e6e4c:	e9 2f 01 00 00       	jmp    e6f80 <varlit_core::native_layout::read_native_record_header+0x400>
   e6e51:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e6e55:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e6e59:	48 89 f0             	mov    %rsi,%rax
   e6e5c:	48 c1 f8 3f          	sar    $0x3f,%rax
   e6e60:	48 21 c8             	and    %rcx,%rax
   e6e63:	48 ff c8             	dec    %rax
   e6e66:	48 83 f8 03          	cmp    $0x3,%rax
   e6e6a:	0f 87 89 03 00 00    	ja     e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e6e70:	b1 01                	mov    $0x1,%cl
   e6e72:	89 4c 24 5c          	mov    %ecx,0x5c(%rsp)
   e6e76:	48 8d 0d fb 36 f4 ff 	lea    -0xbc905(%rip),%rcx        # 2a578 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x14b1>
   e6e7d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e6e81:	48 01 c8             	add    %rcx,%rax
   e6e84:	ff e0                	jmp    *%rax
   e6e86:	40 0f b6 c7          	movzbl %dil,%eax
   e6e8a:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   e6e8f:	48 85 f6             	test   %rsi,%rsi
   e6e92:	0f 8f a8 02 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e6e98:	e9 93 fe ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e6e9d:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e6ea1:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e6ea5:	48 89 f0             	mov    %rsi,%rax
   e6ea8:	48 c1 f8 3f          	sar    $0x3f,%rax
   e6eac:	48 21 c8             	and    %rcx,%rax
   e6eaf:	48 83 f8 04          	cmp    $0x4,%rax
   e6eb3:	0f 84 f2 00 00 00    	je     e6fab <varlit_core::native_layout::read_native_record_header+0x42b>
   e6eb9:	48 83 f8 02          	cmp    $0x2,%rax
   e6ebd:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   e6ec4:	00 
   e6ec5:	0f 84 98 00 00 00    	je     e6f63 <varlit_core::native_layout::read_native_record_header+0x3e3>
   e6ecb:	48 83 f8 01          	cmp    $0x1,%rax
   e6ecf:	0f 85 24 03 00 00    	jne    e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e6ed5:	40 0f b6 df          	movzbl %dil,%ebx
   e6ed9:	e9 e5 00 00 00       	jmp    e6fc3 <varlit_core::native_layout::read_native_record_header+0x443>
   e6ede:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e6ee2:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e6ee6:	48 89 f0             	mov    %rsi,%rax
   e6ee9:	48 c1 f8 3f          	sar    $0x3f,%rax
   e6eed:	48 21 c8             	and    %rcx,%rax
   e6ef0:	48 ff c8             	dec    %rax
   e6ef3:	48 83 f8 03          	cmp    $0x3,%rax
   e6ef7:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
   e6efe:	00 
   e6eff:	0f 87 f4 02 00 00    	ja     e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e6f05:	48 8d 0d 4c 36 f4 ff 	lea    -0xbc9b4(%rip),%rcx        # 2a558 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x1491>
   e6f0c:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e6f10:	48 01 c8             	add    %rcx,%rax
   e6f13:	ff e0                	jmp    *%rax
   e6f15:	40 0f b6 cf          	movzbl %dil,%ecx
   e6f19:	e9 c0 01 00 00       	jmp    e70de <varlit_core::native_layout::read_native_record_header+0x55e>
   e6f1e:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e6f22:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e6f26:	48 89 f0             	mov    %rsi,%rax
   e6f29:	48 c1 f8 3f          	sar    $0x3f,%rax
   e6f2d:	48 21 c8             	and    %rcx,%rax
   e6f30:	48 ff c8             	dec    %rax
   e6f33:	48 83 f8 03          	cmp    $0x3,%rax
   e6f37:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
   e6f3e:	00 
   e6f3f:	0f 87 b4 02 00 00    	ja     e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e6f45:	48 8d 0d fc 35 f4 ff 	lea    -0xbca04(%rip),%rcx        # 2a548 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x1481>
   e6f4c:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e6f50:	48 01 c8             	add    %rcx,%rax
   e6f53:	ff e0                	jmp    *%rax
   e6f55:	40 0f b6 cf          	movzbl %dil,%ecx
   e6f59:	e9 b3 01 00 00       	jmp    e7111 <varlit_core::native_layout::read_native_record_header+0x591>
   e6f5e:	0f b7 c7             	movzwl %di,%eax
   e6f61:	eb 1d                	jmp    e6f80 <varlit_core::native_layout::read_native_record_header+0x400>
   e6f63:	0f b7 df             	movzwl %di,%ebx
   e6f66:	eb 5b                	jmp    e6fc3 <varlit_core::native_layout::read_native_record_header+0x443>
   e6f68:	48 89 f8             	mov    %rdi,%rax
   e6f6b:	48 81 ff ff ff 00 00 	cmp    $0xffff,%rdi
   e6f72:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   e6f79:	00 
   e6f7a:	0f 87 79 02 00 00    	ja     e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e6f80:	48 81 e1 00 00 ff ff 	and    $0xffffffffffff0000,%rcx
   e6f87:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   e6f8c:	48 09 c1             	or     %rax,%rcx
   e6f8f:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
   e6f96:	00 
   e6f97:	b0 01                	mov    $0x1,%al
   e6f99:	89 44 24 58          	mov    %eax,0x58(%rsp)
   e6f9d:	48 85 f6             	test   %rsi,%rsi
   e6fa0:	0f 8f 9a 01 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e6fa6:	e9 85 fd ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e6fab:	48 89 fb             	mov    %rdi,%rbx
   e6fae:	48 81 ff ff ff 00 00 	cmp    $0xffff,%rdi
   e6fb5:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   e6fbc:	00 
   e6fbd:	0f 87 36 02 00 00    	ja     e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e6fc3:	48 81 e1 00 00 ff ff 	and    $0xffffffffffff0000,%rcx
   e6fca:	48 09 d9             	or     %rbx,%rcx
   e6fcd:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
   e6fd4:	00 
   e6fd5:	b0 01                	mov    $0x1,%al
   e6fd7:	89 44 24 60          	mov    %eax,0x60(%rsp)
   e6fdb:	48 85 f6             	test   %rsi,%rsi
   e6fde:	0f 8f 5c 01 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e6fe4:	e9 47 fd ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e6fe9:	89 f8                	mov    %edi,%eax
   e6feb:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   e6ff0:	48 85 f6             	test   %rsi,%rsi
   e6ff3:	0f 8f 47 01 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e6ff9:	e9 32 fd ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e6ffe:	48 89 7c 24 70       	mov    %rdi,0x70(%rsp)
   e7003:	48 85 f6             	test   %rsi,%rsi
   e7006:	0f 8f 34 01 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e700c:	e9 1f fd ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e7011:	0f b7 c7             	movzwl %di,%eax
   e7014:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   e7019:	48 85 f6             	test   %rsi,%rsi
   e701c:	0f 8f 1e 01 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e7022:	e9 09 fd ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e7027:	89 f8                	mov    %edi,%eax
   e7029:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   e702e:	48 85 f6             	test   %rsi,%rsi
   e7031:	0f 8f 09 01 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e7037:	e9 f4 fc ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e703c:	89 f9                	mov    %edi,%ecx
   e703e:	eb 41                	jmp    e7081 <varlit_core::native_layout::read_native_record_header+0x501>
   e7040:	48 89 7c 24 68       	mov    %rdi,0x68(%rsp)
   e7045:	48 85 f6             	test   %rsi,%rsi
   e7048:	0f 8f f2 00 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e704e:	e9 dd fc ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e7053:	48 89 f8             	mov    %rdi,%rax
   e7056:	48 c1 e8 20          	shr    $0x20,%rax
   e705a:	48 89 f9             	mov    %rdi,%rcx
   e705d:	74 22                	je     e7081 <varlit_core::native_layout::read_native_record_header+0x501>
   e705f:	e9 95 01 00 00       	jmp    e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e7064:	0f b7 c7             	movzwl %di,%eax
   e7067:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   e706c:	48 85 f6             	test   %rsi,%rsi
   e706f:	0f 8f cb 00 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e7075:	e9 b6 fc ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e707a:	89 f9                	mov    %edi,%ecx
   e707c:	eb 60                	jmp    e70de <varlit_core::native_layout::read_native_record_header+0x55e>
   e707e:	0f b7 cf             	movzwl %di,%ecx
   e7081:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
   e7088:	ff ff ff 
   e708b:	48 21 c2             	and    %rax,%rdx
   e708e:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   e7095:	00 
   e7096:	48 09 ca             	or     %rcx,%rdx
   e7099:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
   e70a0:	00 
   e70a1:	b0 01                	mov    $0x1,%al
   e70a3:	89 44 24 64          	mov    %eax,0x64(%rsp)
   e70a7:	48 85 f6             	test   %rsi,%rsi
   e70aa:	0f 8f 90 00 00 00    	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e70b0:	e9 7b fc ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e70b5:	89 f9                	mov    %edi,%ecx
   e70b7:	eb 58                	jmp    e7111 <varlit_core::native_layout::read_native_record_header+0x591>
   e70b9:	48 89 f8             	mov    %rdi,%rax
   e70bc:	48 c1 e8 20          	shr    $0x20,%rax
   e70c0:	48 89 f9             	mov    %rdi,%rcx
   e70c3:	74 19                	je     e70de <varlit_core::native_layout::read_native_record_header+0x55e>
   e70c5:	e9 2f 01 00 00       	jmp    e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e70ca:	48 89 f8             	mov    %rdi,%rax
   e70cd:	48 c1 e8 20          	shr    $0x20,%rax
   e70d1:	48 89 f9             	mov    %rdi,%rcx
   e70d4:	74 3b                	je     e7111 <varlit_core::native_layout::read_native_record_header+0x591>
   e70d6:	e9 1e 01 00 00       	jmp    e71f9 <varlit_core::native_layout::read_native_record_header+0x679>
   e70db:	0f b7 cf             	movzwl %di,%ecx
   e70de:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
   e70e5:	ff ff ff 
   e70e8:	48 21 c2             	and    %rax,%rdx
   e70eb:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
   e70f2:	00 
   e70f3:	48 09 ca             	or     %rcx,%rdx
   e70f6:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
   e70fd:	00 
   e70fe:	b0 01                	mov    $0x1,%al
   e7100:	89 44 24 50          	mov    %eax,0x50(%rsp)
   e7104:	48 85 f6             	test   %rsi,%rsi
   e7107:	7f 37                	jg     e7140 <varlit_core::native_layout::read_native_record_header+0x5c0>
   e7109:	e9 22 fc ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e710e:	0f b7 cf             	movzwl %di,%ecx
   e7111:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
   e7118:	ff ff ff 
   e711b:	48 21 c2             	and    %rax,%rdx
   e711e:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
   e7125:	00 
   e7126:	48 09 ca             	or     %rcx,%rdx
   e7129:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
   e7130:	00 
   e7131:	b0 01                	mov    $0x1,%al
   e7133:	89 44 24 4c          	mov    %eax,0x4c(%rsp)
   e7137:	48 85 f6             	test   %rsi,%rsi
   e713a:	0f 8e f0 fb ff ff    	jle    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e7140:	ba 01 00 00 00       	mov    $0x1,%edx
   e7145:	ff 15 1d 56 0e 00    	call   *0xe561d(%rip)        # 1cc768 <_DYNAMIC+0x2f0>
   e714b:	e9 e0 fb ff ff       	jmp    e6d30 <varlit_core::native_layout::read_native_record_header+0x1b0>
   e7150:	48 8d 15 11 07 0e 00 	lea    0xe0711(%rip),%rdx        # 1c7868 <anon.08630c77ddc8e20740d549a4826ccb7c.88.llvm.810036314814969787>
   e7157:	48 b8 6c 00 00 00 00 	movabs $0x800000000000006c,%rax
   e715e:	00 00 80 
   e7161:	48 83 c0 9a          	add    $0xffffffffffffff9a,%rax
   e7165:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   e716a:	48 89 03             	mov    %rax,(%rbx)
   e716d:	48 89 53 08          	mov    %rdx,0x8(%rbx)
   e7171:	e9 b1 00 00 00       	jmp    e7227 <varlit_core::native_layout::read_native_record_header+0x6a7>
   e7176:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
   e717b:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   e7180:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   e7185:	48 89 53 30          	mov    %rdx,0x30(%rbx)
   e7189:	0f 10 44 24 30       	movups 0x30(%rsp),%xmm0
   e718e:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   e7192:	48 89 73 08          	mov    %rsi,0x8(%rbx)
   e7196:	48 89 7b 10          	mov    %rdi,0x10(%rbx)
   e719a:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
   e719e:	48 89 03             	mov    %rax,(%rbx)
   e71a1:	e9 81 00 00 00       	jmp    e7227 <varlit_core::native_layout::read_native_record_header+0x6a7>
   e71a6:	49 83 c4 b2          	add    $0xffffffffffffffb2,%r12
   e71aa:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   e71af:	4c 89 23             	mov    %r12,(%rbx)
   e71b2:	48 8d 05 88 3a f4 ff 	lea    -0xbc578(%rip),%rax        # 2ac41 <anon.17b082cb49e65867434834b0b59514e7.5.llvm.178743251253153762+0x11e>
   e71b9:	48 89 43 08          	mov    %rax,0x8(%rbx)
   e71bd:	b8 2d 00 00 00       	mov    $0x2d,%eax
   e71c2:	48 89 43 10          	mov    %rax,0x10(%rbx)
   e71c6:	48 85 f6             	test   %rsi,%rsi
   e71c9:	7f 51                	jg     e721c <varlit_core::native_layout::read_native_record_header+0x69c>
   e71cb:	eb 5a                	jmp    e7227 <varlit_core::native_layout::read_native_record_header+0x6a7>
   e71cd:	48 83 bc 24 c8 00 00 	cmpq   $0x0,0xc8(%rsp)
   e71d4:	00 00 
   e71d6:	74 64                	je     e723c <varlit_core::native_layout::read_native_record_header+0x6bc>
   e71d8:	49 83 c4 b2          	add    $0xffffffffffffffb2,%r12
   e71dc:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   e71e1:	4c 89 23             	mov    %r12,(%rbx)
   e71e4:	48 8d 05 92 3b f4 ff 	lea    -0xbc46e(%rip),%rax        # 2ad7d <anon.17b082cb49e65867434834b0b59514e7.59.llvm.178743251253153762+0x15>
   e71eb:	48 89 43 08          	mov    %rax,0x8(%rbx)
   e71ef:	48 c7 43 10 36 00 00 	movq   $0x36,0x10(%rbx)
   e71f6:	00 
   e71f7:	eb 2e                	jmp    e7227 <varlit_core::native_layout::read_native_record_header+0x6a7>
   e71f9:	4b 8b 4c 3e f0       	mov    -0x10(%r14,%r15,1),%rcx
   e71fe:	4b 8b 44 3e f8       	mov    -0x8(%r14,%r15,1),%rax
   e7203:	49 83 c4 02          	add    $0x2,%r12
   e7207:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   e720c:	4c 89 23             	mov    %r12,(%rbx)
   e720f:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   e7213:	48 89 43 10          	mov    %rax,0x10(%rbx)
   e7217:	48 85 f6             	test   %rsi,%rsi
   e721a:	7e 0b                	jle    e7227 <varlit_core::native_layout::read_native_record_header+0x6a7>
   e721c:	ba 01 00 00 00       	mov    $0x1,%edx
   e7221:	ff 15 41 55 0e 00    	call   *0xe5541(%rip)        # 1cc768 <_DYNAMIC+0x2f0>
   e7227:	48 89 d8             	mov    %rbx,%rax
   e722a:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
   e7231:	5b                   	pop    %rbx
   e7232:	41 5c                	pop    %r12
   e7234:	41 5d                	pop    %r13
   e7236:	41 5e                	pop    %r14
   e7238:	41 5f                	pop    %r15
   e723a:	5d                   	pop    %rbp
   e723b:	c3                   	ret
   e723c:	49 89 df             	mov    %rbx,%r15
   e723f:	48 8d 05 22 2c f3 ff 	lea    -0xcd3de(%rip),%rax        # 19e68 <anon.17b082cb49e65867434834b0b59514e7.53.llvm.178743251253153762>
   e7246:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   e724b:	48 c7 44 24 20 08 00 	movq   $0x8,0x20(%rsp)
   e7252:	00 00 
   e7254:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   e7259:	f6 44 24 64 01       	testb  $0x1,0x64(%rsp)
   e725e:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   e7263:	0f 84 78 01 00 00    	je     e73e1 <varlit_core::native_layout::read_native_record_header+0x861>
   e7269:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   e726e:	e8 dd 24 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7273:	48 8d 05 ca 3a f4 ff 	lea    -0xbc536(%rip),%rax        # 2ad44 <anon.17b082cb49e65867434834b0b59514e7.54.llvm.178743251253153762>
   e727a:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   e727f:	48 c7 44 24 20 0d 00 	movq   $0xd,0x20(%rsp)
   e7286:	00 00 
   e7288:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   e728d:	f6 44 24 60 01       	testb  $0x1,0x60(%rsp)
   e7292:	0f 84 84 01 00 00    	je     e741c <varlit_core::native_layout::read_native_record_header+0x89c>
   e7298:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   e729d:	e8 ae 24 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e72a2:	48 8d 05 5f 3a f4 ff 	lea    -0xbc5a1(%rip),%rax        # 2ad08 <anon.17b082cb49e65867434834b0b59514e7.45.llvm.178743251253153762>
   e72a9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   e72ae:	48 c7 44 24 20 05 00 	movq   $0x5,0x20(%rsp)
   e72b5:	00 00 
   e72b7:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   e72bc:	f6 44 24 58 01       	testb  $0x1,0x58(%rsp)
   e72c1:	0f 84 9c 01 00 00    	je     e7463 <varlit_core::native_layout::read_native_record_header+0x8e3>
   e72c7:	4c 8d 74 24 10       	lea    0x10(%rsp),%r14
   e72cc:	4c 89 f7             	mov    %r14,%rdi
   e72cf:	e8 7c 24 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e72d4:	48 8d 05 45 2a f3 ff 	lea    -0xcd5bb(%rip),%rax        # 19d20 <anon.17b082cb49e65867434834b0b59514e7.56.llvm.178743251253153762>
   e72db:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   e72e0:	48 c7 44 24 20 08 00 	movq   $0x8,0x20(%rsp)
   e72e7:	00 00 
   e72e9:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   e72ee:	f6 44 24 5c 01       	testb  $0x1,0x5c(%rsp)
   e72f3:	0f 84 b1 01 00 00    	je     e74aa <varlit_core::native_layout::read_native_record_header+0x92a>
   e72f9:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   e72fe:	e8 4d 24 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7303:	48 8d 05 53 3a f4 ff 	lea    -0xbc5ad(%rip),%rax        # 2ad5d <anon.17b082cb49e65867434834b0b59514e7.57.llvm.178743251253153762>
   e730a:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   e730f:	48 c7 44 24 20 0b 00 	movq   $0xb,0x20(%rsp)
   e7316:	00 00 
   e7318:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   e731d:	f6 44 24 54 01       	testb  $0x1,0x54(%rsp)
   e7322:	0f 84 82 01 00 00    	je     e74aa <varlit_core::native_layout::read_native_record_header+0x92a>
   e7328:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   e732d:	e8 1e 24 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7332:	48 8d 05 5f 2a f3 ff 	lea    -0xcd5a1(%rip),%rax        # 19d98 <anon.17b082cb49e65867434834b0b59514e7.58.llvm.178743251253153762>
   e7339:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   e733e:	48 c7 44 24 20 08 00 	movq   $0x8,0x20(%rsp)
   e7345:	00 00 
   e7347:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   e734c:	f6 44 24 50 01       	testb  $0x1,0x50(%rsp)
   e7351:	0f 84 8f 01 00 00    	je     e74e6 <varlit_core::native_layout::read_native_record_header+0x966>
   e7357:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   e735c:	e8 ef 23 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7361:	48 8d 05 00 3a f4 ff 	lea    -0xbc600(%rip),%rax        # 2ad68 <anon.17b082cb49e65867434834b0b59514e7.59.llvm.178743251253153762>
   e7368:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   e736d:	48 c7 44 24 20 15 00 	movq   $0x15,0x20(%rsp)
   e7374:	00 00 
   e7376:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   e737b:	f6 44 24 4c 01       	testb  $0x1,0x4c(%rsp)
   e7380:	0f 84 98 01 00 00    	je     e751e <varlit_core::native_layout::read_native_record_header+0x99e>
   e7386:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   e738b:	e8 c0 23 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7390:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   e7395:	48 89 43 08          	mov    %rax,0x8(%rbx)
   e7399:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   e739e:	48 89 43 10          	mov    %rax,0x10(%rbx)
   e73a2:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   e73a9:	00 
   e73aa:	89 43 18             	mov    %eax,0x18(%rbx)
   e73ad:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
   e73b4:	00 
   e73b5:	89 43 1c             	mov    %eax,0x1c(%rbx)
   e73b8:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   e73bf:	00 
   e73c0:	89 43 20             	mov    %eax,0x20(%rbx)
   e73c3:	66 44 89 7b 24       	mov    %r15w,0x24(%rbx)
   e73c8:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   e73cd:	66 89 43 26          	mov    %ax,0x26(%rbx)
   e73d1:	48 c7 43 28 20 00 00 	movq   $0x20,0x28(%rbx)
   e73d8:	00 
   e73d9:	4c 89 2b             	mov    %r13,(%rbx)
   e73dc:	e9 46 fe ff ff       	jmp    e7227 <varlit_core::native_layout::read_native_record_header+0x6a7>
   e73e1:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
   e73e5:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   e73ea:	8b 54 24 28          	mov    0x28(%rsp),%edx
   e73ee:	0f 10 44 24 2c       	movups 0x2c(%rsp),%xmm0
   e73f3:	0f 10 4c 24 38       	movups 0x38(%rsp),%xmm1
   e73f8:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   e73fc:	0f 11 43 1c          	movups %xmm0,0x1c(%rbx)
   e7400:	89 43 0c             	mov    %eax,0xc(%rbx)
   e7403:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   e7407:	89 53 18             	mov    %edx,0x18(%rbx)
   e740a:	4c 89 23             	mov    %r12,(%rbx)
   e740d:	48 8d 05 54 2a f3 ff 	lea    -0xcd5ac(%rip),%rax        # 19e68 <anon.17b082cb49e65867434834b0b59514e7.53.llvm.178743251253153762>
   e7414:	89 43 08             	mov    %eax,0x8(%rbx)
   e7417:	e9 0b fe ff ff       	jmp    e7227 <varlit_core::native_layout::read_native_record_header+0x6a7>
   e741c:	8b 44 24 1a          	mov    0x1a(%rsp),%eax
   e7420:	0f b7 4c 24 1e       	movzwl 0x1e(%rsp),%ecx
   e7425:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   e742a:	0f b7 74 24 28       	movzwl 0x28(%rsp),%esi
   e742f:	0f 10 44 24 2a       	movups 0x2a(%rsp),%xmm0
   e7434:	0f 10 4c 24 38       	movups 0x38(%rsp),%xmm1
   e7439:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   e743d:	0f 11 43 1a          	movups %xmm0,0x1a(%rbx)
   e7441:	89 43 0a             	mov    %eax,0xa(%rbx)
   e7444:	66 89 4b 0e          	mov    %cx,0xe(%rbx)
   e7448:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   e744c:	66 89 73 18          	mov    %si,0x18(%rbx)
   e7450:	4c 89 23             	mov    %r12,(%rbx)
   e7453:	48 8d 05 ea 38 f4 ff 	lea    -0xbc716(%rip),%rax        # 2ad44 <anon.17b082cb49e65867434834b0b59514e7.54.llvm.178743251253153762>
   e745a:	66 89 43 08          	mov    %ax,0x8(%rbx)
   e745e:	e9 c4 fd ff ff       	jmp    e7227 <varlit_core::native_layout::read_native_record_header+0x6a7>
   e7463:	8b 44 24 1a          	mov    0x1a(%rsp),%eax
   e7467:	0f b7 4c 24 1e       	movzwl 0x1e(%rsp),%ecx
   e746c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   e7471:	0f b7 74 24 28       	movzwl 0x28(%rsp),%esi
   e7476:	0f 10 44 24 2a       	movups 0x2a(%rsp),%xmm0
   e747b:	0f 10 4c 24 38       	movups 0x38(%rsp),%xmm1
   e7480:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   e7484:	0f 11 43 1a          	movups %xmm0,0x1a(%rbx)
   e7488:	89 43 0a             	mov    %eax,0xa(%rbx)
   e748b:	66 89 4b 0e          	mov    %cx,0xe(%rbx)
   e748f:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   e7493:	66 89 73 18          	mov    %si,0x18(%rbx)
   e7497:	4c 89 23             	mov    %r12,(%rbx)
   e749a:	48 8d 05 67 38 f4 ff 	lea    -0xbc799(%rip),%rax        # 2ad08 <anon.17b082cb49e65867434834b0b59514e7.45.llvm.178743251253153762>
   e74a1:	66 89 43 08          	mov    %ax,0x8(%rbx)
   e74a5:	e9 7d fd ff ff       	jmp    e7227 <varlit_core::native_layout::read_native_record_header+0x6a7>
   e74aa:	49 8b 4e 30          	mov    0x30(%r14),%rcx
   e74ae:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
   e74b2:	41 0f 10 46 10       	movups 0x10(%r14),%xmm0
   e74b7:	41 0f 10 4e 20       	movups 0x20(%r14),%xmm1
   e74bc:	0f 11 4b 20          	movups %xmm1,0x20(%rbx)
   e74c0:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
   e74c4:	4c 89 23             	mov    %r12,(%rbx)
   e74c7:	48 89 43 08          	mov    %rax,0x8(%rbx)
   e74cb:	e9 57 fd ff ff       	jmp    e7227 <varlit_core::native_layout::read_native_record_header+0x6a7>
   e74d0:	48 8d 0d a9 03 0e 00 	lea    0xe03a9(%rip),%rcx        # 1c7880 <anon.08630c77ddc8e20740d549a4826ccb7c.89.llvm.810036314814969787>
   e74d7:	48 89 d7             	mov    %rdx,%rdi
   e74da:	4c 89 fe             	mov    %r15,%rsi
   e74dd:	4c 89 fa             	mov    %r15,%rdx
   e74e0:	ff 15 4a 53 0e 00    	call   *0xe534a(%rip)        # 1cc830 <_DYNAMIC+0x3b8>
   e74e6:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
   e74ea:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   e74ef:	8b 54 24 28          	mov    0x28(%rsp),%edx
   e74f3:	0f 10 44 24 2c       	movups 0x2c(%rsp),%xmm0
   e74f8:	0f 10 4c 24 38       	movups 0x38(%rsp),%xmm1
   e74fd:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   e7501:	0f 11 43 1c          	movups %xmm0,0x1c(%rbx)
   e7505:	89 43 0c             	mov    %eax,0xc(%rbx)
   e7508:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   e750c:	89 53 18             	mov    %edx,0x18(%rbx)
   e750f:	4c 89 23             	mov    %r12,(%rbx)
   e7512:	48 8d 05 7f 28 f3 ff 	lea    -0xcd781(%rip),%rax        # 19d98 <anon.17b082cb49e65867434834b0b59514e7.58.llvm.178743251253153762>
   e7519:	e9 f6 fe ff ff       	jmp    e7414 <varlit_core::native_layout::read_native_record_header+0x894>
   e751e:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
   e7522:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   e7527:	8b 54 24 28          	mov    0x28(%rsp),%edx
   e752b:	0f 10 44 24 2c       	movups 0x2c(%rsp),%xmm0
   e7530:	0f 10 4c 24 38       	movups 0x38(%rsp),%xmm1
   e7535:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   e7539:	0f 11 43 1c          	movups %xmm0,0x1c(%rbx)
   e753d:	89 43 0c             	mov    %eax,0xc(%rbx)
   e7540:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   e7544:	89 53 18             	mov    %edx,0x18(%rbx)
   e7547:	4c 89 23             	mov    %r12,(%rbx)
   e754a:	48 8d 05 17 38 f4 ff 	lea    -0xbc7e9(%rip),%rax        # 2ad68 <anon.17b082cb49e65867434834b0b59514e7.59.llvm.178743251253153762>
   e7551:	e9 be fe ff ff       	jmp    e7414 <varlit_core::native_layout::read_native_record_header+0x894>
   e7556:	cc                   	int3
   e7557:	cc                   	int3
   e7558:	cc                   	int3
   e7559:	cc                   	int3
   e755a:	cc                   	int3
   e755b:	cc                   	int3
   e755c:	cc                   	int3
   e755d:	cc                   	int3
   e755e:	cc                   	int3
   e755f:	cc                   	int3

