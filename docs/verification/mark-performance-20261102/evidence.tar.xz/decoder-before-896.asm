00000000000e7560 <varlit_core::native_layout::read_native_record_header>:
   e7560:	55                   	push   %rbp
   e7561:	41 57                	push   %r15
   e7563:	41 56                	push   %r14
   e7565:	41 55                	push   %r13
   e7567:	41 54                	push   %r12
   e7569:	53                   	push   %rbx
   e756a:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
   e7571:	48 89 fb             	mov    %rdi,%rbx
   e7574:	49 bc 6c 00 00 00 00 	movabs $0x800000000000006c,%r12
   e757b:	00 00 80 
   e757e:	48 8b 0e             	mov    (%rsi),%rcx
   e7581:	48 8b 46 08          	mov    0x8(%rsi),%rax
   e7585:	48 83 f8 1f          	cmp    $0x1f,%rax
   e7589:	77 25                	ja     e75b0 <varlit_core::native_layout::read_native_record_header+0x50>
   e758b:	48 01 c1             	add    %rax,%rcx
   e758e:	48 89 0e             	mov    %rcx,(%rsi)
   e7591:	48 c7 46 08 00 00 00 	movq   $0x0,0x8(%rsi)
   e7598:	00 
   e7599:	49 83 c4 9a          	add    $0xffffffffffffff9a,%r12
   e759d:	4c 89 23             	mov    %r12,(%rbx)
   e75a0:	48 8d 05 49 11 0e 00 	lea    0xe1149(%rip),%rax        # 1c86f0 <anon.d485c229fcb7df6cd985fb1fa2c23d43.85.llvm.7858262889936339001+0xa8>
   e75a7:	48 89 43 08          	mov    %rax,0x8(%rbx)
   e75ab:	e9 8a 05 00 00       	jmp    e7b3a <varlit_core::native_layout::read_native_record_header+0x5da>
   e75b0:	48 8d 51 20          	lea    0x20(%rcx),%rdx
   e75b4:	48 83 c0 e0          	add    $0xffffffffffffffe0,%rax
   e75b8:	0f 10 01             	movups (%rcx),%xmm0
   e75bb:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   e75bf:	0f 29 8c 24 e0 00 00 	movaps %xmm1,0xe0(%rsp)
   e75c6:	00 
   e75c7:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   e75ce:	00 
   e75cf:	48 89 16             	mov    %rdx,(%rsi)
   e75d2:	48 89 46 08          	mov    %rax,0x8(%rsi)
   e75d6:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
   e75dd:	00 
   e75de:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   e75e5:	00 
   e75e6:	48 c7 84 24 c8 00 00 	movq   $0x20,0xc8(%rsp)
   e75ed:	00 20 00 00 00 
   e75f2:	bd 38 00 00 00       	mov    $0x38,%ebp
   e75f7:	c7 44 24 5c 00 00 00 	movl   $0x0,0x5c(%rsp)
   e75fe:	00 
   e75ff:	4c 8d 35 f2 11 0e 00 	lea    0xe11f2(%rip),%r14        # 1c87f8 <anon.17b082cb49e65867434834b0b59514e7.60.llvm.178743251253153762>
   e7606:	4d 8d 6c 24 11       	lea    0x11(%r12),%r13
   e760b:	4c 8d 3d 86 2f f4 ff 	lea    -0xbd07a(%rip),%r15        # 2a598 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x14d1>
   e7612:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   e7619:	00 
   e761a:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   e7621:	00 
   e7622:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   e7627:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
   e762e:	00 
   e762f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   e7634:	c7 44 24 54 00 00 00 	movl   $0x0,0x54(%rsp)
   e763b:	00 
   e763c:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
   e7643:	00 
   e7644:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   e764b:	00 
   e764c:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   e7653:	00 
   e7654:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
   e765b:	00 
   e765c:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   e7663:	00 
   e7664:	eb 1b                	jmp    e7681 <varlit_core::native_layout::read_native_record_header+0x121>
   e7666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   e766d:	00 00 00 
   e7670:	48 83 c5 40          	add    $0x40,%rbp
   e7674:	48 81 fd f8 01 00 00 	cmp    $0x1f8,%rbp
   e767b:	0f 84 69 04 00 00    	je     e7aea <varlit_core::native_layout::read_native_record_header+0x58a>
   e7681:	4a 8b 54 35 c8       	mov    -0x38(%rbp,%r14,1),%rdx
   e7686:	4a 8b 4c 35 d0       	mov    -0x30(%rbp,%r14,1),%rcx
   e768b:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   e7690:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
   e7697:	00 
   e7698:	e8 53 cf ff ff       	call   e45f0 <varlit_core::native_layout::read_native_value>
   e769d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   e76a2:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   e76a7:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   e76ac:	4c 39 e8             	cmp    %r13,%rax
   e76af:	0f 85 eb 03 00 00    	jne    e7aa0 <varlit_core::native_layout::read_native_record_header+0x540>
   e76b5:	42 0f b6 44 35 00    	movzbl 0x0(%rbp,%r14,1),%eax
   e76bb:	49 63 04 87          	movslq (%r15,%rax,4),%rax
   e76bf:	4c 01 f8             	add    %r15,%rax
   e76c2:	ff e0                	jmp    *%rax
   e76c4:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e76c8:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e76cc:	48 89 f0             	mov    %rsi,%rax
   e76cf:	48 c1 f8 3f          	sar    $0x3f,%rax
   e76d3:	48 21 c8             	and    %rcx,%rax
   e76d6:	48 ff c8             	dec    %rax
   e76d9:	48 83 f8 03          	cmp    $0x3,%rax
   e76dd:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
   e76e4:	00 
   e76e5:	0f 87 26 04 00 00    	ja     e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e76eb:	48 8d 0d 1e 2f f4 ff 	lea    -0xbd0e2(%rip),%rcx        # 2a610 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x1549>
   e76f2:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e76f6:	48 01 c8             	add    %rcx,%rax
   e76f9:	ff e0                	jmp    *%rax
   e76fb:	40 0f b6 c7          	movzbl %dil,%eax
   e76ff:	e9 c2 02 00 00       	jmp    e79c6 <varlit_core::native_layout::read_native_record_header+0x466>
   e7704:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e7708:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e770c:	48 89 f0             	mov    %rsi,%rax
   e770f:	48 c1 f8 3f          	sar    $0x3f,%rax
   e7713:	48 21 c8             	and    %rcx,%rax
   e7716:	48 ff c8             	dec    %rax
   e7719:	48 83 f8 03          	cmp    $0x3,%rax
   e771d:	0f 87 ee 03 00 00    	ja     e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e7723:	b1 01                	mov    $0x1,%cl
   e7725:	89 4c 24 4c          	mov    %ecx,0x4c(%rsp)
   e7729:	48 8d 0d c0 2e f4 ff 	lea    -0xbd140(%rip),%rcx        # 2a5f0 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x1529>
   e7730:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e7734:	48 01 c8             	add    %rcx,%rax
   e7737:	ff e0                	jmp    *%rax
   e7739:	40 0f b6 c7          	movzbl %dil,%eax
   e773d:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   e7742:	48 85 f6             	test   %rsi,%rsi
   e7745:	0f 8f 45 03 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e774b:	e9 20 ff ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e7750:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e7754:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e7758:	48 89 f0             	mov    %rsi,%rax
   e775b:	48 c1 f8 3f          	sar    $0x3f,%rax
   e775f:	48 21 c8             	and    %rcx,%rax
   e7762:	48 83 f8 04          	cmp    $0x4,%rax
   e7766:	0f 84 3c 01 00 00    	je     e78a8 <varlit_core::native_layout::read_native_record_header+0x348>
   e776c:	48 83 f8 02          	cmp    $0x2,%rax
   e7770:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   e7777:	00 
   e7778:	0f 84 20 01 00 00    	je     e789e <varlit_core::native_layout::read_native_record_header+0x33e>
   e777e:	48 83 f8 01          	cmp    $0x1,%rax
   e7782:	0f 85 89 03 00 00    	jne    e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e7788:	40 0f b6 c7          	movzbl %dil,%eax
   e778c:	e9 2f 01 00 00       	jmp    e78c0 <varlit_core::native_layout::read_native_record_header+0x360>
   e7791:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e7795:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e7799:	48 89 f0             	mov    %rsi,%rax
   e779c:	48 c1 f8 3f          	sar    $0x3f,%rax
   e77a0:	48 21 c8             	and    %rcx,%rax
   e77a3:	48 ff c8             	dec    %rax
   e77a6:	48 83 f8 03          	cmp    $0x3,%rax
   e77aa:	0f 87 61 03 00 00    	ja     e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e77b0:	b1 01                	mov    $0x1,%cl
   e77b2:	89 4c 24 54          	mov    %ecx,0x54(%rsp)
   e77b6:	48 8d 0d 43 2e f4 ff 	lea    -0xbd1bd(%rip),%rcx        # 2a600 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x1539>
   e77bd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e77c1:	48 01 c8             	add    %rcx,%rax
   e77c4:	ff e0                	jmp    *%rax
   e77c6:	40 0f b6 c7          	movzbl %dil,%eax
   e77ca:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   e77cf:	48 85 f6             	test   %rsi,%rsi
   e77d2:	0f 8f b8 02 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e77d8:	e9 93 fe ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e77dd:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e77e1:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e77e5:	48 89 f0             	mov    %rsi,%rax
   e77e8:	48 c1 f8 3f          	sar    $0x3f,%rax
   e77ec:	48 21 c8             	and    %rcx,%rax
   e77ef:	48 83 f8 04          	cmp    $0x4,%rax
   e77f3:	0f 84 f2 00 00 00    	je     e78eb <varlit_core::native_layout::read_native_record_header+0x38b>
   e77f9:	48 83 f8 02          	cmp    $0x2,%rax
   e77fd:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   e7804:	00 
   e7805:	0f 84 98 00 00 00    	je     e78a3 <varlit_core::native_layout::read_native_record_header+0x343>
   e780b:	48 83 f8 01          	cmp    $0x1,%rax
   e780f:	0f 85 fc 02 00 00    	jne    e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e7815:	40 0f b6 c7          	movzbl %dil,%eax
   e7819:	e9 e5 00 00 00       	jmp    e7903 <varlit_core::native_layout::read_native_record_header+0x3a3>
   e781e:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e7822:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e7826:	48 89 f0             	mov    %rsi,%rax
   e7829:	48 c1 f8 3f          	sar    $0x3f,%rax
   e782d:	48 21 c8             	and    %rcx,%rax
   e7830:	48 ff c8             	dec    %rax
   e7833:	48 83 f8 03          	cmp    $0x3,%rax
   e7837:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
   e783e:	00 
   e783f:	0f 87 cc 02 00 00    	ja     e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e7845:	48 8d 0d 94 2d f4 ff 	lea    -0xbd26c(%rip),%rcx        # 2a5e0 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x1519>
   e784c:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e7850:	48 01 c8             	add    %rcx,%rax
   e7853:	ff e0                	jmp    *%rax
   e7855:	40 0f b6 c7          	movzbl %dil,%eax
   e7859:	e9 c5 01 00 00       	jmp    e7a23 <varlit_core::native_layout::read_native_record_header+0x4c3>
   e785e:	49 8d 0c 34          	lea    (%r12,%rsi,1),%rcx
   e7862:	48 83 c1 95          	add    $0xffffffffffffff95,%rcx
   e7866:	48 89 f0             	mov    %rsi,%rax
   e7869:	48 c1 f8 3f          	sar    $0x3f,%rax
   e786d:	48 21 c8             	and    %rcx,%rax
   e7870:	48 ff c8             	dec    %rax
   e7873:	48 83 f8 03          	cmp    $0x3,%rax
   e7877:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
   e787e:	00 
   e787f:	0f 87 8c 02 00 00    	ja     e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e7885:	48 8d 0d 44 2d f4 ff 	lea    -0xbd2bc(%rip),%rcx        # 2a5d0 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x1509>
   e788c:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e7890:	48 01 c8             	add    %rcx,%rax
   e7893:	ff e0                	jmp    *%rax
   e7895:	40 0f b6 c7          	movzbl %dil,%eax
   e7899:	e9 b8 01 00 00       	jmp    e7a56 <varlit_core::native_layout::read_native_record_header+0x4f6>
   e789e:	0f b7 c7             	movzwl %di,%eax
   e78a1:	eb 1d                	jmp    e78c0 <varlit_core::native_layout::read_native_record_header+0x360>
   e78a3:	0f b7 c7             	movzwl %di,%eax
   e78a6:	eb 5b                	jmp    e7903 <varlit_core::native_layout::read_native_record_header+0x3a3>
   e78a8:	48 89 f8             	mov    %rdi,%rax
   e78ab:	48 81 ff ff ff 00 00 	cmp    $0xffff,%rdi
   e78b2:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   e78b9:	00 
   e78ba:	0f 87 51 02 00 00    	ja     e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e78c0:	48 81 e1 00 00 ff ff 	and    $0xffffffffffff0000,%rcx
   e78c7:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   e78cc:	48 09 c1             	or     %rax,%rcx
   e78cf:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
   e78d6:	00 
   e78d7:	b0 01                	mov    $0x1,%al
   e78d9:	89 44 24 50          	mov    %eax,0x50(%rsp)
   e78dd:	48 85 f6             	test   %rsi,%rsi
   e78e0:	0f 8f aa 01 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e78e6:	e9 85 fd ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e78eb:	48 89 f8             	mov    %rdi,%rax
   e78ee:	48 81 ff ff ff 00 00 	cmp    $0xffff,%rdi
   e78f5:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   e78fc:	00 
   e78fd:	0f 87 0e 02 00 00    	ja     e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e7903:	48 81 e1 00 00 ff ff 	and    $0xffffffffffff0000,%rcx
   e790a:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   e790f:	48 09 c1             	or     %rax,%rcx
   e7912:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
   e7919:	00 
   e791a:	b0 01                	mov    $0x1,%al
   e791c:	89 44 24 58          	mov    %eax,0x58(%rsp)
   e7920:	48 85 f6             	test   %rsi,%rsi
   e7923:	0f 8f 67 01 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e7929:	e9 42 fd ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e792e:	89 f8                	mov    %edi,%eax
   e7930:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   e7935:	48 85 f6             	test   %rsi,%rsi
   e7938:	0f 8f 52 01 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e793e:	e9 2d fd ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e7943:	48 89 7c 24 68       	mov    %rdi,0x68(%rsp)
   e7948:	48 85 f6             	test   %rsi,%rsi
   e794b:	0f 8f 3f 01 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e7951:	e9 1a fd ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e7956:	0f b7 c7             	movzwl %di,%eax
   e7959:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   e795e:	48 85 f6             	test   %rsi,%rsi
   e7961:	0f 8f 29 01 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e7967:	e9 04 fd ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e796c:	89 f8                	mov    %edi,%eax
   e796e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   e7973:	48 85 f6             	test   %rsi,%rsi
   e7976:	0f 8f 14 01 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e797c:	e9 ef fc ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e7981:	89 f8                	mov    %edi,%eax
   e7983:	eb 41                	jmp    e79c6 <varlit_core::native_layout::read_native_record_header+0x466>
   e7985:	48 89 7c 24 60       	mov    %rdi,0x60(%rsp)
   e798a:	48 85 f6             	test   %rsi,%rsi
   e798d:	0f 8f fd 00 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e7993:	e9 d8 fc ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e7998:	48 89 f8             	mov    %rdi,%rax
   e799b:	48 c1 e8 20          	shr    $0x20,%rax
   e799f:	48 89 f8             	mov    %rdi,%rax
   e79a2:	74 22                	je     e79c6 <varlit_core::native_layout::read_native_record_header+0x466>
   e79a4:	e9 68 01 00 00       	jmp    e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e79a9:	0f b7 c7             	movzwl %di,%eax
   e79ac:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   e79b1:	48 85 f6             	test   %rsi,%rsi
   e79b4:	0f 8f d6 00 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e79ba:	e9 b1 fc ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e79bf:	89 f8                	mov    %edi,%eax
   e79c1:	eb 60                	jmp    e7a23 <varlit_core::native_layout::read_native_record_header+0x4c3>
   e79c3:	0f b7 c7             	movzwl %di,%eax
   e79c6:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   e79cd:	ff ff ff 
   e79d0:	48 21 ca             	and    %rcx,%rdx
   e79d3:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   e79da:	00 
   e79db:	48 09 c2             	or     %rax,%rdx
   e79de:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
   e79e5:	00 
   e79e6:	b0 01                	mov    $0x1,%al
   e79e8:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
   e79ec:	48 85 f6             	test   %rsi,%rsi
   e79ef:	0f 8f 9b 00 00 00    	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e79f5:	e9 76 fc ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e79fa:	89 f8                	mov    %edi,%eax
   e79fc:	eb 58                	jmp    e7a56 <varlit_core::native_layout::read_native_record_header+0x4f6>
   e79fe:	48 89 f8             	mov    %rdi,%rax
   e7a01:	48 c1 e8 20          	shr    $0x20,%rax
   e7a05:	48 89 f8             	mov    %rdi,%rax
   e7a08:	74 19                	je     e7a23 <varlit_core::native_layout::read_native_record_header+0x4c3>
   e7a0a:	e9 02 01 00 00       	jmp    e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e7a0f:	48 89 f8             	mov    %rdi,%rax
   e7a12:	48 c1 e8 20          	shr    $0x20,%rax
   e7a16:	48 89 f8             	mov    %rdi,%rax
   e7a19:	74 3b                	je     e7a56 <varlit_core::native_layout::read_native_record_header+0x4f6>
   e7a1b:	e9 f1 00 00 00       	jmp    e7b11 <varlit_core::native_layout::read_native_record_header+0x5b1>
   e7a20:	0f b7 c7             	movzwl %di,%eax
   e7a23:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   e7a2a:	ff ff ff 
   e7a2d:	48 21 ca             	and    %rcx,%rdx
   e7a30:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   e7a37:	00 
   e7a38:	48 09 c2             	or     %rax,%rdx
   e7a3b:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
   e7a42:	00 
   e7a43:	b0 01                	mov    $0x1,%al
   e7a45:	89 44 24 48          	mov    %eax,0x48(%rsp)
   e7a49:	48 85 f6             	test   %rsi,%rsi
   e7a4c:	7f 42                	jg     e7a90 <varlit_core::native_layout::read_native_record_header+0x530>
   e7a4e:	e9 1d fc ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e7a53:	0f b7 c7             	movzwl %di,%eax
   e7a56:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   e7a5d:	ff ff ff 
   e7a60:	48 21 ca             	and    %rcx,%rdx
   e7a63:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   e7a6a:	00 
   e7a6b:	48 09 c2             	or     %rax,%rdx
   e7a6e:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
   e7a75:	00 
   e7a76:	b0 01                	mov    $0x1,%al
   e7a78:	89 44 24 44          	mov    %eax,0x44(%rsp)
   e7a7c:	48 85 f6             	test   %rsi,%rsi
   e7a7f:	0f 8e eb fb ff ff    	jle    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e7a85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   e7a8c:	00 00 00 00 
   e7a90:	ba 01 00 00 00       	mov    $0x1,%edx
   e7a95:	ff 15 cd 4c 0e 00    	call   *0xe4ccd(%rip)        # 1cc768 <_DYNAMIC+0x2f0>
   e7a9b:	e9 d0 fb ff ff       	jmp    e7670 <varlit_core::native_layout::read_native_record_header+0x110>
   e7aa0:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   e7aa5:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   e7aaa:	48 89 53 30          	mov    %rdx,0x30(%rbx)
   e7aae:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
   e7ab3:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   e7ab7:	48 89 73 08          	mov    %rsi,0x8(%rbx)
   e7abb:	48 89 7b 10          	mov    %rdi,0x10(%rbx)
   e7abf:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
   e7ac3:	48 89 03             	mov    %rax,(%rbx)
   e7ac6:	eb 72                	jmp    e7b3a <varlit_core::native_layout::read_native_record_header+0x5da>
   e7ac8:	49 83 c4 b2          	add    $0xffffffffffffffb2,%r12
   e7acc:	4c 89 23             	mov    %r12,(%rbx)
   e7acf:	48 8d 05 6b 31 f4 ff 	lea    -0xbce95(%rip),%rax        # 2ac41 <anon.17b082cb49e65867434834b0b59514e7.5.llvm.178743251253153762+0x11e>
   e7ad6:	48 89 43 08          	mov    %rax,0x8(%rbx)
   e7ada:	b8 2d 00 00 00       	mov    $0x2d,%eax
   e7adf:	48 89 43 10          	mov    %rax,0x10(%rbx)
   e7ae3:	48 85 f6             	test   %rsi,%rsi
   e7ae6:	7f 47                	jg     e7b2f <varlit_core::native_layout::read_native_record_header+0x5cf>
   e7ae8:	eb 50                	jmp    e7b3a <varlit_core::native_layout::read_native_record_header+0x5da>
   e7aea:	48 83 bc 24 c8 00 00 	cmpq   $0x0,0xc8(%rsp)
   e7af1:	00 00 
   e7af3:	74 5a                	je     e7b4f <varlit_core::native_layout::read_native_record_header+0x5ef>
   e7af5:	49 83 c4 b2          	add    $0xffffffffffffffb2,%r12
   e7af9:	4c 89 23             	mov    %r12,(%rbx)
   e7afc:	48 8d 05 7a 32 f4 ff 	lea    -0xbcd86(%rip),%rax        # 2ad7d <anon.17b082cb49e65867434834b0b59514e7.59.llvm.178743251253153762+0x15>
   e7b03:	48 89 43 08          	mov    %rax,0x8(%rbx)
   e7b07:	48 c7 43 10 36 00 00 	movq   $0x36,0x10(%rbx)
   e7b0e:	00 
   e7b0f:	eb 29                	jmp    e7b3a <varlit_core::native_layout::read_native_record_header+0x5da>
   e7b11:	4a 8b 4c 35 f0       	mov    -0x10(%rbp,%r14,1),%rcx
   e7b16:	4a 8b 44 35 f8       	mov    -0x8(%rbp,%r14,1),%rax
   e7b1b:	49 83 c4 02          	add    $0x2,%r12
   e7b1f:	4c 89 23             	mov    %r12,(%rbx)
   e7b22:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   e7b26:	48 89 43 10          	mov    %rax,0x10(%rbx)
   e7b2a:	48 85 f6             	test   %rsi,%rsi
   e7b2d:	7e 0b                	jle    e7b3a <varlit_core::native_layout::read_native_record_header+0x5da>
   e7b2f:	ba 01 00 00 00       	mov    $0x1,%edx
   e7b34:	ff 15 2e 4c 0e 00    	call   *0xe4c2e(%rip)        # 1cc768 <_DYNAMIC+0x2f0>
   e7b3a:	48 89 d8             	mov    %rbx,%rax
   e7b3d:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
   e7b44:	5b                   	pop    %rbx
   e7b45:	41 5c                	pop    %r12
   e7b47:	41 5d                	pop    %r13
   e7b49:	41 5e                	pop    %r14
   e7b4b:	41 5f                	pop    %r15
   e7b4d:	5d                   	pop    %rbp
   e7b4e:	c3                   	ret
   e7b4f:	48 8d 05 12 23 f3 ff 	lea    -0xcdcee(%rip),%rax        # 19e68 <anon.17b082cb49e65867434834b0b59514e7.53.llvm.178743251253153762>
   e7b56:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   e7b5b:	48 c7 44 24 18 08 00 	movq   $0x8,0x18(%rsp)
   e7b62:	00 00 
   e7b64:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   e7b69:	f6 44 24 5c 01       	testb  $0x1,0x5c(%rsp)
   e7b6e:	0f 84 7c 01 00 00    	je     e7cf0 <varlit_core::native_layout::read_native_record_header+0x790>
   e7b74:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   e7b79:	e8 d2 1b 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7b7e:	48 8d 05 bf 31 f4 ff 	lea    -0xbce41(%rip),%rax        # 2ad44 <anon.17b082cb49e65867434834b0b59514e7.54.llvm.178743251253153762>
   e7b85:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   e7b8a:	48 c7 44 24 18 0d 00 	movq   $0xd,0x18(%rsp)
   e7b91:	00 00 
   e7b93:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   e7b98:	f6 44 24 58 01       	testb  $0x1,0x58(%rsp)
   e7b9d:	0f 84 88 01 00 00    	je     e7d2b <varlit_core::native_layout::read_native_record_header+0x7cb>
   e7ba3:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   e7ba8:	e8 a3 1b 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7bad:	48 8d 05 54 31 f4 ff 	lea    -0xbceac(%rip),%rax        # 2ad08 <anon.17b082cb49e65867434834b0b59514e7.45.llvm.178743251253153762>
   e7bb4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   e7bb9:	48 c7 44 24 18 05 00 	movq   $0x5,0x18(%rsp)
   e7bc0:	00 00 
   e7bc2:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   e7bc7:	f6 44 24 50 01       	testb  $0x1,0x50(%rsp)
   e7bcc:	0f 84 a0 01 00 00    	je     e7d72 <varlit_core::native_layout::read_native_record_header+0x812>
   e7bd2:	4c 8d 74 24 08       	lea    0x8(%rsp),%r14
   e7bd7:	4c 89 f7             	mov    %r14,%rdi
   e7bda:	e8 71 1b 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7bdf:	48 8d 05 3a 21 f3 ff 	lea    -0xcdec6(%rip),%rax        # 19d20 <anon.17b082cb49e65867434834b0b59514e7.56.llvm.178743251253153762>
   e7be6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   e7beb:	48 c7 44 24 18 08 00 	movq   $0x8,0x18(%rsp)
   e7bf2:	00 00 
   e7bf4:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   e7bf9:	f6 44 24 54 01       	testb  $0x1,0x54(%rsp)
   e7bfe:	0f 84 b5 01 00 00    	je     e7db9 <varlit_core::native_layout::read_native_record_header+0x859>
   e7c04:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   e7c09:	e8 42 1b 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7c0e:	48 8d 05 48 31 f4 ff 	lea    -0xbceb8(%rip),%rax        # 2ad5d <anon.17b082cb49e65867434834b0b59514e7.57.llvm.178743251253153762>
   e7c15:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   e7c1a:	48 c7 44 24 18 0b 00 	movq   $0xb,0x18(%rsp)
   e7c21:	00 00 
   e7c23:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   e7c28:	f6 44 24 4c 01       	testb  $0x1,0x4c(%rsp)
   e7c2d:	0f 84 86 01 00 00    	je     e7db9 <varlit_core::native_layout::read_native_record_header+0x859>
   e7c33:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   e7c38:	e8 13 1b 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7c3d:	48 8d 05 54 21 f3 ff 	lea    -0xcdeac(%rip),%rax        # 19d98 <anon.17b082cb49e65867434834b0b59514e7.58.llvm.178743251253153762>
   e7c44:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   e7c49:	48 c7 44 24 18 08 00 	movq   $0x8,0x18(%rsp)
   e7c50:	00 00 
   e7c52:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   e7c57:	f6 44 24 48 01       	testb  $0x1,0x48(%rsp)
   e7c5c:	0f 84 7d 01 00 00    	je     e7ddf <varlit_core::native_layout::read_native_record_header+0x87f>
   e7c62:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   e7c67:	e8 e4 1a 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7c6c:	48 8d 05 f5 30 f4 ff 	lea    -0xbcf0b(%rip),%rax        # 2ad68 <anon.17b082cb49e65867434834b0b59514e7.59.llvm.178743251253153762>
   e7c73:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   e7c78:	48 c7 44 24 18 15 00 	movq   $0x15,0x18(%rsp)
   e7c7f:	00 00 
   e7c81:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   e7c86:	f6 44 24 44 01       	testb  $0x1,0x44(%rsp)
   e7c8b:	0f 84 86 01 00 00    	je     e7e17 <varlit_core::native_layout::read_native_record_header+0x8b7>
   e7c91:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   e7c96:	e8 b5 1a 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e7c9b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   e7ca0:	48 89 43 08          	mov    %rax,0x8(%rbx)
   e7ca4:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   e7ca9:	48 89 43 10          	mov    %rax,0x10(%rbx)
   e7cad:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   e7cb4:	00 
   e7cb5:	89 43 18             	mov    %eax,0x18(%rbx)
   e7cb8:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
   e7cbf:	00 
   e7cc0:	89 43 1c             	mov    %eax,0x1c(%rbx)
   e7cc3:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   e7cca:	00 
   e7ccb:	89 43 20             	mov    %eax,0x20(%rbx)
   e7cce:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   e7cd3:	66 89 43 24          	mov    %ax,0x24(%rbx)
   e7cd7:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   e7cdc:	66 89 43 26          	mov    %ax,0x26(%rbx)
   e7ce0:	48 c7 43 28 20 00 00 	movq   $0x20,0x28(%rbx)
   e7ce7:	00 
   e7ce8:	4c 89 2b             	mov    %r13,(%rbx)
   e7ceb:	e9 4a fe ff ff       	jmp    e7b3a <varlit_core::native_layout::read_native_record_header+0x5da>
   e7cf0:	8b 44 24 14          	mov    0x14(%rsp),%eax
   e7cf4:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   e7cf9:	8b 54 24 20          	mov    0x20(%rsp),%edx
   e7cfd:	0f 10 44 24 24       	movups 0x24(%rsp),%xmm0
   e7d02:	0f 10 4c 24 30       	movups 0x30(%rsp),%xmm1
   e7d07:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   e7d0b:	0f 11 43 1c          	movups %xmm0,0x1c(%rbx)
   e7d0f:	89 43 0c             	mov    %eax,0xc(%rbx)
   e7d12:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   e7d16:	89 53 18             	mov    %edx,0x18(%rbx)
   e7d19:	4c 89 23             	mov    %r12,(%rbx)
   e7d1c:	48 8d 05 45 21 f3 ff 	lea    -0xcdebb(%rip),%rax        # 19e68 <anon.17b082cb49e65867434834b0b59514e7.53.llvm.178743251253153762>
   e7d23:	89 43 08             	mov    %eax,0x8(%rbx)
   e7d26:	e9 0f fe ff ff       	jmp    e7b3a <varlit_core::native_layout::read_native_record_header+0x5da>
   e7d2b:	8b 44 24 12          	mov    0x12(%rsp),%eax
   e7d2f:	0f b7 4c 24 16       	movzwl 0x16(%rsp),%ecx
   e7d34:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   e7d39:	0f b7 74 24 20       	movzwl 0x20(%rsp),%esi
   e7d3e:	0f 10 44 24 22       	movups 0x22(%rsp),%xmm0
   e7d43:	0f 10 4c 24 30       	movups 0x30(%rsp),%xmm1
   e7d48:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   e7d4c:	0f 11 43 1a          	movups %xmm0,0x1a(%rbx)
   e7d50:	89 43 0a             	mov    %eax,0xa(%rbx)
   e7d53:	66 89 4b 0e          	mov    %cx,0xe(%rbx)
   e7d57:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   e7d5b:	66 89 73 18          	mov    %si,0x18(%rbx)
   e7d5f:	4c 89 23             	mov    %r12,(%rbx)
   e7d62:	48 8d 05 db 2f f4 ff 	lea    -0xbd025(%rip),%rax        # 2ad44 <anon.17b082cb49e65867434834b0b59514e7.54.llvm.178743251253153762>
   e7d69:	66 89 43 08          	mov    %ax,0x8(%rbx)
   e7d6d:	e9 c8 fd ff ff       	jmp    e7b3a <varlit_core::native_layout::read_native_record_header+0x5da>
   e7d72:	8b 44 24 12          	mov    0x12(%rsp),%eax
   e7d76:	0f b7 4c 24 16       	movzwl 0x16(%rsp),%ecx
   e7d7b:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   e7d80:	0f b7 74 24 20       	movzwl 0x20(%rsp),%esi
   e7d85:	0f 10 44 24 22       	movups 0x22(%rsp),%xmm0
   e7d8a:	0f 10 4c 24 30       	movups 0x30(%rsp),%xmm1
   e7d8f:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   e7d93:	0f 11 43 1a          	movups %xmm0,0x1a(%rbx)
   e7d97:	89 43 0a             	mov    %eax,0xa(%rbx)
   e7d9a:	66 89 4b 0e          	mov    %cx,0xe(%rbx)
   e7d9e:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   e7da2:	66 89 73 18          	mov    %si,0x18(%rbx)
   e7da6:	4c 89 23             	mov    %r12,(%rbx)
   e7da9:	48 8d 05 58 2f f4 ff 	lea    -0xbd0a8(%rip),%rax        # 2ad08 <anon.17b082cb49e65867434834b0b59514e7.45.llvm.178743251253153762>
   e7db0:	66 89 43 08          	mov    %ax,0x8(%rbx)
   e7db4:	e9 81 fd ff ff       	jmp    e7b3a <varlit_core::native_layout::read_native_record_header+0x5da>
   e7db9:	49 8b 4e 30          	mov    0x30(%r14),%rcx
   e7dbd:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
   e7dc1:	41 0f 10 46 10       	movups 0x10(%r14),%xmm0
   e7dc6:	41 0f 10 4e 20       	movups 0x20(%r14),%xmm1
   e7dcb:	0f 11 4b 20          	movups %xmm1,0x20(%rbx)
   e7dcf:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
   e7dd3:	4c 89 23             	mov    %r12,(%rbx)
   e7dd6:	48 89 43 08          	mov    %rax,0x8(%rbx)
   e7dda:	e9 5b fd ff ff       	jmp    e7b3a <varlit_core::native_layout::read_native_record_header+0x5da>
   e7ddf:	8b 44 24 14          	mov    0x14(%rsp),%eax
   e7de3:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   e7de8:	8b 54 24 20          	mov    0x20(%rsp),%edx
   e7dec:	0f 10 44 24 24       	movups 0x24(%rsp),%xmm0
   e7df1:	0f 10 4c 24 30       	movups 0x30(%rsp),%xmm1
   e7df6:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   e7dfa:	0f 11 43 1c          	movups %xmm0,0x1c(%rbx)
   e7dfe:	89 43 0c             	mov    %eax,0xc(%rbx)
   e7e01:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   e7e05:	89 53 18             	mov    %edx,0x18(%rbx)
   e7e08:	4c 89 23             	mov    %r12,(%rbx)
   e7e0b:	48 8d 05 86 1f f3 ff 	lea    -0xce07a(%rip),%rax        # 19d98 <anon.17b082cb49e65867434834b0b59514e7.58.llvm.178743251253153762>
   e7e12:	e9 0c ff ff ff       	jmp    e7d23 <varlit_core::native_layout::read_native_record_header+0x7c3>
   e7e17:	8b 44 24 14          	mov    0x14(%rsp),%eax
   e7e1b:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   e7e20:	8b 54 24 20          	mov    0x20(%rsp),%edx
   e7e24:	0f 10 44 24 24       	movups 0x24(%rsp),%xmm0
   e7e29:	0f 10 4c 24 30       	movups 0x30(%rsp),%xmm1
   e7e2e:	0f 11 4b 28          	movups %xmm1,0x28(%rbx)
   e7e32:	0f 11 43 1c          	movups %xmm0,0x1c(%rbx)
   e7e36:	89 43 0c             	mov    %eax,0xc(%rbx)
   e7e39:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   e7e3d:	89 53 18             	mov    %edx,0x18(%rbx)
   e7e40:	4c 89 23             	mov    %r12,(%rbx)
   e7e43:	48 8d 05 1e 2f f4 ff 	lea    -0xbd0e2(%rip),%rax        # 2ad68 <anon.17b082cb49e65867434834b0b59514e7.59.llvm.178743251253153762>
   e7e4a:	e9 d4 fe ff ff       	jmp    e7d23 <varlit_core::native_layout::read_native_record_header+0x7c3>
   e7e4f:	cc                   	int3

