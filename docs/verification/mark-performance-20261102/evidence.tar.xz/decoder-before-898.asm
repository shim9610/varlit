00000000000e8010 <varlit_core::native_layout::decode_native_record_footer>:
   e8010:	55                   	push   %rbp
   e8011:	41 57                	push   %r15
   e8013:	41 56                	push   %r14
   e8015:	41 55                	push   %r13
   e8017:	41 54                	push   %r12
   e8019:	53                   	push   %rbx
   e801a:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
   e8021:	48 89 f5             	mov    %rsi,%rbp
   e8024:	48 89 f8             	mov    %rdi,%rax
   e8027:	48 be 30 00 00 00 00 	movabs $0x8000000000000030,%rsi
   e802e:	00 00 80 
   e8031:	48 83 fa 20          	cmp    $0x20,%rdx
   e8035:	0f 85 53 03 00 00    	jne    e838e <varlit_core::native_layout::decode_native_record_footer+0x37e>
   e803b:	4c 89 44 24 70       	mov    %r8,0x70(%rsp)
   e8040:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
   e8045:	48 89 04 24          	mov    %rax,(%rsp)
   e8049:	31 db                	xor    %ebx,%ebx
   e804b:	41 bd 20 00 00 00    	mov    $0x20,%r13d
   e8051:	4c 8d 3d 60 09 0e 00 	lea    0xe0960(%rip),%r15        # 1c89b8 <anon.17b082cb49e65867434834b0b59514e7.69.llvm.178743251253153762>
   e8058:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
   e805f:	00 00 00 00 00 
   e8064:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
   e806b:	00 00 
   e806d:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   e8074:	00 00 
   e8076:	89 44 24 14          	mov    %eax,0x14(%rsp)
   e807a:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   e8081:	00 00 00 00 00 
   e8086:	49 89 de             	mov    %rbx,%r14
   e8089:	48 83 c3 40          	add    $0x40,%rbx
   e808d:	0f 1f 00             	nopl   (%rax)
   e8090:	45 0f b6 67 38       	movzbl 0x38(%r15),%r12d
   e8095:	41 83 fc 07          	cmp    $0x7,%r12d
   e8099:	75 68                	jne    e8103 <varlit_core::native_layout::decode_native_record_footer+0xf3>
   e809b:	41 80 7f 10 00       	cmpb   $0x0,0x10(%r15)
   e80a0:	0f 85 d0 02 00 00    	jne    e8376 <varlit_core::native_layout::decode_native_record_footer+0x366>
   e80a6:	49 83 3f 00          	cmpq   $0x0,(%r15)
   e80aa:	0f 85 c6 02 00 00    	jne    e8376 <varlit_core::native_layout::decode_native_record_footer+0x366>
   e80b0:	4d 8b 67 20          	mov    0x20(%r15),%r12
   e80b4:	4d 39 67 08          	cmp    %r12,0x8(%r15)
   e80b8:	0f 85 b8 02 00 00    	jne    e8376 <varlit_core::native_layout::decode_native_record_footer+0x366>
   e80be:	4d 29 e5             	sub    %r12,%r13
   e80c1:	0f 82 af 02 00 00    	jb     e8376 <varlit_core::native_layout::decode_native_record_footer+0x366>
   e80c7:	49 8b 77 18          	mov    0x18(%r15),%rsi
   e80cb:	48 89 ef             	mov    %rbp,%rdi
   e80ce:	4c 89 e2             	mov    %r12,%rdx
   e80d1:	ff 15 61 49 0e 00    	call   *0xe4961(%rip)        # 1cca38 <bcmp@GLIBC_2.2.5>
   e80d7:	85 c0                	test   %eax,%eax
   e80d9:	0f 85 97 02 00 00    	jne    e8376 <varlit_core::native_layout::decode_native_record_footer+0x366>
   e80df:	49 83 c6 40          	add    $0x40,%r14
   e80e3:	4c 01 e5             	add    %r12,%rbp
   e80e6:	48 8d 05 cb 08 0e 00 	lea    0xe08cb(%rip),%rax        # 1c89b8 <anon.17b082cb49e65867434834b0b59514e7.69.llvm.178743251253153762>
   e80ed:	4e 8d 3c 30          	lea    (%rax,%r14,1),%r15
   e80f1:	48 83 c3 40          	add    $0x40,%rbx
   e80f5:	48 81 fb 00 02 00 00 	cmp    $0x200,%rbx
   e80fc:	75 92                	jne    e8090 <varlit_core::native_layout::decode_native_record_footer+0x80>
   e80fe:	e9 6e 02 00 00       	jmp    e8371 <varlit_core::native_layout::decode_native_record_footer+0x361>
   e8103:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
   e810a:	00 
   e810b:	48 89 ac 24 90 00 00 	mov    %rbp,0x90(%rsp)
   e8112:	00 
   e8113:	49 8b 17             	mov    (%r15),%rdx
   e8116:	49 8b 4f 08          	mov    0x8(%r15),%rcx
   e811a:	41 0f b6 6f 10       	movzbl 0x10(%r15),%ebp
   e811f:	4d 8b 77 18          	mov    0x18(%r15),%r14
   e8123:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   e812a:	00 
   e812b:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   e8132:	00 
   e8133:	e8 b8 c4 ff ff       	call   e45f0 <varlit_core::native_layout::read_native_value>
   e8138:	49 bd 30 00 00 00 00 	movabs $0x8000000000000030,%r13
   e813f:	00 00 80 
   e8142:	49 8d 45 4d          	lea    0x4d(%r13),%rax
   e8146:	48 39 84 24 a0 00 00 	cmp    %rax,0xa0(%rsp)
   e814d:	00 
   e814e:	0f 85 f9 02 00 00    	jne    e844d <varlit_core::native_layout::decode_native_record_footer+0x43d>
   e8154:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
   e815b:	00 
   e815c:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
   e8163:	00 
   e8164:	44 89 e0             	mov    %r12d,%eax
   e8167:	48 8d 0d c2 24 f4 ff 	lea    -0xbdb3e(%rip),%rcx        # 2a630 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x1569>
   e816e:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e8172:	48 01 c8             	add    %rcx,%rax
   e8175:	ff e0                	jmp    *%rax
   e8177:	40 80 fd 01          	cmp    $0x1,%bpl
   e817b:	0f 85 5f 04 00 00    	jne    e85e0 <varlit_core::native_layout::decode_native_record_footer+0x5d0>
   e8181:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
   e8185:	48 83 c1 d1          	add    $0xffffffffffffffd1,%rcx
   e8189:	48 89 f0             	mov    %rsi,%rax
   e818c:	48 c1 f8 3f          	sar    $0x3f,%rax
   e8190:	48 21 c8             	and    %rcx,%rax
   e8193:	48 ff c8             	dec    %rax
   e8196:	48 83 f8 03          	cmp    $0x3,%rax
   e819a:	0f 87 17 04 00 00    	ja     e85b7 <varlit_core::native_layout::decode_native_record_footer+0x5a7>
   e81a0:	48 8d 15 f1 24 f4 ff 	lea    -0xbdb0f(%rip),%rdx        # 2a698 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x15d1>
   e81a7:	48 63 0c 82          	movslq (%rdx,%rax,4),%rcx
   e81ab:	48 01 d1             	add    %rdx,%rcx
   e81ae:	48 89 f8             	mov    %rdi,%rax
   e81b1:	ff e1                	jmp    *%rcx
   e81b3:	40 0f b6 c7          	movzbl %dil,%eax
   e81b7:	e9 09 01 00 00       	jmp    e82c5 <varlit_core::native_layout::decode_native_record_footer+0x2b5>
   e81bc:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
   e81c0:	48 83 c1 d1          	add    $0xffffffffffffffd1,%rcx
   e81c4:	48 89 f0             	mov    %rsi,%rax
   e81c7:	48 c1 f8 3f          	sar    $0x3f,%rax
   e81cb:	48 21 c8             	and    %rcx,%rax
   e81ce:	48 ff c8             	dec    %rax
   e81d1:	48 83 f8 03          	cmp    $0x3,%rax
   e81d5:	0f 87 86 04 00 00    	ja     e8661 <varlit_core::native_layout::decode_native_record_footer+0x651>
   e81db:	b1 01                	mov    $0x1,%cl
   e81dd:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
   e81e4:	00 
   e81e5:	48 8d 0d 9c 24 f4 ff 	lea    -0xbdb64(%rip),%rcx        # 2a688 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x15c1>
   e81ec:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e81f0:	48 01 c8             	add    %rcx,%rax
   e81f3:	ff e0                	jmp    *%rax
   e81f5:	40 0f b6 c7          	movzbl %dil,%eax
   e81f9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   e81fe:	e9 36 01 00 00       	jmp    e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e8203:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
   e8207:	48 83 c1 d1          	add    $0xffffffffffffffd1,%rcx
   e820b:	48 89 f0             	mov    %rsi,%rax
   e820e:	48 c1 f8 3f          	sar    $0x3f,%rax
   e8212:	48 21 c8             	and    %rcx,%rax
   e8215:	48 ff c8             	dec    %rax
   e8218:	48 83 f8 03          	cmp    $0x3,%rax
   e821c:	0f 87 1a 04 00 00    	ja     e863c <varlit_core::native_layout::decode_native_record_footer+0x62c>
   e8222:	48 8d 0d 3f 24 f4 ff 	lea    -0xbdbc1(%rip),%rcx        # 2a668 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x15a1>
   e8229:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e822d:	48 01 c8             	add    %rcx,%rax
   e8230:	48 89 f9             	mov    %rdi,%rcx
   e8233:	ff e0                	jmp    *%rax
   e8235:	40 0f b6 cf          	movzbl %dil,%ecx
   e8239:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   e823e:	e9 f6 00 00 00       	jmp    e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e8243:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
   e8247:	48 83 c1 d1          	add    $0xffffffffffffffd1,%rcx
   e824b:	48 89 f0             	mov    %rsi,%rax
   e824e:	48 c1 f8 3f          	sar    $0x3f,%rax
   e8252:	48 21 c8             	and    %rcx,%rax
   e8255:	48 83 f8 04          	cmp    $0x4,%rax
   e8259:	74 74                	je     e82cf <varlit_core::native_layout::decode_native_record_footer+0x2bf>
   e825b:	48 83 f8 02          	cmp    $0x2,%rax
   e825f:	74 7b                	je     e82dc <varlit_core::native_layout::decode_native_record_footer+0x2cc>
   e8261:	48 83 f8 01          	cmp    $0x1,%rax
   e8265:	0f 85 ff 02 00 00    	jne    e856a <varlit_core::native_layout::decode_native_record_footer+0x55a>
   e826b:	40 0f b6 c7          	movzbl %dil,%eax
   e826f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   e8273:	b0 01                	mov    $0x1,%al
   e8275:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   e827a:	e9 ba 00 00 00       	jmp    e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e827f:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
   e8283:	48 83 c1 d1          	add    $0xffffffffffffffd1,%rcx
   e8287:	48 89 f0             	mov    %rsi,%rax
   e828a:	48 c1 f8 3f          	sar    $0x3f,%rax
   e828e:	48 21 c8             	and    %rcx,%rax
   e8291:	48 ff c8             	dec    %rax
   e8294:	48 83 f8 03          	cmp    $0x3,%rax
   e8298:	0f 87 79 03 00 00    	ja     e8617 <varlit_core::native_layout::decode_native_record_footer+0x607>
   e829e:	b1 01                	mov    $0x1,%cl
   e82a0:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
   e82a7:	00 
   e82a8:	48 8d 0d c9 23 f4 ff 	lea    -0xbdc37(%rip),%rcx        # 2a678 <anon.d485c229fcb7df6cd985fb1fa2c23d43.17.llvm.7858262889936339001+0x15b1>
   e82af:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   e82b3:	48 01 c8             	add    %rcx,%rax
   e82b6:	ff e0                	jmp    *%rax
   e82b8:	40 0f b6 c7          	movzbl %dil,%eax
   e82bc:	eb 76                	jmp    e8334 <varlit_core::native_layout::decode_native_record_footer+0x324>
   e82be:	0f b7 c7             	movzwl %di,%eax
   e82c1:	eb 02                	jmp    e82c5 <varlit_core::native_layout::decode_native_record_footer+0x2b5>
   e82c3:	89 f8                	mov    %edi,%eax
   e82c5:	4c 39 f0             	cmp    %r14,%rax
   e82c8:	74 6f                	je     e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e82ca:	e9 11 03 00 00       	jmp    e85e0 <varlit_core::native_layout::decode_native_record_footer+0x5d0>
   e82cf:	48 81 ff ff ff 00 00 	cmp    $0xffff,%rdi
   e82d6:	0f 87 8e 02 00 00    	ja     e856a <varlit_core::native_layout::decode_native_record_footer+0x55a>
   e82dc:	b0 01                	mov    $0x1,%al
   e82de:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   e82e3:	89 f8                	mov    %edi,%eax
   e82e5:	89 44 24 14          	mov    %eax,0x14(%rsp)
   e82e9:	eb 4e                	jmp    e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e82eb:	89 f8                	mov    %edi,%eax
   e82ed:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   e82f2:	eb 45                	jmp    e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e82f4:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
   e82f9:	eb 3e                	jmp    e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e82fb:	89 f8                	mov    %edi,%eax
   e82fd:	eb 35                	jmp    e8334 <varlit_core::native_layout::decode_native_record_footer+0x324>
   e82ff:	48 89 f8             	mov    %rdi,%rax
   e8302:	48 c1 e8 20          	shr    $0x20,%rax
   e8306:	48 89 f9             	mov    %rdi,%rcx
   e8309:	0f 85 d1 02 00 00    	jne    e85e0 <varlit_core::native_layout::decode_native_record_footer+0x5d0>
   e830f:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   e8314:	eb 23                	jmp    e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e8316:	0f b7 c7             	movzwl %di,%eax
   e8319:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   e831e:	eb 19                	jmp    e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e8320:	0f b7 cf             	movzwl %di,%ecx
   e8323:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   e8328:	eb 0f                	jmp    e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e832a:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   e832f:	eb 08                	jmp    e8339 <varlit_core::native_layout::decode_native_record_footer+0x329>
   e8331:	0f b7 c7             	movzwl %di,%eax
   e8334:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   e8339:	48 85 f6             	test   %rsi,%rsi
   e833c:	7e 0b                	jle    e8349 <varlit_core::native_layout::decode_native_record_footer+0x339>
   e833e:	ba 01 00 00 00       	mov    $0x1,%edx
   e8343:	ff 15 1f 44 0e 00    	call   *0xe441f(%rip)        # 1cc768 <_DYNAMIC+0x2f0>
   e8349:	48 8b ac 24 90 00 00 	mov    0x90(%rsp),%rbp
   e8350:	00 
   e8351:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   e8358:	00 
   e8359:	48 8d 05 58 06 0e 00 	lea    0xe0658(%rip),%rax        # 1c89b8 <anon.17b082cb49e65867434834b0b59514e7.69.llvm.178743251253153762>
   e8360:	4c 8d 3c 18          	lea    (%rax,%rbx,1),%r15
   e8364:	48 81 fb c0 01 00 00 	cmp    $0x1c0,%rbx
   e836b:	0f 85 15 fd ff ff    	jne    e8086 <varlit_core::native_layout::decode_native_record_footer+0x76>
   e8371:	4d 85 ed             	test   %r13,%r13
   e8374:	74 31                	je     e83a7 <varlit_core::native_layout::decode_native_record_footer+0x397>
   e8376:	48 8b 04 24          	mov    (%rsp),%rax
   e837a:	48 b9 30 00 00 00 00 	movabs $0x8000000000000030,%rcx
   e8381:	00 00 80 
   e8384:	48 89 08             	mov    %rcx,(%rax)
   e8387:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   e838c:	eb 03                	jmp    e8391 <varlit_core::native_layout::decode_native_record_footer+0x381>
   e838e:	48 89 30             	mov    %rsi,(%rax)
   e8391:	48 89 48 08          	mov    %rcx,0x8(%rax)
   e8395:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
   e839c:	5b                   	pop    %rbx
   e839d:	41 5c                	pop    %r12
   e839f:	41 5d                	pop    %r13
   e83a1:	41 5e                	pop    %r14
   e83a3:	41 5f                	pop    %r15
   e83a5:	5d                   	pop    %rbp
   e83a6:	c3                   	ret
   e83a7:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   e83ac:	4c 89 74 24 38       	mov    %r14,0x38(%rsp)
   e83b1:	49 bf 30 00 00 00 00 	movabs $0x8000000000000030,%r15
   e83b8:	00 00 80 
   e83bb:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   e83c0:	f6 44 24 28 01       	testb  $0x1,0x28(%rsp)
   e83c5:	48 8b 04 24          	mov    (%rsp),%rax
   e83c9:	74 44                	je     e840f <varlit_core::native_layout::decode_native_record_footer+0x3ff>
   e83cb:	48 89 c3             	mov    %rax,%rbx
   e83ce:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   e83d3:	e8 78 13 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e83d8:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
   e83dd:	66 41 83 f8 04       	cmp    $0x4,%r8w
   e83e2:	0f 83 73 01 00 00    	jae    e855b <varlit_core::native_layout::decode_native_record_footer+0x54b>
   e83e8:	f6 84 24 88 00 00 00 	testb  $0x1,0x88(%rsp)
   e83ef:	01 
   e83f0:	74 45                	je     e8437 <varlit_core::native_layout::decode_native_record_footer+0x427>
   e83f2:	41 f6 c0 01          	test   $0x1,%r8b
   e83f6:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   e83fb:	0f 85 d5 00 00 00    	jne    e84d6 <varlit_core::native_layout::decode_native_record_footer+0x4c6>
   e8401:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
   e8407:	0f 85 4e 01 00 00    	jne    e855b <varlit_core::native_layout::decode_native_record_footer+0x54b>
   e840d:	eb 37                	jmp    e8446 <varlit_core::native_layout::decode_native_record_footer+0x436>
   e840f:	0f 10 44 24 3a       	movups 0x3a(%rsp),%xmm0
   e8414:	0f 10 4c 24 4a       	movups 0x4a(%rsp),%xmm1
   e8419:	0f 10 54 24 58       	movups 0x58(%rsp),%xmm2
   e841e:	0f 11 50 28          	movups %xmm2,0x28(%rax)
   e8422:	0f 11 48 1a          	movups %xmm1,0x1a(%rax)
   e8426:	0f 11 40 0a          	movups %xmm0,0xa(%rax)
   e842a:	4c 89 38             	mov    %r15,(%rax)
   e842d:	66 44 89 70 08       	mov    %r14w,0x8(%rax)
   e8432:	e9 5e ff ff ff       	jmp    e8395 <varlit_core::native_layout::decode_native_record_footer+0x385>
   e8437:	41 f6 c0 01          	test   $0x1,%r8b
   e843b:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   e8440:	0f 85 15 01 00 00    	jne    e855b <varlit_core::native_layout::decode_native_record_footer+0x54b>
   e8446:	31 c0                	xor    %eax,%eax
   e8448:	e9 a5 00 00 00       	jmp    e84f2 <varlit_core::native_layout::decode_native_record_footer+0x4e2>
   e844d:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   e8454:	00 
   e8455:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   e845a:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
   e8461:	00 
   e8462:	0f 10 8c 24 b0 00 00 	movups 0xb0(%rsp),%xmm1
   e8469:	00 
   e846a:	0f 10 94 24 c0 00 00 	movups 0xc0(%rsp),%xmm2
   e8471:	00 
   e8472:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
   e8477:	0f 29 4c 24 40       	movaps %xmm1,0x40(%rsp)
   e847c:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
   e8481:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   e8486:	e8 c5 12 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e848b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   e8490:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   e8497:	00 
   e8498:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   e849f:	00 
   e84a0:	48 8b 0c 24          	mov    (%rsp),%rcx
   e84a4:	48 89 41 30          	mov    %rax,0x30(%rcx)
   e84a8:	0f 10 84 24 c0 00 00 	movups 0xc0(%rsp),%xmm0
   e84af:	00 
   e84b0:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
   e84b4:	48 8d 84 24 a8 00 00 	lea    0xa8(%rsp),%rax
   e84bb:	00 
   e84bc:	0f 10 00             	movups (%rax),%xmm0
   e84bf:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
   e84c3:	48 8b 40 10          	mov    0x10(%rax),%rax
   e84c7:	48 89 41 18          	mov    %rax,0x18(%rcx)
   e84cb:	48 89 c8             	mov    %rcx,%rax
   e84ce:	4c 89 29             	mov    %r13,(%rcx)
   e84d1:	e9 bf fe ff ff       	jmp    e8395 <varlit_core::native_layout::decode_native_record_footer+0x385>
   e84d6:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   e84db:	48 85 f6             	test   %rsi,%rsi
   e84de:	0f 95 c1             	setne  %cl
   e84e1:	48 3b 74 24 70       	cmp    0x70(%rsp),%rsi
   e84e6:	0f 92 c2             	setb   %dl
   e84e9:	b8 01 00 00 00       	mov    $0x1,%eax
   e84ee:	84 d1                	test   %dl,%cl
   e84f0:	74 69                	je     e855b <varlit_core::native_layout::decode_native_record_footer+0x54b>
   e84f2:	f6 84 24 80 00 00 00 	testb  $0x1,0x80(%rsp)
   e84f9:	01 
   e84fa:	74 0e                	je     e850a <varlit_core::native_layout::decode_native_record_footer+0x4fa>
   e84fc:	66 41 83 f8 02       	cmp    $0x2,%r8w
   e8501:	73 12                	jae    e8515 <varlit_core::native_layout::decode_native_record_footer+0x505>
   e8503:	48 85 ff             	test   %rdi,%rdi
   e8506:	75 53                	jne    e855b <varlit_core::native_layout::decode_native_record_footer+0x54b>
   e8508:	eb 07                	jmp    e8511 <varlit_core::native_layout::decode_native_record_footer+0x501>
   e850a:	66 41 83 f8 02       	cmp    $0x2,%r8w
   e850f:	73 4a                	jae    e855b <varlit_core::native_layout::decode_native_record_footer+0x54b>
   e8511:	31 c9                	xor    %ecx,%ecx
   e8513:	eb 1f                	jmp    e8534 <varlit_core::native_layout::decode_native_record_footer+0x524>
   e8515:	48 85 ff             	test   %rdi,%rdi
   e8518:	0f 95 c2             	setne  %dl
   e851b:	48 3b 7c 24 70       	cmp    0x70(%rsp),%rdi
   e8520:	49 89 f0             	mov    %rsi,%r8
   e8523:	40 0f 92 c6          	setb   %sil
   e8527:	b9 01 00 00 00       	mov    $0x1,%ecx
   e852c:	40 84 f2             	test   %sil,%dl
   e852f:	4c 89 c6             	mov    %r8,%rsi
   e8532:	74 27                	je     e855b <varlit_core::native_layout::decode_native_record_footer+0x54b>
   e8534:	48 89 43 08          	mov    %rax,0x8(%rbx)
   e8538:	48 89 d8             	mov    %rbx,%rax
   e853b:	48 89 73 10          	mov    %rsi,0x10(%rbx)
   e853f:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
   e8543:	48 89 7b 20          	mov    %rdi,0x20(%rbx)
   e8547:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   e854c:	89 4b 28             	mov    %ecx,0x28(%rbx)
   e854f:	49 83 c7 4d          	add    $0x4d,%r15
   e8553:	4c 89 3b             	mov    %r15,(%rbx)
   e8556:	e9 3a fe ff ff       	jmp    e8395 <varlit_core::native_layout::decode_native_record_footer+0x385>
   e855b:	48 89 d8             	mov    %rbx,%rax
   e855e:	4c 89 3b             	mov    %r15,(%rbx)
   e8561:	4c 89 73 08          	mov    %r14,0x8(%rbx)
   e8565:	e9 2b fe ff ff       	jmp    e8395 <varlit_core::native_layout::decode_native_record_footer+0x385>
   e856a:	49 89 fe             	mov    %rdi,%r14
   e856d:	49 89 f4             	mov    %rsi,%r12
   e8570:	49 8b 47 28          	mov    0x28(%r15),%rax
   e8574:	49 8b 5f 30          	mov    0x30(%r15),%rbx
   e8578:	49 8d 4d 3e          	lea    0x3e(%r13),%rcx
   e857c:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   e8581:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   e8586:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
   e858b:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   e8590:	e8 bb 11 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e8595:	48 8b 04 24          	mov    (%rsp),%rax
   e8599:	4c 89 28             	mov    %r13,(%rax)
   e859c:	49 89 c7             	mov    %rax,%r15
   e859f:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   e85a4:	48 89 48 08          	mov    %rcx,0x8(%rax)
   e85a8:	b8 10 00 00 00       	mov    $0x10,%eax
   e85ad:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   e85b2:	e9 dc 00 00 00       	jmp    e8693 <varlit_core::native_layout::decode_native_record_footer+0x683>
   e85b7:	49 89 fe             	mov    %rdi,%r14
   e85ba:	49 89 f4             	mov    %rsi,%r12
   e85bd:	41 0f 10 47 28       	movups 0x28(%r15),%xmm0
   e85c2:	49 8d 45 3e          	lea    0x3e(%r13),%rax
   e85c6:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   e85cb:	0f 11 44 24 38       	movups %xmm0,0x38(%rsp)
   e85d0:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   e85d5:	e8 76 11 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e85da:	4c 89 e6             	mov    %r12,%rsi
   e85dd:	4c 89 f7             	mov    %r14,%rdi
   e85e0:	48 8b 04 24          	mov    (%rsp),%rax
   e85e4:	49 89 c7             	mov    %rax,%r15
   e85e7:	4c 89 28             	mov    %r13,(%rax)
   e85ea:	b8 08 00 00 00       	mov    $0x8,%eax
   e85ef:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   e85f4:	49 89 14 07          	mov    %rdx,(%r15,%rax,1)
   e85f8:	4c 89 f8             	mov    %r15,%rax
   e85fb:	48 85 f6             	test   %rsi,%rsi
   e85fe:	0f 8e 91 fd ff ff    	jle    e8395 <varlit_core::native_layout::decode_native_record_footer+0x385>
   e8604:	ba 01 00 00 00       	mov    $0x1,%edx
   e8609:	ff 15 59 41 0e 00    	call   *0xe4159(%rip)        # 1cc768 <_DYNAMIC+0x2f0>
   e860f:	4c 89 f8             	mov    %r15,%rax
   e8612:	e9 7e fd ff ff       	jmp    e8395 <varlit_core::native_layout::decode_native_record_footer+0x385>
   e8617:	49 89 fe             	mov    %rdi,%r14
   e861a:	49 89 f4             	mov    %rsi,%r12
   e861d:	41 0f 10 47 28       	movups 0x28(%r15),%xmm0
   e8622:	49 8d 45 3e          	lea    0x3e(%r13),%rax
   e8626:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   e862b:	0f 11 44 24 38       	movups %xmm0,0x38(%rsp)
   e8630:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   e8635:	e8 16 11 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e863a:	eb 48                	jmp    e8684 <varlit_core::native_layout::decode_native_record_footer+0x674>
   e863c:	49 89 fe             	mov    %rdi,%r14
   e863f:	49 89 f4             	mov    %rsi,%r12
   e8642:	41 0f 10 47 28       	movups 0x28(%r15),%xmm0
   e8647:	49 8d 45 3e          	lea    0x3e(%r13),%rax
   e864b:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   e8650:	0f 11 44 24 38       	movups %xmm0,0x38(%rsp)
   e8655:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   e865a:	e8 f1 10 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e865f:	eb 23                	jmp    e8684 <varlit_core::native_layout::decode_native_record_footer+0x674>
   e8661:	49 89 fe             	mov    %rdi,%r14
   e8664:	49 89 f4             	mov    %rsi,%r12
   e8667:	41 0f 10 47 28       	movups 0x28(%r15),%xmm0
   e866c:	49 8d 45 3e          	lea    0x3e(%r13),%rax
   e8670:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   e8675:	0f 11 44 24 38       	movups %xmm0,0x38(%rsp)
   e867a:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   e867f:	e8 cc 10 00 00       	call   e9750 <core::ptr::drop_in_place<varlit_core::error::Error>>
   e8684:	48 8b 04 24          	mov    (%rsp),%rax
   e8688:	49 89 c7             	mov    %rax,%r15
   e868b:	4c 89 28             	mov    %r13,(%rax)
   e868e:	b8 08 00 00 00       	mov    $0x8,%eax
   e8693:	4c 89 e6             	mov    %r12,%rsi
   e8696:	4c 89 f7             	mov    %r14,%rdi
   e8699:	e9 51 ff ff ff       	jmp    e85ef <varlit_core::native_layout::decode_native_record_footer+0x5df>
   e869e:	48 89 c3             	mov    %rax,%rbx
   e86a1:	4d 85 e4             	test   %r12,%r12
   e86a4:	7e 11                	jle    e86b7 <varlit_core::native_layout::decode_native_record_footer+0x6a7>
   e86a6:	ba 01 00 00 00       	mov    $0x1,%edx
   e86ab:	4c 89 f7             	mov    %r14,%rdi
   e86ae:	4c 89 e6             	mov    %r12,%rsi
   e86b1:	ff 15 b1 40 0e 00    	call   *0xe40b1(%rip)        # 1cc768 <_DYNAMIC+0x2f0>
   e86b7:	48 89 df             	mov    %rbx,%rdi
   e86ba:	e8 c1 c8 0d 00       	call   1c4f80 <_Unwind_Resume@plt>
   e86bf:	cc                   	int3

