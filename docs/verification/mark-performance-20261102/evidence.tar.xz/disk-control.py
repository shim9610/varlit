import os,json,subprocess,statistics,random,hashlib
from pathlib import Path
r=Path('/workspace/scratch/mark-perf-fix/disk-control');r.mkdir(exist_ok=True);scratch=r/'disk-data';scratch.mkdir(exist_ok=True)
old=Path('/workspace/scratch/compound-hardening/final/before-bin/record_mutation_load');current=Path('/workspace/scratch/compound-hardening/final/after-bin/record_mutation_load');fixed=Path('/workspace/scratch/mark-perf-fix/qualified/after-bin/record_mutation_load');measure=Path('/workspace/scratch/compound-hardening/final/native/measure-child')
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});rng=random.Random(24601);rows=[];env={**os.environ,'TMPDIR':str(scratch)}
bins={'reference-a':old,'reference-b':old,'current':current,'fixed':fixed}
meta={k:Path('/sys/fs/cgroup',k).read_text() for k in ['cpu.max','memory.max','memory.events']};meta['command']=['writer','large','reverse','65536','4096'];meta['groups']=20;meta['tmpdir']=str(scratch);meta['filesystem']=subprocess.check_output(['df','-T',str(scratch)],text=True);meta['binary_hashes']={s:hashlib.sha256(p.read_bytes()).hexdigest() for s,p in bins.items()};(r/'host.json').write_text(json.dumps(meta,indent=2)+'\n')
for group in range(meta['groups']):
 labels=list(bins);rng.shuffle(labels)
 for label in labels:
  run=subprocess.run([str(measure),str(r/'usage.json'),str(bins[label]),*meta['command']],capture_output=True,text=True,env=env,check=True,timeout=600);row={'group':group,'label':label,'result':json.loads(run.stdout),'usage':json.loads((r/'usage.json').read_text())};rows.append(row);(r/'samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(group,label,row['result']['seconds'],flush=True)
work=[{k:v for k,v in x['result'].items() if k!='seconds'} for x in rows];assert all(x==work[0] for x in work)
metrics={}
for label in bins:
 xs=[x for x in rows if x['label']==label];metrics[label]={'operation':statistics.median(x['result']['seconds'] for x in xs),'cpu':statistics.median(x['usage']['cpu'] for x in xs),'rss':max(x['usage']['rss'] for x in xs)}
comparisons={}
for before,after in [('reference-a','reference-b'),('reference-a','current'),('reference-b','current'),('reference-a','fixed'),('reference-b','fixed'),('current','fixed')]:
 comparisons[before+' -> '+after]={k:100*(metrics[after][k]/metrics[before][k]-1) for k in ['operation','cpu','rss']}
result={'metrics':metrics,'comparisons':comparisons,'work':work[0]};(r/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
