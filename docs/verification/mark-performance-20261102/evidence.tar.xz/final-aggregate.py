import json,statistics,hashlib,random
from pathlib import Path
r=Path('/workspace/scratch/mark-perf-fix')
def read(p): return json.loads(p.read_text())
for name,h in read(r/'final-source-hashes.json').items(): assert hashlib.sha256((Path('/workspace/varlit')/name).read_bytes()).hexdigest()==h
control=read(r/'final-control/samples.json');assert len(control)==800
assert all(sum(x['label']==label for x in control)==200 for label in ['reference-a','reference-b','intermediate','fixed'])
def metrics(xs,labels=('before','after')):
 out={}
 for field,get,agg in [('operation_seconds',lambda x:x['result']['seconds'],statistics.median),('cpu_seconds',lambda x:x['usage']['cpu'],statistics.median),('rss_kib',lambda x:x['usage']['rss'],max),('write_bytes',lambda x:x['usage']['write_blocks']*512,statistics.median)]:
  a,b=[agg(get(x) for x in xs if x['side']==s) for s in labels];d=100*(b/a-1) if a else None
  out[field]={'before':a,'after':b,'change_percent':d,'status':'passed' if (d is None and b==0) or (d is not None and d<=5) else 'failed'}
 return out
def native(q,extra=[]):
 xs=read(q/'native/native-samples.json')
 if (q/'confirmation/native-samples.json').exists(): xs+=read(q/'confirmation/native-samples.json')
 xs+=extra;out=[]
 for case in sorted({x['case'] for x in xs}):
  ys=[x for x in xs if x['case']==case];w=[{k:v for k,v in x['result'].items() if k!='seconds'} for x in ys];assert all(x==w[0] for x in w)
  assert sum(x['side']=='before' for x in ys)==sum(x['side']=='after' for x in ys)
  out.append({'case':case,'pairs':len(ys)//2,'work':w[0],'metrics':metrics(ys)})
 return {'native':out,'native_observations':len(xs),'swmr':{n:read(q/f'swmr/swmr-{n}-comparison.json') for n in ['1','4']},'resources':{s:read(q/f'resources-{s}.json') for s in ['before','after']},'host':read(q/'host.json')}
extras=[dict(x,case=4,side={'intermediate':'before','fixed':'after'}[x['label']]) for x in control if x['label'] in ['intermediate','fixed']]
out={'baseline':'dad27af77d6356af8a2b6a78896290d0a27f8a8d','original_reference':'598ec8b31dcf09d718955d901fa7bed4d2360eb2','unit1':native(r/'qualified'),'unit2_ordinary_series':native(r/'decoder-qualified'),'unit2_pooled':native(r/'decoder-qualified',extras),'control':read(r/'final-control/summary.json'),'control_host':read(r/'final-control/host.json'),'control_comparisons':{}}
for a,b in [('reference-a','reference-b'),('reference-a','fixed'),('reference-b','fixed'),('intermediate','fixed')]:
 ys=[dict(x,side=x['label']) for x in control if x['label'] in [a,b]];m=metrics(ys,(a,b));out['control_comparisons'][a+' -> '+b]=m
 # Group bootstrap preserves contemporaneous pairing. Supplemental uncertainty,
 # not a replacement for the existing median/maximum five-percent gate.
 aa=[next(x['result']['seconds'] for x in control if x['group']==i and x['label']==a) for i in range(200)]
 bb=[next(x['result']['seconds'] for x in control if x['group']==i and x['label']==b) for i in range(200)]
 rng=random.Random(47103);ds=[]
 for _ in range(10000):
  idx=[rng.randrange(200) for _ in range(200)];ds.append(100*(statistics.median(bb[i] for i in idx)/statistics.median(aa[i] for i in idx)-1))
 ds.sort();m['operation_seconds']['paired_group_bootstrap_95_percent_interval']=[ds[249],ds[9749]]
out['unit1_commit']='b6833f2c7225460fb5837f8ef1488392c97c9c01'
out['final_source_hashes']=read(r/'final-source-hashes.json')
out['binary_hashes']={q:read(r/q/'native/binary-hashes.json') for q in ['qualified','decoder-qualified']}
assert out['binary_hashes']['qualified']['after']==out['binary_hashes']['decoder-qualified']['before']
assert out['control_host']['binary_hashes']['fixed']==out['binary_hashes']['decoder-qualified']['after']['record_mutation_load']
out['large_resources']={s:read(r/f'large-resources-{s}.json') for s in ['before','after']}
out['large_resources_host']=read(r/'large-resources-host.json')
(r/'results.json').write_text(json.dumps(out,indent=2)+'\n')
for unit in ['unit1','unit2_ordinary_series','unit2_pooled']:
 print(unit)
 for x in out[unit]['native']:print(x['case'],x['pairs'],{k:round(v['change_percent'],3) if v['change_percent'] is not None else None for k,v in x['metrics'].items()})
 for n,x in out[unit]['swmr'].items():print('SWMR',n,x['status'],{k:round(v['change_percent'],3) for k,v in x['metrics'].items()})
print(json.dumps(out['control_comparisons'],indent=2))
