import os,json,subprocess
from pathlib import Path
r=Path('/workspace/scratch/mark-perf-fix');d=r/'large-resource-disk';d.mkdir(exist_ok=True)
meta={k:Path('/sys/fs/cgroup',k).read_text() for k in ['cpu.max','memory.max','memory.events']};meta['filesystem']=subprocess.check_output(['df','-T',str(d)],text=True)
for side,binary in [('before','/workspace/scratch/compound-hardening/final/before-bin/record_mutation_load'),('after',str(r/'decoder-qualified/after-bin/record_mutation_load'))]:
 meta[side+'_memory_stat_before']=Path('/sys/fs/cgroup/memory.stat').read_text()
 subprocess.run(['python3',str(r/'resource-with-cgroup.py'),'--output',str(r/('large-resources-'+side+'.json')),binary,'writer','large','reverse','65536','4096'],env={**os.environ,'TMPDIR':str(d)},check=True)
meta['memory.events_after']=Path('/sys/fs/cgroup/memory.events').read_text();(r/'large-resources-host.json').write_text(json.dumps(meta,indent=2)+'\n')
