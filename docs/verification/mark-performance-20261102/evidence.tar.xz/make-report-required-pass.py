from pathlib import Path
import json
r=Path('/workspace/scratch/mark-perf-fix');d=Path('/workspace/varlit/docs/verification/mark-performance-20261102');x=json.loads((r/'results.json').read_text())
fail=[]
for unit in ['unit1','unit2_pooled']:
 for c in x[unit]['native']:
  for k,v in c['metrics'].items():
   if v['status']!='passed':fail.append((unit,c['case'],k,v))
 for n,v in x[unit]['swmr'].items():
  if v['status']!='passed':fail.append((unit,'swmr',n,v['metrics']))
for name,m in x['control_comparisons'].items():
 for k,v in m.items():
  if name=='reference-a -> reference-b': bad=abs(v['change_percent'])>5 if v['change_percent'] is not None else False
  else:bad=v['status']!='passed'
  if bad:fail.append((name,k,v))
assert not fail,fail
p=lambda v:f"{v:+.2f}%"
lines=['## Final measured results','', '**The final pooled comparisons pass the unchanged 5% gates.** There are', '**984 timing observations across the two units and the final control**, plus', '**6 separate resource probes**. The additional 80-observation disk diagnostic', 'and 36-observation tmpfs diagnostic remain separately identified.','', '| Workload | Unit 1 pairs | Time | CPU | Unit 2 pairs | Time | CPU |', '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
labels={0:'Fixed writer, 2M records',4:'Large reverse writer',7:'Complex maintenance, 65,536 × 512 B',9:'Compression, 64 MiB',10:'Decoding, 64 MiB'}
for a,b in zip(x['unit1']['native'],x['unit2_pooled']['native']):
 assert a['case']==b['case'];ma,mb=a['metrics'],b['metrics']
 lines.append(f"| {labels[a['case']]} | {a['pairs']} | {p(ma['operation_seconds']['change_percent'])} | {p(ma['cpu_seconds']['change_percent'])} | {b['pairs']} | {p(mb['operation_seconds']['change_percent'])} | {p(mb['cpu_seconds']['change_percent'])} |")
for n in ['1','4']:
 a,b=[x[u]['swmr'][n]['metrics'] for u in ['unit1','unit2_pooled']]
 lines.append(f"| SWMR {n} GiB, eight followers + pin | 3 | {p(a['wall_seconds']['change_percent'])} | {p(a['cpu_seconds']['change_percent'])} | 3 | {p(b['wall_seconds']['change_percent'])} | {p(b['cpu_seconds']['change_percent'])} |")
lines+=['','Unit 1 compares `dad27af` to `b6833f2`; unit 2 compares `b6833f2` to the','final decoder change. These are separate predecessor comparisons, not additive','or cumulative speedup claims. Unit 1 decoding initially failed at +9.54% time /','+6.89% CPU; its prescribed 15 confirmation pairs bring the full 20-pair result','to the values above. Unit 2 reverse-writer time is **+12.63% across its ordinary','20 pairs**. All those samples remain in the final **220-pair** result above.','', 'The final direct comparison to the original `598ec8b` reference is:', '', '| Comparison (200 samples per label) | Operation medians (ms) | Time | CPU | Peak RSS |','| --- | ---: | ---: | ---: | ---: |']
for name,m in x['control_comparisons'].items():
 t=m['operation_seconds'];lines.append(f"| {name} | {t['before']*1000:.3f} → {t['after']*1000:.3f} | {p(t['change_percent'])} | {p(m['cpu_seconds']['change_percent'])} | {p(m['rss_kib']['change_percent'])} |")
lines+=['','Supplemental paired-group bootstrap 95% intervals for operation-time changes', '(10,000 resamples; the configured gate still uses the recorded medians):']
for name,m in x['control_comparisons'].items():
 lo,hi=m['operation_seconds']['paired_group_bootstrap_95_percent_interval'];lines.append(f'* {name}: {p(lo)} to {p(hi)}.')
lines+=['','Both complex resource comparisons retain **4,194,304 bytes** of sampled private','temporary allocation and **91,955,200 bytes** of open regular-file allocation.','The separate disk-backed large-file resource comparison records:','', '| Sampled peak | Original reference | Final |','| --- | ---: | ---: |']
for k in ['rss_bytes','temporary_deleted_allocated_bytes','open_regular_allocated_bytes','cgroup_current_bytes','cgroup_file_bytes','cgroup_anon_bytes','cgroup_shmem_bytes']:
 a,b=[x['large_resources'][s]['peaks'][k] for s in ['before','after']];lines.append(f'| {k} | {a:,} | {b:,} |')
lines+=['','Cgroup readings include pre-existing workspace memory/file cache; the raw report','also records each pre-run memory breakdown. They are not process-only allocation','counts. All resource readings are sampled separately from the timing gate. CPU','and memory limits and memory-event counters remain unchanged; no new OOM/kill','events occurred.','']
# Exact observation accounting, without counting pooled control samples twice.
assert sum(x[u]['native_observations']+12 for u in ['unit1','unit2_ordinary_series'])+800==984
for unit in ['unit1','unit2_pooled']:
 h=x[unit]['host'];assert h['memory.events']==h['memory.events_after']
for host in ['control_host','large_resources_host']:
 h=x[host];assert h['memory.events']==h['memory.events_after']
for unit in ['unit1','unit2_pooled']:
 for v in x[unit]['resources'].values():
  assert v['exit']==0 and v['peaks']['temporary_deleted_allocated_bytes']==4194304 and v['peaks']['open_regular_allocated_bytes']==91955200
wa,wb=[{k:v for k,v in json.loads(x['large_resources'][s]['stdout']).items() if k!='seconds'} for s in ['before','after']];assert wa==wb
text=(r/'report-draft.md').read_text().replace('@@RESULTS@@','\n'.join(lines))
d.mkdir(parents=True,exist_ok=True);(d/'README.md').write_text(text);(d/'results.json').write_text(json.dumps(x,indent=2)+'\n');print(d)
