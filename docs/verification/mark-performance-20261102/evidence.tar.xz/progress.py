import json,time
from pathlib import Path
r=Path('/workspace/scratch/mark-perf-fix/final-control');p=r/'samples.json'
try:
 rows=json.loads(p.read_text());n=len(rows)
 work=[{k:v for k,v in x['result'].items() if k!='seconds'} for x in rows]
 assert all(x==work[0] for x in work)
except (FileNotFoundError,json.JSONDecodeError): n=0
elapsed=time.time()-(r/'host.json').stat().st_mtime
print({'observations':n,'target':800,'complete_groups':n//4,'elapsed_minutes':round(elapsed/60,1),'estimated_minutes_remaining':round(elapsed/60*(800/n-1),1) if n else None})
