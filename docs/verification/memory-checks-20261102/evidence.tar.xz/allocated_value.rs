#[kani::proof]
fn allocated_value_is_initialized() {
    let value: u32 = kani::any();
    let owner = Box::new(value);
    assert_eq!(*owner, value);
}
