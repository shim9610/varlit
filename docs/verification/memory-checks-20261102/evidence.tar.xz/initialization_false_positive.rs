use std::mem::MaybeUninit;
#[repr(C)]
struct Pair { initialized: bool, pending: bool }
#[kani::proof]
fn field_initialization() {
    let mut storage = MaybeUninit::<Pair>::uninit();
    let pointer = storage.as_mut_ptr();
    let field = unsafe { &raw mut (*pointer).initialized };
    unsafe { field.write(true); assert!(*field); }
}
#[kani::proof]
fn box_initialization() {
    let value: bool = kani::any();
    let owner = Box::new(Pair { initialized: value, pending: false });
    assert_eq!(owner.initialized, value);
    std::mem::forget(owner);
}
