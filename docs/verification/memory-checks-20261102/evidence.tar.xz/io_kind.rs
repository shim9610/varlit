#[kani::proof]
fn io_kind_roundtrip() {
    let error = std::io::Error::from(std::io::ErrorKind::OutOfMemory);
    assert_eq!(error.kind(), std::io::ErrorKind::OutOfMemory);
}
