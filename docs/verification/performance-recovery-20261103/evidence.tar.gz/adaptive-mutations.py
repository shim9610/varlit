from pathlib import Path
import subprocess,os,json,hashlib
repo=Path('/workspace/varlit');r=Path('/workspace/scratch/perf-recovery');out=r/'adaptive-mutations';out.mkdir(exist_ok=False)
mutations=[
 ('copied_payload_byte_missing','crates/varlit-core/src/file.rs','output.write_all(&buffer[..count])?;','output.write_all(&buffer[..count - 1])?;','verified_copy_checks_crc_and_retries_repaired_sources_at_buffer_edges','fn copy_snapshot_payload_crc<'),
 ('source_crc_gate_ignored','crates/varlit-core/src/file.rs','if actual != source.checksum {','if actual != source.checksum && false {','verified_copy_checks_crc_and_retries_repaired_sources_at_buffer_edges',None),
 ('writer_error_ignored','crates/varlit-core/src/snapshot.rs','output.write_all(&buffer[..chunk_len])?;','let _ = output.write_all(&buffer[..chunk_len]);','range_copy_preserves_prefixes_and_retries_short_or_failed_writes',None)]
results=[]
for name,path,needle,replacement,test,scope in mutations:
 p=repo/path;original=p.read_text();start=original.index(scope) if scope else 0;assert original[start:].count(needle)==1,(name,original[start:].count(needle));changed=original[:start]+original[start:].replace(needle,replacement,1)
 try:
  p.write_text(changed)
  x=subprocess.run(['cargo','test','--locked','-p','varlit-core','--all-features','--lib',test],cwd=repo,env={**os.environ,'CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_DEV_DEBUG':'0'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=300)
  (out/(name+'.log')).write_text(x.stdout)
  detected=x.returncode!=0 and 'panicked at' in x.stdout and 'FAILED' in x.stdout and 'test result: FAILED. 0 passed; 1 failed;' in x.stdout
  results.append({'name':name,'test':test,'exit_code':x.returncode,'assertion_detected':detected});(out/'results.json').write_text(json.dumps(results,indent=2));assert detected,name+' was not caught at its assertion; compile errors/timeouts do not qualify'
  print('DETECTED',name,flush=True)
 finally:
  p.write_text(original)
  assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(original.encode()).digest()
print('DONE',flush=True)
