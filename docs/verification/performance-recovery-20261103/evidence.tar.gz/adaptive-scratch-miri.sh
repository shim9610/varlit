set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
export MIRIFLAGS=-Zmiri-disable-isolation
for contract in range_copy_preserves_prefixes_and_retries_short_or_failed_writes crc_streaming_preserves_bytes_across_short_reads_and_repair verified_copy_checks_crc_and_retries_repaired_sources_at_buffer_edges; do
 cargo +nightly-2026-10-12 miri test --locked -p varlit-core --all-features --lib "$contract" > "/workspace/scratch/perf-recovery/adaptive-scratch-miri-$contract.log" 2>&1
done
