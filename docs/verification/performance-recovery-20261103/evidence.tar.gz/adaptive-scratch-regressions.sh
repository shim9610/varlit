set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
export CARGO_INCREMENTAL=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0
cargo test --locked --workspace --all-features > /workspace/scratch/perf-recovery/adaptive-scratch-workspace-all.log 2>&1
cargo test --locked --workspace > /workspace/scratch/perf-recovery/adaptive-scratch-workspace-default.log 2>&1
cargo clippy --locked --workspace --all-features --all-targets -- -D warnings > /workspace/scratch/perf-recovery/adaptive-scratch-clippy.log 2>&1
cargo fmt --all -- --check
git diff --check
