from pathlib import Path
import subprocess,json,os
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:
  code=subprocess.run(args,cwd=repo,stdout=f,stderr=subprocess.STDOUT).returncode
 print('END',name,code,flush=True)
 if code:raise SystemExit(code)
run('nested-allocation',['python3',str(r/'nested-allocation.py')])
run('allocation-owned',['python3',str(r/'owned-pairs.py'),'--before',str(r/'compact-bin'),'--after',str(r/'allocation-bin'),'--output',str(r/'allocation-owned')])
base=['python3',str(r/'bench.py'),'--before',str(r/'compact-bin'),'--after',str(r/'allocation-bin'),'--repo',str(repo)]
run('allocation-native',base+['--phase','native','--pairs','5','--native-cases','0','4','6','7','--output',str(r/'allocation-native')])
flagged=[str(x['case']) for x in json.loads((r/'allocation-native/native-summary.json').read_text()) if any(v['change_percent']>5 for v in x['metrics'].values())]
if flagged:run('allocation-confirmation',base+['--phase','native','--pairs','15','--native-cases',*flagged,'--output',str(r/'allocation-confirmation')])
run('allocation-pool',['python3',str(r/'pool.py'),'--primary',str(r/'allocation-native'),'--confirmation',str(r/'allocation-confirmation'),'--output',str(r/'allocation-pooled.json')])
run('allocation-swmr',base+['--phase','concurrent','--pairs','3','--output',str(r/'allocation-swmr')])
for side in ['compact','allocation']:
 for name,cmd in [('complex',['oom_maintenance_load','complex','65536','512']),('bytes',['ownership_load','bytes','1073741824','2'])]:
  with (r/f'allocation-resource-{side}-{name}.log').open('w') as f:
   subprocess.run(['python3',str(repo/'docs/performance/audit-followup-20261102/resource_probe.py'),'--output',str(r/f'allocation-resource-{side}-{name}.json'),str(r/(side+'-bin')/cmd[0]),*cmd[1:]],stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':str(r/'disk-data')},check=True)
(r/'host-allocation-after.json').write_text(json.dumps({k:Path('/sys/fs/cgroup',k).read_text() for k in ['cpu.max','memory.max','memory.events']},indent=2))
print('DONE',flush=True)
