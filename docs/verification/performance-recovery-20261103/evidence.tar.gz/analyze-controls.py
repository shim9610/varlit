"""Summarize complete randomized triples, including same-binary calibration."""
import argparse,json,random,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('samples',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
rows=json.loads(a.samples.read_text());key='case' if 'case' in rows[0] else 'mode';label='label';labels=['old-a','old-b','current'];rng=random.Random(349821);result=[]
for case in sorted({r[key] for r in rows}):
 selected=[r for r in rows if r[key]==case];groups=sorted({r['group'] for r in selected});triples=[]
 for g in groups:
  group=[r for r in selected if r['group']==g];assert len(group)==3 and {r[label] for r in group}==set(labels)
  triples.append({r[label]:r for r in group})
 work=[{k:v for k,v in r['result'].items() if k not in ('seconds','temporary_bytes')} for r in selected];assert all(w==work[0] for w in work)
 metrics={}
 for name,get,agg in [('seconds',lambda r:r['result']['seconds'],statistics.median),('cpu',lambda r:r['usage']['cpu'],statistics.median),('rss',lambda r:r['usage']['rss'],max),('writes',lambda r:r['usage']['write_blocks']*512,statistics.median),('temporary_bytes',lambda r:r['result'].get('temporary_bytes',0),max)]:
  values={s:agg(get(r) for r in selected if r[label]==s) for s in labels}
  changes={s:100*(values['current']/values[s]-1) if values[s] else (0 if values['current']==0 else None) for s in labels[:2]}
  metrics[name]={'values':values,'current_change_percent':changes,'passed_against_both':all(values['current']<=values[s]*1.05 for s in labels[:2])}
 distributions={'conservative_current':[],'same_binary_b_over_a':[]}
 for _ in range(10000):
  draw=[triples[rng.randrange(len(triples))] for _ in triples]
  med={s:statistics.median(g[s]['result']['seconds'] for g in draw) for s in labels}
  distributions['conservative_current'].append(100*(max(med['current']/med[s] for s in labels[:2])-1))
  distributions['same_binary_b_over_a'].append(100*(med['old-b']/med['old-a']-1))
 intervals={}
 for name,values in distributions.items():
  values.sort();intervals[name]=[values[249],values[9749]]
 med=metrics['seconds']['values'];aa=100*(med['old-b']/med['old-a']-1)
 result.append({key:case,'groups':len(groups),'work':work[0],'metrics':metrics,'same_binary_median_percent':aa,'paired_group_bootstrap_95_percent':intervals,'observed_gates_pass':all(m['passed_against_both'] for m in metrics.values()),'operation_conservative_upper_within_5_percent':intervals['conservative_current'][1]<=5})
 print(case,metrics['seconds']['current_change_percent'],'AA',aa,'interval',intervals['conservative_current'],flush=True)
a.output.write_text(json.dumps({'bootstrap_draws':10000,'seed':349821,'comparisons':result},indent=2)+'\n')
