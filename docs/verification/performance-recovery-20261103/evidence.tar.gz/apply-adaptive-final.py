from pathlib import Path
import subprocess
repo=Path('/workspace/varlit')
# The decoder extraction did not improve complex CPU on its own. Keep the prior
# decoder and its complete retained-input failure regressions.
p=repo/'crates/varlit-core/src/packed_rows.rs';p.write_bytes(subprocess.check_output(['git','show','6bcfe0a:crates/varlit-core/src/packed_rows.rs'],cwd=repo))
p=repo/'crates/varlit-core/src/file.rs';s=p.read_text();a=s.index('fn copy_verified_snapshot_record(');b=s.index('    let mut remaining = len;',a);end=s.index('    let checksum = |footer: &[u8]| {',b);body=s[b:end];body=body.replace('let mut buffer = [0; STREAM_BUFFER_LEN];','let mut buffer = [0; BUFFER];')
s=s[:b]+'''    if len <= 1024 {
        copy_snapshot_payload_crc::<1024>(&mut payload, snapshot, output, offset, len)?;
    } else {
        copy_snapshot_payload_crc::<STREAM_BUFFER_LEN>(&mut payload, snapshot, output, offset, len)?;
    }
'''+s[end:]
pos=s.index('#[cfg(not(feature = "integrity"))]\nfn copy_verified_snapshot_record(')
helper='''// Keeping each sized array in its own call frame avoids reserving the wide
// frame when a small record is copied. Source CRC and footer validation remain
// in the caller and still precede publication.
#[cfg(feature = "integrity")]
#[inline(never)]
fn copy_snapshot_payload_crc<const BUFFER: usize>(
    payload: &mut crc32fast::Hasher,
    snapshot: &SnapshotFile,
    output: &mut File,
    offset: u64,
    len: u64,
) -> Result<()> {
    const { assert!(BUFFER > 0); }
'''+body+'''    Ok(())
}

'''
s=s[:pos]+helper+s[pos:];p.write_text(s)
p=repo/'crates/varlit-core/src/file/validation_tests.rs';p.write_text(p.read_text()+'\n'+Path('/workspace/scratch/perf-recovery/verified-copy-regression.txt').read_text())
