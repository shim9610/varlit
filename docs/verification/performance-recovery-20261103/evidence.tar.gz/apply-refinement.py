from pathlib import Path
p=Path('/workspace/varlit/crates/varlit-core/src/spill_rows.rs');s=p.read_text();s=s.replace('                let corrected = if wanted > observed {','                let mut corrected = if wanted > observed {',1)
needle='''                let start = corrected.saturating_sub(16);''';assert s.count(needle)==1
extra='''                // A large irregular directory can leave the first correction
                // outside this small window. Refine only while observed error
                // falls by at least half; every answer still comes from a row.
                // The fixed iteration bound also covers hostile geometry.
                let mut previous_distance = wanted.abs_diff(observed);
                let mut last_probe = estimate;
                for _ in 0..3 {
                    if corrected == last_probe {
                        break;
                    }
                    let at = key(&rows[corrected]);
                    last_probe = corrected;
                    if at == wanted {
                        return Some(rows[corrected]);
                    }
                    if at < wanted && corrected + 1 < count {
                        let next = key(&rows[corrected + 1]);
                        if wanted <= next {
                            return Some(rows[corrected + usize::from(wanted == next)]);
                        }
                    } else if at > wanted && corrected > 0 && key(&rows[corrected - 1]) <= wanted {
                        return Some(rows[corrected - 1]);
                    }
                    let distance = wanted.abs_diff(at);
                    if distance >= previous_distance / 2 {
                        break;
                    }
                    previous_distance = distance;
                    let step = (scaled_position(distance, intervals, span)
                        .min(intervals as u128) as usize).max(1);
                    corrected = if wanted > at {
                        corrected.saturating_add(step).min(count - 1)
                    } else {
                        corrected.saturating_sub(step)
                    };
                }
                if corrected != last_probe && key(&rows[corrected]) == wanted {
                    return Some(rows[corrected]);
                }
'''
s=s.replace(needle,extra+needle);p.write_text(s)
