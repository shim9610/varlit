from pathlib import Path
p=Path('/workspace/varlit/crates/varlit-core/src/spill_rows.rs');s=p.read_text()
old='''            let end = rows.partition_point(|row| key(row) <= wanted);
            end.checked_sub(1).and_then(|at| rows.get(at)).copied()'''
new='''            let (mut low, mut high) = (0, count);
            // Large resident directories otherwise incur a full binary search
            // per mark. Two bounded estimates can locate a small real-key
            // bracket, but never authorize a record boundary by themselves.
            let last = key(&rows[count - 1]);
            if count >= 1024 && last > first {
                let span = u128::from(last - first);
                let intervals = (count - 1) as u128;
                let estimate = (u128::from(wanted - first) * intervals / span) as usize;
                let observed = key(&rows[estimate]);
                if observed == wanted {
                    return Some(rows[estimate]);
                }
                let correction = (u128::from(wanted.abs_diff(observed)) * intervals / span)
                    .min(intervals) as usize;
                let corrected = if wanted > observed {
                    estimate.saturating_add(correction).min(count - 1)
                } else {
                    estimate.saturating_sub(correction)
                };
                let start = corrected.saturating_sub(16);
                let end = corrected.saturating_add(17).min(count);
                if key(&rows[start]) <= wanted && wanted <= key(&rows[end - 1]) {
                    (low, high) = (start, end);
                } else if observed < wanted {
                    low = estimate + 1;
                } else {
                    high = estimate;
                }
            }
            let end = low + rows[low..high].partition_point(|row| key(row) <= wanted);
            end.checked_sub(1).and_then(|at| rows.get(at)).copied()'''
assert s.count(old)==1;s=s.replace(old,new).replace('for count in [1usize, 2, 63, 64, 65, 256] {','for count in [1usize, 2, 63, 64, 65, 256, 1024, 1025] {')
s=s.replace('''                for wanted in keys.iter().flat_map(|&key| {''','''                // Keep all small cases and sample both ends plus about 64
                // positions in large cases, including the prediction threshold.
                let probes = keys.iter().step_by(if count >= 1024 { 16 } else { 1 })
                    .chain(keys.last());
                for wanted in probes.flat_map(|&key| {''')
p.write_text(s)
