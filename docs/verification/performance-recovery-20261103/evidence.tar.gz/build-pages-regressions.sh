set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
cargo fmt --all
cargo test -p varlit-core --all-features > /workspace/scratch/perf-recovery/build-pages-core-all.log 2>&1
cargo test -p varlit-core > /workspace/scratch/perf-recovery/build-pages-core-default.log 2>&1
cargo test -p varlit --all-features --test oom_recovery_guards --test publication_failure_results --test record_liveness --test validation_coverage > /workspace/scratch/perf-recovery/build-pages-public.log 2>&1
cargo clippy --workspace --all-features --all-targets -- -D warnings > /workspace/scratch/perf-recovery/build-pages-clippy.log 2>&1
MIRIFLAGS=-Zmiri-disable-isolation cargo +nightly-2026-10-12 miri test -p varlit-core --all-features --lib file::native_rewrite::tests::rewrite_pages_preserve_entries_and_retry_across_refused_growth > /workspace/scratch/perf-recovery/build-pages-miri.log 2>&1
cargo fmt --all -- --check
git diff --check
