set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
export CARGO_INCREMENTAL=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0
cargo test --locked --workspace --all-features > /workspace/scratch/perf-recovery/call-shape-workspace-all.log 2>&1
cargo test --locked --workspace > /workspace/scratch/perf-recovery/call-shape-workspace-default.log 2>&1
cargo clippy --locked --workspace --all-features --all-targets -- -D warnings > /workspace/scratch/perf-recovery/call-shape-clippy.log 2>&1
cargo build --locked --release --workspace --all-features --example record_mutation_load --example oom_maintenance_load --example scalable_load --example ownership_load --example ownership_boundary_load > /workspace/scratch/perf-recovery/call-shape-build.log 2>&1
MIRIFLAGS=-Zmiri-disable-isolation cargo +nightly-2026-10-12 miri test -p varlit-core --all-features --lib adaptive_mark_reads_preserve_frames_and_retry_after_io_failure > /workspace/scratch/perf-recovery/call-shape-miri.log 2>&1
cargo fmt --all -- --check
git diff --check
