from pathlib import Path
import argparse,json,subprocess,os,random,statistics,hashlib
p=argparse.ArgumentParser();p.add_argument('--candidate',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args();a.output.mkdir(exist_ok=True)
r=Path('/workspace/scratch/perf-recovery');os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});rng=random.Random(659172);rows=[]
cases=[(r/'compact-bin','ownership_boundary_load',['nested-box','8000']),(Path('/workspace/scratch/fallible-ownership/before-bin'),'ownership_load',['nested','16384','16'])]
(a.output/'provenance.json').write_text(json.dumps([{'case':i,'args':args,'hashes':{label:hashlib.sha256((root/exe).read_bytes()).hexdigest() for label,root in [('old',old),('current',a.candidate)]}} for i,(old,exe,args) in enumerate(cases)],indent=2))
for case,(old,exe,args) in enumerate(cases):
 for group in range(20):
  labels=['old-a','old-b','current'];rng.shuffle(labels)
  for label in labels:
   binary=(a.candidate if label=='current' else old)/exe
   x=subprocess.run([str(r/'initial/measure'),str(a.output/'usage.json'),str(binary),*args],capture_output=True,text=True,check=True)
   row={'case':case,'group':group,'label':label,'result':json.loads(x.stdout),'usage':json.loads((a.output/'usage.json').read_text())};rows.append(row);(a.output/'samples.json').write_text(json.dumps(rows,indent=2))
 selected=[x for x in rows if x['case']==case]
 summary={}
 for metric,get,agg in [('seconds',lambda x:x['result']['seconds'],statistics.median),('cpu',lambda x:x['usage']['cpu'],statistics.median),('rss',lambda x:x['usage']['rss'],max)]:
  values={s:agg(get(x) for x in selected if x['label']==s) for s in labels};summary[metric]={'values':values,'deltas':{s:100*(values['current']/values[s]-1) for s in labels if s!='current'}}
 print(case,json.dumps(summary),flush=True)
