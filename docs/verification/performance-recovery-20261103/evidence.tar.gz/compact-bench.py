from pathlib import Path
import json,subprocess,os
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit')
host={k:Path('/sys/fs/cgroup',k).read_text() for k in ['cpu.max','memory.max','memory.events']};(r/'host-compact-before.json').write_text(json.dumps(host,indent=2))
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=repo).returncode
 print('END',name,code,flush=True)
 return code
base=['python3',str(r/'bench.py'),'--before',str(r/'decoder-bin'),'--after',str(r/'compact-bin'),'--repo',str(repo)]
assert run('compact-native',base+['--phase','native','--pairs','5','--output',str(r/'compact-native')])==0
flagged=[str(x['case']) for x in json.loads((r/'compact-native/native-summary.json').read_text()) if any((v['change_percent'] or 0)>5 for v in x['metrics'].values())]
if flagged: assert run('compact-confirmation',base+['--phase','native','--pairs','15','--native-cases',*flagged,'--output',str(r/'compact-confirmation')])==0
run('compact-swmr',base+['--phase','concurrent','--pairs','3','--output',str(r/'compact-swmr')])
for side in ['decoder','compact']:
 for name,cmd in [('complex',['oom_maintenance_load','complex','65536','512']),('rewrite',['record_mutation_load','rewrite','variable','random','200000','20000'])]:
  env={**os.environ,'TMPDIR':str(r/'disk-data')}
  with (r/f'compact-resource-{side}-{name}.log').open('w') as f:
   subprocess.run(['python3',str(repo/'docs/performance/audit-followup-20261102/resource_probe.py'),'--output',str(r/f'compact-resource-{side}-{name}.json'),str(r/(side+'-bin')/cmd[0]),*cmd[1:]],stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
host['memory.events_after']=Path('/sys/fs/cgroup/memory.events').read_text();(r/'host-compact.json').write_text(json.dumps(host,indent=2));print('DONE',flush=True)
