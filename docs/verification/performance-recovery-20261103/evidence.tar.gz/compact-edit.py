from pathlib import Path
import sys
root=Path(sys.argv[1])
p=root/'crates/varlit-core/src/spill_rows.rs';s=p.read_text();at=s.index('    pub(crate) fn reserve_rows_hint(')
s=s[:at]+'''    // Account for the cache that a later read may allocate, not just today's
    // capacities. This is shared with the parent packed-directory budget.
    pub(crate) fn read_heap_bytes(&self) -> usize {
        self.buffer.capacity().saturating_add(
            self.read_cache.borrow().1.capacity().max(if self.spilled == 0 {
                0
            } else {
                self.capacity.min(64 * 1024)
            }),
        )
    }

    /// Optional read-only promotion. The old and new buffers both fit the
    /// supplied allowance; refusal or short I/O leaves every old row intact.
    pub(crate) fn try_retain_for_reads(&mut self, budget: usize) -> io::Result<bool> {
        if self.spilled == 0 {
            return Ok(true);
        }
        let bytes = self.len().checked_mul(N).ok_or(io::ErrorKind::InvalidData)?;
        if bytes > budget.saturating_sub(self.read_heap_bytes()) {
            return Ok(false);
        }
        let mut buffer = Vec::new();
        buffer.try_reserve_exact(bytes).map_err(|_| io::Error::from(io::ErrorKind::OutOfMemory))?;
        buffer.resize(bytes, 0);
        let prefix = self.spilled * N;
        let mut consumed = 0;
        while consumed < prefix {
            let n = match crate::snapshot::read_at(
                self.file.as_ref().unwrap(), &mut buffer[consumed..prefix], consumed as u64,
            ) {
                Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
                other => other?,
            };
            if n == 0 {
                return Err(io::ErrorKind::UnexpectedEof.into());
            }
            consumed += n;
        }
        buffer[prefix..].copy_from_slice(&self.buffer);
        self.buffer = buffer;
        self.capacity = self.capacity.max(bytes);
        self.spilled = 0;
        self.file = None;
        self.read_cache.get_mut().1 = Vec::new();
        Ok(true)
    }

'''+s[at:];p.write_text(s)
p=root/'crates/varlit-core/src/packed_rows.rs';s=p.read_text();at=s.index('    pub(crate) fn len(&self)')
s=s[:at]+'''    pub(crate) const fn minimum_buffer_bytes() -> usize {
        (READ_PAGES + 1) * (N + N.div_ceil(8) * 10 + N.div_ceil(64)) + 16
    }

    fn read_heap_bytes(&self) -> usize {
        let mut bytes = self.retained.capacity()
            .saturating_add(self.buffer.capacity().saturating_mul(N))
            .saturating_add(self.encoded.capacity())
            .saturating_add(self.pages.read_heap_bytes());
        for page in &self.cache.borrow().pages {
            bytes = bytes
                .saturating_add(page.rows.capacity().max(self.page_rows).saturating_mul(N))
                .saturating_add(page.encoded.capacity().max(self.encoded_bound()));
        }
        bytes
    }

    /// Reuse a released rewrite allowance for immutable compact rows. Peak
    /// allocation includes both copies and every future decoded-page cache.
    /// If it cannot fit, keep the existing spill representation unchanged.
    pub(crate) fn try_retain_for_reads(&mut self, budget: usize) -> io::Result<()> {
        let data_bytes = usize::try_from(self.file_end).map_err(|_| invalid())?;
        if self.spilled_bytes != 0
            && data_bytes <= budget.saturating_sub(self.read_heap_bytes())
        {
            let mut retained = Vec::new();
            retained.try_reserve_exact(data_bytes).map_err(oom)?;
            retained.resize(data_bytes, 0);
            self.read_encoded(&mut retained, 0)?;
            self.retained = retained;
            self.spilled_bytes = 0;
            self.file = None;
        }
        let other = self.read_heap_bytes().saturating_sub(self.pages.read_heap_bytes());
        self.pages.try_retain_for_reads(budget.saturating_sub(other))?;
        Ok(())
    }

'''+s[at:];p.write_text(s)
p=root/'crates/varlit-core/src/native_directory.rs';s=p.read_text().replace('    rewritten: Option<RewriteRows>,','    rewritten: Option<RewrittenRows>,',1)
at=s.index('fn encode(entry:')
s=s[:at]+'''// Full rewrite rows are needed while constructing and validating a new
// generation. Once published, the resident directory uses only offset, block
// id and committed state. Compact that private metadata under the *remaining*
// allowance before releasing the original; every failed attempt keeps it.
#[derive(Debug)]
enum RewrittenRows {
    Full(RewriteRows),
    Compact(crate::packed_rows::PackedRows<16>),
}
impl RewrittenRows {
    fn new(rows: RewriteRows, spec: FormatSpec) -> Self {
        let scratch = buffer_bytes(spec) - rewrite_buffer_bytes(spec);
        if scratch < crate::packed_rows::PackedRows::<16>::minimum_buffer_bytes() {
            return Self::Full(rows);
        }
        let compact = (|| -> std::io::Result<_> {
            let mut compact = crate::packed_rows::PackedRows::with_page_rows(scratch, 16);
            for at in 0..rows.len() {
                let source = rows.get(at)?.ok_or(std::io::ErrorKind::UnexpectedEof)?;
                compact.push(Self::project(&source))?;
            }
            Ok(compact)
        })();
        match compact {
            Ok(mut compact) => {
                drop(rows);
                // This is optional cache residency, not publication. A refused
                // allocation or read retains the complete compact spill data.
                let _ = compact.try_retain_for_reads(rewrite_buffer_bytes(spec));
                Self::Compact(compact)
            }
            Err(_) => Self::Full(rows),
        }
    }
    fn project(source: &[u8; 62]) -> [u8; 16] {
        let mut row = [0; 16];
        row[..8].copy_from_slice(&source[16..24]);
        row[8..12].copy_from_slice(&source[..4]);
        row[12] = source[56];
        row
    }
    fn get(&self, at: usize) -> std::io::Result<Option<[u8; 16]>> {
        match self {
            Self::Full(rows) => Ok(rows.get(at)?.as_ref().map(Self::project)),
            Self::Compact(rows) => rows.get(at),
        }
    }
    fn contains(&self, offset: u64) -> std::io::Result<bool> {
        match self {
            Self::Full(rows) => Ok(rows.find_sorted(offset, |row| {
                u64::from_le_bytes(row[16..24].try_into().unwrap())
            })?.is_some()),
            Self::Compact(rows) => Ok(rows.find_sorted(offset, |row| {
                u64::from_le_bytes(row[..8].try_into().unwrap())
            })?.is_some()),
        }
    }
}

'''+s[at:]
s=s.replace('            rewritten: Some(rows),','            rewritten: Some(RewrittenRows::new(rows, spec)),',1)
old='''                if rows
                    .find_sorted(offset, |row| {
                        u64::from_le_bytes(row[16..24].try_into().unwrap())
                    })?
                    .is_some()
                {'''
assert old in s;s=s.replace(old,'''                if rows.contains(offset)? {''',1)
old='''        let Some(source) = self.rewritten.as_ref().unwrap().get(position)? else {
            return Ok(None);
        };
        let mut row = [0; 16];
        row[..8].copy_from_slice(&source[16..24]);
        row[8..12].copy_from_slice(&source[..4]);
        row[12] = source[56];
        Ok(Some(row))'''
assert old in s;s=s.replace(old,'''        self.rewritten.as_ref().unwrap().get(position)''',1);p.write_text(s)
