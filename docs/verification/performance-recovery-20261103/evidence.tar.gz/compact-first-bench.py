from pathlib import Path
import json,os,subprocess
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit')
host={k:Path('/sys/fs/cgroup',k).read_text() for k in ['cpu.max','memory.max','memory.events']};(r/'host-compact-before.json').write_text(json.dumps(host,indent=2))
with (r/'compact-first.log').open('w') as f:
 subprocess.run(['python3',str(r/'bench.py'),'--before',str(r/'decoder-bin'),'--after',str(r/'compact-bin'),'--repo',str(repo),'--phase','native','--pairs','5','--native-cases','1','2','6','--output',str(r/'compact-first')],stdout=f,stderr=subprocess.STDOUT,check=True)
for side in ['decoder','compact']:
 for name,cmd in [('complex',['oom_maintenance_load','complex','65536','512']),('rewrite',['record_mutation_load','rewrite','variable','random','200000','20000'])]:
  env={**os.environ,'TMPDIR':str(r/'disk-data')}
  with (r/f'compact-resource-{side}-{name}.log').open('w') as f:
   subprocess.run(['python3',str(repo/'docs/performance/audit-followup-20261102/resource_probe.py'),'--output',str(r/f'compact-resource-{side}-{name}.json'),str(r/(side+'-bin')/cmd[0]),*cmd[1:]],stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
print('DONE',flush=True)
