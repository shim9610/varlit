from pathlib import Path
import json,os,subprocess
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=repo).returncode
 print('END',name,code,flush=True)
 return code
base=['python3',str(r/'bench.py'),'--before',str(r/'decoder-bin'),'--after',str(r/'compact-bin'),'--repo',str(repo)]
assert run('compact-rest',base+['--phase','native','--pairs','5','--native-cases','0','3','4','5','7','8','9','10','--output',str(r/'compact-rest')])==0
combined=r/'compact-native';combined.mkdir(exist_ok=True)
for filename in ['native-samples.json','native-summary.json']:
 data=[row for name in ['compact-first','compact-rest'] for row in json.loads((r/name/filename).read_text())];(combined/filename).write_text(json.dumps(data,indent=2))
flagged=[str(x['case']) for x in json.loads((combined/'native-summary.json').read_text()) if any((v['change_percent'] or 0)>5 for v in x['metrics'].values())]
if flagged:assert run('compact-confirmation',base+['--phase','native','--pairs','15','--native-cases',*flagged,'--output',str(r/'compact-confirmation')])==0
assert run('compact-pool',['python3',str(r/'pool.py'),'--primary',str(combined),'--confirmation',str(r/'compact-confirmation'),'--output',str(r/'compact-pooled.json')])==0
run('compact-swmr',base+['--phase','concurrent','--pairs','3','--output',str(r/'compact-swmr')])
assert run('final-reference',['python3',str(r/'reference-control.py'),'--after',str(r/'compact-bin'),'--output',str(r/'final-reference'),'--groups','20'])==0
assert run('owner-final',['python3',str(r/'owner-final.py')])==0
host={k:Path('/sys/fs/cgroup',k).read_text() for k in ['cpu.max','memory.max','memory.events']};(r/'host-compact-after.json').write_text(json.dumps(host,indent=2));print('DONE',flush=True)
