from pathlib import Path
import subprocess,shutil,hashlib,json,os,random,statistics
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');out=r/'decode-scratch-diagnostic';out.mkdir(exist_ok=False)
paths={n:repo/'crates/varlit-core/src'/n for n in ['file.rs','snapshot.rs','packed_rows.rs','file/validation_tests.rs']};original={n:p.read_text() for n,p in paths.items()}
labels=['previous-749','current-6bc','outlined-decode','sized-scratch'];cases=[ ['complex','65536','512'], ['checkpoint','200000','256'], ['writer','fixed','forward','2000000','200000'], ['writer','mixed','random','131072','65536'], ['rewrite','variable','random','200000','200000'] ]
plan={'purpose':'diagnostic, ordinary unchanged workloads; separate encoded-input decoding call, then size copy/CRC stack scratch to1024for small payloads and existing64KiBfor large; core regressions before each prototype build; no buffers allocated on heap','groups':12,'seed':719246,'cases':cases,'variants':{}}
(out/'plan.json').write_text(json.dumps(plan,indent=2))
try:
 for label in labels:
  dest=out/(label+'-bin');dest.mkdir()
  if label in ['previous-749','current-6bc']:
   origin=r/('read-hint-bin' if label=='previous-749' else 'call-shape-bin')
   for n in ['record_mutation_load','oom_maintenance_load','scalable_load','ownership_load','ownership_boundary_load']:shutil.copy2(origin/n,dest/n)
  else:
   for n,p in paths.items():
    content=original[n]
    if label=='outlined-decode' and n in ['file.rs','snapshot.rs']:
     content=subprocess.check_output(['git','show','6bcfe0a:crates/varlit-core/src/'+n],cwd=repo,text=True)
     if n=='snapshot.rs':
      at=content.rindex('\n}');content=content[:at]+'\n'+(r/'snapshot-copy-regression.txt').read_text()+content[at:]
    p.write_text(content)
   print('REGRESSION',label,flush=True)
   with (out/(label+'-tests.log')).open('w') as f:subprocess.run(['cargo','test','--locked','-p','varlit-core','--all-features','--lib'],cwd=repo,env={**os.environ,'CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0'},stdout=f,stderr=subprocess.STDOUT,check=True)
   print('BUILD',label,flush=True)
   with (out/(label+'-build.log')).open('w') as f:subprocess.run(['cargo','build','--locked','--release','--workspace','--all-features','--example','record_mutation_load','--example','oom_maintenance_load','--example','scalable_load','--example','ownership_load','--example','ownership_boundary_load'],cwd=repo,stdout=f,stderr=subprocess.STDOUT,check=True)
   for n in ['record_mutation_load','oom_maintenance_load','scalable_load','ownership_load','ownership_boundary_load']:shutil.copy2(repo/'target/release/examples'/n,dest/n)
  plan['variants'][label]={'source_revision':label if label.startswith(('previous','current')) else '6bcfe0a plus recorded modified sources','sources':{n:hashlib.sha256(subprocess.check_output(['git','show',('749532d' if label=='previous-749' else '6bcfe0a')+':crates/varlit-core/src/'+n],cwd=repo) if label in ['previous-749','current-6bc'] else p.read_bytes()).hexdigest() for n,p in paths.items()},'binaries':{n:hashlib.sha256((dest/n).read_bytes()).hexdigest() for n in ['record_mutation_load','oom_maintenance_load','scalable_load','ownership_load','ownership_boundary_load']}};(out/'plan.json').write_text(json.dumps(plan,indent=2))
  symbols=subprocess.check_output(['nm','-S','-C',str(dest/'record_mutation_load')],text=True)
  (out/(label+'-symbols.txt')).write_text('\n'.join(l for l in symbols.splitlines() if any(k in l for k in ['mark_record_dead','write_framed_record_flags','SnapshotFile::read_exact_at'])))
finally:
 for n,p in paths.items():p.write_text(original[n])
 (out/'source-restored.json').write_text(json.dumps({n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in paths.items()},indent=2))
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});rng=random.Random(719246);samples=[];summaries=[]
for case,args in enumerate(cases):
 exe='oom_maintenance_load' if case<2 else 'record_mutation_load'
 orders=[]
 for group in range(12):
  if not orders:
   names=labels.copy();rng.shuffle(names);orders=[[names[i] for i in order] for order in [[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1]]];rng.shuffle(orders)
  for label in orders.pop():
   x=subprocess.run([str(r/'initial/measure'),str(out/'usage.json'),str(out/(label+'-bin')/exe),*args],capture_output=True,text=True,env={**os.environ,'TMPDIR':str(r/'disk-data')},check=True)
   row={'case':case,'group':group,'label':label,'result':json.loads(x.stdout),'usage':json.loads((out/'usage.json').read_text())};samples.append(row);(out/'samples.json').write_text(json.dumps(samples,indent=2));print(case,group,label,row['result']['seconds'],flush=True)
 selected=[x for x in samples if x['case']==case];work=[{k:v for k,v in x['result'].items() if k not in ('seconds','temporary_bytes')} for x in selected];assert all(x==work[0] for x in work)
 summary={'case':case,'values':{label:{metric:agg(get(x) for x in selected if x['label']==label) for metric,get,agg in [('wall',lambda x:x['result']['seconds'],statistics.median),('process_cpu',lambda x:x['usage']['cpu'],statistics.median),('rss',lambda x:x['usage']['rss'],max),('writes',lambda x:x['usage']['write_blocks'],statistics.median),('temporary_bytes',lambda x:x['result'].get('temporary_bytes',0),max)]} for label in labels}}
 summaries.append(summary);(out/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',summary,flush=True)
