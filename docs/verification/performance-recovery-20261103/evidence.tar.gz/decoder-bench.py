from pathlib import Path
import json,subprocess,os
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit')
host={k:Path('/sys/fs/cgroup',k).read_text() for k in ['cpu.max','memory.max','memory.events']};(r/'host-before.json').write_text(json.dumps(host,indent=2))
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=repo).returncode
 print('END',name,code,flush=True)
 return code
assert run('owner-probe',['python3',str(r/'owner-probe.py')])==0
assert run('decoder-reference',['python3',str(r/'decoder-reference.py')])==0
base=['python3',str(repo/'docs/performance/audit-followup-20261102/bench.py'),'--before',str(r/'before-bin'),'--after',str(r/'decoder-bin'),'--repo',str(repo)]
assert run('decoder-native',base+['--phase','native','--pairs','5','--output',str(r/'decoder-native')])==0
flagged=[str(x['case']) for x in json.loads((r/'decoder-native/native-summary.json').read_text()) if any((v['change_percent'] or 0)>5 for v in x['metrics'].values())]
if flagged: assert run('decoder-confirmation',base+['--phase','native','--pairs','15','--native-cases',*flagged,'--output',str(r/'decoder-confirmation')])==0
run('decoder-swmr',base+['--phase','concurrent','--pairs','3','--output',str(r/'decoder-swmr')])
for side in ['before','decoder']:
 for name,cmd in [('complex',['oom_maintenance_load','complex','65536','512']),('rewrite',['record_mutation_load','rewrite','variable','random','200000','20000'])]:
  env={**os.environ,'TMPDIR':str(r/'disk-data')}
  with (r/f'decoder-resource-{side}-{name}.log').open('w') as f:
   subprocess.run(['python3',str(repo/'docs/performance/audit-followup-20261102/resource_probe.py'),'--output',str(r/f'decoder-resource-{side}-{name}.json'),str(r/(side+'-bin')/cmd[0]),*cmd[1:]],stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
host['memory.events_after']=Path('/sys/fs/cgroup/memory.events').read_text();(r/'host-decoder.json').write_text(json.dumps(host,indent=2));print('DONE',flush=True)
