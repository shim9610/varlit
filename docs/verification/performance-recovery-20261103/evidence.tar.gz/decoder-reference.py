import os,subprocess,json,statistics,random
from pathlib import Path
r=Path('/workspace/scratch/perf-recovery');out=r/'decoder-reference';out.mkdir(exist_ok=True)
bins={'old':Path('/workspace/varlit-pre-boundary/target/release/examples/record_mutation_load'),'head':r/'decoder-bin/record_mutation_load'}
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});env={**os.environ,'TMPDIR':str(r/'disk-data')}
measure=out/'measure';subprocess.run(['cc','-O2','/workspace/varlit/docs/performance/boundary-redesign-20261101/measure-child.c','-o',str(measure)],check=True)
cases=[['writer','variable','random','200000','20000'],['epochs','fixed','random','200000','20000'],['rewrite','variable','random','200000','20000'],['writer','large','reverse','65536','4096'],['writer','mixed','random','131072','8192']]
rows=[];rng=random.Random(731)
for case,args in enumerate(cases):
 for group in range(5):
  sides=list(bins);rng.shuffle(sides)
  for side in sides:
   x=subprocess.run([str(measure),str(out/'usage.json'),str(bins[side]),*args],capture_output=True,text=True,check=True,env=env,timeout=600)
   row={'case':case,'args':args,'group':group,'side':side,'result':json.loads(x.stdout),'usage':json.loads((out/'usage.json').read_text())};rows.append(row)
   (out/'samples.json').write_text(json.dumps(rows,indent=2));print(case,group,side,row['result']['seconds'],flush=True)
 xs=[x for x in rows if x['case']==case];ms={s:statistics.median(x['result']['seconds'] for x in xs if x['side']==s) for s in bins};print('SUMMARY',args,ms,100*(ms['head']/ms['old']-1),flush=True)
