from pathlib import Path
import subprocess
r=Path('/workspace/scratch/perf-recovery')
for name in ['mixed','rewrite']:
 print('START',name,flush=True)
 with (r/f'entry-validation-{name}.log').open('w') as f:
  p=subprocess.run(['python3',str(r/f'entry-validation-{name}.py')],stdout=f,stderr=subprocess.STDOUT)
 print('EXIT',name,p.returncode,flush=True)
