from pathlib import Path
import sys
source=Path('/workspace/varlit/crates/varlit-core/src/spill_rows.rs').read_text();a=source.index('fn search<const N: usize>',source.index('fn cached_floor'))
b=source.index('{',a);depth=1;i=b+1
while depth:
 if source[i]=='{':depth+=1
 elif source[i]=='}':depth-=1
 i+=1
body=source[a:i]
main=r'''
fn main() {
 let count=131072usize;
 let mut rows=Vec::<[u8;13]>::with_capacity(count);
 let mut offset=4096u64;
 for i in 0..count { let mut row=[0;13];row[..8].copy_from_slice(&offset.to_le_bytes());rows.push(row);offset+=100+(i*8191%65536) as u64; }
 let bytes=rows.as_flattened();
 for marks in [8192usize,65536] {
  let calls=std::cell::Cell::new(0usize);
  for i in 0..marks {
   let at=(i+1)*count/marks-1;let wanted=u64::from_le_bytes(rows[at][..8].try_into().unwrap());
   let key=|row:&[u8]| {calls.set(calls.get()+1);u64::from_le_bytes(row[..8].try_into().unwrap())};
   assert_eq!(search::<13>(bytes,wanted,&key),Some(rows[at]));
   assert_eq!(search::<13>(bytes,wanted+1,&key),if at+1<count {Some(rows[at])} else {None});
  }
  println!("marks={marks} queries={} key_calls={} mean={}",marks*2,calls.get(),calls.get() as f64/(marks*2) as f64);
 }
}
'''
Path(sys.argv[1]).write_text('// Exact extracted production search body; structural cost diagnostic, not an I/O benchmark.\n'+body+'\n'+main)
