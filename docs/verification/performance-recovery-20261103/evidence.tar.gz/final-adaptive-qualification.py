from pathlib import Path
import subprocess,json
r=Path('/workspace/scratch/perf-recovery')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:subprocess.run(['python3',*map(str,args)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
def analyze(name):
 run(name+'-analysis',[r/'analyze-controls.py',r/name/'samples.json',r/name/'analysis.json'])
 d=json.loads((r/name/'analysis.json').read_text())
 assert all(x['observed_gates_pass'] for x in d['comparisons']), name+' observed gate failed; every sample retained'
 assert all(abs(x['same_binary_median_percent'])<=5 for x in d['comparisons']), name+' calibration exceeds 5%; every sample retained'
def combine(destination,parts):
 out=r/destination;out.mkdir(exist_ok=False)
 samples=sum([json.loads((r/p/'samples.json').read_text()) for p in parts],[])
 keys=[(x['case'],x['group'],x.get('side',x.get('label'))) for x in samples];assert len(keys)==len(set(keys))
 (out/'samples.json').write_text(json.dumps(samples,indent=2))
 (out/'plans.json').write_text(json.dumps({p:json.loads((r/p/'plan.json').read_text()) for p in parts},indent=2))
 if (r/parts[0]/'summary.json').exists():
  (out/'summary.json').write_text(json.dumps(sum([json.loads((r/p/'summary.json').read_text()) for p in parts],[]),indent=2))
run('final-adaptive-native-early',[r/'final-adaptive-four.py','--phase','native','--cases','7','8','0','--output',r/'final-adaptive-native-early'])
run('final-adaptive-reference-long',[r/'final-adaptive-reference.py','--after',r/'adaptive-scratch-bin','--output',r/'final-adaptive-reference-long','--groups','60','--cases','6','7'])
analyze('final-adaptive-reference-long')
run('final-adaptive-native-rest',[r/'final-adaptive-four.py','--phase','native','--cases','6','2','11','12','1','3','4','5','9','10','--output',r/'final-adaptive-native-rest'])
combine('final-adaptive-native',['final-adaptive-native-early','final-adaptive-native-rest'])
assert {x['case'] for x in json.loads((r/'final-adaptive-native/summary.json').read_text())} == set(range(13))
run('final-adaptive-swmr',[r/'final-adaptive-four.py','--phase','concurrent','--output',r/'final-adaptive-swmr'])
run('final-adaptive-reference-rest',[r/'final-adaptive-reference.py','--after',r/'adaptive-scratch-bin','--output',r/'final-adaptive-reference-rest','--groups','60','--cases','0','1','2','3','4','5'])
combine('final-adaptive-reference',['final-adaptive-reference-long','final-adaptive-reference-rest'])
analyze('final-adaptive-reference')
assert len(json.loads((r/'final-adaptive-reference/analysis.json').read_text())['comparisons']) == 8
run('final-adaptive-owned',[r/'owned-pairs.py','--before',r/'call-shape-bin','--after',r/'adaptive-scratch-bin','--output',r/'final-adaptive-owned'])
assert all(m['passed'] for x in json.loads((r/'final-adaptive-owned/summary.json').read_text()) for m in x['metrics'].values()), 'Ownership gate failed; all samples retained'
run('final-adaptive-owned-initial',[r/'owned-pairs.py','--before',r/'before-bin','--after',r/'adaptive-scratch-bin','--output',r/'final-adaptive-owned-initial'])
assert all(m['passed'] for x in json.loads((r/'final-adaptive-owned-initial/summary.json').read_text()) for m in x['metrics'].values()), 'Initial ownership comparison failed; all samples retained'
for name in ['final-adaptive-owner-controls','final-adaptive-nested-short','final-adaptive-nested-long']:
 run(name,[r/(name+'.py')]);analyze(name)
run('final-adaptive-resources',[r/'final-adaptive-resources.py'])
print('DONE ALL PLANNED SERIES; inspect resources and statistical limits.',flush=True)
