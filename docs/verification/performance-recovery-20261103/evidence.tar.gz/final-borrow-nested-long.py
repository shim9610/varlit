import json,subprocess,os,random,statistics
from pathlib import Path
r=Path('/workspace/scratch/perf-recovery');out=r/'final-borrow-nested-long';out.mkdir(exist_ok=True)
measure=r/'initial/measure';baseline=Path('/workspace/scratch/fallible-ownership/before-bin');current=r/'borrow-policy-bin';rng=random.Random(39482)
import hashlib
(out/'plan.json').write_text(json.dumps({'groups':20,'seed':39482,'work':{'nested_records': 16384, 'iterations': 128},'same_binary_labels':['old-a','old-b'],'binary_sha256':{s:hashlib.sha256((b/'ownership_load').read_bytes()).hexdigest() for s,b in [('original',baseline),('current',current)]}},indent=2))
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});samples=[]
for exe in ['ownership_load']:
 for mode,iters in [('nested',128)]:
  for group in range(20):
   labels=['old-a','old-b','current'];rng.shuffle(labels)
   for label in labels:
    binary=(current if label=='current' else baseline)/exe
    run=subprocess.run([str(measure),str(out/'usage.json'),str(binary),mode,'16384',str(iters)],check=True,text=True,capture_output=True)
    row=dict(mode=mode,group=group,label=label,result=json.loads(run.stdout),usage=json.loads((out/'usage.json').read_text()));samples.append(row)
    (out/'samples.json').write_text(json.dumps(samples,indent=2))
  med={s:statistics.median(x['result']['seconds'] for x in samples if x['mode']==mode and x['label']==s) for s in labels}
  print(mode,med,{s:100*(med[s]/med['old-a']-1) for s in med},flush=True)
