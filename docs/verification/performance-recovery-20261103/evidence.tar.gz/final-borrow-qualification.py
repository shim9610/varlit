from pathlib import Path
import subprocess,json
r=Path('/workspace/scratch/perf-recovery')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:subprocess.run(['python3',*map(str,args)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
def analyze(name):
 run(name+'-analysis',[r/'analyze-controls.py',r/name/'samples.json',r/name/'analysis.json'])
 d=json.loads((r/name/'analysis.json').read_text())
 assert all(x['observed_gates_pass'] for x in d['comparisons']), name+' observed gate failed; every sample retained'
 assert all(abs(x['same_binary_median_percent'])<=5 for x in d['comparisons']), name+' calibration exceeds 5%; every sample retained'
def combine(destination,parts):
 out=r/destination;out.mkdir(exist_ok=False)
 samples=sum([json.loads((r/p/'samples.json').read_text()) for p in parts],[])
 keys=[(x['case'],x['group'],x.get('side',x.get('label'))) for x in samples];assert len(keys)==len(set(keys))
 (out/'samples.json').write_text(json.dumps(samples,indent=2))
 (out/'plans.json').write_text(json.dumps({p:json.loads((r/p/'plan.json').read_text()) for p in parts},indent=2))
 if (r/parts[0]/'summary.json').exists():
  (out/'summary.json').write_text(json.dumps(sum([json.loads((r/p/'summary.json').read_text()) for p in parts],[]),indent=2))
run('final-borrow-native-fixed',[r/'final-borrow-four.py','--phase','native','--cases','0','--output',r/'final-borrow-native-fixed'])
run('final-borrow-reference-long',[r/'final-borrow-reference.py','--after',r/'borrow-policy-bin','--output',r/'final-borrow-reference-long','--groups','60','--cases','6','7'])
analyze('final-borrow-reference-long')
run('final-borrow-native-rest',[r/'final-borrow-four.py','--phase','native','--cases','6','2','11','12','1','3','4','5','7','8','9','10','--output',r/'final-borrow-native-rest'])
combine('final-borrow-native',['final-borrow-native-fixed','final-borrow-native-rest'])
assert {x['case'] for x in json.loads((r/'final-borrow-native/summary.json').read_text())} == set(range(13))
run('final-borrow-swmr',[r/'final-borrow-four.py','--phase','concurrent','--output',r/'final-borrow-swmr'])
run('final-borrow-reference-rest',[r/'final-borrow-reference.py','--after',r/'borrow-policy-bin','--output',r/'final-borrow-reference-rest','--groups','60','--cases','0','1','2','3','4','5'])
combine('final-borrow-reference',['final-borrow-reference-long','final-borrow-reference-rest'])
analyze('final-borrow-reference')
assert len(json.loads((r/'final-borrow-reference/analysis.json').read_text())['comparisons']) == 8
run('final-borrow-owned',[r/'owned-pairs.py','--before',r/'before-bin','--after',r/'borrow-policy-bin','--output',r/'final-borrow-owned'])
assert all(m['passed'] for x in json.loads((r/'final-borrow-owned/summary.json').read_text()) for m in x['metrics'].values()), 'Ownership gate failed; all samples retained'
for name in ['final-borrow-owner-controls','final-borrow-nested-short','final-borrow-nested-long']:
 run(name,[r/(name+'.py')]);analyze(name)
run('final-borrow-resources',[r/'final-borrow-resources.py'])
print('DONE ALL PLANNED SERIES; inspect resources and statistical limits.',flush=True)
