"""Four frozen versions; native8+16 and SWMR4+8 groups on any failed 5% metric.
All planned observations retained, Williams order fixed before execution.
"""
from pathlib import Path
import argparse,hashlib,itertools,json,os,random,shutil,statistics,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--cases',nargs='+',type=int);p.add_argument('--phase',choices=['native','concurrent'],required=True);p.add_argument('--output',required=True,type=Path);a=p.parse_args();a.output.mkdir(exist_ok=True)
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');scratch=a.output/'disk-data';scratch.mkdir(exist_ok=True);env={**os.environ,'TMPDIR':str(scratch)}
bins={'qualified-before':r/'read-hint-bin','unit-before':r/'borrow-policy-bin','initial-before':r/'before-bin','after':r/'call-shape-bin'};rng=random.Random(396215)
(a.output/'plan.json').write_text(json.dumps({'phase':a.phase,'selected_cases':a.cases,'seed':396215,'limit_percent':5,'native_case_order':[0,6,2,11,12,1,3,4,5,7,8,9,10],'initial_groups':8 if a.phase=='native' else 4,'additional_groups':16 if a.phase=='native' else 8,'order_balance':'four-version Williams blocks balance every position and directed predecessor pair','binaries':{s:{n:hashlib.sha256((b/n).read_bytes()).hexdigest() for n in ['record_mutation_load','oom_maintenance_load','scalable_load']} for s,b in bins.items()}},indent=2))
pending_orders=[]
def order():
 if not pending_orders:
  labels=list(bins);rng.shuffle(labels)
  pending_orders.extend([[labels[i] for i in order] for order in [[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1]]]);rng.shuffle(pending_orders)
 return list(pending_orders.pop())
if a.phase=='native':
 os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
 encoded=scratch/'decode-fixture.bin';subprocess.run([str(bins['unit-before']/'oom_maintenance_load'),'prepare-decode','67108864','1048576',str(encoded)],check=True,env=env)
 cases=[('record_mutation_load',['writer','fixed','forward','2000000','200000']),('record_mutation_load',['writer','variable','random','200000','20000']),('record_mutation_load',['rewrite','variable','random','200000','20000']),('record_mutation_load',['recovery','fixed','forward','200000','20000']),('record_mutation_load',['writer','large','reverse','65536','4096']),('record_mutation_load',['lazy','large','reverse','65536','4096']),('record_mutation_load',['writer','mixed','random','131072','8192']),('oom_maintenance_load',['complex','65536','512']),('oom_maintenance_load',['checkpoint','200000','256']),('oom_maintenance_load',['chunks','67108864','1048576']),('oom_maintenance_load',['decode','67108864','1048576',str(encoded)])]
 cases.extend([('record_mutation_load',['rewrite','variable','random','2000000','20000']),('record_mutation_load',['rewrite','mixed','random','32768','8192'])])
 rows=[];summaries=[]
 def summarize(selected):
  work=[{k:v for k,v in x['result'].items() if k not in ('seconds','temporary_bytes')} for x in selected];assert all(x==work[0] for x in work)
  metrics={}
  for name,get,agg in [('seconds',lambda x:x['result']['seconds'],statistics.median),('cpu',lambda x:x['usage']['cpu'],statistics.median),('rss',lambda x:x['usage']['rss'],max),('writes',lambda x:x['usage']['write_blocks']*512,statistics.median),('temporary_bytes',lambda x:x['result'].get('temporary_bytes',0),max)]:
   values={s:agg(get(x) for x in selected if x['side']==s) for s in bins}
   metrics[name]={'values':values,'comparisons':{s:{'change_percent':100*(values['after']/values[s]-1) if values[s] else (0 if values['after']==0 else None),'passed':values['after']<=values[s]*1.05} for s in bins if s!='after'}}
  return {'work':work[0],'metrics':metrics,'passed':all(c['passed'] for m in metrics.values() for c in m['comparisons'].values())}
 for case in [0,6,2,11,12,1,3,4,5,7,8,9,10]:
  if a.cases is not None and case not in a.cases:continue
  exe,args=cases[case]
  selected=[]
  for stage,(start,end) in enumerate([(0,8),(8,24)]):
   if stage and summarize(selected)['passed']:break
   for group in range(start,end):
    for side in order():
     x=subprocess.run([str(r/'initial/measure'),str(a.output/'usage.json'),str(bins[side]/exe),*args],env=env,capture_output=True,text=True,check=True,timeout=600)
     row={'case':case,'binary':exe,'args':args,'group':group,'side':side,'result':json.loads(x.stdout),'usage':json.loads((a.output/'usage.json').read_text())};rows.append(row);selected.append(row);(a.output/'samples.json').write_text(json.dumps(rows,indent=2));print(case,group,side,row['result']['seconds'],flush=True)
  summary={'case':case,'groups':len(selected)//4,**summarize(selected)};summaries.append(summary);(a.output/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',case,json.dumps(summary),flush=True)
  if not summary['passed']:raise SystemExit(f'Native gate failed at case {case}; completed observations retained')
 if not all(s['passed'] for s in summaries):raise SystemExit('Native gate failed')
else:
 sys.path.insert(0,str(repo/'scripts'));from compare_load import compare
 summaries={}
 for total,epoch in [('1','16'),('4','64')]:
  reports={s:[] for s in bins}
  def comparisons():return {s:compare(reports[s],reports['after']) for s in bins if s!='after'}
  for stage,(start,end) in enumerate([(0,4),(4,12)]):
   if stage and all(d['status']=='passed' for d in comparisons().values()):break
   for group in range(start,end):
    for side in order():
     name=f'swmr-{total}-{group}-{side}';out=a.output/name;data=scratch/name;print('RUN',name,flush=True)
     cmd=['python3',str(repo/'scripts/load_scalable.py'),'--suite','large','--only','indexed-r8-20g','--total-gib',total,'--epoch-mib',epoch,'--reader-checks-per-epoch','16384','--read-seconds','1','--data-root',str(data),'--output',str(out),'--binary',str(bins[side]/'scalable_load')]
     with (a.output/(name+'.log')).open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
     reports[side].append(json.loads((out/'report.json').read_text()));assert (data/'.varlit-load-owner').read_text()==str(out);shutil.rmtree(data)
  summaries[total]={'groups':len(reports['after']),'comparisons':comparisons(),'inline_read_comparison':compare(reports['qualified-before'],reports['unit-before'])};(a.output/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',total,json.dumps(summaries[total]),flush=True)
 if not all(d['status']=='passed' for x in summaries.values() for d in x['comparisons'].values()):raise SystemExit('SWMR gate failed')
print('DONE',flush=True)
