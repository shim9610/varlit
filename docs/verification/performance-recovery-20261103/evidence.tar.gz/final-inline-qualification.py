from pathlib import Path
import subprocess
r=Path('/workspace/scratch/perf-recovery')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:subprocess.run(['python3',*map(str,args)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
run('final-inline-native',[r/'final-inline-four.py','--phase','native','--output',r/'final-inline-native'])
run('final-inline-swmr',[r/'final-inline-four.py','--phase','concurrent','--output',r/'final-inline-swmr'])
run('final-inline-reference',[r/'final-inline-reference.py','--after',r/'inline-read-bin','--output',r/'final-inline-reference','--groups','24'])
run('final-inline-reference-analysis',[r/'analyze-controls.py',r/'final-inline-reference/samples.json',r/'final-inline-reference/analysis.json'])
run('final-inline-owned',[r/'owned-pairs.py','--before',r/'before-bin','--after',r/'inline-read-bin','--output',r/'final-inline-owned'])
for name in ['final-inline-owner-controls','final-inline-nested-short','final-inline-nested-long']:
 run(name,[r/(name+'.py')])
 run(name+'-analysis',[r/'analyze-controls.py',r/name/'samples.json',r/name/'analysis.json'])
run('final-inline-resources',[r/'final-inline-resources.py'])
print('DONE ALL PLANNED SERIES; inspect all metrics/calibration.',flush=True)
