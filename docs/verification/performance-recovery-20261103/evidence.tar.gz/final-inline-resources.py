from pathlib import Path
import json,subprocess,os
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');dirs={'initial-before':r/'before-bin','qualified-before':r/'read-hint-bin','unit-before':r/'entry-validation-bin','after':r/'inline-read-bin','original':Path('/workspace/varlit-pre-boundary/target/release/examples')}
for mode,args in [('rewrite',['record_mutation_load','rewrite','variable','random','200000','20000']),('complex',['oom_maintenance_load','complex','65536','512'])]:
 for side,d in dirs.items():
  if side=='original' and mode!='rewrite':continue
  stem=f'final-inline-resource-{mode}-{side}'
  with (r/(stem+'.log')).open('w') as f:
   subprocess.run(['python3',str(repo/'docs/performance/audit-followup-20261102/resource_probe.py'),'--output',str(r/(stem+'.json')),str(d/args[0]),*args[1:]],env={**os.environ,'TMPDIR':str(r/'disk-data')},stdout=f,stderr=subprocess.STDOUT,check=True)
  print(mode,side,json.loads((r/(stem+'.json')).read_text())['peaks'],flush=True)
