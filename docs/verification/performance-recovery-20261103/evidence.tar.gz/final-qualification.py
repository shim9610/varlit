"""Sequential final qualification; no build or concurrent benchmark overlap."""
from pathlib import Path
import json,subprocess,shutil
r=Path('/workspace/scratch/perf-recovery')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as log:subprocess.run(['python3',*map(str,args)],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
# Completed compilation caches only; preserve every measurement and fixture log.
p=Path('/workspace/varlit/target/debug/incremental')
size=sum(f.stat().st_size for f in p.rglob('*') if f.is_file()) if p.exists() else 0
(r/'final-cache-cleanup.json').write_text(json.dumps({'path':str(p),'bytes':size,'reason':'completed local checks; leave disk space for unchanged 4-GiB qualification workload'},indent=2))
if p.exists():shutil.rmtree(p)
run('final-swmr',[r/'final-four-way-swmr.py','--phase','concurrent','--output',r/'final-swmr'])
run('final-reference',[r/'reference-control-with-long-rewrite.py','--after',r/'build-pages-bin','--output',r/'final-reference','--groups','20'])
run('final-reference-analysis',[r/'analyze-controls.py',r/'final-reference/samples.json',r/'final-reference/analysis.json'])
run('final-owned',[r/'owned-pairs.py','--before',r/'before-bin','--after',r/'build-pages-bin','--output',r/'final-owned'])
for name in ['final-owner-controls','nested-final-short','nested-final-long']:
 run(name,[r/(name+'.py')])
 run(name+'-analysis',[r/'analyze-controls.py',r/name/'samples.json',r/name/'analysis.json'])
print('ALL PLANNED SERIES FINISHED; inspect every metric before qualification.',flush=True)
