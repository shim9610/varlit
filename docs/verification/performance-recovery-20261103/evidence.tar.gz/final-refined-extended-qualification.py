from pathlib import Path
import subprocess,json
r=Path('/workspace/scratch/perf-recovery')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:subprocess.run(['python3',*map(str,args)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
def analyze(name):
 run(name+'-analysis',[r/'analyze-controls.py',r/name/'samples.json',r/name/'analysis.json'])
 d=json.loads((r/name/'analysis.json').read_text())
 assert all(x['observed_gates_pass'] for x in d['comparisons']), name+' observed gate failed; every sample retained'
 assert all(abs(x['same_binary_median_percent'])<=5 for x in d['comparisons']), name+' calibration exceeds 5%; every sample retained'
def combine(destination,parts):
 out=r/destination;out.mkdir(exist_ok=False)
 samples=sum([json.loads((r/p/'samples.json').read_text()) for p in parts],[])
 keys=[(x['case'],x['group'],x.get('side',x.get('label'))) for x in samples];assert len(keys)==len(set(keys))
 (out/'samples.json').write_text(json.dumps(samples,indent=2))
 (out/'plans.json').write_text(json.dumps({p:json.loads((r/p/'plan.json').read_text()) for p in parts},indent=2))
 if (r/parts[0]/'summary.json').exists():
  (out/'summary.json').write_text(json.dumps(sum([json.loads((r/p/'summary.json').read_text()) for p in parts],[]),indent=2))
run('final-refined-reference-short-replication',[r/'final-refined-replication.py','--after',r/'refined-bin','--output',r/'final-refined-reference-short-replication','--groups','180','--cases','4'])
run('final-refined-reference-short-replication-analysis',[r/'analyze-controls.py',r/'final-refined-reference-short-replication/samples.json',r/'final-refined-reference-short-replication/analysis.json'])
out=r/'final-refined-reference-short-pooled';out.mkdir(exist_ok=False)
rows=[]
for part,offset in [('final-refined-reference-short',0),('final-refined-reference-short-replication',60)]:
 for x in json.loads((r/part/'samples.json').read_text()):
  x={**x,'series':part,'original_group':x['group'],'group':x['group']+offset};rows.append(x)
assert len(rows)==720 and len({(x['group'],x['label']) for x in rows})==720
(out/'samples.json').write_text(json.dumps(rows,indent=2))
(out/'plan.json').write_text((r/'refined-replication-plan.json').read_text())
analyze('final-refined-reference-short-pooled')
run('final-refined-native-early',[r/'final-refined-four.py','--phase','native','--cases','6','7','8','0','--output',r/'final-refined-native-early'])
run('final-refined-reference-long',[r/'final-refined-reference.py','--after',r/'refined-bin','--output',r/'final-refined-reference-long','--groups','60','--cases','6','7'])
analyze('final-refined-reference-long')
run('final-refined-native-rest',[r/'final-refined-four.py','--phase','native','--cases','2','11','12','1','3','4','5','9','10','--output',r/'final-refined-native-rest'])
combine('final-refined-native',['final-refined-native-early','final-refined-native-rest'])
assert {x['case'] for x in json.loads((r/'final-refined-native/summary.json').read_text())} == set(range(13))
run('final-refined-swmr',[r/'final-refined-four.py','--phase','concurrent','--output',r/'final-refined-swmr'])
run('final-refined-reference-rest',[r/'final-refined-reference.py','--after',r/'refined-bin','--output',r/'final-refined-reference-rest','--groups','60','--cases','0','1','2','3','5'])
combine('final-refined-reference',['final-refined-reference-short-pooled','final-refined-reference-long','final-refined-reference-rest'])
analyze('final-refined-reference')
assert len(json.loads((r/'final-refined-reference/analysis.json').read_text())['comparisons']) == 8
run('final-refined-owned',[r/'owned-pairs.py','--before',r/'adaptive-scratch-bin','--after',r/'refined-bin','--output',r/'final-refined-owned'])
assert all(m['passed'] for x in json.loads((r/'final-refined-owned/summary.json').read_text()) for m in x['metrics'].values()), 'Ownership gate failed; all samples retained'
run('final-refined-owned-initial',[r/'owned-pairs.py','--before',r/'before-bin','--after',r/'refined-bin','--output',r/'final-refined-owned-initial'])
assert all(m['passed'] for x in json.loads((r/'final-refined-owned-initial/summary.json').read_text()) for m in x['metrics'].values()), 'Initial ownership comparison failed; all samples retained'
for name in ['final-refined-owner-controls','final-refined-nested-short','final-refined-nested-long']:
 run(name,[r/(name+'.py')]);analyze(name)
run('final-refined-resources',[r/'final-refined-resources.py'])
print('DONE ALL PLANNED SERIES; inspect resources and statistical limits.',flush=True)
