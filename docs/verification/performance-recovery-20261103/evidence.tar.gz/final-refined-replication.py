"""Predeclared randomized groups; labels old-a/old-b are one exact binary."""
import argparse, hashlib, itertools, json, os, random, statistics, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--after',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--groups',type=int,default=60);p.add_argument('--cases',nargs='+',type=int);a=p.parse_args()
r=Path('/workspace/scratch/perf-recovery');out=a.output;out.mkdir(exist_ok=True)
old=Path('/workspace/varlit-pre-boundary/target/release/examples/record_mutation_load');bins={'old-a':old,'old-b':old,'current':a.after/'record_mutation_load'}
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});env={**os.environ,'TMPDIR':str(r/'disk-data')}
cases=[['writer','variable','random','200000','20000'],['epochs','fixed','random','200000','20000'],['rewrite','variable','random','200000','20000'],['writer','large','reverse','65536','4096'],['writer','mixed','random','131072','8192'],['writer','large','reverse','65536','65536'],['writer','mixed','random','131072','65536']]
cases.append(['rewrite','variable','random','200000','200000'])
(out/'plan.json').write_text(json.dumps({'groups':a.groups,'groups_by_case':{i:a.groups for i in range(8)},'order_balance':'each six-group block uses every label permutation','seed_by_case':'315729 + case + 731913','cases':cases,'selected':a.cases,'sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in bins.items()}},indent=2))
assert a.groups%6==0
rows=[];rng=random.Random(315729);pending=[]
for case,args in enumerate(cases):
 if a.cases is not None and case not in a.cases:continue
 rng=random.Random(315729+case+731913);pending=[]
 for group in range(a.groups):
  if not pending:
   pending.extend(itertools.permutations(bins));rng.shuffle(pending)
  labels=pending.pop()
  for label in labels:
   result=subprocess.run([str(r/'initial/measure'),str(out/'usage.json'),str(bins[label]),*args],capture_output=True,text=True,check=True,env=env,timeout=600)
   row={'case':case,'args':args,'group':group,'label':label,'result':json.loads(result.stdout),'usage':json.loads((out/'usage.json').read_text())};rows.append(row)
   (out/'samples.json').write_text(json.dumps(rows,indent=2));print(case,group,label,row['result']['seconds'],flush=True)
 selected=[x for x in rows if x['case']==case];work=[{k:v for k,v in x['result'].items() if k not in ('seconds','temporary_bytes')} for x in selected];assert all(w==work[0] for w in work)
 med={s:statistics.median(x['result']['seconds'] for x in selected if x['label']==s) for s in bins};print('SUMMARY',case,med,{s:100*(med[s]/med['old-a']-1) for s in med},flush=True)
