from pathlib import Path
import subprocess
r=Path('/workspace/scratch/perf-recovery')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:subprocess.run(['python3',*map(str,args)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
run('final-retained-native',[r/'final-retained-four.py','--phase','native','--output',r/'final-retained-native'])
run('final-retained-swmr',[r/'final-retained-four.py','--phase','concurrent','--output',r/'final-retained-swmr'])
run('final-retained-reference',[r/'final-retained-reference.py','--after',r/'retained-pages-bin','--output',r/'final-retained-reference','--groups','24'])
run('final-retained-reference-analysis',[r/'analyze-controls.py',r/'final-retained-reference/samples.json',r/'final-retained-reference/analysis.json'])
run('final-retained-owned',[r/'owned-pairs.py','--before',r/'before-bin','--after',r/'retained-pages-bin','--output',r/'final-retained-owned'])
for name in ['final-retained-owner-controls','final-retained-nested-short','final-retained-nested-long']:
 run(name,[r/(name+'.py')])
 run(name+'-analysis',[r/'analyze-controls.py',r/name/'samples.json',r/name/'analysis.json'])
run('final-retained-resources',[r/'final-retained-resources.py'])
print('DONE ALL PLANNED SERIES; inspect all metrics/calibration.',flush=True)
