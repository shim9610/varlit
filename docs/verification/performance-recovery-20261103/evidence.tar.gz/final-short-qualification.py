from pathlib import Path
import subprocess
r=Path('/workspace/scratch/perf-recovery')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:subprocess.run(['python3',*map(str,args)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
run('final-short-native',[r/'final-short-four.py','--phase','native','--output',r/'final-short-native'])
run('final-short-swmr',[r/'final-short-four.py','--phase','concurrent','--output',r/'final-short-swmr'])
run('final-short-reference',[r/'final-short-reference.py','--after',r/'short-prefix-bin','--output',r/'final-short-reference','--groups','24'])
run('final-short-reference-analysis',[r/'analyze-controls.py',r/'final-short-reference/samples.json',r/'final-short-reference/analysis.json'])
run('final-short-owned',[r/'owned-pairs.py','--before',r/'before-bin','--after',r/'short-prefix-bin','--output',r/'final-short-owned'])
for name in ['final-short-owner-controls','final-short-nested-short','final-short-nested-long']:
 run(name,[r/(name+'.py')])
 run(name+'-analysis',[r/'analyze-controls.py',r/name/'samples.json',r/name/'analysis.json'])
run('final-short-resources',[r/'final-short-resources.py'])
print('DONE ALL PLANNED SERIES; inspect all metrics/calibration.',flush=True)
