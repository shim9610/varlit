from pathlib import Path
import json,subprocess,os
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');dirs={'initial-before':r/'before-bin','qualified-before':r/'read-hint-bin','unit-before':r/'retained-pages-bin','after':r/'short-prefix-bin','original':Path('/workspace/varlit-pre-boundary/target/release/examples')}
for mode,args in [('rewrite',['record_mutation_load','rewrite','variable','random','200000','20000']),('complex',['oom_maintenance_load','complex','65536','512']),('rewrite-2m',['record_mutation_load','rewrite','variable','random','2000000','20000']),('rewrite-mixed',['record_mutation_load','rewrite','mixed','random','32768','8192'])]:
 for side,d in dirs.items():
  if side=='original' and not mode.startswith('rewrite'):continue
  stem=f'final-short-resource-{mode}-{side}'
  with (r/(stem+'.log')).open('w') as f:
   subprocess.run(['python3',str(repo/'docs/performance/audit-followup-20261102/resource_probe.py'),'--output',str(r/(stem+'.json')),str(d/args[0]),*args[1:]],env={**os.environ,'TMPDIR':str(r/'disk-data')},stdout=f,stderr=subprocess.STDOUT,check=True)
  print(mode,side,json.loads((r/(stem+'.json')).read_text())['peaks'],flush=True)
