from pathlib import Path
import json
r=Path('/workspace/scratch/perf-recovery');out=[]
def read(name):return json.loads((r/name).read_text())
def pct(v):return 'n/a' if v is None else f'{v:+.2f}%'
labels=['Fixed writer 2M / 200k marks','Variable writer 200k / 20k random marks','After rewrite 200k / 20k random marks','MarkTail recovery 200k','4GiB large / 4,096 reverse marks','4GiB reopened / 4,096 reverse marks','4GiB mixed / 8,192 random marks','Complex maintenance 65,536 / 512B','Checkpoint rewrite 200k / 256B','Chunk build 64MiB x20','Decode 64MiB x20','After rewrite 2M / 20k random marks','After mixed rewrite ~1GiB / 8,192 marks']
n=read('final-refined-native/summary.json');out+=['## Final native measurements','','Operation time excludes fixture creation; rewrite mark modes time marking after rewrite. CPU covers the entire child process. Changes are medians except maximum RSS/private final file length.','','| Workload | Groups | Time vs 749 | CPU vs 749 | RSS vs 749 | Time vs a2c | CPU vs a2c | Final private bytes |','| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for x in sorted(n,key=lambda x:x['case']):
 m=x['metrics'];vals=[pct(m[k]['comparisons'][b]['change_percent']) for k,b in [('seconds','qualified-before'),('cpu','qualified-before'),('rss','qualified-before'),('seconds','unit-before'),('cpu','unit-before')]];temp=str(m['temporary_bytes']['values']['after']) if x['case'] not in [7,8,9,10] else 'not collected';out.append('| '+' | '.join([labels[x['case']],str(x['groups']),*vals,temp])+' |')
out+=['','Maintenance/codec harnesses do not report final deleted-file lengths. Their internal zero placeholders are not temporary-space measurements. Separate probes cover complex/checkpoint and large rewrites. Codec cases do not create spill files.','','## Original native controls','','| Case | Groups | Time vs old-a / old-b | CPU vs old-a / old-b | Same binary b/a | Conservative time 95% interval |','| --- | ---: | ---: | ---: | ---: | ---: |']
h=read('final-refined-reference/analysis.json')
for x in h['comparisons']:
 m=x['metrics'];changes=lambda k:' / '.join(pct(m[k]['current_change_percent'][s]) for s in ['old-a','old-b']);ci=x['paired_group_bootstrap_95_percent']['conservative_current'];out.append(f"| {x['case']} | {x['groups']} | {changes('seconds')} | {changes('cpu')} | {pct(x['same_binary_median_percent'])} | [{pct(ci[0])}, {pct(ci[1])}] |")
out+=['','Observed gates and calibration are separate from the bootstrap upper bound. A passing observed gate does not establish a universal 5% bound.','','## SWMR write phase','','Eight followers plus one pinned reader; checks/epoch and trace hashes must match.','','| Size | Groups | Before | Wall | CPU | RSS | Writes |','| --- | ---: | --- | ---: | ---: | ---: | ---: |']
sw=read('final-refined-swmr/summary.json')
for size,x in sw.items():
 for before,c in x['comparisons'].items():out.append('| '+' | '.join([size+'GiB',str(x['groups']),before,*[pct(c['metrics'][k]['change_percent']) for k in ['wall_seconds','cpu_seconds','observed_peak_rss_bytes','write_bytes']]])+' |')
for name,title in [('final-refined-owned','Ownership vs direct a2c'),('final-refined-owned-initial','Ownership vs initial 0e')]:
 out+=['','## '+title,'','| Work | Pairs | Time | CPU | RSS |','| --- | ---: | ---: | ---: | ---: |']
 for x in read(name+'/summary.json'):out.append('| '+' | '.join([' '.join(x['args']),str(x['pairs']),*[pct(x['metrics'][k]['change_percent']) for k in ['seconds','cpu','rss']]])+' |')
for name,title in [('final-refined-owner-controls','Original ownership controls'),('final-refined-nested-short','Std nested short'),('final-refined-nested-long','Std nested long')]:
 out+=['','## '+title,'','| Case | Groups | Time vs old-a / old-b | Same binary b/a | Conservative time 95% interval |','| --- | ---: | ---: | ---: | ---: |']
 for x in read(name+'/analysis.json')['comparisons']:
  ci=x['paired_group_bootstrap_95_percent']['conservative_current'];m=x['metrics']['seconds']['current_change_percent'];out.append(f"| {x['case']} | {x['groups']} | {pct(m['old-a'])} / {pct(m['old-b'])} | {pct(x['same_binary_median_percent'])} | [{pct(ci[0])}, {pct(ci[1])}] |")
out+=['','## Separate resource probes','','5ms sampled peaks; these runs do not replace operation timing. RSS includes stack/heap; cgroup includes filesystem cache and the rest of this fixed-budget workspace. Open regular-file allocation includes source/replacement generations; deleted temporary allocation is shown separately.','','| Work | Version | Peak RSS MiB | Private allocated bytes | All open allocated bytes | Cgroup GiB |','| --- | --- | ---: | ---: | ---: | ---: |']
probes=[]
for mode in ['rewrite','complex','checkpoint','rewrite-2m','rewrite-mixed']:
 for side in ['original','initial-before','qualified-before','unit-before','after']:
  p=r/f'final-refined-resource-{mode}-{side}.json'
  if not p.exists():continue
  d=json.loads(p.read_text());assert d['exit']==0;probes.append(d);m=d['peaks'];out.append(f"| {mode} | {side} | {m['rss_bytes']/2**20:.2f} | {m['temporary_deleted_allocated_bytes']} | {m['open_regular_allocated_bytes']} | {m['cgroup_current_bytes']/2**30:.3f} |")
counts={'native_timing_observations':sum(x['groups']*4 for x in n),'historical_timing_observations':len(read('final-refined-reference/samples.json')),'swmr_write_runs':sum(x['groups']*4 for x in sw.values()),'direct_ownership':len(read('final-refined-owned/samples.json')),'initial_ownership':len(read('final-refined-owned-initial/samples.json')),'original_ownership_controls':len(read('final-refined-owner-controls/samples.json')),'std_nested_short':len(read('final-refined-nested-short/samples.json')),'std_nested_long':len(read('final-refined-nested-long/samples.json')),'separate_resource_probes':len(probes)}
(r/'final-counts.json').write_text(json.dumps(counts,indent=2)+'\n');(r/'final-tables.md').write_text('\n'.join(out)+'\n');print(counts)
