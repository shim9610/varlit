set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
export CARGO_INCREMENTAL=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0
cargo fmt --all -- --check
cargo test --locked --workspace --all-features > /workspace/scratch/perf-recovery/footer-boundary-workspace-all.log 2>&1
cargo test --locked --workspace > /workspace/scratch/perf-recovery/footer-boundary-workspace-default.log 2>&1
cargo clippy --locked --workspace --all-features --all-targets -- -D warnings > /workspace/scratch/perf-recovery/footer-boundary-clippy.log 2>&1
cargo build --locked --release --workspace --all-features --example record_mutation_load --example oom_maintenance_load --example scalable_load --example ownership_load --example ownership_boundary_load > /workspace/scratch/perf-recovery/footer-boundary-build.log 2>&1
MIRIFLAGS=-Zmiri-disable-isolation cargo +nightly-2026-10-12 miri test -p varlit-core --all-features --lib scalar_footer_decoder_matches_table_on_corruption_and_pointer_edges > /workspace/scratch/perf-recovery/footer-boundary-decoder-miri.log 2>&1
MIRIFLAGS=-Zmiri-disable-isolation cargo +nightly-2026-10-12 miri test -p varlit-core --all-features --lib uniform_prefix_never_authorizes_unobserved_or_truncated_offsets > /workspace/scratch/perf-recovery/footer-boundary-membership-miri.log 2>&1
cargo fmt --all -- --check
git diff --check
