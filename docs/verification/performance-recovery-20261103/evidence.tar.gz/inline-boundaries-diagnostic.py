from pathlib import Path
import subprocess,shutil,hashlib,json,os,random,statistics
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');out=r/'inline-boundaries-diagnostic';out.mkdir(exist_ok=False)
names=['file.rs','file/header_codec.rs','file/validation_tests.rs','native_directory.rs','packed_rows.rs','snapshot.rs','native_layout.rs'];paths={n:repo/'crates/varlit-core/src'/n for n in names};original={n:p.read_text() for n,p in paths.items()}
profile=repo/'crates/varlit/examples/record_phase_cpu.rs';assert not profile.exists();s=(r/'prefix-inline-factorial/record_phase_cpu.rs').read_text();(out/'record_phase_cpu.rs').write_text(s)
labels=['previous-749','retained-d7','footer-inline','footer-boundary-inline'];args=['writer','fixed','forward','2000000','200000'];plan={'purpose':'diagnostic only, fixed512read retained; same phase CPU harness, inline existing footer decoder and verified-boundary predicate without body edits','groups':12,'seed':711894,'variants':{},'args':args};(out/'plan.json').write_text(json.dumps(plan,indent=2))
try:
 profile.write_text(s)
 for label in labels:
  for n,p in paths.items():
   content=subprocess.check_output(['git','show',f'749532d:crates/varlit-core/src/{n}'],cwd=repo,text=True) if label=='previous-749' else original[n]
   if n=='native_layout.rs' and label.startswith('footer'):
    needle='pub(crate) fn decode_native_record_footer(';assert content.count(needle)==1;content=content.replace(needle,'#[inline]\n'+needle)
   if n=='native_directory.rs' and label=='footer-boundary-inline':
    needle='    pub(crate) fn has_verified_boundary(';assert content.count(needle)==1;content=content.replace(needle,'    #[inline]\n'+needle)
   p.write_text(content)
  print('BUILD',label,flush=True)
  with (out/(label+'-build.log')).open('w') as f:subprocess.run(['cargo','build','--locked','--release','-p','varlit','--all-features','--example','record_phase_cpu'],cwd=repo,stdout=f,stderr=subprocess.STDOUT,check=True)
  dest=out/(label+'-bin');dest.mkdir();shutil.copy2(repo/'target/release/examples/record_phase_cpu',dest/'record_phase_cpu')
  plan['variants'][label]={'sources':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in paths.items()},'binary_sha256':hashlib.sha256((dest/'record_phase_cpu').read_bytes()).hexdigest()};(out/'plan.json').write_text(json.dumps(plan,indent=2))
finally:
 for n,p in paths.items():p.write_text(original[n])
 profile.unlink(missing_ok=True)
 (out/'source-restored.json').write_text(json.dumps({n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in paths.items()},indent=2))
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});rng=random.Random(711894);orders=[];samples=[]
for group in range(12):
 if not orders:
  names=labels.copy();rng.shuffle(names);orders=[[names[i] for i in order] for order in [[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1]]];rng.shuffle(orders)
 for label in orders.pop():
  x=subprocess.run([str(r/'initial/measure'),str(out/'usage.json'),str(out/(label+'-bin')/'record_phase_cpu'),*args],capture_output=True,text=True,env={**os.environ,'TMPDIR':str(r/'disk-data')},check=True)
  row={'group':group,'label':label,'result':json.loads(x.stdout),'usage':json.loads((out/'usage.json').read_text()),'mark_cpu':float(x.stderr.strip())};samples.append(row);(out/'samples.json').write_text(json.dumps(samples,indent=2));print(group,label,row['result']['seconds'],row['mark_cpu'],flush=True)
work=[{k:v for k,v in x['result'].items() if k not in ('seconds','temporary_bytes')} for x in samples];assert all(x==work[0] for x in work)
summary={label:{metric:agg(get(x) for x in samples if x['label']==label) for metric,get,agg in [('wall',lambda x:x['result']['seconds'],statistics.median),('mark_cpu',lambda x:x['mark_cpu'],statistics.median),('process_cpu',lambda x:x['usage']['cpu'],statistics.median),('rss',lambda x:x['usage']['rss'],max),('writes',lambda x:x['usage']['write_blocks'],statistics.median),('temporary_bytes',lambda x:x['result']['temporary_bytes'],max)]} for label in labels}
(out/'summary.json').write_text(json.dumps(summary,indent=2));print('SUMMARY',summary,flush=True)
