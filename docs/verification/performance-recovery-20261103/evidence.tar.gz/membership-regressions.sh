set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
cargo fmt --all -- --check
cargo test -p varlit-core --all-features > /workspace/scratch/perf-recovery/membership-core-all.log 2>&1
cargo test -p varlit-core > /workspace/scratch/perf-recovery/membership-core-default.log 2>&1
cargo test -p varlit --all-features --test oom_recovery_guards --test publication_failure_results --test record_liveness --test validation_coverage > /workspace/scratch/perf-recovery/membership-public.log 2>&1
cargo clippy --workspace --all-features --all-targets -- -D warnings > /workspace/scratch/perf-recovery/membership-clippy.log 2>&1
cargo build --locked --release --workspace --all-features --example record_mutation_load --example oom_maintenance_load --example scalable_load --example ownership_load --example ownership_boundary_load > /workspace/scratch/perf-recovery/membership-build-final.log 2>&1
MIRIFLAGS=-Zmiri-disable-isolation cargo +nightly-2026-10-12 miri test -p varlit-core --all-features --lib file::resident_index::tests::rewritten_membership_hints_preserve_gaps_and_truncated_prefixes > /workspace/scratch/perf-recovery/membership-miri.log 2>&1
cargo fmt --all -- --check
git diff --check
