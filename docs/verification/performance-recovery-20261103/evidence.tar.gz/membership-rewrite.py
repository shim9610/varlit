"""Predeclared equal-work long mixed test, four randomized labels, all samples retained."""
from pathlib import Path
import hashlib,json,os,random,statistics,subprocess
r=Path('/workspace/scratch/perf-recovery');out=r/'membership-rewrite';out.mkdir(exist_ok=True)
old=Path('/workspace/varlit-pre-boundary/target/release/examples/record_mutation_load')
bins={'old-a':old,'old-b':old,'earlier-before':r/'read-hint-bin/record_mutation_load','unit-before':r/'inline-read-bin/record_mutation_load','after':r/'membership-bin/record_mutation_load'}
args=['rewrite', 'variable', 'random', '200000', '200000'];rng=random.Random(816372);rows=[];os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
# Williams rows balance position and directed adjacent treatment pairs.
base=[[(i+j)%5 for i in [0,1,4,2,3]] for j in range(5)]
base += [row[::-1] for row in base.copy()]
orders=[]
for block in range(2):
 labels=list(bins);rng.shuffle(labels);patterns=base.copy();rng.shuffle(patterns)
 orders.extend([[labels[i] for i in order] for order in patterns])
assert all(sum(order[pos]==side for order in orders)==4 for side in bins for pos in range(5))
assert all(sum(sum(a==left and b==right for a,b in zip(order,order[1:])) for order in orders)==4 for left in bins for right in bins if left!=right)
(out/'plan.json').write_text(json.dumps({'seed':816372,'groups':20,'limit_percent':5,'args':args,'orders':orders,'reason':'20 predeclared five-version Williams groups qualify eight-row published pages and actual-key reuse; earlier candidates and reference labels remain separate','sha256':{s:hashlib.sha256(b.read_bytes()).hexdigest() for s,b in bins.items()}},indent=2))

def summary():
 metrics={}
 for name,get,agg in [('seconds',lambda r:r['result']['seconds'],statistics.median),('cpu',lambda r:r['usage']['cpu'],statistics.median),('rss',lambda r:r['usage']['rss'],max),('writes',lambda r:r['usage']['write_blocks']*512,statistics.median),('temporary_bytes',lambda r:r['result'].get('temporary_bytes',0),max)]:
  v={s:agg(get(x) for x in rows if x['side']==s) for s in bins}
  metrics[name]={'values':v,'comparisons':{s:{'change_percent':100*(v['after']/v[s]-1) if v[s] else (0 if v['after']==0 else None),'passed':v['after']<=v[s]*1.05} for s in bins if s!='after'}}
 return {'groups':len(rows)//5,'metrics':metrics,'passed':all(c['passed'] for m in metrics.values() for c in m['comparisons'].values())}
for stage,(start,end) in enumerate([(0,20)]):
 if stage and summary()['passed']:break
 for group in range(start,end):
  labels=orders[group]
  for side in labels:
   p=subprocess.run([str(r/'initial/measure'),str(out/'usage.json'),str(bins[side]),*args],capture_output=True,text=True,check=True,env={**os.environ,'TMPDIR':str(r/'disk-data')})
   row={'group':group,'side':side,'result':json.loads(p.stdout),'usage':json.loads((out/'usage.json').read_text())};rows.append(row);(out/'samples.json').write_text(json.dumps(rows,indent=2));print(group,side,row['result']['seconds'],flush=True)
 work=[{k:v for k,v in x['result'].items() if k not in ('seconds','temporary_bytes')} for x in rows];assert all(x==work[0] for x in work)
 result=summary();(out/'summary.json').write_text(json.dumps(result,indent=2));print('SUMMARY',stage,json.dumps(result),flush=True)
aa={name:100*(max(m['values']['old-a'],m['values']['old-b'])/min(m['values']['old-a'],m['values']['old-b'])-1) if min(m['values']['old-a'],m['values']['old-b']) else 0 for name,m in result['metrics'].items()}
result['same_binary_absolute_difference_percent']=aa
result['calibration_passed']=all(v<=5 for v in aa.values())
(out/'summary.json').write_text(json.dumps(result,indent=2))
print('CALIBRATION',aa,flush=True)
if not (result['passed'] and result['calibration_passed']):raise SystemExit('Failed focus gate; all planned samples retained')
