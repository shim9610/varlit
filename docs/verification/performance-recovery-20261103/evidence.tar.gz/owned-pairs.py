import argparse,hashlib,json,os,statistics,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--before',type=Path,required=True);p.add_argument('--after',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(exist_ok=True)
r=Path('/workspace/scratch/perf-recovery');bins={'before':a.before,'after':a.after};os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
cases=[('ownership_load',['bytes','67108864','16']),('ownership_load',['bytes','1073741824','2']),('ownership_load',['nested','16384','16']),('ownership_boundary_load',['box','10000000']),('ownership_boundary_load',['nested-box','8000']),('ownership_boundary_load',['shared','10000000'])]
(a.output/'provenance.json').write_text(json.dumps({s:{n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in ['ownership_load','ownership_boundary_load']} for s,d in bins.items()},indent=2))
rows=[];summaries=[]
def summary(selected):
 metrics={}
 for name,get,agg in [('seconds',lambda r:r['result']['seconds'],statistics.median),('cpu',lambda r:r['usage']['cpu'],statistics.median),('rss',lambda r:r['usage']['rss'],max),('writes',lambda r:r['usage']['write_blocks']*512,statistics.median)]:
  values={s:agg(get(r) for r in selected if r['side']==s) for s in bins};delta=100*(values['after']/values['before']-1) if values['before'] else (0 if values['after']==0 else None)
  metrics[name]={**values,'change_percent':delta,'passed':values['after']<=values['before']*1.05}
 return metrics
for case,(exe,args) in enumerate(cases):
 selected=[]
 for stage,(start,end) in enumerate([(0,5),(5,20)]):
  if stage and all(x['passed'] for x in summary(selected).values()):break
  for pair in range(start,end):
   for side in (['before','after'] if pair%2==0 else ['after','before']):
    x=subprocess.run([str(r/'initial/measure'),str(a.output/'usage.json'),str(bins[side]/exe),*args],capture_output=True,text=True,check=True,timeout=600)
    row={'case':case,'args':args,'pair':pair,'side':side,'result':json.loads(x.stdout),'usage':json.loads((a.output/'usage.json').read_text())};selected.append(row);rows.append(row)
    (a.output/'samples.json').write_text(json.dumps(rows,indent=2));print(case,pair,side,row['result']['seconds'],flush=True)
 work=[{k:v for k,v in x['result'].items() if k!='seconds'} for x in selected];assert all(w==work[0] for w in work)
 result={'case':case,'binary':exe,'args':args,'pairs':len(selected)//2,'metrics':summary(selected)};summaries.append(result)
 (a.output/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',case,json.dumps(result),flush=True)
