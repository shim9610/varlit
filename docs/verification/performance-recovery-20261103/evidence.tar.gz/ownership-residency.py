from pathlib import Path
import subprocess,time,json,re
r=Path('/workspace/scratch/perf-recovery');results=[]
for side in ['compact','string','allocation']:
 for trial in range(3):
  binary=r/(side+'-bin')/'ownership_boundary_load'
  child=subprocess.Popen([str(binary),'nested-box','80000'],stdout=subprocess.PIPE,text=True)
  snapshots=[]
  while child.poll() is None:
   try:
    groups={};name='';maps=Path(f'/proc/{child.pid}/smaps').read_text()
    for line in maps.splitlines():
     if re.match(r'^[0-9a-f]+-[0-9a-f]+ ',line):
      fields=line.split(maxsplit=5);name=fields[5] if len(fields)>5 else '(anonymous)';groups.setdefault(name,{'Rss':0,'Anonymous':0,'Private_Dirty':0,'Private_Clean':0})
     else:
      fields=line.split()
      if fields and fields[0].rstrip(':') in groups.get(name,{}):groups[name][fields[0].rstrip(':')]+=int(fields[1])*1024
    snapshots.append({'groups':groups,'total_rss':sum(v['Rss'] for v in groups.values())})
   except (FileNotFoundError,ProcessLookupError):pass
   time.sleep(.1)
  output=child.communicate()[0];assert child.returncode==0
  result={'side':side,'trial':trial,'result':json.loads(output),'peak_snapshot':max(snapshots,key=lambda x:x['total_rss'])};results.append(result)
  (r/'ownership-residency.json').write_text(json.dumps(results,indent=2))
  print(side,trial,result['peak_snapshot'],flush=True)
