use std::{hint::black_box, time::Instant};
use varlit_core::{Error, Result, TryClone};
#[inline]
fn slots(source: &[String]) -> Result<Vec<String>> {
    let mut output = Vec::new();
    output.try_reserve_exact(source.len()).map_err(|_| Error::AllocationFailed { resource: "vector clone", requested: source.len().saturating_mul(size_of::<String>()) as u64 })?;
    output.resize_with(source.len(), String::new);
    for (source, target) in source.iter().zip(&mut output) {
        target.try_reserve_exact(source.len()).map_err(|_| Error::AllocationFailed { resource: "string clone", requested: source.len() as u64 })?;
        target.push_str(source);
    }
    Ok(output)
}
#[inline]
fn nested_slots(source: &[Vec<String>]) -> Result<Vec<Vec<String>>> {
    let mut output = Vec::new();
    output.try_reserve_exact(source.len()).map_err(|_| Error::AllocationFailed { resource: "vector clone", requested: source.len().saturating_mul(size_of::<Vec<String>>()) as u64 })?;
    for value in source { output.push(slots(value)?); }
    Ok(output)
}
fn measure(mut clone: impl FnMut() -> Vec<Vec<String>>) -> (f64,u64) {
    let start=Instant::now();let mut sum=0;
    for _ in 0..16 { let copy=clone();sum+=copy.len() as u64+copy.last().unwrap()[3].len() as u64;black_box(&copy); }
    (start.elapsed().as_secs_f64(),sum)
}
fn main() {
    let mode=std::env::args().nth(1).unwrap();
    let source=vec![vec![String::from("0123456789abcdef0123456789abcdef");4];16384];
    let (seconds,sum)=match mode.as_str() { "std"=>measure(||source.clone()), "current"=>measure(||source.try_clone().unwrap()), "slots"=>measure(||nested_slots(&source).unwrap()), _=>panic!() };
    println!("{{\"seconds\":{seconds},\"sum\":{sum}}}");
}
