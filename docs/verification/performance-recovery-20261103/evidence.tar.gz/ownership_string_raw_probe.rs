use std::{hint::black_box, time::Instant};
use varlit_core::{Error, Result, TryClone};
#[inline]
fn slots(source: &[String]) -> Result<Vec<String>> {
    let mut output = Vec::new();
    output.try_reserve_exact(source.len()).map_err(|_| Error::AllocationFailed { resource: "vector clone", requested: source.len().saturating_mul(size_of::<String>()) as u64 })?;
    output.resize_with(source.len(), String::new);
    for (source, target) in source.iter().zip(&mut output) {
        target.try_reserve_exact(source.len()).map_err(|_| Error::AllocationFailed { resource: "string clone", requested: source.len() as u64 })?;
        target.push_str(source);
    }
    Ok(output)
}
#[inline]
fn nested_slots(source: &[Vec<String>]) -> Result<Vec<Vec<String>>> {
    let mut output = Vec::new();
    output.try_reserve_exact(source.len()).map_err(|_| Error::AllocationFailed { resource: "vector clone", requested: source.len().saturating_mul(size_of::<Vec<String>>()) as u64 })?;
    for value in source { output.push(slots(value)?); }
    Ok(output)
}
#[inline]
fn mapped(source: &[String]) -> Result<Vec<String>> {
    let mut output=Vec::new();
    output.try_reserve_exact(source.len()).map_err(|_| Error::AllocationFailed { resource:"vector clone", requested:source.len().saturating_mul(size_of::<String>()) as u64 })?;
    let mut error=None;
    output.extend(source.iter().map(|value| {
        if error.is_some() { return String::new(); }
        match value.try_clone() { Ok(value)=>value, Err(failed)=>{error=Some(failed);String::new()} }
    }));
    match error { Some(error)=>Err(error), None=>Ok(output) }
}
#[inline]
fn nested_mapped(source: &[Vec<String>]) -> Result<Vec<Vec<String>>> {
    let mut output=Vec::new();
    output.try_reserve_exact(source.len()).map_err(|_| Error::AllocationFailed { resource:"vector clone", requested:source.len().saturating_mul(size_of::<Vec<String>>()) as u64 })?;
    for value in source { output.push(mapped(value)?); }
    Ok(output)
}
#[inline]
fn vacant<T>(len: usize) -> Result<Vec<T>> {
    if len==0 || size_of::<T>()==0 { return Ok(Vec::new()); }
    let failed=||Error::AllocationFailed { resource:"clone", requested:len.saturating_mul(size_of::<T>()) as u64 };
    let layout=std::alloc::Layout::array::<T>(len).map_err(|_|failed())?;
    // The nonzero array layout is checked; null is returned as an error.
    let pointer=unsafe {std::alloc::alloc(layout)}.cast::<T>();
    if pointer.is_null() { return Err(failed()); }
    // Same global allocator/layout; zero length publishes no uninitialized T.
    Ok(unsafe {Vec::from_raw_parts(pointer,0,len)})
}
#[inline]
fn raw_strings(source: &[String]) -> Result<Vec<String>> {
    let mut output=vacant(source.len())?;
    for value in source {
        let mut bytes=vacant(value.len())?;
        bytes.extend_from_slice(value.as_bytes());
        // All bytes are initialized copies of a valid String.
        output.push(unsafe {String::from_utf8_unchecked(bytes)});
    }
    Ok(output)
}
#[inline]
fn nested_raw(source: &[Vec<String>]) -> Result<Vec<Vec<String>>> {
    let mut output=vacant(source.len())?;
    for value in source {output.push(raw_strings(value)?);}
    Ok(output)
}
fn measure(mut clone: impl FnMut() -> Vec<Vec<String>>) -> (f64,u64) {
    let start=Instant::now();let mut sum=0;
    for _ in 0..16 { let copy=clone();sum+=copy.len() as u64+copy.last().unwrap()[3].len() as u64;black_box(&copy); }
    (start.elapsed().as_secs_f64(),sum)
}
fn main() {
    let mode=std::env::args().nth(1).unwrap();
    let source=vec![vec![String::from("0123456789abcdef0123456789abcdef");4];16384];
    let (seconds,sum)=match mode.as_str() { "std"=>measure(||source.clone()), "current"=>measure(||source.try_clone().unwrap()), "slots"=>measure(||nested_slots(&source).unwrap()), "mapped"=>measure(||nested_mapped(&source).unwrap()), "raw"=>measure(||nested_raw(&source).unwrap()), _=>panic!() };
    println!("{{\"seconds\":{seconds},\"sum\":{sum}}}");
}
