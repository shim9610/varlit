"""Package every completed qualification and retained adverse observation."""
from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');out=repo/'docs/verification/performance-recovery-20261103'
def read(p):return json.loads((r/p).read_text())
units={
 'decoder':{'native':read('decoder-pooled.json'),'swmr':{n:read(f'decoder-swmr/swmr-{n}-comparison.json') for n in ['1','4']}},
 'compact_intermediate':{'native':read('compact-pooled.json'),'swmr':{n:read(f'compact-swmr/swmr-{n}-comparison.json') for n in ['1','4']}},
 'string':{'native':read('string-reserve-pooled.json'),'ownership':read('string-reserve-owned/summary.json'),'swmr':{n:read(f'string-reserve-swmr/swmr-{n}-comparison.json') for n in ['1','4']}},
 'search':{'native':read('search-native/summary.json')},
 'construction_pages':{'native':read('build-pages-native/summary.json'),'historical':read('final-reference/analysis.json'),'swmr':read('final-swmr/summary.json')},
 'read_hint':{'native':read('read-hint-native/summary.json'),'initial_focus':read('read-hint-focus/summary.json'),'balanced_focus':read('read-hint-balanced/summary.json')},
}
final={'native':read('final-refined-native/summary.json'),'swmr':read('final-refined-swmr/summary.json'),'original_native':read('final-refined-reference/analysis.json'),'ownership':read('final-refined-owned/summary.json'),'ownership_initial':read('final-refined-owned-initial/summary.json'),'original_ownership':read('final-refined-owner-controls/analysis.json'),'std_nested_short':read('final-refined-nested-short/analysis.json'),'std_nested_long':read('final-refined-nested-long/analysis.json'),'provenance':read('refined-provenance.json'),'resource_probes':{p.stem:json.loads(p.read_text()) for p in r.glob('final-refined-resource-*.json')}}
final['measurement_notes']={'native_temporary_bytes':'Returned by record_mutation_load only. Maintenance/chunks/decode internal zero placeholders are not temporary-file measurements. Separate complex/checkpoint/rewrite probes collect peak deleted/open file allocation; codec workloads do not create spill files.','resource_probe_plan':'23 probes: five rewrite200k, four complex, four checkpoint, five rewrite2m, five rewrite-mixed, unchanged budgets.'}
# Earlier full results remain separate; a later pass never rewrites them.
units['read_hint'].update({'swmr':read('read-hint-swmr/summary.json'),'historical':read('read-hint-reference/analysis.json')})
units['later_intermediates']={str(p.relative_to(r)):json.loads(p.read_text()) for pattern in ['entry-validation-*/summary.json','inline-read-*/summary.json','membership-*/summary.json'] for p in r.glob(pattern)}
units['rejected_eight_row_pages']={'spill_diagnostic':read('membership-spill-diagnostic.json')}
units['retained_pages']={'spill_diagnostic':read('retained-pages-spill-diagnostic.json'),'partial_native':read('final-retained-native/summary.json'),'resources':{p.stem:json.loads(p.read_text()) for p in r.glob('retained-pages-resource-*.json')}}
units['rejected_short_prefix']={'partial_native':read('final-short-native/summary.json'),'provenance':read('short-prefix-provenance.json')}
units['footer_inline_candidate']={'partial_native':read('final-footer-native-fixed/summary.json'),'provenance':read('footer-boundary-provenance.json')}
units['borrow_policy_candidate']={'partial_native':read('final-borrow-native-fixed/summary.json'),'provenance':read('borrow-policy-provenance.json')}
units['call_shape_candidate']={'fixed_native':read('final-call-native-fixed/summary.json'),'partial_native_rest':read('final-call-native-rest/summary.json'),'provenance':read('call-shape-provenance.json'),'historical_long':read('final-call-reference-long/analysis.json')}
units['adaptive_scratch_candidate']={'native':read('final-adaptive-native/summary.json'),'swmr':read('final-adaptive-swmr/summary.json'),'historical':read('final-adaptive-reference/analysis.json'),'provenance':read('adaptive-scratch-provenance.json'),'status':'Rejected short mixed observed time and same-binary calibration; ownership/resource stages did not run.'}
checks={'native':all(x['passed'] for x in final['native']), 'swmr':all(c['status']=='passed' for x in final['swmr'].values() for c in x['comparisons'].values()),'ownership':all(m['passed'] for x in final['ownership'] for m in x['metrics'].values())}
checks['ownership_initial']=all(m['passed'] for x in final['ownership_initial'] for m in x['metrics'].values())
for name in ['original_native','original_ownership','std_nested_short','std_nested_long']:
 checks[name]=all(x['observed_gates_pass'] for x in final[name]['comparisons'])
for name in ['original_native','original_ownership','std_nested_short','std_nested_long']:
 checks[name+'_calibration']=all(abs(x['same_binary_median_percent'])<=5 for x in final[name]['comparisons'])
data={'initial_head':'0e9abd7f5296636a460ddf533637ae3a01ecac90','verification_head':final['provenance']['committed_head'],'implementation_head':final['provenance']['committed_head'],'cpu_quota':'400000 100000','memory_limit_bytes':17179869184,'limit_percent':5,'units':units,'final':final,'observed_gate_results':checks,'scope':'Observed equal-work measurements, not a universal performance or OOM proof. Intermediate failed variants and all planned observations retained.'}
(out/'results.json').write_text(json.dumps(data,indent=2)+'\n')
print('OBSERVED GATES',checks,flush=True)
# Keep source, raw measurements, logs, disassembly, failed variants and provenance.
# Executables/build products and workload data are deliberately not evidence.
files=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 parts=p.relative_to(r).parts
 if any(x.endswith('-bin') or x in ('bin','build','target','disk-data','__pycache__') for x in parts):continue
 if p.name in ('HANDOFF.md','evidence-manifest.json','package-results.log','pr-body-draft.md'):continue
 with p.open('rb') as f:magic=f.read(4)
 if magic==b'\x7fELF':continue
 if p.stat().st_size>32*1024*1024:raise ValueError(f'unexpected large evidence {p}')
 files.append(p)
manifest=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(r/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.xz','w:xz',preset=6) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
 tar.add(r/'evidence-manifest.json',arcname='evidence-manifest.json',recursive=False)
digest=hashlib.sha256((out/'evidence.tar.xz').read_bytes()).hexdigest();(out/'evidence.sha256').write_text(digest+'  evidence.tar.xz\n')
print('ARCHIVE',len(files),(out/'evidence.tar.xz').stat().st_size,flush=True)
