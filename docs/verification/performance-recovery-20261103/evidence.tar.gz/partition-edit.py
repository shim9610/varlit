from pathlib import Path
p=Path('/workspace/varlit/crates/varlit-core/src/spill_rows.rs')
s=p.read_text()
old="""            let (mut low, mut high) = (0, count);
            while low < high {
                let middle = low + (high - low) / 2;
                if key(&bytes[middle * N..(middle + 1) * N]) <= wanted {
                    low = middle + 1;
                } else {
                    high = middle;
                }
            }
            bytes[(low - 1) * N..low * N].try_into().ok()"""
new="""            // The standard slice search uses a fixed iteration schedule and
            // branchless bound selection for unpredictable irregular offsets.
            // It still compares real private rows, never an estimated boundary.
            let (rows, remainder) = bytes.as_chunks::<N>();
            debug_assert!(remainder.is_empty());
            let end = rows.partition_point(|row| key(row) <= wanted);
            end.checked_sub(1).and_then(|at| rows.get(at)).copied()"""
assert old in s;s=s.replace(old,new,1)
anchor='''    #[test]
    fn read_promotion_is_bounded_and_preserves_retry_after_short_io()'''
test='''    #[test]
    fn cached_floor_matches_ordered_rows_across_irregular_and_full_width_gaps() -> io::Result<()> {
        for count in [1usize, 2, 63, 64, 65, 256] {
            for shape in 0..3 {
                let keys: Vec<u64> = (0..count)
                    .scan(0u64, |previous, i| {
                        let key = match shape {
                            0 => *previous + 64 + (i as u64 * 8191 % 65536),
                            1 => i as u64 + if i >= count / 2 { 1u64 << 63 } else { 0 },
                            _ => (i as u128 * u128::from(u64::MAX)
                                / count.saturating_sub(1).max(1) as u128) as u64,
                        };
                        *previous = key;
                        Some(key)
                    })
                    .collect();
                let mut rows = SpillRows::<8>::new(count * 8);
                for key in &keys {
                    rows.push(key.to_le_bytes())?;
                }
                for wanted in keys.iter().flat_map(|&key| {
                    [Some(key), key.checked_sub(1), key.checked_add(1)]
                        .into_iter()
                        .flatten()
                }) {
                    let expected = if wanted < keys[0] || wanted > keys[count - 1] {
                        None
                    } else {
                        keys[..keys.partition_point(|&key| key <= wanted)]
                            .last()
                            .copied()
                    };
                    let found = rows
                        .cached_floor(wanted, |row| {
                            u64::from_le_bytes(row.try_into().unwrap())
                        })
                        .map(u64::from_le_bytes);
                    assert_eq!(found, expected, "count={count} shape={shape} wanted={wanted}");
                }
            }
        }
        Ok(())
    }

'''+anchor
assert anchor in s;s=s.replace(anchor,test,1);p.write_text(s)
