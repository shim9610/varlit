"""Pool every initial and planned confirmation sample; never select a subset."""
import argparse, json, statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--primary',type=Path,required=True);p.add_argument('--confirmation',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
paths=[a.primary/'native-samples.json']
if a.confirmation and (a.confirmation/'native-samples.json').exists():paths.append(a.confirmation/'native-samples.json')
samples=[row for path in paths for row in json.loads(path.read_text())];summaries=[]
for case in sorted({r['case'] for r in samples}):
 rows=[r for r in samples if r['case']==case]
 work=[{k:v for k,v in r['result'].items() if k not in ('seconds','temporary_bytes')} for r in rows];assert all(w==work[0] for w in work)
 metrics={}
 for name,field,aggregate in [('seconds',lambda r:r['result']['seconds'],statistics.median),('cpu',lambda r:r['usage']['cpu'],statistics.median),('rss',lambda r:r['usage']['rss'],max),('writes',lambda r:r['usage']['write_blocks']*512,statistics.median),('temporary_bytes',lambda r:r['result'].get('temporary_bytes',0),max)]:
  values={s:aggregate(field(r) for r in rows if r['side']==s) for s in ['before','after']}
  change=100*(values['after']/values['before']-1) if values['before'] else (0 if values['after']==0 else None)
  metrics[name]={**values,'change_percent':change,'passed':values['after']<=values['before']*1.05}
 summaries.append({'case':case,'pairs':len(rows)//2,'work':work[0],'metrics':metrics,'passed':all(x['passed'] for x in metrics.values())})
a.output.write_text(json.dumps(summaries,indent=2)+'\n')
for row in summaries:print(row['case'],row['pairs'],row['passed'],{k:v['change_percent'] for k,v in row['metrics'].items()})
