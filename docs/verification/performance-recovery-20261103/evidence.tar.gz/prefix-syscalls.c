#define _GNU_SOURCE
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
static double now(clockid_t clock){struct timespec t;if(clock_gettime(clock,&t))abort();return t.tv_sec+t.tv_nsec/1e9;}
int main(int argc,char **argv){if(argc!=2)return 2;size_t width=strtoul(argv[1],0,10);if(width<72||width>512)return 2;char path[]="/workspace/scratch/perf-recovery/disk-data/width-XXXXXX";int fd=mkstemp(path);if(fd<0)return 3;unlink(path);char zeros[65536]={0};for(size_t i=0;i<2200;i++)if(write(fd,zeros,sizeof zeros)!=sizeof zeros)return 4;char buffer[512]={0};uint32_t flags=1;double cpu=now(CLOCK_THREAD_CPUTIME_ID),wall=now(CLOCK_MONOTONIC);for(size_t i=0;i<200000;i++){off_t at=(i+1)*720-72+128;if(pread(fd,buffer,width,at)!=(ssize_t)width)return 5;if(pwrite(fd,&flags,sizeof flags,at+68)!=sizeof flags)return 6;}wall=now(CLOCK_MONOTONIC)-wall;cpu=now(CLOCK_THREAD_CPUTIME_ID)-cpu;printf("{\"width\":%zu,\"wall\":%.9f,\"cpu\":%.9f}\n",width,wall,cpu);close(fd);return 0;}
