from pathlib import Path
import subprocess,json
repo=Path('/workspace/varlit');r=Path('/workspace/scratch/perf-recovery');p=repo/'crates/varlit/tests/reader_follow_cost_probe.rs';assert not p.exists()
s=(repo/'crates/varlit/tests/reader_follow.rs').read_text();s=s[:s.index('/// The claim, against')]
s+='''
#[test]
fn probe_pending_tail_and_committed_delta() -> varlit::Result<()> {
    let spec = spec().with_commit_policy(varlit::CommitPolicy::TransactionMarker(
        varlit::TransactionMarkerMode::Explicit,
    ));
    let directory = tempfile::tempdir()?;
    let path = directory.path().join("pending.varlit");
    let mut writer = spec.create(&path)?;
    for value in 0..128 { writer.push(&Reading { value })?; }
    writer.commit()?;
    let mut reader = varlit::VarlitFile::open_readonly(spec, &path)?;
    let initial = records(&reader)?;
    for value in 128..4224 { writer.push(&Reading { value })?; }
    writer.flush()?;
    for call in 0..3 {
        let before = varlit::VarlitFile::records_framed();
        varlit::VarlitFile::take_open_scan_bytes();
        let gained = reader.follow()?;
        let framed = varlit::VarlitFile::records_framed() - before;
        let scanned = varlit::VarlitFile::take_open_scan_bytes();
        eprintln!("PROBE pending call={call} gained={gained} framed={framed} scanned={scanned}");
        assert_eq!(gained, 0);
    }
    assert_eq!(records(&reader)?, initial);
    writer.commit()?;
    let before = varlit::VarlitFile::records_framed();
    varlit::VarlitFile::take_open_scan_bytes();
    let gained = reader.follow()?;
    let framed = varlit::VarlitFile::records_framed() - before;
    let scanned = varlit::VarlitFile::take_open_scan_bytes();
    eprintln!("PROBE committed gained={gained} framed={framed} scanned={scanned}");
    assert!(gained > 0);
    assert!(records(&reader)? >= initial + 4096);
    let before = varlit::VarlitFile::records_framed();
    assert_eq!(reader.follow()?, 0);
    let framed = varlit::VarlitFile::records_framed() - before;
    eprintln!("PROBE idle framed={framed}");
    assert_eq!(framed, 0);
    Ok(())
}
'''
(r/'reader_follow_cost_probe.rs').write_text(s)
try:
 p.write_text(s)
 with (r/'dirty-follow-probe.log').open('w') as f:
  x=subprocess.run(['cargo','test','--locked','-p','varlit','--all-features','--test','reader_follow_cost_probe','--','--nocapture'],cwd=repo,stdout=f,stderr=subprocess.STDOUT)
finally:p.unlink(missing_ok=True)
print('exit',x.returncode)
log=(r/'dirty-follow-probe.log').read_text();print('\n'.join(line for line in log.splitlines() if 'PROBE' in line or 'test result:' in line or 'error' in line))
assert x.returncode==0
