#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
static ssize_t (*rp)(int,void*,size_t,off64_t);
static ssize_t (*wp)(int,const void*,size_t,off64_t);
static int (*rr)(int);
static _Thread_local int active;
static _Thread_local uint64_t reads,writes,rbytes,wbytes,rns,wns,start;
static uint64_t now(void){struct timespec t;if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t))_exit(124);return (uint64_t)t.tv_sec*1000000000u+t.tv_nsec;}
__attribute__((constructor)) static void init(void){rp=dlsym(RTLD_NEXT,"pread64");wp=dlsym(RTLD_NEXT,"pwrite64");rr=dlsym(RTLD_NEXT,"raise");if(!rp||!wp||!rr)_exit(125);}
int raise(int sig){if(sig!=10)return rr(sig);if(!active){reads=writes=rbytes=wbytes=rns=wns=0;start=now();active=1;}else{active=0;uint64_t elapsed=now()-start;fprintf(stderr,"{\"reads\":%lu,\"writes\":%lu,\"read_bytes\":%lu,\"write_bytes\":%lu,\"pread_cpu_ns\":%lu,\"pwrite_cpu_ns\":%lu,\"mark_cpu_ns\":%lu}\n",reads,writes,rbytes,wbytes,rns,wns,elapsed);}return 0;}
ssize_t pread64(int fd,void *buf,size_t n,off64_t at){if(!active)return rp(fd,buf,n,at);uint64_t t=now();ssize_t v=rp(fd,buf,n,at);int e=errno;rns+=now()-t;reads++;rbytes+=n;errno=e;return v;}
ssize_t pwrite64(int fd,const void *buf,size_t n,off64_t at){if(!active)return wp(fd,buf,n,at);uint64_t t=now();ssize_t v=wp(fd,buf,n,at);int e=errno;wns+=now()-t;writes++;wbytes+=n;errno=e;return v;}
