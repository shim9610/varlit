#define _GNU_SOURCE
#include <dlfcn.h>
#include <link.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <ucontext.h>
#include <unistd.h>
#include <errno.h>
#define BINS 131072
static volatile sig_atomic_t hits[BINS], external_hits, active;
static uintptr_t base;
static void *(*real_memset)(void*,int,size_t);
static uint64_t memset_calls,memset_bytes;
static int (*real_clock)(clockid_t,struct timespec*);
static int image_base(struct dl_phdr_info *x,size_t size,void *arg){(void)size;(void)arg;if(!x->dlpi_name[0])base=x->dlpi_addr;return 0;}
static void sample(int signo,siginfo_t *info,void *ctx){(void)signo;(void)info;int saved=errno;if(active){uintptr_t pc=((ucontext_t*)ctx)->uc_mcontext.gregs[REG_RIP];if(pc>=base&&pc-base<BINS*16u)hits[(pc-base)/16u]++;else external_hits++;}errno=saved;}
__attribute__((constructor)) static void init(void){real_clock=dlsym(RTLD_NEXT,"clock_gettime");real_memset=dlsym(RTLD_NEXT,"memset");if(!real_clock)_exit(125);dl_iterate_phdr(image_base,0);struct sigaction a={0};a.sa_sigaction=sample;a.sa_flags=SA_SIGINFO|SA_RESTART;sigemptyset(&a.sa_mask);if(sigaction(SIGPROF,&a,0))_exit(124);}
int clock_gettime(clockid_t id,struct timespec *out){int result=real_clock(id,out);int saved=errno;if(id==CLOCK_THREAD_CPUTIME_ID&&result==0){struct itimerval t={0};if(!active){active=1;t.it_interval.tv_usec=1000;t.it_value.tv_usec=1000;if(setitimer(ITIMER_PROF,&t,0))_exit(123);}else{active=0;if(setitimer(ITIMER_PROF,&t,0))_exit(122);fprintf(stderr,"{\"sample_interval_us\":1000,\"external\":%d,\"hits\":[",external_hits);int comma=0;for(unsigned i=0;i<BINS;i++)if(hits[i]){fprintf(stderr,"%s[%u,%d]",comma?",":"",i*16,hits[i]);comma=1;}fprintf(stderr,"],\"memset_calls\":%lu,\"memset_bytes\":%lu}\n",memset_calls,memset_bytes);}}errno=saved;return result;}

void *memset(void *buf,int value,size_t n){if(!real_memset){volatile unsigned char *p=buf;for(size_t i=0;i<n;i++)p[i]=(unsigned char)value;return buf;}if(active){memset_calls++;memset_bytes+=n;}return real_memset(buf,value,n);}
