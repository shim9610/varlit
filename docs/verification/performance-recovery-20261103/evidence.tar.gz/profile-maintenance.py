from pathlib import Path
import subprocess,hashlib,json,os,random,shutil,bisect
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');out=r/'maintenance-sampling';out.mkdir(exist_ok=False)
paths=[repo/p for p in subprocess.check_output(['git','diff','--name-only','749532d','6bcfe0a','--','crates/varlit-core/src'],cwd=repo,text=True).splitlines()];original={p:p.read_text() for p in paths}
s=(repo/'crates/varlit/examples/oom_maintenance_load.rs').read_text();needle='    let start = Instant::now();\n    let dropped';assert s.count(needle)==1;s=s.replace(needle,'    let phase_start = phase_cpu();\n'+needle);needle='    let seconds = start.elapsed().as_secs_f64();';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    eprintln!("{}", phase_cpu() - phase_start);')
helper=(r/'prefix-inline-factorial/record_phase_cpu.rs').read_text();s+='\n'+helper[helper.index('#[repr(C)]'):]
harness=repo/'crates/varlit/examples/maintenance_phase_cpu.rs';assert not harness.exists();(out/'maintenance_phase_cpu.rs').write_text(s)
subprocess.run(['cc','-O2','-shared','-fPIC',str(r/'profile-maintenance.c'),'-ldl','-o',str(out/'profile.so')],check=True)
plan={'groups':12,'seed':491823,'args':['complex','65536','512'],'instrumentation':'two CPU clock calls toggle ITIMER_PROF1ms sampling; 16byte bins up to2MiB of main executable, plus external count; diagnostics only, no qualification','variants':{}}
try:
 harness.write_text(s)
 for label in ['previous-749','current-6bc']:
  for p in paths:p.write_text(subprocess.check_output(['git','show','749532d:'+str(p.relative_to(repo))],cwd=repo,text=True) if label=='previous-749' else original[p])
  b=out/(label+'-bin');b.mkdir();print('BUILD',label,flush=True)
  with (out/(label+'-build.log')).open('w') as f:subprocess.run(['cargo','build','--locked','--release','--workspace','--all-features','--example','maintenance_phase_cpu'],cwd=repo,env={**os.environ,'CARGO_PROFILE_RELEASE_DEBUG':'1'},stdout=f,stderr=subprocess.STDOUT,check=True)
  shutil.copy2(repo/'target/release/examples/maintenance_phase_cpu',b/'maintenance_phase_cpu')
  plan['variants'][label]={'sources':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'binary_sha256':hashlib.sha256((b/'maintenance_phase_cpu').read_bytes()).hexdigest()}
finally:
 for p in paths:p.write_text(original[p])
 harness.unlink(missing_ok=True);(out/'source-restored.json').write_text(json.dumps({str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},indent=2))
(out/'plan.json').write_text(json.dumps(plan,indent=2));os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});rng=random.Random(491823);rows=[]
for group in range(12):
 labels=['previous-749','current-6bc'];rng.shuffle(labels)
 for label in labels:
  x=subprocess.run([str(out/(label+'-bin')/'maintenance_phase_cpu'),*plan['args']],env={**os.environ,'TMPDIR':str(r/'disk-data'),'LD_PRELOAD':str(out/'profile.so')},capture_output=True,text=True,check=True)
  (out/f'{group}-{label}.stderr').write_text(x.stderr);parts=x.stderr.splitlines();profile=json.loads(next(q for q in parts if q.startswith('{')));rows.append({'group':group,'label':label,'result':json.loads(x.stdout),'phase_cpu':float(parts[-1]),'profile':profile});(out/'samples.json').write_text(json.dumps(rows,indent=2));print(group,label,rows[-1]['phase_cpu'],flush=True)
# Addr2line resolves both the current function and inlined caller chain.
for label in ['previous-749','current-6bc']:
 bins={};external=0
 for x in rows:
  if x['label']!=label:continue
  external+=x['profile']['external']
  for pc,n in x['profile']['hits']:bins[pc]=bins.get(pc,0)+n
 ranked=sorted(bins.items(),key=lambda v:v[1],reverse=True);pcs=[hex(pc) for pc,n in ranked]
 resolved=[]
 for i in range(0,len(pcs),100):
  res=subprocess.check_output(['addr2line','-a','-C','-f','-i','-e',str(out/(label+'-bin')/'maintenance_phase_cpu'),*pcs[i:i+100]],text=True);resolved.append(res)
 (out/(label+'-locations.txt')).write_text('\n'.join(resolved));(out/(label+'-ranked.json')).write_text(json.dumps({'external':external,'main_samples':sum(bins.values()),'ranked':ranked},indent=2));print('SAMPLES',label,sum(bins.values()),external,flush=True)
print('DONE',flush=True)
