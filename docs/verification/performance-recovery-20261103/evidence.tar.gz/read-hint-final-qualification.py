from pathlib import Path
import subprocess
r=Path('/workspace/scratch/perf-recovery')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:subprocess.run(['python3',*map(str,args)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
run('read-hint-native',[r/'read-hint-three-balanced.py','--phase','native','--output',r/'read-hint-native'])
run('read-hint-swmr',[r/'read-hint-three-balanced.py','--phase','concurrent','--output',r/'read-hint-swmr'])
run('read-hint-reference',[r/'read-hint-reference-balanced.py','--after',r/'read-hint-bin','--output',r/'read-hint-reference','--groups','24'])
run('read-hint-reference-analysis',[r/'analyze-controls.py',r/'read-hint-reference/samples.json',r/'read-hint-reference/analysis.json'])
run('read-hint-resources',[r/'read-hint-resources.py'])
print('DONE ALL SERIES; inspect every metric.',flush=True)
