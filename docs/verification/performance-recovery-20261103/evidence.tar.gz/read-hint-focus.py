"""Predeclared equal-work long mixed test, four randomized labels, all samples retained."""
from pathlib import Path
import hashlib,json,os,random,statistics,subprocess
r=Path('/workspace/scratch/perf-recovery');out=r/'read-hint-focus';out.mkdir(exist_ok=True)
old=Path('/workspace/varlit-pre-boundary/target/release/examples/record_mutation_load')
bins={'old-a':old,'old-b':old,'unit-before':r/'build-pages-bin/record_mutation_load','after':r/'read-hint-bin/record_mutation_load'}
args=['writer','mixed','random','131072','65536'];rng=random.Random(816372);rows=[];os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
(out/'plan.json').write_text(json.dumps({'seed':816372,'initial_groups':5,'additional_groups_on_any_failed_metric':15,'limit_percent':5,'args':args,'sha256':{s:hashlib.sha256(b.read_bytes()).hexdigest() for s,b in bins.items()}},indent=2))
def summary():
 metrics={}
 for name,get,agg in [('seconds',lambda r:r['result']['seconds'],statistics.median),('cpu',lambda r:r['usage']['cpu'],statistics.median),('rss',lambda r:r['usage']['rss'],max),('writes',lambda r:r['usage']['write_blocks']*512,statistics.median),('temporary_bytes',lambda r:r['result'].get('temporary_bytes',0),max)]:
  v={s:agg(get(x) for x in rows if x['side']==s) for s in bins}
  metrics[name]={'values':v,'comparisons':{s:{'change_percent':100*(v['after']/v[s]-1) if v[s] else (0 if v['after']==0 else None),'passed':v['after']<=v[s]*1.05} for s in bins if s!='after'}}
 return {'groups':len(rows)//4,'metrics':metrics,'passed':all(c['passed'] for m in metrics.values() for c in m['comparisons'].values())}
for stage,(start,end) in enumerate([(0,5),(5,20)]):
 if stage and summary()['passed']:break
 for group in range(start,end):
  labels=list(bins);rng.shuffle(labels)
  for side in labels:
   p=subprocess.run([str(r/'initial/measure'),str(out/'usage.json'),str(bins[side]),*args],capture_output=True,text=True,check=True,env={**os.environ,'TMPDIR':str(r/'disk-data')})
   row={'group':group,'side':side,'result':json.loads(p.stdout),'usage':json.loads((out/'usage.json').read_text())};rows.append(row);(out/'samples.json').write_text(json.dumps(rows,indent=2));print(group,side,row['result']['seconds'],flush=True)
 work=[{k:v for k,v in x['result'].items() if k not in ('seconds','temporary_bytes')} for x in rows];assert all(x==work[0] for x in work)
 result=summary();(out/'summary.json').write_text(json.dumps(result,indent=2));print('SUMMARY',stage,json.dumps(result),flush=True)
if not result['passed']:raise SystemExit('Failed focus gate; all planned samples retained')
