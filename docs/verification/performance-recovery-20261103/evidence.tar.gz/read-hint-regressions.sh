set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
cargo fmt --all
cargo test -p varlit-core --all-features > /workspace/scratch/perf-recovery/read-hint-core-all.log 2>&1
cargo test -p varlit-core > /workspace/scratch/perf-recovery/read-hint-core-default.log 2>&1
cargo test -p varlit --all-features --test oom_recovery_guards --test publication_failure_results --test record_liveness --test validation_coverage > /workspace/scratch/perf-recovery/read-hint-public.log 2>&1
cargo clippy --workspace --all-features --all-targets -- -D warnings > /workspace/scratch/perf-recovery/read-hint-clippy.log 2>&1
MIRIFLAGS=-Zmiri-disable-isolation cargo +nightly-2026-10-12 miri test -p varlit-core --all-features --lib file::validation_tests::adaptive_mark_reads_preserve_frames_and_retry_after_io_failure > /workspace/scratch/perf-recovery/read-hint-miri.log 2>&1
MIRIFLAGS=-Zmiri-disable-isolation cargo +nightly-2026-10-12 miri test -p varlit-core --all-features --lib file::validation_tests::mark_read_hint_preserves_full_width_geometry > /workspace/scratch/perf-recovery/read-hint-miri-arithmetic.log 2>&1
cargo fmt --all -- --check
git diff --check
