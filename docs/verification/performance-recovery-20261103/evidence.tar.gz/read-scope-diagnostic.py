from pathlib import Path
import subprocess,shutil,hashlib,json,os,random,statistics
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');out=r/'read-scope-diagnostic';out.mkdir(exist_ok=False)
paths={n:repo/'crates/varlit-core/src'/n for n in ['file.rs','snapshot.rs','file/header_codec.rs']};original={n:p.read_text() for n,p in paths.items()}
labels=['previous-749','current-6bc','plain-read','plain-read-inline-validation'];cases=[ ['complex','65536','512'], ['checkpoint','200000','256'], ['writer','fixed','forward','2000000','200000'], ['writer','mixed','random','131072','65536'], ['rewrite','variable','random','200000','200000'] ]
plan={'purpose':'diagnostic, ordinary unchanged harness; four versions compare complex/checkpoint and three critical mark cases; candidate read function body unchanged, optional validator restored inline with borrowed policy','groups':12,'seed':498182,'cases':cases,'variants':{}}
(out/'plan.json').write_text(json.dumps(plan,indent=2))
try:
 for label in labels:
  for n,p in paths.items():
   content=original[n]
   if n=='snapshot.rs' and 'plain-read' in label:
    needle='    #[inline]\n    pub(crate) fn read_exact_at(&self,';assert content.count(needle)==1;content=content.replace(needle,'    pub(crate) fn read_exact_at(&self,')
   if n=='file/header_codec.rs' and label=='plain-read-inline-validation':
    prior=subprocess.check_output(['git','show','749532d:crates/varlit-core/src/file/header_codec.rs'],cwd=repo,text=True)
    start='#[inline]\npub(super) fn validate_record_entry(';end='// Control-record versions belong'
    a=prior.index(start);b=prior.index(end,a);body=prior[a:b].replace('spec: FormatSpec,','spec: &FormatSpec,').replace('variable_compression_for_block(spec,','variable_compression_for_block(*spec,')
    a=content.index(start);b=content.index(end,a);content=content[:a]+body+content[b:]
   p.write_text(content)
  dest=out/(label+'-bin');dest.mkdir()
  if label in ['previous-749','current-6bc']:
   origin=r/('read-hint-bin' if label=='previous-749' else 'call-shape-bin')
   for n in ['record_mutation_load','oom_maintenance_load']:shutil.copy2(origin/n,dest/n)
  else:
   print('BUILD',label,flush=True)
   with (out/(label+'-build.log')).open('w') as f:subprocess.run(['cargo','build','--locked','--release','--workspace','--all-features','--example','record_mutation_load','--example','oom_maintenance_load','--example','scalable_load','--example','ownership_load','--example','ownership_boundary_load'],cwd=repo,stdout=f,stderr=subprocess.STDOUT,check=True)
   for n in ['record_mutation_load','oom_maintenance_load']:shutil.copy2(repo/'target/release/examples'/n,dest/n)
  plan['variants'][label]={'sources':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in paths.items()},'binary_sha256':hashlib.sha256((dest/'record_mutation_load').read_bytes()).hexdigest()};(out/'plan.json').write_text(json.dumps(plan,indent=2))
  symbols=subprocess.check_output(['nm','-S','-C',str(dest/'record_mutation_load')],text=True)
  (out/(label+'-symbols.txt')).write_text('\n'.join(l for l in symbols.splitlines() if any(k in l for k in ['mark_record_dead','write_framed_record_flags','SnapshotFile::read_exact_at'])))
finally:
 for n,p in paths.items():p.write_text(original[n])
 (out/'source-restored.json').write_text(json.dumps({n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in paths.items()},indent=2))
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});rng=random.Random(498182);samples=[];summaries=[]
for case,args in enumerate(cases):
 exe='oom_maintenance_load' if case<2 else 'record_mutation_load'
 orders=[]
 for group in range(12):
  if not orders:
   names=labels.copy();rng.shuffle(names);orders=[[names[i] for i in order] for order in [[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1]]];rng.shuffle(orders)
  for label in orders.pop():
   x=subprocess.run([str(r/'initial/measure'),str(out/'usage.json'),str(out/(label+'-bin')/exe),*args],capture_output=True,text=True,env={**os.environ,'TMPDIR':str(r/'disk-data')},check=True)
   row={'case':case,'group':group,'label':label,'result':json.loads(x.stdout),'usage':json.loads((out/'usage.json').read_text())};samples.append(row);(out/'samples.json').write_text(json.dumps(samples,indent=2));print(case,group,label,row['result']['seconds'],flush=True)
 selected=[x for x in samples if x['case']==case];work=[{k:v for k,v in x['result'].items() if k not in ('seconds','temporary_bytes')} for x in selected];assert all(x==work[0] for x in work)
 summary={'case':case,'values':{label:{metric:agg(get(x) for x in selected if x['label']==label) for metric,get,agg in [('wall',lambda x:x['result']['seconds'],statistics.median),('process_cpu',lambda x:x['usage']['cpu'],statistics.median),('rss',lambda x:x['usage']['rss'],max),('writes',lambda x:x['usage']['write_blocks'],statistics.median),('temporary_bytes',lambda x:x['result'].get('temporary_bytes',0),max)]} for label in labels}}
 summaries.append(summary);(out/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',summary,flush=True)
