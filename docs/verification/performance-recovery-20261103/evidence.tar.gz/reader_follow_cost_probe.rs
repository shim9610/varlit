//! A reader that catches up without reopening.
//!
//! A handle fixes its snapshot length at open and reads positionally against
//! it, which is what lets one handle serve concurrent readers while a writer
//! appends. The cost was that the handle never saw the appends either: measured
//! before this existed, a handle open on a five-record file that then grew to
//! fifteen went on reporting 6 records while a fresh open reported 18.
//!
//! `follow()` closes that, and the things worth pinning are the ones that are
//! easy to get wrong rather than the happy path: it must adopt exactly what a
//! fresh open would adopt, it must stop at the same commit boundary, it must
//! cost the tail rather than the file, and it must **not** wander onto a
//! different generation when the pathname is replaced under it.

#![cfg(all(feature = "integrity", feature = "scalable-fault-injection"))]

use varlit::{VarlitBlock, varlit_format};

#[derive(Clone, Debug, PartialEq, VarlitBlock)]
#[varlit(id = 10, version = 1, kind = "fixed")]
struct Reading {
    value: u64,
}

#[derive(Clone, Debug, PartialEq, VarlitBlock)]
#[varlit(id = 11, version = 1, kind = "variable")]
struct Label {
    #[varlit(field_id = 1)]
    text: String,
}

varlit_format! {
    pub struct FollowFormat {
        magic: b"VFOLLOW1";
        version: 1;
        endian: little;
        schema_hash: computed;
        integrity: crc32;
        index: block_offset_chain;
        commit: transaction_marker(on_flush);
        blocks: [Reading, Label];
    }
}

// The same declaration with no commit marker, so "visible" means "framed"
// rather than "committed". The boundary rules differ and both are pinned.
varlit_format! {
    pub struct FollowNoMarker {
        magic: b"VFOLLOW2";
        version: 1;
        endian: little;
        schema_hash: computed;
        integrity: crc32;
        index: block_offset_chain;
        commit: none;
        blocks: [Reading, Label];
    }
}

fn spec() -> varlit::FormatSpec {
    FollowFormat::spec()
}

fn records(file: &varlit::VarlitFile) -> varlit::Result<usize> {
    let mut buffer = Vec::new();
    let mut walk = file.record_map(&mut buffer)?;
    let mut count = 0;
    while walk.advance()?.is_some() {
        count += 1;
    }
    Ok(count)
}


#[test]
fn probe_pending_tail_and_committed_delta() -> varlit::Result<()> {
    let spec = spec().with_commit_policy(varlit::CommitPolicy::TransactionMarker(
        varlit::TransactionMarkerMode::Explicit,
    ));
    let directory = tempfile::tempdir()?;
    let path = directory.path().join("pending.varlit");
    let mut writer = spec.create(&path)?;
    for value in 0..128 { writer.push(&Reading { value })?; }
    writer.commit()?;
    let mut reader = varlit::VarlitFile::open_readonly(spec, &path)?;
    let initial = records(&reader)?;
    for value in 128..4224 { writer.push(&Reading { value })?; }
    writer.flush()?;
    for call in 0..3 {
        let before = varlit::VarlitFile::records_framed();
        varlit::VarlitFile::take_open_scan_bytes();
        let gained = reader.follow()?;
        let framed = varlit::VarlitFile::records_framed() - before;
        let scanned = varlit::VarlitFile::take_open_scan_bytes();
        eprintln!("PROBE pending call={call} gained={gained} framed={framed} scanned={scanned}");
        assert_eq!(gained, 0);
    }
    assert_eq!(records(&reader)?, initial);
    writer.commit()?;
    let before = varlit::VarlitFile::records_framed();
    varlit::VarlitFile::take_open_scan_bytes();
    let gained = reader.follow()?;
    let framed = varlit::VarlitFile::records_framed() - before;
    let scanned = varlit::VarlitFile::take_open_scan_bytes();
    eprintln!("PROBE committed gained={gained} framed={framed} scanned={scanned}");
    assert!(gained > 0);
    assert!(records(&reader)? >= initial + 4096);
    let before = varlit::VarlitFile::records_framed();
    assert_eq!(reader.follow()?, 0);
    let framed = varlit::VarlitFile::records_framed() - before;
    eprintln!("PROBE idle framed={framed}");
    assert_eq!(framed, 0);
    Ok(())
}
