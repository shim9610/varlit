from pathlib import Path
import hashlib,json,subprocess,shutil
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');out=r/'refined-bin';out.mkdir(exist_ok=True)
p=json.loads((r/'adaptive-scratch-provenance.json').read_text());p['committed_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();p['rustc']=subprocess.check_output(['rustc','-Vv'],text=True)
names=['record_mutation_load','oom_maintenance_load','scalable_load','ownership_load','ownership_boundary_load']
for n in names:
 if (out/n).exists():assert hashlib.sha256((out/n).read_bytes()).digest()==hashlib.sha256((repo/'target/release/examples'/n).read_bytes()).digest()
 else:shutil.copy2(repo/'target/release/examples'/n,out/n)
paths=set(p['sources'])|{str(next(repo.glob(f'crates/*/examples/{n}.rs')).relative_to(repo)) for n in names}
p['sources']={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in sorted(paths)};p['binaries']={n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in names}
p['build']='cargo build --locked --release --workspace --all-features (five named examples); release optimized without debug info; unchanged 4CPU16GiB budgets'
(r/'refined-provenance.json').write_text(json.dumps(p,indent=2)+'\n')
print(json.dumps({'head':p['committed_head'],'binary_hashes':p['binaries']},indent=2))
