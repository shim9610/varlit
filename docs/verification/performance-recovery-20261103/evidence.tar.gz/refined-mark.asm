
/workspace/scratch/perf-recovery/refined-bin/record_mutation_load:     file format elf64-x86-64


Disassembly of section .text:

000000000007b2c0 <varlit_core::file::VarlitFile::mark_record_dead>:
   7b2c0:	55                   	push   %rbp
   7b2c1:	41 57                	push   %r15
   7b2c3:	41 56                	push   %r14
   7b2c5:	41 55                	push   %r13
   7b2c7:	41 54                	push   %r12
   7b2c9:	53                   	push   %rbx
   7b2ca:	48 81 ec a8 03 00 00 	sub    $0x3a8,%rsp
   7b2d1:	48 89 fb             	mov    %rdi,%rbx
   7b2d4:	49 bc 30 00 00 00 00 	movabs $0x8000000000000030,%r12
   7b2db:	00 00 80 
   7b2de:	49 8d 4c 24 0b       	lea    0xb(%r12),%rcx
   7b2e3:	48 8d 05 da f0 f9 ff 	lea    -0x60f26(%rip),%rax        # 1a3c4 <anon.0f009bcc72980f61c3f35510f83bea5d.36.llvm.12361760896344735183+0x8>
   7b2ea:	80 be a0 0d 00 00 00 	cmpb   $0x0,0xda0(%rsi)
   7b2f1:	0f 85 ca 00 00 00    	jne    7b3c1 <varlit_core::file::VarlitFile::mark_record_dead+0x101>
   7b2f7:	49 89 f6             	mov    %rsi,%r14
   7b2fa:	80 be a1 0d 00 00 00 	cmpb   $0x0,0xda1(%rsi)
   7b301:	0f 85 ba 00 00 00    	jne    7b3c1 <varlit_core::file::VarlitFile::mark_record_dead+0x101>
   7b307:	41 80 be a2 0d 00 00 	cmpb   $0x0,0xda2(%r14)
   7b30e:	00 
   7b30f:	0f 84 8e 00 00 00    	je     7b3a3 <varlit_core::file::VarlitFile::mark_record_dead+0xe3>
   7b315:	41 80 be 92 02 00 00 	cmpb   $0x0,0x292(%r14)
   7b31c:	00 
   7b31d:	0f 84 ca 00 00 00    	je     7b3ed <varlit_core::file::VarlitFile::mark_record_dead+0x12d>
   7b323:	4d 8d be 98 02 00 00 	lea    0x298(%r14),%r15
   7b32a:	49 3b 96 b8 08 00 00 	cmp    0x8b8(%r14),%rdx
   7b331:	48 89 14 24          	mov    %rdx,(%rsp)
   7b335:	0f 83 31 01 00 00    	jae    7b46c <varlit_core::file::VarlitFile::mark_record_dead+0x1ac>
   7b33b:	41 80 be a8 08 00 00 	cmpb   $0x2,0x8a8(%r14)
   7b342:	02 
   7b343:	0f 84 d1 00 00 00    	je     7b41a <varlit_core::file::VarlitFile::mark_record_dead+0x15a>
   7b349:	49 83 be 88 08 00 00 	cmpq   $0x0,0x888(%r14)
   7b350:	00 
   7b351:	0f 84 c3 00 00 00    	je     7b41a <varlit_core::file::VarlitFile::mark_record_dead+0x15a>
   7b357:	49 8b 8e 90 08 00 00 	mov    0x890(%r14),%rcx
   7b35e:	48 39 ca             	cmp    %rcx,%rdx
   7b361:	0f 82 b3 00 00 00    	jb     7b41a <varlit_core::file::VarlitFile::mark_record_dead+0x15a>
   7b367:	49 3b 96 a0 08 00 00 	cmp    0x8a0(%r14),%rdx
   7b36e:	0f 87 a6 00 00 00    	ja     7b41a <varlit_core::file::VarlitFile::mark_record_dead+0x15a>
   7b374:	48 89 d0             	mov    %rdx,%rax
   7b377:	48 29 c8             	sub    %rcx,%rax
   7b37a:	0f 84 76 01 00 00    	je     7b4f6 <varlit_core::file::VarlitFile::mark_record_dead+0x236>
   7b380:	49 8b 8e 98 08 00 00 	mov    0x898(%r14),%rcx
   7b387:	48 85 c9             	test   %rcx,%rcx
   7b38a:	0f 84 8a 00 00 00    	je     7b41a <varlit_core::file::VarlitFile::mark_record_dead+0x15a>
   7b390:	48 89 c2             	mov    %rax,%rdx
   7b393:	48 09 ca             	or     %rcx,%rdx
   7b396:	48 c1 ea 20          	shr    $0x20,%rdx
   7b39a:	74 6d                	je     7b409 <varlit_core::file::VarlitFile::mark_record_dead+0x149>
   7b39c:	31 d2                	xor    %edx,%edx
   7b39e:	48 f7 f1             	div    %rcx
   7b3a1:	eb 6a                	jmp    7b40d <varlit_core::file::VarlitFile::mark_record_dead+0x14d>
   7b3a3:	48 8d 35 cd 70 fa ff 	lea    -0x58f33(%rip),%rsi        # 22477 <anon.0ccafa760f16028ef2da30d8fb23ded9.3.llvm.8148477165880511475+0x1a92>
   7b3aa:	ba 19 00 00 00       	mov    $0x19,%edx
   7b3af:	bf 01 00 00 00       	mov    $0x1,%edi
   7b3b4:	ff 15 96 5e 15 00    	call   *0x155e96(%rip)        # 1d1250 <_DYNAMIC+0x7b8>
   7b3ba:	49 83 c4 d6          	add    $0xffffffffffffffd6,%r12
   7b3be:	4c 89 e1             	mov    %r12,%rcx
   7b3c1:	48 89 0b             	mov    %rcx,(%rbx)
   7b3c4:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7b3c8:	48 c7 43 10 04 00 00 	movq   $0x4,0x10(%rbx)
   7b3cf:	00 
   7b3d0:	48 c7 43 18 04 00 00 	movq   $0x4,0x18(%rbx)
   7b3d7:	00 
   7b3d8:	48 89 d8             	mov    %rbx,%rax
   7b3db:	48 81 c4 a8 03 00 00 	add    $0x3a8,%rsp
   7b3e2:	5b                   	pop    %rbx
   7b3e3:	41 5c                	pop    %r12
   7b3e5:	41 5d                	pop    %r13
   7b3e7:	41 5e                	pop    %r14
   7b3e9:	41 5f                	pop    %r15
   7b3eb:	5d                   	pop    %rbp
   7b3ec:	c3                   	ret
   7b3ed:	49 83 c4 ee          	add    $0xffffffffffffffee,%r12
   7b3f1:	4c 89 23             	mov    %r12,(%rbx)
   7b3f4:	48 8d 05 58 71 fa ff 	lea    -0x58ea8(%rip),%rax        # 22553 <anon.0ccafa760f16028ef2da30d8fb23ded9.3.llvm.8148477165880511475+0x1b6e>
   7b3fb:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7b3ff:	48 c7 43 10 30 00 00 	movq   $0x30,0x10(%rbx)
   7b406:	00 
   7b407:	eb cf                	jmp    7b3d8 <varlit_core::file::VarlitFile::mark_record_dead+0x118>
   7b409:	31 d2                	xor    %edx,%edx
   7b40b:	f7 f1                	div    %ecx
   7b40d:	48 85 d2             	test   %rdx,%rdx
   7b410:	48 8b 14 24          	mov    (%rsp),%rdx
   7b414:	0f 84 dc 00 00 00    	je     7b4f6 <varlit_core::file::VarlitFile::mark_record_dead+0x236>
   7b41a:	41 80 be d0 08 00 00 	cmpb   $0x1,0x8d0(%r14)
   7b421:	01 
   7b422:	75 48                	jne    7b46c <varlit_core::file::VarlitFile::mark_record_dead+0x1ac>
   7b424:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
   7b42b:	00 
   7b42c:	4c 89 fe             	mov    %r15,%rsi
   7b42f:	e8 2c ba 04 00       	call   c6e60 <varlit_core::file::resident_index::ResidentIndex::offset_floor>
   7b434:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
   7b43b:	00 
   7b43c:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
   7b443:	00 
   7b444:	49 8d 74 24 4d       	lea    0x4d(%r12),%rsi
   7b449:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
   7b450:	00 
   7b451:	48 39 f2             	cmp    %rsi,%rdx
   7b454:	0f 85 0a 03 00 00    	jne    7b764 <varlit_core::file::VarlitFile::mark_record_dead+0x4a4>
   7b45a:	48 8b 14 24          	mov    (%rsp),%rdx
   7b45e:	48 39 d1             	cmp    %rdx,%rcx
   7b461:	0f 94 c1             	sete   %cl
   7b464:	84 c8                	test   %cl,%al
   7b466:	0f 85 8a 00 00 00    	jne    7b4f6 <varlit_core::file::VarlitFile::mark_record_dead+0x236>
   7b46c:	41 83 be 38 09 00 00 	cmpl   $0x2,0x938(%r14)
   7b473:	02 
   7b474:	75 3a                	jne    7b4b0 <varlit_core::file::VarlitFile::mark_record_dead+0x1f0>
   7b476:	4d 8b ae b8 0b 00 00 	mov    0xbb8(%r14),%r13
   7b47d:	48 8d ac 24 10 01 00 	lea    0x110(%rsp),%rbp
   7b484:	00 
   7b485:	ba 98 02 00 00       	mov    $0x298,%edx
   7b48a:	48 89 ef             	mov    %rbp,%rdi
   7b48d:	4c 89 f6             	mov    %r14,%rsi
   7b490:	ff 15 0a 59 15 00    	call   *0x15590a(%rip)        # 1d0da0 <memcpy@GLIBC_2.14>
   7b496:	48 89 ef             	mov    %rbp,%rdi
   7b499:	4c 89 ee             	mov    %r13,%rsi
   7b49c:	ff 15 86 5a 15 00    	call   *0x155a86(%rip)        # 1d0f28 <_DYNAMIC+0x490>
   7b4a2:	48 8b 14 24          	mov    (%rsp),%rdx
   7b4a6:	48 39 c2             	cmp    %rax,%rdx
   7b4a9:	73 15                	jae    7b4c0 <varlit_core::file::VarlitFile::mark_record_dead+0x200>
   7b4ab:	e9 6e 01 00 00       	jmp    7b61e <varlit_core::file::VarlitFile::mark_record_dead+0x35e>
   7b4b0:	49 8b 86 08 0b 00 00 	mov    0xb08(%r14),%rax
   7b4b7:	48 39 c2             	cmp    %rax,%rdx
   7b4ba:	0f 82 5e 01 00 00    	jb     7b61e <varlit_core::file::VarlitFile::mark_record_dead+0x35e>
   7b4c0:	49 3b 96 b8 08 00 00 	cmp    0x8b8(%r14),%rdx
   7b4c7:	0f 83 51 01 00 00    	jae    7b61e <varlit_core::file::VarlitFile::mark_record_dead+0x35e>
   7b4cd:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
   7b4d4:	00 
   7b4d5:	4c 89 fe             	mov    %r15,%rsi
   7b4d8:	48 89 d1             	mov    %rdx,%rcx
   7b4db:	48 89 c2             	mov    %rax,%rdx
   7b4de:	e8 0d da 04 00       	call   c8ef0 <varlit_core::file::resident_index::ResidentIndex::extend_boundary_proof>
   7b4e3:	49 8d 44 24 4d       	lea    0x4d(%r12),%rax
   7b4e8:	48 39 84 24 10 01 00 	cmp    %rax,0x110(%rsp)
   7b4ef:	00 
   7b4f0:	0f 85 4f 01 00 00    	jne    7b645 <varlit_core::file::VarlitFile::mark_record_dead+0x385>
   7b4f6:	49 8b ae 38 0d 00 00 	mov    0xd38(%r14),%rbp
   7b4fd:	48 b8 c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rax
   7b504:	ec c4 4e 
   7b507:	49 f7 a6 98 05 00 00 	mulq   0x598(%r14)
   7b50e:	49 8b 86 a0 05 00 00 	mov    0x5a0(%r14),%rax
   7b515:	49 03 86 c0 08 00 00 	add    0x8c0(%r14),%rax
   7b51c:	48 c1 ea 02          	shr    $0x2,%rdx
   7b520:	48 01 d0             	add    %rdx,%rax
   7b523:	41 0f b6 8e 8d 02 00 	movzbl 0x28d(%r14),%ecx
   7b52a:	00 
   7b52b:	88 4c 24 20          	mov    %cl,0x20(%rsp)
   7b52f:	41 0f b6 8e 8e 02 00 	movzbl 0x28e(%r14),%ecx
   7b536:	00 
   7b537:	88 4c 24 38          	mov    %cl,0x38(%rsp)
   7b53b:	45 0f b6 ae 8f 02 00 	movzbl 0x28f(%r14),%r13d
   7b542:	00 
   7b543:	41 0f b6 8e 92 02 00 	movzbl 0x292(%r14),%ecx
   7b54a:	00 
   7b54b:	88 4c 24 0f          	mov    %cl,0xf(%rsp)
   7b54f:	41 0f b6 8e 97 02 00 	movzbl 0x297(%r14),%ecx
   7b556:	00 
   7b557:	88 4c 24 30          	mov    %cl,0x30(%rsp)
   7b55b:	48 83 f8 20          	cmp    $0x20,%rax
   7b55f:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
   7b564:	72 1c                	jb     7b582 <varlit_core::file::VarlitFile::mark_record_dead+0x2c2>
   7b566:	48 89 c1             	mov    %rax,%rcx
   7b569:	48 c1 e1 09          	shl    $0x9,%rcx
   7b56d:	48 c1 e8 37          	shr    $0x37,%rax
   7b571:	0f 94 c0             	sete   %al
   7b574:	48 39 cd             	cmp    %rcx,%rbp
   7b577:	0f 97 c1             	seta   %cl
   7b57a:	84 c8                	test   %cl,%al
   7b57c:	0f 85 0c 02 00 00    	jne    7b78e <varlit_core::file::VarlitFile::mark_record_dead+0x4ce>
   7b582:	44 88 6c 24 40       	mov    %r13b,0x40(%rsp)
   7b587:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   7b58e:	25 00 00 00 00 
   7b593:	48 8b 88 98 ff ff ff 	mov    -0x68(%rax),%rcx
   7b59a:	48 ff c1             	inc    %rcx
   7b59d:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
   7b5a4:	48 0f 45 d1          	cmovne %rcx,%rdx
   7b5a8:	48 89 90 98 ff ff ff 	mov    %rdx,-0x68(%rax)
   7b5af:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
   7b5b6:	00 
   7b5b7:	45 31 ed             	xor    %r13d,%r13d
   7b5ba:	41 bf 00 02 00 00    	mov    $0x200,%r15d
   7b5c0:	ba 00 02 00 00       	mov    $0x200,%edx
   7b5c5:	31 f6                	xor    %esi,%esi
   7b5c7:	ff 15 13 58 15 00    	call   *0x155813(%rip)        # 1d0de0 <memset@GLIBC_2.2.5>
   7b5cd:	48 89 e8             	mov    %rbp,%rax
   7b5d0:	48 2b 04 24          	sub    (%rsp),%rax
   7b5d4:	49 0f 42 c5          	cmovb  %r13,%rax
   7b5d8:	48 83 f8 21          	cmp    $0x21,%rax
   7b5dc:	41 bb 20 00 00 00    	mov    $0x20,%r11d
   7b5e2:	4c 0f 43 d8          	cmovae %rax,%r11
   7b5e6:	49 81 fb 00 02 00 00 	cmp    $0x200,%r11
   7b5ed:	4d 0f 43 df          	cmovae %r15,%r11
   7b5f1:	48 8b 14 24          	mov    (%rsp),%rdx
   7b5f5:	4c 89 d8             	mov    %r11,%rax
   7b5f8:	bf 02 00 00 00       	mov    $0x2,%edi
   7b5fd:	48 01 d0             	add    %rdx,%rax
   7b600:	0f 82 bd 0b 00 00    	jb     7c1c3 <varlit_core::file::VarlitFile::mark_record_dead+0xf03>
   7b606:	48 39 e8             	cmp    %rbp,%rax
   7b609:	0f 86 82 00 00 00    	jbe    7b691 <varlit_core::file::VarlitFile::mark_record_dead+0x3d1>
   7b60f:	4d 8d 44 24 e7       	lea    -0x19(%r12),%r8
   7b614:	48 89 e8             	mov    %rbp,%rax
   7b617:	31 ed                	xor    %ebp,%ebp
   7b619:	e9 dc 01 00 00       	jmp    7b7fa <varlit_core::file::VarlitFile::mark_record_dead+0x53a>
   7b61e:	49 83 c4 e1          	add    $0xffffffffffffffe1,%r12
   7b622:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
   7b629:	00 
   7b62a:	48 8d 05 47 af fa ff 	lea    -0x550b9(%rip),%rax        # 26578 <anon.272046bdb21d5e9799f7df567f2ebed8.64.llvm.11952611753328415554>
   7b631:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   7b638:	00 
   7b639:	48 c7 84 24 20 01 00 	movq   $0x26,0x120(%rsp)
   7b640:	00 26 00 00 00 
   7b645:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
   7b64c:	00 
   7b64d:	48 89 43 30          	mov    %rax,0x30(%rbx)
   7b651:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   7b658:	00 
   7b659:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   7b660:	00 
   7b661:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
   7b668:	00 
   7b669:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
   7b670:	00 
   7b671:	0f 10 84 24 30 01 00 	movups 0x130(%rsp),%xmm0
   7b678:	00 
   7b679:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   7b67d:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   7b681:	48 89 73 18          	mov    %rsi,0x18(%rbx)
   7b685:	48 89 03             	mov    %rax,(%rbx)
   7b688:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   7b68c:	e9 47 fd ff ff       	jmp    7b3d8 <varlit_core::file::VarlitFile::mark_record_dead+0x118>
   7b691:	49 8b ae 30 0d 00 00 	mov    0xd30(%r14),%rbp
   7b698:	48 83 c5 08          	add    $0x8,%rbp
   7b69c:	45 31 ed             	xor    %r13d,%r13d
   7b69f:	eb 2e                	jmp    7b6cf <varlit_core::file::VarlitFile::mark_record_dead+0x40f>
   7b6a1:	48 89 d0             	mov    %rdx,%rax
   7b6a4:	48 c1 e8 20          	shr    $0x20,%rax
   7b6a8:	83 f8 2a             	cmp    $0x2a,%eax
   7b6ab:	b9 2a 00 00 00       	mov    $0x2a,%ecx
   7b6b0:	0f 43 c1             	cmovae %ecx,%eax
   7b6b3:	3c 23                	cmp    $0x23,%al
   7b6b5:	0f 85 47 03 00 00    	jne    7ba02 <varlit_core::file::VarlitFile::mark_record_dead+0x742>
   7b6bb:	48 89 d7             	mov    %rdx,%rdi
   7b6be:	e8 0d df 00 00       	call   895d0 <core::ptr::drop_in_place<std::io::error::Error>>
   7b6c3:	4d 89 fb             	mov    %r15,%r11
   7b6c6:	4d 39 fd             	cmp    %r15,%r13
   7b6c9:	0f 83 33 01 00 00    	jae    7b802 <varlit_core::file::VarlitFile::mark_record_dead+0x542>
   7b6cf:	4c 89 e9             	mov    %r13,%rcx
   7b6d2:	48 03 0c 24          	add    (%rsp),%rcx
   7b6d6:	0f 82 97 09 00 00    	jb     7c073 <varlit_core::file::VarlitFile::mark_record_dead+0xdb3>
   7b6dc:	4d 89 df             	mov    %r11,%r15
   7b6df:	4c 89 da             	mov    %r11,%rdx
   7b6e2:	4c 29 ea             	sub    %r13,%rdx
   7b6e5:	4a 8d 34 2c          	lea    (%rsp,%r13,1),%rsi
   7b6e9:	48 81 c6 10 01 00 00 	add    $0x110,%rsi
   7b6f0:	48 89 ef             	mov    %rbp,%rdi
   7b6f3:	ff 15 ff 5b 15 00    	call   *0x155bff(%rip)        # 1d12f8 <_DYNAMIC+0x860>
   7b6f9:	48 83 f8 01          	cmp    $0x1,%rax
   7b6fd:	75 1b                	jne    7b71a <varlit_core::file::VarlitFile::mark_record_dead+0x45a>
   7b6ff:	89 d0                	mov    %edx,%eax
   7b701:	83 e0 03             	and    $0x3,%eax
   7b704:	48 8d 0d 7d 69 fa ff 	lea    -0x59683(%rip),%rcx        # 22088 <anon.0ccafa760f16028ef2da30d8fb23ded9.3.llvm.8148477165880511475+0x16a3>
   7b70b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   7b70f:	48 01 c8             	add    %rcx,%rax
   7b712:	ff e0                	jmp    *%rax
   7b714:	0f b6 42 10          	movzbl 0x10(%rdx),%eax
   7b718:	eb 99                	jmp    7b6b3 <varlit_core::file::VarlitFile::mark_record_dead+0x3f3>
   7b71a:	48 85 d2             	test   %rdx,%rdx
   7b71d:	0f 84 d8 02 00 00    	je     7b9fb <varlit_core::file::VarlitFile::mark_record_dead+0x73b>
   7b723:	49 01 d5             	add    %rdx,%r13
   7b726:	4d 89 fb             	mov    %r15,%r11
   7b729:	4d 39 fd             	cmp    %r15,%r13
   7b72c:	72 a1                	jb     7b6cf <varlit_core::file::VarlitFile::mark_record_dead+0x40f>
   7b72e:	e9 cf 00 00 00       	jmp    7b802 <varlit_core::file::VarlitFile::mark_record_dead+0x542>
   7b733:	48 89 d0             	mov    %rdx,%rax
   7b736:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   7b73d:	ff ff ff 
   7b740:	48 21 c8             	and    %rcx,%rax
   7b743:	48 b9 00 00 00 00 04 	movabs $0x400000000,%rcx
   7b74a:	00 00 00 
   7b74d:	48 39 c8             	cmp    %rcx,%rax
   7b750:	0f 84 65 ff ff ff    	je     7b6bb <varlit_core::file::VarlitFile::mark_record_dead+0x3fb>
   7b756:	e9 a7 02 00 00       	jmp    7ba02 <varlit_core::file::VarlitFile::mark_record_dead+0x742>
   7b75b:	0f b6 42 0f          	movzbl 0xf(%rdx),%eax
   7b75f:	e9 4f ff ff ff       	jmp    7b6b3 <varlit_core::file::VarlitFile::mark_record_dead+0x3f3>
   7b764:	0f 10 84 24 28 01 00 	movups 0x128(%rsp),%xmm0
   7b76b:	00 
   7b76c:	f3 0f 6f 8c 24 38 01 	movdqu 0x138(%rsp),%xmm1
   7b773:	00 00 
   7b775:	f3 0f 7f 4b 28       	movdqu %xmm1,0x28(%rbx)
   7b77a:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
   7b77e:	48 89 13             	mov    %rdx,(%rbx)
   7b781:	48 89 43 08          	mov    %rax,0x8(%rbx)
   7b785:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   7b789:	e9 4a fc ff ff       	jmp    7b3d8 <varlit_core::file::VarlitFile::mark_record_dead+0x118>
   7b78e:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   7b795:	25 00 00 00 00 
   7b79a:	48 8b 88 98 ff ff ff 	mov    -0x68(%rax),%rcx
   7b7a1:	48 ff c1             	inc    %rcx
   7b7a4:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
   7b7ab:	48 0f 45 d1          	cmovne %rcx,%rdx
   7b7af:	48 89 90 98 ff ff ff 	mov    %rdx,-0x68(%rax)
   7b7b6:	0f 57 c0             	xorps  %xmm0,%xmm0
   7b7b9:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   7b7be:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   7b7c3:	48 8b 14 24          	mov    (%rsp),%rdx
   7b7c7:	4c 8d 52 20          	lea    0x20(%rdx),%r10
   7b7cb:	4d 8d 44 24 e5       	lea    -0x1b(%r12),%r8
   7b7d0:	bf 02 00 00 00       	mov    $0x2,%edi
   7b7d5:	48 83 fa df          	cmp    $0xffffffffffffffdf,%rdx
   7b7d9:	0f 87 a6 0a 00 00    	ja     7c285 <varlit_core::file::VarlitFile::mark_record_dead+0xfc5>
   7b7df:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   7b7e4:	49 39 c2             	cmp    %rax,%r10
   7b7e7:	0f 86 35 01 00 00    	jbe    7b922 <varlit_core::file::VarlitFile::mark_record_dead+0x662>
   7b7ed:	4d 8d 44 24 e7       	lea    -0x19(%r12),%r8
   7b7f2:	31 ed                	xor    %ebp,%ebp
   7b7f4:	41 bb 20 00 00 00    	mov    $0x20,%r11d
   7b7fa:	48 89 d6             	mov    %rdx,%rsi
   7b7fd:	e9 73 06 00 00       	jmp    7be75 <varlit_core::file::VarlitFile::mark_record_dead+0xbb5>
   7b802:	49 8d 4c 24 e5       	lea    -0x1b(%r12),%rcx
   7b807:	48 8b 14 24          	mov    (%rsp),%rdx
   7b80b:	48 83 fa df          	cmp    $0xffffffffffffffdf,%rdx
   7b80f:	0f 87 e5 0a 00 00    	ja     7c2fa <varlit_core::file::VarlitFile::mark_record_dead+0x103a>
   7b815:	8b 84 24 10 01 00 00 	mov    0x110(%rsp),%eax
   7b81c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   7b820:	66 0f 6e 8c 24 14 01 	movd   0x114(%rsp),%xmm1
   7b827:	00 00 
   7b829:	4c 8b bc 24 18 01 00 	mov    0x118(%rsp),%r15
   7b830:	00 
   7b831:	4c 8b 8c 24 20 01 00 	mov    0x120(%rsp),%r9
   7b838:	00 
   7b839:	f2 0f 10 94 24 28 01 	movsd  0x128(%rsp),%xmm2
   7b840:	00 00 
   7b842:	4c 8d 52 20          	lea    0x20(%rdx),%r10
   7b846:	80 7c 24 30 02       	cmpb   $0x2,0x30(%rsp)
   7b84b:	bf 02 00 00 00       	mov    $0x2,%edi
   7b850:	75 1c                	jne    7b86e <varlit_core::file::VarlitFile::mark_record_dead+0x5ae>
   7b852:	0f b6 74 24 20       	movzbl 0x20(%rsp),%esi
   7b857:	40 3a 74 24 38       	cmp    0x38(%rsp),%sil
   7b85c:	0f 95 c0             	setne  %al
   7b85f:	40 08 f0             	or     %sil,%al
   7b862:	0a 44 24 40          	or     0x40(%rsp),%al
   7b866:	a8 01                	test   $0x1,%al
   7b868:	0f 84 7e 02 00 00    	je     7baec <varlit_core::file::VarlitFile::mark_record_dead+0x82c>
   7b86e:	4d 89 c8             	mov    %r9,%r8
   7b871:	4d 01 d0             	add    %r10,%r8
   7b874:	0f 82 a7 0a 00 00    	jb     7c321 <varlit_core::file::VarlitFile::mark_record_dead+0x1061>
   7b87a:	0f 57 c0             	xorps  %xmm0,%xmm0
   7b87d:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   7b882:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   7b887:	4c 89 c0             	mov    %r8,%rax
   7b88a:	48 29 d0             	sub    %rdx,%rax
   7b88d:	48 89 c1             	mov    %rax,%rcx
   7b890:	48 83 e9 e0          	sub    $0xffffffffffffffe0,%rcx
   7b894:	0f 83 8b 01 00 00    	jae    7ba25 <varlit_core::file::VarlitFile::mark_record_dead+0x765>
   7b89a:	4c 39 d9             	cmp    %r11,%rcx
   7b89d:	0f 87 82 01 00 00    	ja     7ba25 <varlit_core::file::VarlitFile::mark_record_dead+0x765>
   7b8a3:	48 8d 0c 04          	lea    (%rsp,%rax,1),%rcx
   7b8a7:	48 81 c1 10 01 00 00 	add    $0x110,%rcx
   7b8ae:	81 39 56 52 46 31    	cmpl   $0x31465256,(%rcx)
   7b8b4:	0f 85 86 04 00 00    	jne    7bd40 <varlit_core::file::VarlitFile::mark_record_dead+0xa80>
   7b8ba:	66 83 79 04 01       	cmpw   $0x1,0x4(%rcx)
   7b8bf:	0f 85 7b 04 00 00    	jne    7bd40 <varlit_core::file::VarlitFile::mark_record_dead+0xa80>
   7b8c5:	83 79 18 00          	cmpl   $0x0,0x18(%rcx)
   7b8c9:	0f 85 71 04 00 00    	jne    7bd40 <varlit_core::file::VarlitFile::mark_record_dead+0xa80>
   7b8cf:	0f b7 41 06          	movzwl 0x6(%rcx),%eax
   7b8d3:	66 83 f8 03          	cmp    $0x3,%ax
   7b8d7:	0f 87 63 04 00 00    	ja     7bd40 <varlit_core::file::VarlitFile::mark_record_dead+0xa80>
   7b8dd:	4d 89 cd             	mov    %r9,%r13
   7b8e0:	4c 89 fd             	mov    %r15,%rbp
   7b8e3:	49 89 cb             	mov    %rcx,%r11
   7b8e6:	4c 8b 79 08          	mov    0x8(%rcx),%r15
   7b8ea:	a8 01                	test   $0x1,%al
   7b8ec:	0f 84 a5 07 00 00    	je     7c097 <varlit_core::file::VarlitFile::mark_record_dead+0xdd7>
   7b8f2:	4d 85 ff             	test   %r15,%r15
   7b8f5:	0f 95 c1             	setne  %cl
   7b8f8:	48 89 d6             	mov    %rdx,%rsi
   7b8fb:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
   7b900:	49 39 d7             	cmp    %rdx,%r15
   7b903:	0f 92 c2             	setb   %dl
   7b906:	41 b9 01 00 00 00    	mov    $0x1,%r9d
   7b90c:	84 d1                	test   %dl,%cl
   7b90e:	0f 85 8f 07 00 00    	jne    7c0a3 <varlit_core::file::VarlitFile::mark_record_dead+0xde3>
   7b914:	45 31 c9             	xor    %r9d,%r9d
   7b917:	4d 89 e5             	mov    %r12,%r13
   7b91a:	48 89 f2             	mov    %rsi,%rdx
   7b91d:	e9 24 04 00 00       	jmp    7bd46 <varlit_core::file::VarlitFile::mark_record_dead+0xa86>
   7b922:	44 88 6c 24 40       	mov    %r13b,0x40(%rsp)
   7b927:	4c 89 54 24 18       	mov    %r10,0x18(%rsp)
   7b92c:	49 8b ae 30 0d 00 00 	mov    0xd30(%r14),%rbp
   7b933:	48 83 c5 08          	add    $0x8,%rbp
   7b937:	45 31 ed             	xor    %r13d,%r13d
   7b93a:	4c 8d 3d 67 67 fa ff 	lea    -0x59899(%rip),%r15        # 220a8 <anon.0ccafa760f16028ef2da30d8fb23ded9.3.llvm.8148477165880511475+0x16c3>
   7b941:	eb 2c                	jmp    7b96f <varlit_core::file::VarlitFile::mark_record_dead+0x6af>
   7b943:	48 89 d7             	mov    %rdx,%rdi
   7b946:	48 89 d0             	mov    %rdx,%rax
   7b949:	48 c1 e8 20          	shr    $0x20,%rax
   7b94d:	83 f8 2a             	cmp    $0x2a,%eax
   7b950:	b9 2a 00 00 00       	mov    $0x2a,%ecx
   7b955:	0f 43 c1             	cmovae %ecx,%eax
   7b958:	3c 23                	cmp    $0x23,%al
   7b95a:	0f 85 9a 02 00 00    	jne    7bbfa <varlit_core::file::VarlitFile::mark_record_dead+0x93a>
   7b960:	e8 6b dc 00 00       	call   895d0 <core::ptr::drop_in_place<std::io::error::Error>>
   7b965:	49 83 fd 20          	cmp    $0x20,%r13
   7b969:	0f 83 e7 00 00 00    	jae    7ba56 <varlit_core::file::VarlitFile::mark_record_dead+0x796>
   7b96f:	48 8b 04 24          	mov    (%rsp),%rax
   7b973:	4a 8d 0c 28          	lea    (%rax,%r13,1),%rcx
   7b977:	ba 20 00 00 00       	mov    $0x20,%edx
   7b97c:	4c 29 ea             	sub    %r13,%rdx
   7b97f:	4a 8d 34 2c          	lea    (%rsp,%r13,1),%rsi
   7b983:	48 83 c6 50          	add    $0x50,%rsi
   7b987:	48 89 ef             	mov    %rbp,%rdi
   7b98a:	ff 15 68 59 15 00    	call   *0x155968(%rip)        # 1d12f8 <_DYNAMIC+0x860>
   7b990:	48 83 f8 01          	cmp    $0x1,%rax
   7b994:	75 17                	jne    7b9ad <varlit_core::file::VarlitFile::mark_record_dead+0x6ed>
   7b996:	89 d0                	mov    %edx,%eax
   7b998:	83 e0 03             	and    $0x3,%eax
   7b99b:	49 63 04 87          	movslq (%r15,%rax,4),%rax
   7b99f:	4c 01 f8             	add    %r15,%rax
   7b9a2:	ff e0                	jmp    *%rax
   7b9a4:	48 89 d7             	mov    %rdx,%rdi
   7b9a7:	0f b6 42 10          	movzbl 0x10(%rdx),%eax
   7b9ab:	eb ab                	jmp    7b958 <varlit_core::file::VarlitFile::mark_record_dead+0x698>
   7b9ad:	48 85 d2             	test   %rdx,%rdx
   7b9b0:	0f 84 3d 02 00 00    	je     7bbf3 <varlit_core::file::VarlitFile::mark_record_dead+0x933>
   7b9b6:	49 01 d5             	add    %rdx,%r13
   7b9b9:	49 83 fd 20          	cmp    $0x20,%r13
   7b9bd:	72 b0                	jb     7b96f <varlit_core::file::VarlitFile::mark_record_dead+0x6af>
   7b9bf:	e9 92 00 00 00       	jmp    7ba56 <varlit_core::file::VarlitFile::mark_record_dead+0x796>
   7b9c4:	48 89 d7             	mov    %rdx,%rdi
   7b9c7:	48 89 d0             	mov    %rdx,%rax
   7b9ca:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   7b9d1:	ff ff ff 
   7b9d4:	48 21 c8             	and    %rcx,%rax
   7b9d7:	48 b9 00 00 00 00 04 	movabs $0x400000000,%rcx
   7b9de:	00 00 00 
   7b9e1:	48 39 c8             	cmp    %rcx,%rax
   7b9e4:	0f 84 76 ff ff ff    	je     7b960 <varlit_core::file::VarlitFile::mark_record_dead+0x6a0>
   7b9ea:	e9 0b 02 00 00       	jmp    7bbfa <varlit_core::file::VarlitFile::mark_record_dead+0x93a>
   7b9ef:	48 89 d7             	mov    %rdx,%rdi
   7b9f2:	0f b6 42 0f          	movzbl 0xf(%rdx),%eax
   7b9f6:	e9 5d ff ff ff       	jmp    7b958 <varlit_core::file::VarlitFile::mark_record_dead+0x698>
   7b9fb:	4d 8d 44 24 db       	lea    -0x25(%r12),%r8
   7ba00:	eb 08                	jmp    7ba0a <varlit_core::file::VarlitFile::mark_record_dead+0x74a>
   7ba02:	48 89 d6             	mov    %rdx,%rsi
   7ba05:	4d 8d 44 24 d6       	lea    -0x2a(%r12),%r8
   7ba0a:	41 bb 14 00 00 00    	mov    $0x14,%r11d
   7ba10:	31 ed                	xor    %ebp,%ebp
   7ba12:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   7ba17:	48 8b 14 24          	mov    (%rsp),%rdx
   7ba1b:	bf 02 00 00 00       	mov    $0x2,%edi
   7ba20:	e9 50 04 00 00       	jmp    7be75 <varlit_core::file::VarlitFile::mark_record_dead+0xbb5>
   7ba25:	4c 89 c9             	mov    %r9,%rcx
   7ba28:	4d 8b 8e 38 0d 00 00 	mov    0xd38(%r14),%r9
   7ba2f:	49 83 f8 df          	cmp    $0xffffffffffffffdf,%r8
   7ba33:	0f 87 0a 09 00 00    	ja     7c343 <varlit_core::file::VarlitFile::mark_record_dead+0x1083>
   7ba39:	49 8d 40 20          	lea    0x20(%r8),%rax
   7ba3d:	4c 39 c8             	cmp    %r9,%rax
   7ba40:	0f 86 c7 00 00 00    	jbe    7bb0d <varlit_core::file::VarlitFile::mark_record_dead+0x84d>
   7ba46:	4d 8d 6c 24 e7       	lea    -0x19(%r12),%r13
   7ba4b:	41 bb 20 00 00 00    	mov    $0x20,%r11d
   7ba51:	e9 f0 02 00 00       	jmp    7bd46 <varlit_core::file::VarlitFile::mark_record_dead+0xa86>
   7ba56:	8b 4c 24 50          	mov    0x50(%rsp),%ecx
   7ba5a:	66 0f 6e 4c 24 54    	movd   0x54(%rsp),%xmm1
   7ba60:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
   7ba65:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   7ba6a:	f2 0f 10 54 24 68    	movsd  0x68(%rsp),%xmm2
   7ba70:	80 7c 24 30 02       	cmpb   $0x2,0x30(%rsp)
   7ba75:	75 1a                	jne    7ba91 <varlit_core::file::VarlitFile::mark_record_dead+0x7d1>
   7ba77:	0f b6 54 24 20       	movzbl 0x20(%rsp),%edx
   7ba7c:	3a 54 24 38          	cmp    0x38(%rsp),%dl
   7ba80:	0f 95 c0             	setne  %al
   7ba83:	08 d0                	or     %dl,%al
   7ba85:	0a 44 24 40          	or     0x40(%rsp),%al
   7ba89:	a8 01                	test   $0x1,%al
   7ba8b:	0f 84 ca 02 00 00    	je     7bd5b <varlit_core::file::VarlitFile::mark_record_dead+0xa9b>
   7ba91:	48 89 f2             	mov    %rsi,%rdx
   7ba94:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   7ba99:	4c 01 d6             	add    %r10,%rsi
   7ba9c:	0f 82 d7 08 00 00    	jb     7c379 <varlit_core::file::VarlitFile::mark_record_dead+0x10b9>
   7baa2:	0f 57 c0             	xorps  %xmm0,%xmm0
   7baa5:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
   7baac:	00 
   7baad:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
   7bab4:	00 
   7bab5:	4d 8b 8e 38 0d 00 00 	mov    0xd38(%r14),%r9
   7babc:	48 83 fe df          	cmp    $0xffffffffffffffdf,%rsi
   7bac0:	0f 87 e0 08 00 00    	ja     7c3a6 <varlit_core::file::VarlitFile::mark_record_dead+0x10e6>
   7bac6:	48 8d 46 20          	lea    0x20(%rsi),%rax
   7baca:	4c 39 c8             	cmp    %r9,%rax
   7bacd:	0f 86 4f 01 00 00    	jbe    7bc22 <varlit_core::file::VarlitFile::mark_record_dead+0x962>
   7bad3:	4d 8d 44 24 e7       	lea    -0x19(%r12),%r8
   7bad8:	41 bb 20 00 00 00    	mov    $0x20,%r11d
   7bade:	48 8b 14 24          	mov    (%rsp),%rdx
   7bae2:	bf 02 00 00 00       	mov    $0x2,%edi
   7bae7:	e9 7f 03 00 00       	jmp    7be6b <varlit_core::file::VarlitFile::mark_record_dead+0xbab>
   7baec:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   7baf1:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   7baf8:	00 00 
   7bafa:	31 c0                	xor    %eax,%eax
   7bafc:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   7bb03:	00 
   7bb04:	31 f6                	xor    %esi,%esi
   7bb06:	31 ff                	xor    %edi,%edi
   7bb08:	e9 68 03 00 00       	jmp    7be75 <varlit_core::file::VarlitFile::mark_record_dead+0xbb5>
   7bb0d:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   7bb14:	00 
   7bb15:	66 0f 7f 4c 24 40    	movdqa %xmm1,0x40(%rsp)
   7bb1b:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
   7bb20:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   7bb25:	4c 89 54 24 18       	mov    %r10,0x18(%rsp)
   7bb2a:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
   7bb2f:	4d 89 c5             	mov    %r8,%r13
   7bb32:	45 31 ff             	xor    %r15d,%r15d
   7bb35:	49 8d 44 24 d6       	lea    -0x2a(%r12),%rax
   7bb3a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   7bb3f:	eb 2c                	jmp    7bb6d <varlit_core::file::VarlitFile::mark_record_dead+0x8ad>
   7bb41:	48 89 d0             	mov    %rdx,%rax
   7bb44:	48 c1 e8 20          	shr    $0x20,%rax
   7bb48:	83 f8 2a             	cmp    $0x2a,%eax
   7bb4b:	b9 2a 00 00 00       	mov    $0x2a,%ecx
   7bb50:	0f 43 c1             	cmovae %ecx,%eax
   7bb53:	3c 23                	cmp    $0x23,%al
   7bb55:	0f 85 c7 02 00 00    	jne    7be22 <varlit_core::file::VarlitFile::mark_record_dead+0xb62>
   7bb5b:	48 89 d7             	mov    %rdx,%rdi
   7bb5e:	e8 6d da 00 00       	call   895d0 <core::ptr::drop_in_place<std::io::error::Error>>
   7bb63:	49 83 ff 20          	cmp    $0x20,%r15
   7bb67:	0f 83 99 01 00 00    	jae    7bd06 <varlit_core::file::VarlitFile::mark_record_dead+0xa46>
   7bb6d:	4b 8d 0c 2f          	lea    (%r15,%r13,1),%rcx
   7bb71:	ba 20 00 00 00       	mov    $0x20,%edx
   7bb76:	4c 29 fa             	sub    %r15,%rdx
   7bb79:	4a 8d 34 3c          	lea    (%rsp,%r15,1),%rsi
   7bb7d:	48 83 c6 50          	add    $0x50,%rsi
   7bb81:	48 89 ef             	mov    %rbp,%rdi
   7bb84:	ff 15 6e 57 15 00    	call   *0x15576e(%rip)        # 1d12f8 <_DYNAMIC+0x860>
   7bb8a:	48 83 f8 01          	cmp    $0x1,%rax
   7bb8e:	75 1b                	jne    7bbab <varlit_core::file::VarlitFile::mark_record_dead+0x8eb>
   7bb90:	89 d0                	mov    %edx,%eax
   7bb92:	83 e0 03             	and    $0x3,%eax
   7bb95:	48 8d 0d fc 64 fa ff 	lea    -0x59b04(%rip),%rcx        # 22098 <anon.0ccafa760f16028ef2da30d8fb23ded9.3.llvm.8148477165880511475+0x16b3>
   7bb9c:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   7bba0:	48 01 c8             	add    %rcx,%rax
   7bba3:	ff e0                	jmp    *%rax
   7bba5:	0f b6 42 10          	movzbl 0x10(%rdx),%eax
   7bba9:	eb a8                	jmp    7bb53 <varlit_core::file::VarlitFile::mark_record_dead+0x893>
   7bbab:	48 85 d2             	test   %rdx,%rdx
   7bbae:	0f 84 64 02 00 00    	je     7be18 <varlit_core::file::VarlitFile::mark_record_dead+0xb58>
   7bbb4:	49 01 d7             	add    %rdx,%r15
   7bbb7:	49 83 ff 20          	cmp    $0x20,%r15
   7bbbb:	72 b0                	jb     7bb6d <varlit_core::file::VarlitFile::mark_record_dead+0x8ad>
   7bbbd:	e9 44 01 00 00       	jmp    7bd06 <varlit_core::file::VarlitFile::mark_record_dead+0xa46>
   7bbc2:	48 89 d0             	mov    %rdx,%rax
   7bbc5:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   7bbcc:	ff ff ff 
   7bbcf:	48 21 c8             	and    %rcx,%rax
   7bbd2:	48 b9 00 00 00 00 04 	movabs $0x400000000,%rcx
   7bbd9:	00 00 00 
   7bbdc:	48 39 c8             	cmp    %rcx,%rax
   7bbdf:	0f 84 76 ff ff ff    	je     7bb5b <varlit_core::file::VarlitFile::mark_record_dead+0x89b>
   7bbe5:	e9 38 02 00 00       	jmp    7be22 <varlit_core::file::VarlitFile::mark_record_dead+0xb62>
   7bbea:	0f b6 42 0f          	movzbl 0xf(%rdx),%eax
   7bbee:	e9 60 ff ff ff       	jmp    7bb53 <varlit_core::file::VarlitFile::mark_record_dead+0x893>
   7bbf3:	4d 8d 44 24 db       	lea    -0x25(%r12),%r8
   7bbf8:	eb 08                	jmp    7bc02 <varlit_core::file::VarlitFile::mark_record_dead+0x942>
   7bbfa:	48 89 fe             	mov    %rdi,%rsi
   7bbfd:	4d 8d 44 24 d6       	lea    -0x2a(%r12),%r8
   7bc02:	41 bb 14 00 00 00    	mov    $0x14,%r11d
   7bc08:	31 ed                	xor    %ebp,%ebp
   7bc0a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   7bc0f:	48 8b 14 24          	mov    (%rsp),%rdx
   7bc13:	bf 02 00 00 00       	mov    $0x2,%edi
   7bc18:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   7bc1d:	e9 53 02 00 00       	jmp    7be75 <varlit_core::file::VarlitFile::mark_record_dead+0xbb5>
   7bc22:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   7bc29:	00 
   7bc2a:	66 0f 7f 4c 24 40    	movdqa %xmm1,0x40(%rsp)
   7bc30:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
   7bc35:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   7bc3a:	89 4c 24 2c          	mov    %ecx,0x2c(%rsp)
   7bc3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
   7bc43:	45 31 ff             	xor    %r15d,%r15d
   7bc46:	eb 2f                	jmp    7bc77 <varlit_core::file::VarlitFile::mark_record_dead+0x9b7>
   7bc48:	48 89 d0             	mov    %rdx,%rax
   7bc4b:	48 c1 e8 20          	shr    $0x20,%rax
   7bc4f:	83 f8 2a             	cmp    $0x2a,%eax
   7bc52:	b9 2a 00 00 00       	mov    $0x2a,%ecx
   7bc57:	0f 43 c1             	cmovae %ecx,%eax
   7bc5a:	3c 23                	cmp    $0x23,%al
   7bc5c:	0f 85 e8 01 00 00    	jne    7be4a <varlit_core::file::VarlitFile::mark_record_dead+0xb8a>
   7bc62:	48 89 d7             	mov    %rdx,%rdi
   7bc65:	e8 66 d9 00 00       	call   895d0 <core::ptr::drop_in_place<std::io::error::Error>>
   7bc6a:	49 83 ff 20          	cmp    $0x20,%r15
   7bc6e:	4c 89 ee             	mov    %r13,%rsi
   7bc71:	0f 83 12 01 00 00    	jae    7bd89 <varlit_core::file::VarlitFile::mark_record_dead+0xac9>
   7bc77:	49 89 f5             	mov    %rsi,%r13
   7bc7a:	49 8d 0c 37          	lea    (%r15,%rsi,1),%rcx
   7bc7e:	ba 20 00 00 00       	mov    $0x20,%edx
   7bc83:	4c 29 fa             	sub    %r15,%rdx
   7bc86:	4a 8d 34 3c          	lea    (%rsp,%r15,1),%rsi
   7bc8a:	48 81 c6 10 01 00 00 	add    $0x110,%rsi
   7bc91:	48 89 ef             	mov    %rbp,%rdi
   7bc94:	ff 15 5e 56 15 00    	call   *0x15565e(%rip)        # 1d12f8 <_DYNAMIC+0x860>
   7bc9a:	48 83 f8 01          	cmp    $0x1,%rax
   7bc9e:	75 1b                	jne    7bcbb <varlit_core::file::VarlitFile::mark_record_dead+0x9fb>
   7bca0:	89 d0                	mov    %edx,%eax
   7bca2:	83 e0 03             	and    $0x3,%eax
   7bca5:	48 8d 0d 0c 64 fa ff 	lea    -0x59bf4(%rip),%rcx        # 220b8 <anon.0ccafa760f16028ef2da30d8fb23ded9.3.llvm.8148477165880511475+0x16d3>
   7bcac:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   7bcb0:	48 01 c8             	add    %rcx,%rax
   7bcb3:	ff e0                	jmp    *%rax
   7bcb5:	0f b6 42 10          	movzbl 0x10(%rdx),%eax
   7bcb9:	eb 9f                	jmp    7bc5a <varlit_core::file::VarlitFile::mark_record_dead+0x99a>
   7bcbb:	48 85 d2             	test   %rdx,%rdx
   7bcbe:	0f 84 7f 01 00 00    	je     7be43 <varlit_core::file::VarlitFile::mark_record_dead+0xb83>
   7bcc4:	49 01 d7             	add    %rdx,%r15
   7bcc7:	49 83 ff 20          	cmp    $0x20,%r15
   7bccb:	4c 89 ee             	mov    %r13,%rsi
   7bcce:	72 a7                	jb     7bc77 <varlit_core::file::VarlitFile::mark_record_dead+0x9b7>
   7bcd0:	e9 b4 00 00 00       	jmp    7bd89 <varlit_core::file::VarlitFile::mark_record_dead+0xac9>
   7bcd5:	48 89 d0             	mov    %rdx,%rax
   7bcd8:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   7bcdf:	ff ff ff 
   7bce2:	48 21 c8             	and    %rcx,%rax
   7bce5:	48 b9 00 00 00 00 04 	movabs $0x400000000,%rcx
   7bcec:	00 00 00 
   7bcef:	48 39 c8             	cmp    %rcx,%rax
   7bcf2:	0f 84 6a ff ff ff    	je     7bc62 <varlit_core::file::VarlitFile::mark_record_dead+0x9a2>
   7bcf8:	e9 4d 01 00 00       	jmp    7be4a <varlit_core::file::VarlitFile::mark_record_dead+0xb8a>
   7bcfd:	0f b6 42 0f          	movzbl 0xf(%rdx),%eax
   7bd01:	e9 54 ff ff ff       	jmp    7bc5a <varlit_core::file::VarlitFile::mark_record_dead+0x99a>
   7bd06:	48 8b 14 24          	mov    (%rsp),%rdx
   7bd0a:	bf 02 00 00 00       	mov    $0x2,%edi
   7bd0f:	4d 89 e8             	mov    %r13,%r8
   7bd12:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   7bd17:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
   7bd1c:	4c 8b 7c 24 38       	mov    0x38(%rsp),%r15
   7bd21:	66 0f 6f 4c 24 40    	movdqa 0x40(%rsp),%xmm1
   7bd27:	0f 28 94 24 90 00 00 	movaps 0x90(%rsp),%xmm2
   7bd2e:	00 
   7bd2f:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
   7bd34:	81 39 56 52 46 31    	cmpl   $0x31465256,(%rcx)
   7bd3a:	0f 84 7a fb ff ff    	je     7b8ba <varlit_core::file::VarlitFile::mark_record_dead+0x5fa>
   7bd40:	45 31 c9             	xor    %r9d,%r9d
   7bd43:	4d 89 e5             	mov    %r12,%r13
   7bd46:	31 ed                	xor    %ebp,%ebp
   7bd48:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
   7bd4d:	4c 89 c8             	mov    %r9,%rax
   7bd50:	4c 89 c6             	mov    %r8,%rsi
   7bd53:	4d 89 e8             	mov    %r13,%r8
   7bd56:	e9 1a 01 00 00       	jmp    7be75 <varlit_core::file::VarlitFile::mark_record_dead+0xbb5>
   7bd5b:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   7bd60:	89 4c 24 2c          	mov    %ecx,0x2c(%rsp)
   7bd64:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   7bd6b:	00 00 
   7bd6d:	31 c0                	xor    %eax,%eax
   7bd6f:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   7bd76:	00 
   7bd77:	31 f6                	xor    %esi,%esi
   7bd79:	31 ff                	xor    %edi,%edi
   7bd7b:	48 8b 14 24          	mov    (%rsp),%rdx
   7bd7f:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   7bd84:	e9 ec 00 00 00       	jmp    7be75 <varlit_core::file::VarlitFile::mark_record_dead+0xbb5>
   7bd89:	45 31 c9             	xor    %r9d,%r9d
   7bd8c:	81 bc 24 10 01 00 00 	cmpl   $0x31465256,0x110(%rsp)
   7bd93:	56 52 46 31 
   7bd97:	0f 85 19 03 00 00    	jne    7c0b6 <varlit_core::file::VarlitFile::mark_record_dead+0xdf6>
   7bd9d:	66 83 bc 24 14 01 00 	cmpw   $0x1,0x114(%rsp)
   7bda4:	00 01 
   7bda6:	48 8b 14 24          	mov    (%rsp),%rdx
   7bdaa:	bf 02 00 00 00       	mov    $0x2,%edi
   7bdaf:	0f 85 22 03 00 00    	jne    7c0d7 <varlit_core::file::VarlitFile::mark_record_dead+0xe17>
   7bdb5:	83 bc 24 28 01 00 00 	cmpl   $0x0,0x128(%rsp)
   7bdbc:	00 
   7bdbd:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   7bdc2:	0f 85 bc 02 00 00    	jne    7c084 <varlit_core::file::VarlitFile::mark_record_dead+0xdc4>
   7bdc8:	0f b7 84 24 16 01 00 	movzwl 0x116(%rsp),%eax
   7bdcf:	00 
   7bdd0:	66 83 f8 03          	cmp    $0x3,%ax
   7bdd4:	0f 87 b2 02 00 00    	ja     7c08c <varlit_core::file::VarlitFile::mark_record_dead+0xdcc>
   7bdda:	4c 8b 84 24 18 01 00 	mov    0x118(%rsp),%r8
   7bde1:	00 
   7bde2:	a8 01                	test   $0x1,%al
   7bde4:	0f 84 dd 02 00 00    	je     7c0c7 <varlit_core::file::VarlitFile::mark_record_dead+0xe07>
   7bdea:	4d 85 c0             	test   %r8,%r8
   7bded:	0f 95 c1             	setne  %cl
   7bdf0:	48 89 d6             	mov    %rdx,%rsi
   7bdf3:	4d 89 c3             	mov    %r8,%r11
   7bdf6:	49 39 d0             	cmp    %rdx,%r8
   7bdf9:	0f 92 c2             	setb   %dl
   7bdfc:	41 b9 01 00 00 00    	mov    $0x1,%r9d
   7be02:	84 d1                	test   %dl,%cl
   7be04:	0f 85 d5 02 00 00    	jne    7c0df <varlit_core::file::VarlitFile::mark_record_dead+0xe1f>
   7be0a:	45 31 c9             	xor    %r9d,%r9d
   7be0d:	4d 89 e0             	mov    %r12,%r8
   7be10:	48 89 f2             	mov    %rsi,%rdx
   7be13:	e9 a3 03 00 00       	jmp    7c1bb <varlit_core::file::VarlitFile::mark_record_dead+0xefb>
   7be18:	49 8d 44 24 db       	lea    -0x25(%r12),%rax
   7be1d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   7be22:	41 bb 14 00 00 00    	mov    $0x14,%r11d
   7be28:	49 89 d0             	mov    %rdx,%r8
   7be2b:	48 8b 14 24          	mov    (%rsp),%rdx
   7be2f:	bf 02 00 00 00       	mov    $0x2,%edi
   7be34:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
   7be39:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   7be3e:	e9 03 ff ff ff       	jmp    7bd46 <varlit_core::file::VarlitFile::mark_record_dead+0xa86>
   7be43:	4d 8d 44 24 db       	lea    -0x25(%r12),%r8
   7be48:	eb 05                	jmp    7be4f <varlit_core::file::VarlitFile::mark_record_dead+0xb8f>
   7be4a:	4d 8d 44 24 d6       	lea    -0x2a(%r12),%r8
   7be4f:	41 bb 14 00 00 00    	mov    $0x14,%r11d
   7be55:	48 89 d6             	mov    %rdx,%rsi
   7be58:	48 8b 14 24          	mov    (%rsp),%rdx
   7be5c:	bf 02 00 00 00       	mov    $0x2,%edi
   7be61:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
   7be66:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   7be6b:	31 ed                	xor    %ebp,%ebp
   7be6d:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
   7be72:	4c 89 c8             	mov    %r9,%rax
   7be75:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
   7be7c:	ff ff ff 
   7be7f:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
   7be84:	49 21 c9             	and    %rcx,%r9
   7be87:	89 c0                	mov    %eax,%eax
   7be89:	4c 09 c8             	or     %r9,%rax
   7be8c:	83 ff 02             	cmp    $0x2,%edi
   7be8f:	75 20                	jne    7beb1 <varlit_core::file::VarlitFile::mark_record_dead+0xbf1>
   7be91:	4c 89 03             	mov    %r8,(%rbx)
   7be94:	48 89 73 08          	mov    %rsi,0x8(%rbx)
   7be98:	4c 89 5b 10          	mov    %r11,0x10(%rbx)
   7be9c:	48 89 43 18          	mov    %rax,0x18(%rbx)
   7bea0:	48 89 6b 20          	mov    %rbp,0x20(%rbx)
   7bea4:	4c 89 7b 28          	mov    %r15,0x28(%rbx)
   7bea8:	48 89 53 30          	mov    %rdx,0x30(%rbx)
   7beac:	e9 27 f5 ff ff       	jmp    7b3d8 <varlit_core::file::VarlitFile::mark_record_dead+0x118>
   7beb1:	48 89 bc 24 a8 00 00 	mov    %rdi,0xa8(%rsp)
   7beb8:	00 
   7beb9:	4c 89 84 24 b0 00 00 	mov    %r8,0xb0(%rsp)
   7bec0:	00 
   7bec1:	48 89 b4 24 b8 00 00 	mov    %rsi,0xb8(%rsp)
   7bec8:	00 
   7bec9:	4c 89 9c 24 c0 00 00 	mov    %r11,0xc0(%rsp)
   7bed0:	00 
   7bed1:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
   7bed8:	00 
   7bed9:	48 89 ac 24 d0 00 00 	mov    %rbp,0xd0(%rsp)
   7bee0:	00 
   7bee1:	4c 89 bc 24 d8 00 00 	mov    %r15,0xd8(%rsp)
   7bee8:	00 
   7bee9:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
   7bef0:	00 
   7bef1:	4c 89 94 24 e8 00 00 	mov    %r10,0xe8(%rsp)
   7bef8:	00 
   7bef9:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   7befe:	48                   	rex.W
   7beff:	89                   	.byte 0x89
