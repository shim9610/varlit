set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
export MIRIFLAGS=-Zmiri-disable-isolation
for contract in scaled_positions_match_full_width_arithmetic cached_floor_bounds_probes_on_periodically_varying_extents cached_floor_matches_ordered_rows_across_irregular_and_full_width_gaps rewritten_membership_hints_preserve_gaps_and_truncated_prefixes; do
 cargo +nightly-2026-10-12 miri test --locked -p varlit-core --all-features --lib "$contract" > "/workspace/scratch/perf-recovery/refined-miri-$contract.log" 2>&1
done
