from pathlib import Path
import subprocess,json,hashlib,difflib
repo=Path('/workspace/varlit');r=Path('/workspace/scratch/perf-recovery');p=repo/'crates/varlit-core/src/spill_rows.rs';original=p.read_text();results=[]
controls=[('wrapping-product','delta.checked_mul(intervals)','Some(delta.wrapping_mul(intervals))','spill_rows::tests::scaled_positions_match_full_width_arithmetic'),('unchecked-refinement','if at == wanted {','if at != wanted {','spill_rows::tests::cached_floor_bounds_probes_on_periodically_varying_extents')]
try:
 for name,needle,replacement,test in controls:
  assert original.count(needle)==1
  mutant=original.replace(needle,replacement,1)
  (r/f'refined-control-{name}.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),mutant.splitlines(True),fromfile='original/spill_rows.rs',tofile=f'{name}/spill_rows.rs')))
  p.write_text(mutant)
  with (r/f'refined-control-{name}.log').open('w') as log:
   x=subprocess.run(['cargo','test','--locked','-p','varlit-core','--all-features','--lib',test,'--','--exact'],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
  log=(r/f'refined-control-{name}.log').read_text()
  detected=x.returncode!=0 and 'test result: FAILED' in log and 'assertion `left == right` failed' in log
  result={'control':name,'source_sha256':hashlib.sha256(original.encode()).hexdigest(),'mutation_sha256':hashlib.sha256(mutant.encode()).hexdigest(),'exit_code':x.returncode,'test':test,'detected_by_value_assertion':detected};results.append(result)
  (r/'refined-negative-controls.json').write_text(json.dumps(results,indent=2))
  assert detected,log[-3000:]
  p.write_text(original)
finally:
 p.write_text(original)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==hashlib.sha256(original.encode()).hexdigest()
print('Both deliberate defects detected; source restored byte-for-byte.')
