from pathlib import Path
import subprocess,shutil,hashlib,json,os,random,statistics
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');out=r/'refinement-diagnostic';out.mkdir(exist_ok=False)
paths={n:repo/'crates/varlit-core/src'/n for n in ['spill_rows.rs','native_directory.rs']};original={n:p.read_bytes() for n,p in paths.items()}
labels=['case-reference','unit-a2c','fast-scale','bounded-refine'];cases=[('record_mutation_load',['writer','mixed','random','131072','8192']),('oom_maintenance_load',['complex','65536','512']),('record_mutation_load',['writer','variable','random','200000','20000']),('record_mutation_load',['writer','mixed','random','131072','65536'])]
names=['record_mutation_load','oom_maintenance_load','scalable_load','ownership_load','ownership_boundary_load'];plan={'purpose':'diagnostic only, unchanged ordinary workloads; common-width exact arithmetic and bounded resident refinement; test each prototype before timing','groups':12,'seed':169235,'cases':cases,'reference':'record_mutation_load at317fc98; maintenance at749532d','variants':{}}
try:
 for label in labels:
  dest=out/(label+'-bin');dest.mkdir()
  if label=='case-reference':
   shutil.copy2('/workspace/varlit-pre-boundary/target/release/examples/record_mutation_load',dest/'record_mutation_load');shutil.copy2(r/'read-hint-bin/oom_maintenance_load',dest/'oom_maintenance_load')
  elif label=='unit-a2c':
   for n in names:shutil.copy2(r/'adaptive-scratch-bin'/n,dest/n)
  else:
   src=r/('refinement-fast-source' if label=='fast-scale' else 'refinement-combined-source')
   for n,p in paths.items():p.write_bytes((src/n).read_bytes())
   print('REGRESSION',label,flush=True)
   with (out/(label+'-tests.log')).open('w') as f:subprocess.run(['cargo','test','--locked','-p','varlit-core','--all-features','--lib'],cwd=repo,env={**os.environ,'CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_DEV_DEBUG':'0'},stdout=f,stderr=subprocess.STDOUT,check=True)
   print('BUILD',label,flush=True)
   with (out/(label+'-build.log')).open('w') as f:subprocess.run(['cargo','build','--locked','--release','--workspace','--all-features',*[v for n in names for v in ['--example',n]]],cwd=repo,stdout=f,stderr=subprocess.STDOUT,check=True)
   for n in names:shutil.copy2(repo/'target/release/examples'/n,dest/n)
  plan['variants'][label]={'binaries':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.iterdir()},'sources':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in paths.items()} if label in ['fast-scale','bounded-refine'] else {'revision':'a2c51a5' if label=='unit-a2c' else 'per-case references recorded above'}};(out/'plan.json').write_text(json.dumps(plan,indent=2))
finally:
 for n,p in paths.items():p.write_bytes(original[n])
 (out/'source-restored.json').write_text(json.dumps({n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in paths.items()},indent=2))
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});rng=random.Random(169235);samples=[];summaries=[]
for case,(exe,args) in enumerate(cases):
 orders=[]
 for group in range(12):
  if not orders:
   ordered=labels.copy();rng.shuffle(ordered);orders=[[ordered[i] for i in order] for order in [[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1]]];rng.shuffle(orders)
  for label in orders.pop():
   x=subprocess.run([str(r/'initial/measure'),str(out/'usage.json'),str(out/(label+'-bin')/exe),*args],capture_output=True,text=True,env={**os.environ,'TMPDIR':str(r/'disk-data')},check=True)
   row={'case':case,'group':group,'label':label,'result':json.loads(x.stdout),'usage':json.loads((out/'usage.json').read_text())};samples.append(row);(out/'samples.json').write_text(json.dumps(samples,indent=2));print(case,group,label,row['result']['seconds'],flush=True)
 selected=[x for x in samples if x['case']==case];work=[{k:v for k,v in x['result'].items() if k not in ('seconds','temporary_bytes')} for x in selected];assert all(x==work[0] for x in work)
 summary={'case':case,'values':{label:{metric:agg(get(x) for x in selected if x['label']==label) for metric,get,agg in [('wall',lambda x:x['result']['seconds'],statistics.median),('cpu',lambda x:x['usage']['cpu'],statistics.median),('rss',lambda x:x['usage']['rss'],max),('writes',lambda x:x['usage']['write_blocks'],statistics.median),('temporary_bytes',lambda x:x['result'].get('temporary_bytes',0),max)]} for label in labels}}
 summaries.append(summary);(out/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',summary,flush=True)
print('DONE',flush=True)
