set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
cargo fmt --all -- --check
cargo test -p varlit-core --all-features > /workspace/scratch/perf-recovery/retained-pages-core-all.log 2>&1
cargo test -p varlit-core > /workspace/scratch/perf-recovery/retained-pages-core-default.log 2>&1
cargo test -p varlit --all-features --test oom_recovery_guards --test publication_failure_results --test record_liveness --test validation_coverage > /workspace/scratch/perf-recovery/retained-pages-public.log 2>&1
cargo clippy --workspace --all-features --all-targets -- -D warnings > /workspace/scratch/perf-recovery/retained-pages-clippy.log 2>&1
cargo build --locked --release --workspace --all-features --example record_mutation_load --example oom_maintenance_load --example scalable_load --example ownership_load --example ownership_boundary_load > /workspace/scratch/perf-recovery/retained-pages-build-final.log 2>&1
MIRIFLAGS=-Zmiri-disable-isolation cargo +nightly-2026-10-12 miri test -p varlit-core --all-features --lib packed_rows::tests > /workspace/scratch/perf-recovery/retained-pages-miri.log 2>&1
cargo fmt --all -- --check
git diff --check
