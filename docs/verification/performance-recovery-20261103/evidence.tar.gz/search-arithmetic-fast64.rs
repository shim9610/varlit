fn scale(a: u64, b: usize, c: u64) -> usize {
 a.checked_mul(b as u64).map_or_else(|| (u128::from(a) * b as u128 / u128::from(c)) as usize, |n| (n / c) as usize)
}
// Exact extracted production search body; structural cost diagnostic, not an I/O benchmark.
fn search<const N: usize>(
            bytes: &[u8],
            wanted: u64,
            key: &impl Fn(&[u8]) -> u64,
        ) -> Option<[u8; N]> {
            let count = bytes.len() / N;
            if count == 0 {
                return None;
            }
            let first = key(&bytes[..N]);
            if wanted < first {
                return None;
            }
            let last = key(&bytes[(count - 1) * N..]);
            if wanted > last {
                return None;
            }
            // Fixed-size records are common, with occasional large internal
            // records between runs. Guess from the first adjacent spacing,
            // not the entire page span (whose last row can follow a large
            // checkpoint). Only exact equality proves membership; arbitrary
            // extents retain the binary search below.
            if count > 1 {
                let second = key(&bytes[N..2 * N]);
                if second > first {
                    let candidate = (wanted - first) / (second - first);
                    if candidate < count as u64 {
                        let at = candidate as usize * N;
                        let row = &bytes[at..at + N];
                        if key(row) == wanted {
                            return row.try_into().ok();
                        }
                    }
                }
            }
            // The standard slice search uses a fixed iteration schedule and
            // branchless bound selection for unpredictable irregular offsets.
            // It still compares real private rows, never an estimated boundary.
            let (rows, remainder) = bytes.as_chunks::<N>();
            debug_assert!(remainder.is_empty());
            let (mut low, mut high) = (0, count);
            // Large resident directories otherwise incur a full binary search
            // per mark. Two bounded estimates can locate a small real-key
            // bracket, but never authorize a record boundary by themselves.
            if count >= 1024 && last > first {
                let _span = u128::from(last - first);
                let _intervals = (count - 1) as u128;
                let estimate = scale(wanted-first, count-1, last-first);
                let observed = key(&rows[estimate]);
                if observed == wanted {
                    return Some(rows[estimate]);
                }
                // Near-uniform extents often put the estimate beside the
                // answer. An actual adjacent-key bracket proves the floor.
                if observed < wanted && estimate + 1 < count {
                    let next = key(&rows[estimate + 1]);
                    if wanted <= next {
                        return Some(rows[estimate + usize::from(wanted == next)]);
                    }
                } else if observed > wanted && estimate > 0 && key(&rows[estimate - 1]) <= wanted {
                    return Some(rows[estimate - 1]);
                }
                let correction = scale(wanted.abs_diff(observed), count-1, last-first).min(count-1);
                let corrected = if wanted > observed {
                    estimate.saturating_add(correction).min(count - 1)
                } else {
                    estimate.saturating_sub(correction)
                };
                let start = corrected.saturating_sub(16);
                let end = corrected.saturating_add(17).min(count);
                if key(&rows[start]) <= wanted && wanted <= key(&rows[end - 1]) {
                    (low, high) = (start, end);
                } else if observed < wanted {
                    low = estimate + 1;
                } else {
                    high = estimate;
                }
            }
            let end = low + rows[low..high].partition_point(|row| key(row) <= wanted);
            end.checked_sub(1).and_then(|at| rows.get(at)).copied()
        }

fn main() {
 let count=131072usize;
 let mut rows=Vec::<[u8;13]>::with_capacity(count);
 let mut offset=4096u64;
 for i in 0..count { let mut row=[0;13];row[..8].copy_from_slice(&offset.to_le_bytes());rows.push(row);offset+=100+(i*8191%65536) as u64; }
 let bytes=rows.as_flattened();
 for marks in [8192usize,65536] {
  let calls=std::cell::Cell::new(0usize);
  for i in 0..marks {
   let at=(i+1)*count/marks-1;let wanted=u64::from_le_bytes(rows[at][..8].try_into().unwrap());
   let key=|row:&[u8]| {calls.set(calls.get()+1);u64::from_le_bytes(row[..8].try_into().unwrap())};
   assert_eq!(search::<13>(bytes,wanted,&key),Some(rows[at]));
   assert_eq!(search::<13>(bytes,wanted+1,&key),if at+1<count {Some(rows[at])} else {None});
  }

  let mut positions:Vec<_>=(0..marks).map(|i|(i+1)*count/marks-1).collect();
  let mut state=0x1fbb_3171_519a_3927u64;
  for i in (1..positions.len()).rev() {state^=state<<13;state^=state>>7;state^=state<<17;positions.swap(i,state as usize%(i+1));}
  let key=|row:&[u8]|u64::from_le_bytes(row[..8].try_into().unwrap());
  let start=std::time::Instant::now();
  for _ in 0..20 {for &at in &positions {
   let wanted=u64::from_le_bytes(rows[at][..8].try_into().unwrap());
   std::hint::black_box(search::<13>(std::hint::black_box(bytes),std::hint::black_box(wanted),&key));
  }}
  println!("timing marks={marks} repeats=20 seconds={}",start.elapsed().as_secs_f64());
  println!("marks={marks} queries={} key_calls={} mean={}",marks*2,calls.get(),calls.get() as f64/(marks*2) as f64);
 }
}
