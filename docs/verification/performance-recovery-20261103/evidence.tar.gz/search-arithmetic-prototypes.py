from pathlib import Path
r=Path('/workspace/scratch/perf-recovery');s=(r/'search-cost-before.rs').read_text()
a='let estimate = (u128::from(wanted - first) * intervals / span) as usize;'
b='let correction = (u128::from(wanted.abs_diff(observed)) * intervals / span)\n                    .min(intervals) as usize;'
assert a in s and b in s
helper='''fn scale(a: u64, b: usize, c: u64) -> usize {
 a.checked_mul(b as u64).map_or_else(|| (u128::from(a) * b as u128 / u128::from(c)) as usize, |n| (n / c) as usize)
}
'''
fast=helper+s.replace(a,'let estimate = scale(wanted-first, count-1, last-first);').replace(b,'let correction = scale(wanted.abs_diff(observed), count-1, last-first).min(count-1);')
flt=s.replace(a,'let estimate = (((wanted-first) as f64 * (count-1) as f64 / (last-first) as f64) as usize).min(count-1);').replace(b,'let correction = ((wanted.abs_diff(observed) as f64 * (count-1) as f64 / (last-first) as f64) as usize).min(count-1);')
for name,source in [('base',s),('fast64',fast),('float',flt)]:
 source=source.replace('let span = u128::from(last - first);','let _span = u128::from(last - first);' if name!='base' else 'let span = u128::from(last - first);').replace('let intervals = (count - 1) as u128;','let _intervals = (count - 1) as u128;' if name!='base' else 'let intervals = (count - 1) as u128;')
 insertion='''
  let mut positions:Vec<_>=(0..marks).map(|i|(i+1)*count/marks-1).collect();
  let mut state=0x1fbb_3171_519a_3927u64;
  for i in (1..positions.len()).rev() {state^=state<<13;state^=state>>7;state^=state<<17;positions.swap(i,state as usize%(i+1));}
  let key=|row:&[u8]|u64::from_le_bytes(row[..8].try_into().unwrap());
  let start=std::time::Instant::now();
  for _ in 0..20 {for &at in &positions {
   let wanted=u64::from_le_bytes(rows[at][..8].try_into().unwrap());
   std::hint::black_box(search::<13>(std::hint::black_box(bytes),std::hint::black_box(wanted),&key));
  }}
  println!("timing marks={marks} repeats=20 seconds={}",start.elapsed().as_secs_f64());
'''
 source=source.replace('  println!("marks={marks}',insertion+'  println!("marks={marks}')
 (r/f'search-arithmetic-{name}.rs').write_text(source)
