from pathlib import Path
import subprocess,json,hashlib,difflib
repo=Path('/workspace/varlit');r=Path('/workspace/scratch/perf-recovery');p=repo/'crates/varlit-core/src/spill_rows.rs';original=p.read_text();needle='if observed == wanted {';assert original.count(needle)==1
mutant=original.replace(needle,'if true {',1);(r/'search-unchecked-estimate.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),mutant.splitlines(True),fromfile='original/spill_rows.rs',tofile='unchecked-estimate/spill_rows.rs')))
try:
 p.write_text(mutant)
 with (r/'search-negative-control.log').open('w') as log:
  x=subprocess.run(['cargo','test','-p','varlit-core','--all-features','--lib','spill_rows::tests::cached_floor_matches_ordered_rows_across_irregular_and_full_width_gaps','--','--exact'],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
finally:p.write_text(original)
log=(r/'search-negative-control.log').read_text();detected=x.returncode!=0 and 'test result: FAILED' in log and 'count=1024' in log
(r/'search-negative-control.json').write_text(json.dumps({'production_sha256':hashlib.sha256(original.encode()).hexdigest(),'mutation_sha256':hashlib.sha256(mutant.encode()).hexdigest(),'exit_code':x.returncode,'detected':detected,'test':'spill_rows::tests::cached_floor_matches_ordered_rows_across_irregular_and_full_width_gaps'},indent=2));assert detected,log[-3000:]
print('Unchecked estimated boundary rejected')
