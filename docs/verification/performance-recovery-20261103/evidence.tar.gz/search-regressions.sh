set -e
source /workspace/tooling/varlit/env.sh
cd /workspace/varlit
cargo fmt --all
python3 /workspace/scratch/perf-recovery/search-negative-control.py > /workspace/scratch/perf-recovery/search-negative-run.log 2>&1
cargo test -p varlit-core --all-features > /workspace/scratch/perf-recovery/search-core-all.log 2>&1
cargo test -p varlit-core > /workspace/scratch/perf-recovery/search-core-default.log 2>&1
cargo test -p varlit --all-features --test oom_recovery_guards --test publication_failure_results --test record_liveness --test validation_coverage > /workspace/scratch/perf-recovery/search-public.log 2>&1
cargo clippy --workspace --all-features --all-targets -- -D warnings > /workspace/scratch/perf-recovery/search-clippy.log 2>&1
MIRIFLAGS=-Zmiri-disable-isolation cargo +nightly-2026-10-12 miri test -p varlit-core --all-features --lib spill_rows::tests::cached_floor > /workspace/scratch/perf-recovery/search-miri.log 2>&1
cargo build --release --locked --all-features --examples > /workspace/scratch/perf-recovery/search-build.log 2>&1
cargo fmt --all -- --check
git diff --check
