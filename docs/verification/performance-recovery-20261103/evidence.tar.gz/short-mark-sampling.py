from pathlib import Path
import subprocess,hashlib,json,os,random,shutil,itertools,statistics
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');out=r/'short-mark-sampling';out.mkdir(exist_ok=False)
roots={'original':Path('/workspace/varlit-pre-boundary'),'current':repo}
s=(r/'prefix-inline-factorial/record_phase_cpu.rs').read_text()
(out/'record_phase_cpu.rs').write_text(s)
for mode,source in [('sample','profile-maintenance.c'),('io','profile-phase-io.c')]:subprocess.run(['cc','-O2','-shared','-fPIC',str(r/source),'-ldl','-o',str(out/(mode+'.so'))],check=True)
plan={'seed':731842,'plain_groups':12,'sample_pairs':12,'io_pairs':4,'args':['writer','mixed','random','131072','8192'],'instrumentation':'Two thread CPU-clock calls; separate no-interpose, I/O-clock interpose, and 1ms ITIMER_PROF diagnostic series. Release debug info; never a qualification result.','binaries':{}}
created=[]
try:
 for label,root in roots.items():
  harness=root/'crates/varlit/examples/record_phase_cpu.rs';assert not harness.exists();harness.write_text(s);created.append(harness)
  b=out/(label+'-bin');b.mkdir();print('BUILD',label,flush=True)
  with (out/(label+'-build.log')).open('w') as f:subprocess.run(['cargo','build','--locked','--release','--workspace','--all-features','--example','record_phase_cpu'],cwd=root,env={**os.environ,'CARGO_PROFILE_RELEASE_DEBUG':'1'},stdout=f,stderr=subprocess.STDOUT,check=True)
  shutil.copy2(root/'target/release/examples/record_phase_cpu',b/'record_phase_cpu')
  plan['binaries'][label]={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sha256':hashlib.sha256((b/'record_phase_cpu').read_bytes()).hexdigest(),'harness_sha256':hashlib.sha256(harness.read_bytes()).hexdigest(),'lock_sha256':hashlib.sha256((root/'Cargo.lock').read_bytes()).hexdigest()}
finally:
 for h in created:h.unlink(missing_ok=True)
 (out/'source-restored.json').write_text(json.dumps({str(root):subprocess.check_output(['git','status','--short'],cwd=root,text=True) for root in roots.values()},indent=2))
(out/'plan.json').write_text(json.dumps(plan,indent=2));os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});rng=random.Random(plan['seed']);rows=[]
for series,groups in [('plain',12),('sample',12),('io',4)]:
 pending=[]
 for group in range(groups):
  if series=='plain':
   if not pending:pending=list(itertools.permutations(['old-a','old-b','current']));rng.shuffle(pending)
   labels=pending.pop()
  else:labels=['original','current'] if group%2==0 else ['current','original']
  for label in labels:
   env={**os.environ,'TMPDIR':str(r/'disk-data')}
   if series!='plain':env['LD_PRELOAD']=str(out/(series+'.so'))
   side='current' if label=='current' else 'original'
   x=subprocess.run([str(out/(side+'-bin')/'record_phase_cpu'),*plan['args']],env=env,capture_output=True,text=True,check=True,timeout=600)
   (out/f'{series}-{group}-{label}.stderr').write_text(x.stderr);parts=x.stderr.splitlines();profile=None if series=='plain' else json.loads(next(q for q in parts if q.startswith('{')))
   row={'series':series,'group':group,'label':label,'result':json.loads(x.stdout),'phase_cpu':float(parts[-1]),'profile':profile};rows.append(row);(out/'samples.json').write_text(json.dumps(rows,indent=2));print(series,group,label,row['phase_cpu'],flush=True)
for label in roots:
 hits={};external=0
 for x in rows:
  if x['series']!='sample' or x['label']!=label:continue
  external+=x['profile']['external']
  for pc,n in x['profile']['hits']:hits[pc]=hits.get(pc,0)+n
 ranked=sorted(hits.items(),key=lambda p:p[1],reverse=True);pcs=[hex(pc) for pc,n in ranked];resolved=[]
 for i in range(0,len(pcs),100):resolved.append(subprocess.check_output(['addr2line','-a','-C','-f','-i','-e',str(out/(label+'-bin')/'record_phase_cpu'),*pcs[i:i+100]],text=True))
 (out/(label+'-locations.txt')).write_text('\n'.join(resolved));(out/(label+'-ranked.json')).write_text(json.dumps({'external':external,'main_samples':sum(hits.values()),'ranked':ranked},indent=2))
summary={}
for series in ['plain','sample','io']:
 summary[series]={}
 for label in sorted({x['label'] for x in rows if x['series']==series}):
  subset=[x for x in rows if x['series']==series and x['label']==label]
  summary[series][label]={'wall':statistics.median(x['result']['seconds'] for x in subset),'cpu':statistics.median(x['phase_cpu'] for x in subset)}
  if series=='io':summary[series][label]['profile']={k:statistics.median(x['profile'][k] for x in subset) for k in subset[0]['profile']}
(out/'summary.json').write_text(json.dumps(summary,indent=2));print('DONE',summary,flush=True)
