from pathlib import Path
import subprocess,json,os
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit')
def run(name,args):
 print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:
  code=subprocess.run(args,cwd=repo,stdout=f,stderr=subprocess.STDOUT).returncode
 print('END',name,code,flush=True)
 if code:raise SystemExit(code)
run('nested-string-reserve-long',['python3',str(r/'nested-string-reserve-long.py')])
run('string-reserve-owned',['python3',str(r/'owned-pairs.py'),'--before',str(r/'compact-bin'),'--after',str(r/'string-reserve-bin'),'--output',str(r/'string-reserve-owned')])
assert all(v['passed'] for x in json.loads((r/'string-reserve-owned/summary.json').read_text()) for v in x['metrics'].values()), 'ownership resource gate failed'
base=['python3',str(r/'bench.py'),'--before',str(r/'compact-bin'),'--after',str(r/'string-reserve-bin'),'--repo',str(repo)]
run('string-reserve-native',base+['--phase','native','--pairs','5','--native-cases','0','4','6','7','--output',str(r/'string-reserve-native')])
flagged=[str(x['case']) for x in json.loads((r/'string-reserve-native/native-summary.json').read_text()) if any(v['change_percent']>5 for v in x['metrics'].values())]
if flagged:run('string-reserve-confirmation',base+['--phase','native','--pairs','15','--native-cases',*flagged,'--output',str(r/'string-reserve-confirmation')])
run('string-reserve-pool',['python3',str(r/'pool.py'),'--primary',str(r/'string-reserve-native'),'--confirmation',str(r/'string-reserve-confirmation'),'--output',str(r/'string-reserve-pooled.json')])
run('string-reserve-swmr',['python3',str(r/'swmr-qualification.py'),'--before',str(r/'compact-bin'),'--after',str(r/'string-reserve-bin'),'--output',str(r/'string-reserve-swmr')])
for side in ['compact','string-reserve']:
 for name,cmd in [('complex',['oom_maintenance_load','complex','65536','512']),('bytes',['ownership_load','bytes','1073741824','2'])]:
  with (r/f'string-reserve-resource-{side}-{name}.log').open('w') as f:
   subprocess.run(['python3',str(repo/'docs/performance/audit-followup-20261102/resource_probe.py'),'--output',str(r/f'string-reserve-resource-{side}-{name}.json'),str(r/(side+'-bin')/cmd[0]),*cmd[1:]],stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':str(r/'disk-data')},check=True)
(r/'host-string-reserve-after.json').write_text(json.dumps({k:Path('/sys/fs/cgroup',k).read_text() for k in ['cpu.max','memory.max','memory.events']},indent=2))
print('DONE',flush=True)
