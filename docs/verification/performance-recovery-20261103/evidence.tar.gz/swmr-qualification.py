"""Three pairs; on a metric failure add six pairs and retain all nine."""
from pathlib import Path
import argparse,json,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--before',type=Path,required=True);p.add_argument('--after',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
r=Path('/workspace/scratch/perf-recovery');repo=Path('/workspace/varlit');sys.path.insert(0,str(repo/'scripts'));from compare_load import compare
base=['python3',str(r/'bench.py'),'--repo',str(repo),'--before',str(a.before),'--after',str(a.after),'--phase','concurrent']
subprocess.run(base+['--pairs','3','--output',str(a.output)],check=False)
initial={s:json.loads((a.output/f'swmr-{s}-comparison.json').read_text()) for s in ['1','4']}
failed=[s for s,d in initial.items() if d['status']!='passed'];extra=a.output.with_name(a.output.name+'-confirmation')
if failed:subprocess.run(base+['--pairs','6','--sizes',*failed,'--output',str(extra)],check=False)
pooled={}
for size in ['1','4']:
 roots=[a.output]+([extra] if size in failed else [])
 inputs={side:[p for root in roots for p in sorted(root.glob(f'swmr-{size}-*-{side}/report.json'))] for side in ['before','after']}
 expected=9 if size in failed else 3
 assert all(len(v)==expected for v in inputs.values())
 result=compare(*[[json.loads(p.read_text()) for p in inputs[side]] for side in ['before','after']]);result['inputs']={s:[str(p) for p in v] for s,v in inputs.items()};pooled[size]=result
 (a.output/f'swmr-{size}-pooled.json').write_text(json.dumps(result,indent=2));print('POOLED',size,json.dumps(result['metrics']),flush=True)
if any(x['status']!='passed' for x in pooled.values()):raise SystemExit('Pooled SWMR resource gate failed')
