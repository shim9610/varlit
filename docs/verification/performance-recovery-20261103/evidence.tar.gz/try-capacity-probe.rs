fn main() { let _ = Vec::<u8>::try_with_capacity(4); let _ = String::try_with_capacity(4); }
