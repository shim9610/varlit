from pathlib import Path
import subprocess,json,time,os
r=Path('/workspace/scratch/stream-cache');out=r/'budget-resource';out.mkdir(exist_ok=True)
bins={'before':r/'before-bin/native_follow_load','v2':r/'reuse-after-bin/native_follow_load','budget':r/'budget-bin/native_follow_load'}
cases=[('nonresident',['pending',str(1<<30),'65536','64','8','16','4','0','nonresident']),('single',['pending',str(1<<30),'65536','64','1','16','4','0','resident']),('complex',['pending',str(256<<20),'4096','64','8','8','4','0','resident','varying'])]
for name,args in cases:
 for group in range(3):
  for label,bin in bins.items():
   usage=out/f'{name}-{group}-{label}-usage.json';p=subprocess.Popen(['/workspace/scratch/perf-recovery/initial/measure',str(usage),str(bin),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env={**os.environ,'TMPDIR':str(r/'disk-data')});target=None;peak=0;rollup=''
   while p.poll() is None:
    try:
     if target is None:
      ids=Path(f'/proc/{p.pid}/task/{p.pid}/children').read_text().split()
      if ids:target=int(ids[0])
     if target:
      raw=Path(f'/proc/{target}/smaps_rollup').read_text();rss=int(next(s.split()[1] for s in raw.splitlines() if s.startswith('Rss:')))
      if rss>peak:peak=rss;rollup=raw
    except (OSError,StopIteration):pass
    time.sleep(.005)
   stdout,stderr=p.communicate();d={'case':name,'group':group,'label':label,'command':[str(bin),*args],'exit':p.returncode,'usage':json.loads(usage.read_text()) if usage.exists() else None,'stdout':stdout,'stderr':stderr,'sampled_rss_kib':peak,'rollup_at_sampled_peak':rollup};(out/f'{name}-{group}-{label}.json').write_text(json.dumps(d,indent=2));print(name,group,label,d['usage'],flush=True);assert p.returncode==0
