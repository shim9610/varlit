from pathlib import Path
repo=Path('/workspace/varlit');unit=Path('/workspace/varlit-stream-cache-follow-only');r=Path('/workspace/scratch/stream-cache')
s=(repo/'crates/varlit-core/src/file.rs').read_text()
s=s.replace('let mut index = load_generation_index(', 'let index = load_generation_index(').replace('let mut scanned = load_generation_index(', 'let scanned = load_generation_index(')
s=s.replace('        let boundaries = index.boundaries.take();\n','').replace('        let boundaries = scanned.boundaries.take();\n','')
s=s.replace('''                boundaries,
''','').replace('''                        boundaries,
''','').replace('''                    boundaries,
''','')
s=s.replace('''            None,
        )?;\n        assert''','''        )?;\n        assert''') if False else s
# Remove the explicit fifth argument in the forged-directory unit fixture.
s=s.replace('''ResidentIndex::adopt_generation(&vec![fake], writer.snapshot.clone(), spec, false, None)?''','''ResidentIndex::adopt_generation(&vec![fake], writer.snapshot.clone(), spec, false)?''')
s=s.replace('        self.index\n            .install_verified_boundary(record_offset, prospective_len);\n','').replace('        self.index.install_verified_boundary(record_offset, prospective_len);\n','')
# cargo fmt may put the fifth argument of the forged-directory fixture on its own line.
needle='''            spec,
            false,
            None,
        )?;''';s=s.replace(needle,'''            spec,
            false,
        )?;''')
(unit/'crates/varlit-core/src/file.rs').write_text(s)
s=(repo/'crates/varlit-core/src/file/scan.rs').read_text()
while '        if let Some(boundaries) = &mut self.boundaries' in s:
 a=s.index('        if let Some(boundaries) = &mut self.boundaries')
 opening=s.index('{',a);depth=1;i=opening+1
 while depth:
  depth += (s[i]=='{') - (s[i]=='}');i+=1
 if s[i:i+1]=='\n':i+=1
 s=s[:a]+s[i:]

s=s.replace('    pub(super) boundaries: Option<resident_index::BoundaryProof>,\n','').replace('        boundaries: None,\n','').replace('            boundaries: None,\n','')
s=s.replace('''        if let Some(boundaries) = &mut self.boundaries {
            boundaries.note(entry.record_offset, physical_end)?;
        }
''','')
s=s.replace('''        if let Some(boundaries) = &mut self.boundaries {
            boundaries.truncate_to(self.physical_end.unwrap_or(boundaries.start()))?;
        }
''','')
a=s.index('    if intent != ScanIntent::ReadOnly',s.index('pub(super) fn scan_records_range_at_len'))
b=s.index('    let mut progress = resume_record_scan',a)
s=s[:a]+s[b:];s=s.replace('    let mut progress = ScanProgress::new(spec, from, prefix_charge, resume_commit_end)?;','    let progress = ScanProgress::new(spec, from, prefix_charge, resume_commit_end)?;')
(unit/'crates/varlit-core/src/file/scan.rs').write_text(s)
s=(repo/'crates/varlit-core/src/native_scan.rs').read_text().replace('resident_index::slot_budget(spec)','resident_index::buffer_bytes(spec)');(unit/'crates/varlit-core/src/native_scan.rs').write_text(s)
(unit/'crates/varlit-core/src/native_directory.rs').write_bytes((r/'native-directory-before.rs').read_bytes())
for p in ['crates/varlit-core/src/file/locks.rs','crates/varlit-core/src/file/publication.rs','crates/varlit/tests/native_follow_cache.rs','crates/varlit/examples/native_follow_load.rs',*[str(p.relative_to(repo)) for p in (repo/'crates/varlit/tests/ui').glob('fail_share*matrix_reader*.stderr')]]:
 (unit/p).write_bytes((repo/p).read_bytes())
print('Isolated follow-only source created; boundary retention remains original 5e480a5.')
