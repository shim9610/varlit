import json,hashlib,subprocess,os,random
from pathlib import Path
r=Path('/workspace/scratch/stream-cache');out=r/'growth-diagnostic';out.mkdir(exist_ok=True)
bins={'v2':r/'reuse-after-bin/native_streaming_load','budget':r/'budget-bin/native_streaming_load','growth':r/'growth-bin/native_streaming_load'}
args=['1073741824','65536','16777216','8','16','0','resident'];rng=random.Random(961021)
(out/'plan.json').write_text(json.dumps({'groups':6,'args':args,'seed':961021,'purpose':'diagnostic, not qualification; retain every result','hashes':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in bins.items()}},indent=2));rows=[]
for group in range(6):
 order=list(bins);rng.shuffle(order)
 for label in order:
  usage=out/'usage.json';p=subprocess.run(['/workspace/scratch/perf-recovery/initial/measure',str(usage),str(bins[label]),*args],capture_output=True,text=True,env={**os.environ,'TMPDIR':str(r/'disk-data')},check=True,timeout=90)
  row={'group':group,'label':label,'result':json.loads(p.stdout),'usage':json.loads(usage.read_text())};rows.append(row);(out/'samples.json').write_text(json.dumps(rows,indent=2));print(group,label,row['usage'],row['result']['writer_seconds'],row['result']['seconds'],flush=True)
