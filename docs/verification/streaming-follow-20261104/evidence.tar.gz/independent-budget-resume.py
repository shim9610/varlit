"""Fixed-work writer that never waits for reader acknowledgements."""
import hashlib,json,os,random,statistics,subprocess
from pathlib import Path
r=Path('/workspace/scratch/stream-cache');out=r/'independent-qualification';out.mkdir(exist_ok=True)
bins={k:r/v/'native_streaming_load' for k,v in [('before-a','reuse-before-bin'),('before-b','reuse-before-bin'),('follow','reuse-after-bin'),('after','budget-bin')]}
cases=[('independent-1g-r8',1<<30,8,'resident'),('independent-4g-r8',4<<30,8,'resident'),('independent-1g-r1',1<<30,1,'resident'),('independent-1g-nonresident',1<<30,8,'nonresident')]
plan={'initial_groups':8,'extra_groups_if_any_observed_5_percent_gate_or_calibration_fails':16,'seed':961019,'cases':cases,'payload_bytes':65536,'epoch_bytes':16<<20,'follows_per_reader_per_epoch':16,'resource_limits':{'cpu':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'memory_bytes':Path('/sys/fs/cgroup/memory.max').read_text().strip()},'metrics':['completion seconds median','writer ingestion seconds median','whole-child CPU median','max RSS','median write bytes'],'unit_before_label':'follow is the preceding combined v2 runtime','private_storage':'Separate peak resource probes, never claim timing binaries measured peak private bytes.','rate_diagnostics':{'groups':3,'bytes':1<<30,'bits_per_sample':[16,32,64],'samples_per_second':100_000_000,'batch_bytes':65536,'epoch_bytes':16<<20,'readers':8,'note':'Unconfirmed user sample width; test all three assumptions. Pacing and lag are measured per epoch, maximum push/commit calls separately; this is not a hard real-time deadline proof.'},'sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in bins.items()},'gate':1.05,'calibration':'absolute before-b/before-a median difference <= 5% for completion and ingestion; all observations pooled'}
prior_plan=out/'plan.json'
if prior_plan.exists():
 assert json.loads(prior_plan.read_text())==json.loads(json.dumps(plan)), 'Refusing changed frozen plan on resume'
else:prior_plan.write_text(json.dumps(plan,indent=2))
orders=[['before-a','before-b','after','follow'],['before-b','follow','before-a','after'],['follow','after','before-b','before-a'],['after','before-a','follow','before-b']];random.Random(plan['seed']).shuffle(orders)
getters={'seconds':lambda x:x['result']['seconds'],'writer_seconds':lambda x:x['result']['writer_seconds'],'cpu':lambda x:x['usage']['cpu'],'rss':lambda x:x['usage']['rss'],'writes':lambda x:x['usage']['write_blocks']*512}
env={**os.environ,'TMPDIR':str(r/'disk-data')};rows=[];summaries=[]
samples=out/'samples.jsonl'
rows=[json.loads(line) for line in samples.read_text().splitlines()] if samples.exists() else []
summaries=json.loads((out/'summary.json').read_text()) if (out/'summary.json').exists() else []
resume_keys={(x['case'],x['group'],x['label']) for x in rows}
assert len(resume_keys)==len(rows), 'Duplicate retained observations'
completed_cases={x['case'] for x in summaries}
print('RESUME retaining',len(rows),'observations; completed',sorted(completed_cases),flush=True)
def summarize(name):
 selected=[x for x in rows if x['case']==name];keys=['bytes','payload','epoch_bytes','readers','follows','records','read_bytes','trace','source_bytes','residency']
 work=[{k:x['result'][k] for k in keys} for x in selected];assert all(x==work[0] for x in work)
 values={k:{label:(max if k=='rss' else statistics.median)(fn(x) for x in selected if x['label']==label) for label in bins} for k,fn in getters.items()}
 comparisons={after:{before:{k:{'percent':100*(v[after]/v[before]-1) if v[before] else (0 if v[after]==0 else None),'passed':v[after]<=v[before]*1.05} for k,v in values.items()} for before in befores} for after,befores in [('after',['before-a','before-b','follow'])]}
 calibration={k:100*(values[k]['before-b']/values[k]['before-a']-1) for k in ['seconds','writer_seconds']}
 return {'case':name,'groups':len(selected)//4,'work':work[0],'values':values,'comparisons':comparisons,'same_binary_median_percent':calibration,'calibration_passed':all(abs(x)<=5 for x in calibration.values()),'passed':all(abs(x)<=5 for x in calibration.values()) and all(m['passed'] for g in comparisons.values() for c in g.values() for m in c.values())}
def measure(label,args):
 usage=out/'usage.json';cmd=[str(Path('/workspace/scratch/perf-recovery/initial/measure')),str(usage),str(bins[label]),*map(str,args)]
 p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=600)
 if p.returncode:
  (out/'failure.json').write_text(json.dumps({'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2));raise RuntimeError(cmd)
 return json.loads(p.stdout),json.loads(usage.read_text())
for name,total,readers,residency in cases:
 if name in completed_cases:continue
 args=[total,65536,16<<20,readers,16,0,residency]
 for group in range(24):
  if group==8:
   initial_path=out/(name+'-initial.json')
   if initial_path.exists():initial=json.loads(initial_path.read_text())
   else:
    initial=summarize(name);initial_path.write_text(json.dumps(initial,indent=2))
   if initial['passed']:break
  for label in orders[group%4]:
   if (name,group,label) in resume_keys:continue
   result,usage=measure(label,args);row={'case':name,'group':group,'label':label,'args':args,'result':result,'usage':usage};rows.append(row)
   with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(name,group,label,'writer',result['writer_seconds'],'total',result['seconds'],'cpu',usage['cpu'],'rss',usage['rss'],flush=True)
 summary=summarize(name);summaries.append(summary);(out/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',name,json.dumps(summary),flush=True)
assert not (out/'capacity.json').exists(), 'Rate phase requires explicit resume if interrupted'
capacity=[]
for bits in [16,32,64]:
 for group in range(3):
  for label in orders[group%4]:
   rate=100_000_000*(bits//8)/1048576;args=[1<<30,65536,16<<20,8,16,rate,'resident'];result,usage=measure(label,args);row={'bits':bits,'group':group,'label':label,'args':args,'result':result,'usage':usage};capacity.append(row);(out/'capacity.json').write_text(json.dumps(capacity,indent=2));print('CAPACITY',bits,group,label,result['ingest_mib_s'],result['max_lag_seconds'],result['max_push_seconds'],flush=True)
print('FINISHED',flush=True)
