from pathlib import Path
import hashlib,itertools,json,os,random,statistics,subprocess,tempfile,time
r=Path('/workspace/scratch/stream-cache');out=r/'lazy-partitioned-writer';out.mkdir(exist_ok=True)
cpus=sorted(os.sched_getaffinity(0))[:4];assert len(cpus)==4;os.sched_setaffinity(0,{cpus[-1]})
bins={'before-a':r/'budget-bin/native_streaming_load','before-b':r/'budget-bin/native_streaming_load','after':r/'lazy-sequence-bin/native_streaming_load'}
plan={'purpose':'Separate CPU-role partition comparison, not a replacement for failed shared-CPU series. Same four CPU quota: writer one logical CPU, eight readers share three. Same unmodified binary/harness and all actual work. Parent pins readers as their OS threads become visible; setup overhead is included and recorded. No producer acknowledgment waits added.','seed':961027,'groups':12,'writer_cpu':cpus[0],'reader_cpus':cpus[1:],'parent_cpu':cpus[-1],'cases':[['1g',1<<30],['4g',4<<30]],'sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in bins.items()},'cpu_quota':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'memory_limit':Path('/sys/fs/cgroup/memory.max').read_text().strip(),'gate':1.05}
(out/'plan.json').write_text(json.dumps(plan,indent=2));rows=[];summaries=[]
for case,total in plan['cases']:
 rng=random.Random(plan['seed']+total);orders=[]
 for _ in range(2):
  block=list(itertools.permutations(bins));rng.shuffle(block);orders+=block
 for group,order in enumerate(orders):
  for label in order:
   args=[total,65536,16<<20,8,16,0,'resident'];start=time.monotonic();pinned=set();setup=None
   with tempfile.TemporaryFile() as stdout,tempfile.TemporaryFile() as stderr:
    p=subprocess.Popen([str(bins[label]),*map(str,args)],stdout=stdout,stderr=stderr,env={**os.environ,'TMPDIR':str(r/'disk-data')},preexec_fn=lambda:os.sched_setaffinity(0,{cpus[0]}))
    while True:
     pid,status,usage=os.wait4(p.pid,os.WNOHANG)
     if pid:p.returncode=os.waitstatus_to_exitcode(status);break
     if setup is None:
      try:
       for task in Path(f'/proc/{p.pid}/task').iterdir():
        tid=int(task.name)
        if tid!=p.pid and tid not in pinned:os.sched_setaffinity(tid,set(cpus[1:]));pinned.add(tid)
       if len(pinned)==8:setup=time.monotonic()-start
      except ProcessLookupError:pass
     if time.monotonic()-start>600:p.kill()
     time.sleep(.0002 if setup is None else .005)
    stdout.seek(0);stderr.seek(0);raw=stdout.read().decode();err=stderr.read().decode()
   row={'case':case,'group':group,'label':label,'exit':p.returncode,'pinned_reader_threads':len(pinned),'affinity_setup_seconds':setup,'usage':{'cpu':usage.ru_utime+usage.ru_stime,'rss':usage.ru_maxrss,'write_blocks':usage.ru_oublock},'stderr':err,'stdout':raw};assert p.returncode==0 and len(pinned)==8,row;row['result']=json.loads(raw);rows.append(row)
   with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(case,group,label,row['result']['seconds'],row['result']['writer_seconds'],row['usage']['cpu'],row['usage']['rss'],setup,flush=True)
 selected=[x for x in rows if x['case']==case];keys=['bytes','payload','epoch_bytes','readers','follows','records','read_bytes','trace','source_bytes','residency'];work=[{k:x['result'][k] for k in keys} for x in selected];assert all(w==work[0] for w in work)
 getters={'seconds':lambda x:x['result']['seconds'],'writer_seconds':lambda x:x['result']['writer_seconds'],'cpu':lambda x:x['usage']['cpu'],'rss_kib':lambda x:x['usage']['rss'],'write_bytes':lambda x:x['usage']['write_blocks']*512}
 values={k:{label:(max if k=='rss_kib' else statistics.median)(fn(x) for x in selected if x['label']==label) for label in bins} for k,fn in getters.items()};comparisons={b:{k:{'percent':100*(v['after']/v[b]-1),'passed':v['after']<=v[b]*1.05} for k,v in values.items()} for b in ['before-a','before-b']};aa={k:100*(values[k]['before-b']/values[k]['before-a']-1) for k in ['seconds','writer_seconds']};s={'case':case,'groups':12,'values':values,'comparisons':comparisons,'same_binary_median_percent':aa,'passed':all(abs(v)<=5 for v in aa.values()) and all(m['passed'] for c in comparisons.values() for m in c.values())};summaries.append(s);(out/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',case,json.dumps(s),flush=True)
print('FINISHED',flush=True)
