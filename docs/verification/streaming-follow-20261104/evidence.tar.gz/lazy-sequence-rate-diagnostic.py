from pathlib import Path
import hashlib,json,os,random,subprocess
r=Path('/workspace/scratch/stream-cache');out=r/'lazy-sequence-rate-diagnostic';out.mkdir(exist_ok=True);bins={'before':r/'budget-bin/native_streaming_load','after':r/'lazy-sequence-bin/native_streaming_load'};affinity=sorted(os.sched_getaffinity(0))[:4]
plan={'purpose':'Paced workload feasibility diagnostic, not maximum-throughput qualification. Sample width is not user-confirmed. Synthetic demand-generated input does not prove external acquisition deadlines/noADC drops.','groups':3,'sample_rate':100_000_000,'bits':[16,32,64],'bytes':1<<30,'payload':65536,'epoch_bytes':16<<20,'readers':8,'follows':16,'affinity':affinity,'sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in bins.items()},'resource_limits':{'cpu':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'memory':Path('/sys/fs/cgroup/memory.max').read_text().strip()}}
(out/'plan.json').write_text(json.dumps(plan,indent=2));os.sched_setaffinity(0,set(affinity));rng=random.Random(961026);rows=[]
for group in range(3):
 for bits in plan['bits']:
  labels=list(bins);rng.shuffle(labels);rate=100_000_000*(bits//8)/(1<<20)
  for label in labels:
   usage=out/'usage.json';args=[1<<30,65536,16<<20,8,16,rate,'resident'];p=subprocess.run(['/workspace/scratch/perf-recovery/initial/measure',str(usage),str(bins[label]),*map(str,args)],capture_output=True,text=True,check=True,timeout=600,env={**os.environ,'TMPDIR':str(r/'disk-data')});row={'group':group,'bits':bits,'label':label,'result':json.loads(p.stdout),'usage':json.loads(usage.read_text())};rows.append(row)
   with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(group,bits,label,row['result'],flush=True)
(out/'results.json').write_text(json.dumps(rows,indent=2));print('FINISHED',flush=True)
