from pathlib import Path
import hashlib,json,os,stat,subprocess,tempfile,time
r=Path('/workspace/scratch/stream-cache');out=r/'lazy-sequence-resource-native';out.mkdir(exist_ok=True)
bins={'original':r/'reuse-before-bin','budget':r/'budget-bin','final':r/'lazy-sequence-bin'}
cases=[('small','native_follow_load',['pending',16<<20,128,32,8,8,4,0,'resident']),('complex','native_follow_load',['pending',256<<20,4096,64,8,8,4,0,'resident','varying']),('nonresident','native_follow_load',['pending',1<<30,65536,64,8,16,4,0,'nonresident']),('independent-4g','native_streaming_load',[4<<30,65536,16<<20,8,16,0,'resident'])]
affinity=sorted(os.sched_getaffinity(0))[:4];os.sched_setaffinity(0,set(affinity))
plan={'purpose':'Separate resource probes; observer-affected times are not qualification results. Process wait4 RSS/CPU and sampled5ms FD/cgroup peaks. Cgroup includes page cache and workspace/observer overhead; sampled storage peaks are lower bounds.','groups':2,'affinity':affinity,'cases':cases,'sha256':{label:{exe:hashlib.sha256((folder/exe).read_bytes()).hexdigest() for exe in ['native_follow_load','native_streaming_load']} for label,folder in bins.items()}}
(out/'plan.json').write_text(json.dumps(plan,indent=2));results=[]
for name,exe,args in cases:
 for group in range(2):
  for label,folder in bins.items():
   usage_path=out/'usage.json';pid_path=out/'child.pid';pid_path.unlink(missing_ok=True);cmd=[str(r/'measure-native-pid'),str(usage_path),str(pid_path),str(folder/exe),*map(str,args)];native_pid=None;peaks={k:0 for k in ['rss_bytes','deleted_regular_logical_bytes','deleted_regular_allocated_bytes','open_regular_allocated_bytes','cgroup_current_bytes']};samples=0;status_ok=fd_ok=0;errors={};started=time.monotonic()
   with tempfile.TemporaryFile() as stdout,tempfile.TemporaryFile() as stderr:
    p=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,env={**os.environ,'TMPDIR':str(r/'disk-data')})
    while True:
     pid,wait_status,usage=os.wait4(p.pid,os.WNOHANG)
     if pid:
      p.returncode=os.waitstatus_to_exitcode(wait_status);break
     if time.monotonic()-started>120:p.kill()
     values=dict.fromkeys(peaks,0);seen=set()
     if native_pid is None:
      try:native_pid=int(pid_path.read_text())
      except (OSError,ValueError):time.sleep(.001);continue
     try:
      status=Path(f'/proc/{native_pid}/status').read_text();status_ok+=1
      for line in status.splitlines():
       if line.startswith('VmHWM:'):values['rss_bytes']=int(line.split()[1])*1024
     except OSError as e:errors['status:'+str(e.errno)]=errors.get('status:'+str(e.errno),0)+1
     try:
      fds=list(Path(f'/proc/{native_pid}/fd').iterdir());fd_ok+=1
      for fd in fds:
       if fd.name in ['0','1','2']:continue
       try:
        meta=fd.stat();key=(meta.st_dev,meta.st_ino)
        if not stat.S_ISREG(meta.st_mode) or key in seen:continue
        seen.add(key);link=os.readlink(fd);values['open_regular_allocated_bytes']+=meta.st_blocks*512
        if link.endswith(' (deleted)'):
         values['deleted_regular_logical_bytes']+=meta.st_size;values['deleted_regular_allocated_bytes']+=meta.st_blocks*512
       except OSError as e:errors['fd:'+str(e.errno)]=errors.get('fd:'+str(e.errno),0)+1
     except OSError as e:errors['fdscan:'+str(e.errno)]=errors.get('fdscan:'+str(e.errno),0)+1
     values['cgroup_current_bytes']=int(Path('/sys/fs/cgroup/memory.current').read_text());peaks={k:max(peaks[k],v) for k,v in values.items()};samples+=1;time.sleep(.005)
    stdout.seek(0);stderr.seek(0);raw=stdout.read().decode();err=stderr.read().decode()
   row={'case':name,'group':group,'label':label,'command':cmd,'exit':p.returncode,'usage':{'cpu_seconds':json.loads(usage_path.read_text())['cpu'],'rss_kib':json.loads(usage_path.read_text())['rss'],'write_bytes':json.loads(usage_path.read_text())['write_blocks']*512},'sample_interval_seconds':.005,'samples':samples,'status_samples':status_ok,'fd_samples':fd_ok,'sample_errors':errors,'peaks':peaks,'stdout':raw,'stderr':err};(out/f'{name}-{group}-{label}.json').write_text(json.dumps(row,indent=2));print(name,group,label,row['exit'],row['usage'],peaks,flush=True)
   assert p.returncode==0 and status_ok>0 and fd_ok>0
   result=json.loads(raw);row['result']=result;results.append(row)
 (out/'results.json').write_text(json.dumps(results,indent=2))
print('FINISHED',flush=True)
