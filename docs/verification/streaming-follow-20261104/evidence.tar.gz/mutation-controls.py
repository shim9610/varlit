from pathlib import Path
import subprocess,hashlib,json,os
repo=Path('/workspace/varlit');r=Path('/workspace/scratch/stream-cache');out=r/'mutation-controls';out.mkdir(exist_ok=True)
files=['crates/varlit-core/src/file.rs','crates/varlit-core/src/native_directory.rs'];original={p:(repo/p).read_bytes() for p in files}
mutations=[
 ('forget-progress',files[0],'let reusable = progress.from == from','let reusable = false && progress.from == from','growing_pending_polls_parse_only_new_complete_records'),
 ('skip-publication-replay',files[0],'if resumed\n            && progress','if false && resumed\n            && progress','cached_pending_headers_are_revalidated_before_publication'),
 ('discard-open-certificate',files[1],'result.boundary_proof = boundaries;','result.boundary_proof = None;','nonresident_open_reuses_verified_boundaries_without_a_second_scan'),
 ('skip-appended-certificate',files[1],'proof.publish_reserved(offset, end);','let _ = (offset, end);','nonresident_appends_extend_certificates_without_scanning_the_prefix'),
]
results=[]
try:
 for name,path,before,after,contract in mutations:
  src=original[path].decode();assert src.count(before)==1,(name,src.count(before));mutated=src.replace(before,after);(repo/path).write_text(mutated);(out/(name+'.rs')).write_text(mutated)
  cmd=['cargo','test','-p','varlit','--all-features','--test','native_follow_cache',contract,'--','--exact']
  p=subprocess.run(cmd,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180,env=os.environ)
  (out/(name+'.log')).write_text(p.stdout)
  result={'name':name,'command':cmd,'returncode':p.returncode,'killed':p.returncode!=0 and 'panicked at' in p.stdout and 'test result: FAILED' in p.stdout};results.append(result);(out/'results.json').write_text(json.dumps(results,indent=2));print(name,result,flush=True)
  (repo/path).write_bytes(original[path])
  assert result['killed'],name
finally:
 for path,data in original.items():(repo/path).write_bytes(data)
 (out/'restored.json').write_text(json.dumps({path:hashlib.sha256((repo/path).read_bytes()).hexdigest() for path in files},indent=2))
