"""Fixed nonresident marks: live writer, full open, warmed, large varied records."""
from pathlib import Path
import json,hashlib,os,random,statistics,subprocess
r=Path('/workspace/scratch/stream-cache');out=r/'nonresident-qualification';out.mkdir(exist_ok=True)
bins={k:r/v/'nonresident_boundary_load' for k,v in [('before-a','reuse-before-bin'),('before-b','reuse-before-bin'),('v2','reuse-after-bin'),('after','budget-bin')]}
cases=[('live-cold',['nonresident','variable','random','200000','20000']),('open-cold',['nonresident-open','variable','random','200000','20000']),('open-warm',['nonresident-open','variable','random','200000','20000','warm']),('large-cold',['nonresident','mixed','random','65536','8192'])]
plan={'seed':961020,'initial_groups':8,'extra_groups_if_any_gate_or_calibration_fails':16,'limit_percent':5,'cases':cases,'sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in bins.items()},'work':'mode/layout/order/count/marks/sourcebytes and post-timer marked flags match. Framing count intentionally differs. Warm first verifies the maximum offset outside timing, not a random partial prefix. Whole-child CPU includes preparation and verification.','metrics':['operation seconds median','whole-child CPU median','maximum RSS','median write blocks','maximum final private logical bytes'],'limits':{'cpu':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'memory':Path('/sys/fs/cgroup/memory.max').read_text().strip()}}
p=out/'plan.json'
if p.exists():assert json.loads(p.read_text())==json.loads(json.dumps(plan))
else:p.write_text(json.dumps(plan,indent=2))
orders=[['before-a','before-b','after','v2'],['before-b','v2','before-a','after'],['v2','after','before-b','before-a'],['after','before-a','v2','before-b']];random.Random(plan['seed']).shuffle(orders)
rows=[json.loads(x) for x in (out/'samples.jsonl').read_text().splitlines()] if (out/'samples.jsonl').exists() else [];done={(x['case'],x['group'],x['label']) for x in rows}
summaries=json.loads((out/'summary.json').read_text()) if (out/'summary.json').exists() else [];completed={s['case'] for s in summaries}
metrics={'seconds':lambda x:x['result']['seconds'],'cpu':lambda x:x['usage']['cpu'],'rss':lambda x:x['usage']['rss'],'writes':lambda x:x['usage']['write_blocks']*512,'temporary_bytes':lambda x:x['result']['temporary_bytes']}
def summarize(name):
 selected=[x for x in rows if x['case']==name];keys=['mode','layout','order','count','marks','source_bytes'];work=[{k:x['result'][k] for k in keys} for x in selected];assert all(w==work[0] for w in work)
 values={k:{label:(max if k in ['rss','temporary_bytes'] else statistics.median)(fn(x) for x in selected if x['label']==label) for label in bins} for k,fn in metrics.items()}
 comparisons={before:{k:{'percent':100*(v['after']/v[before]-1) if v[before] else (0 if not v['after'] else None),'passed':v['after']<=v[before]*1.05} for k,v in values.items()} for before in ['before-a','before-b','v2']}
 aa=100*(values['seconds']['before-b']/values['seconds']['before-a']-1)
 return {'case':name,'groups':len(selected)//4,'work':work[0],'values':values,'comparisons':comparisons,'same_binary_median_percent':aa,'passed':abs(aa)<=5 and all(m['passed'] for b in comparisons.values() for m in b.values())}
for name,args in cases:
 if name in completed:continue
 for group in range(24):
  if group==8:
   p=out/(name+'-initial.json')
   if p.exists():initial=json.loads(p.read_text())
   else:initial=summarize(name);p.write_text(json.dumps(initial,indent=2))
   if initial['passed']:break
  for label in orders[group%4]:
   if (name,group,label) in done:continue
   usage=out/'usage.json';cmd=['/workspace/scratch/perf-recovery/initial/measure',str(usage),str(bins[label]),*args];p=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'TMPDIR':str(r/'disk-data')},timeout=600)
   if p.returncode:(out/'failure.json').write_text(json.dumps({'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2));raise RuntimeError(cmd)
   row={'case':name,'group':group,'label':label,'result':json.loads(p.stdout),'usage':json.loads(usage.read_text())};rows.append(row)
   with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(name,group,label,row['result']['seconds'],row['usage']['cpu'],row['usage']['rss'],row['result']['frames'],flush=True)
 summary=summarize(name);summaries.append(summary);(out/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',name,json.dumps(summary),flush=True)
print('FINISHED',flush=True)
