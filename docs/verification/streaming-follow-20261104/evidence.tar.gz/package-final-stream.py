from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil,re
r=Path('/workspace/scratch/stream-cache');repo=Path('/workspace/varlit');out=repo/'docs/verification/streaming-follow-20261104';snapshot=r/'final-source'
assert not snapshot.exists(),'Do not silently overwrite an earlier frozen source snapshot'
paths=list((repo/'crates/varlit-core/src').rglob('*.rs'))+[repo/x for x in ['Cargo.toml','Cargo.lock','crates/varlit/Cargo.toml','crates/varlit-core/Cargo.toml','crates/varlit/examples/native_follow_load.rs','crates/varlit/examples/native_streaming_load.rs','crates/varlit/examples/record_mutation_load.rs','crates/varlit/examples/nonresident_boundary_load.rs','crates/varlit/tests/native_follow_cache.rs','crates/varlit/tests/record_liveness.rs','crates/varlit/tests/support/source_audit.rs','docs/verification/proof-contracts.json','.github/workflows/verification.yml','.github/workflows/ci.yml','.github/workflows/sanitizers.yml']]
for p in paths:
 q=snapshot/p.relative_to(repo);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
(snapshot/'source.json').write_text(json.dumps({'runtime':json.loads((r/'lazy-sequence-runtime.json').read_text()),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'note':'Source and diagnostics snapshot. Executables and workload data are excluded; original source revisions and binary hashes remain in plans/provenance.'},indent=2))
files=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 parts=p.relative_to(r).parts
 if any(x.endswith('-bin') or x in ('bin','target','build','disk-data','__pycache__') for x in parts):continue
 if p.name.startswith('HANDOFF') or p.name in ('evidence-manifest.json','pr-body-draft.md','pr-final-body.md'):continue
 if p.suffix not in ('.json','.jsonl','.log','.md','.py','.rs','.c','.sh','.patch','.txt','.asm','.stderr','.stdout','.toml','.lock','.yml'):continue
 assert p.stat().st_size<32*1024*1024,p
 files.append(p)
secret_patterns=[rb'github_pat_[A-Za-z0-9_]{30,}',rb'ghp_[A-Za-z0-9]{30,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
for p in files:
 raw=p.read_bytes()
 assert not any(re.search(pat,raw) for pat in secret_patterns),f'Credential pattern in evidence: {p.name}'
manifest=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=6) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
 tar.add(out/'evidence-manifest.json',arcname='evidence-manifest.json',recursive=False)
digest=hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest();(out/'evidence.sha256').write_text(digest+'  evidence.tar.gz\n')
with tarfile.open(out/'evidence.tar.gz','r:gz') as tar:
 for entry in manifest:
  data=tar.extractfile(entry['path']).read();assert len(data)==entry['bytes'];assert hashlib.sha256(data).hexdigest()==entry['sha256']
print('Packaged/verified',len(files),'evidence files;', (out/'evidence.tar.gz').stat().st_size,'bytes;',digest,flush=True)
