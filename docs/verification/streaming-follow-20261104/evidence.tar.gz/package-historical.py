from pathlib import Path
import json,hashlib,tarfile
r=Path('/workspace/scratch/perf-recovery');out=Path('/workspace/varlit/docs/verification/performance-recovery-20261103')
files=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 parts=p.relative_to(r).parts
 if any(x.endswith('-bin') or x in ('bin','build','target','disk-data','__pycache__') for x in parts):continue
 if p.name.startswith('HANDOFF') or p.name in ('evidence-manifest.json','package-results.log','pr-body-draft.md'):continue
 if p.suffix not in ('.json','.jsonl','.log','.md','.py','.rs','.c','.sh','.patch','.txt','.asm'):continue
 assert p.stat().st_size<32*1024*1024,p
 files.append(p)
manifest=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=6) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
 tar.add(out/'evidence-manifest.json',arcname='evidence-manifest.json',recursive=False)
digest=hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest();(out/'evidence.sha256').write_text(digest+'  evidence.tar.gz\n')
analysis=json.loads((r/'final-refined-reference-short-pooled/analysis.json').read_text())
(out/'results.json').write_text(json.dumps({'runtime_commit':'5e480a540997cc42186e3152813dfab45c2e2378','status':'Original-reference short mixed mark time fails after all240 groups; later stages were not run for this unchanged candidate.','pooled_original_reference':analysis,'not_executed':['final-refined-native','final-refined-swmr','final-refined-owned','final-refined-owner-controls','final-refined-nested-short','final-refined-nested-long','23 planned final-refined peak-resource probes'],'raw_evidence_files':len(manifest),'raw_evidence_bytes':sum(x['bytes'] for x in manifest),'archive_sha256':digest,'next_runtime_report':'../streaming-follow-20261104/README.md'},indent=2)+'\n')
print('Packaged',len(files),'files;', (out/'evidence.tar.gz').stat().st_size,'compressed bytes',flush=True)
