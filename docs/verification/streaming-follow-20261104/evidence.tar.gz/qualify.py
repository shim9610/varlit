"""Fixed work, balanced four-label groups; retain initial and pooled samples."""
import hashlib,json,os,random,statistics,subprocess,time
from pathlib import Path
r=Path('/workspace/scratch/stream-cache');out=r/'qualification';out.mkdir(exist_ok=True)
bins={label:r/folder/'native_follow_load' for label,folder in [('before-a','before-bin'),('before-b','before-bin'),('follow','follow-bin'),('after','after-bin')]}
# bytes, payload bytes, epochs, readers, fixed polls/epoch, commit every, rate MiB/s
cases=[
 ('small-pending',['pending',str(16<<20),'128','32','8','8','4','0','resident']),
 ('large-pending',['pending',str(1<<30),'65536','64','8','16','4','0','resident']),
 ('large-concurrent',['concurrent',str(4<<30),'65536','256','8','16','4','0','resident']),
 ('committed',['committed',str(1<<30),'65536','64','8','0','1','0','resident']),
 ('complex-varying',['pending',str(256<<20),'4096','64','8','8','4','0','resident','varying']),
 ('nonresident',['pending',str(1<<30),'65536','64','8','16','4','0','nonresident']),
 ('single-reader',['pending',str(1<<30),'65536','64','1','16','4','0','resident']),
]
plan={'seed':961018,'initial_groups':8,'additional_groups_if_any_metric_exceeds_5_percent':16,'pooled':'all 24 groups, never discard initial observations','gate':1.05,'metrics':['seconds median','whole-child CPU median','max RSS','median write blocks','max end-epoch private logical temporary bytes'],'cases':cases,'comparisons':{'follow':['before-a','before-b'],'after':['before-a','before-b','follow']},'sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in bins.items()},'resource_limits':{'cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'memory_max':Path('/sys/fs/cgroup/memory.max').read_text().strip()},'note':'Frames intentionally differ. Same payload, calls, polls, committed record count, decoded bytes and hashes are asserted; concurrent interleavings can differ. RSS is whole process including unchanged benchmark/client buffers. Private temporary metric is end-epoch logical size, separate polling probes measure peaks. Initial reader opening is reported separately, and included in CPU/RSS.'}
(out/'plan.json').write_text(json.dumps(plan,indent=2))
metrics={'seconds':lambda x:x['result']['seconds'],'cpu':lambda x:x['usage']['cpu'],'rss':lambda x:x['usage']['rss'],'writes':lambda x:x['usage']['write_blocks']*512,'temporary_bytes':lambda x:x['result']['temporary_bytes']}
max_metrics={'rss','temporary_bytes'}
orders=[['before-a','before-b','after','follow'],['before-b','follow','before-a','after'],['follow','after','before-b','before-a'],['after','before-a','follow','before-b']]
rng=random.Random(plan['seed']);rng.shuffle(orders)
rows=[];summaries=[];env={**os.environ,'TMPDIR':str(r/'disk-data')};(r/'disk-data').mkdir(exist_ok=True)
def summarize(name):
 selected=[x for x in rows if x['case']==name]
 workkeys=['mode','residency','shape','bytes','payload','epochs','readers','polls','records','read_bytes','trace','source_bytes']
 work=[{k:x['result'][k] for k in workkeys} for x in selected];assert all(w==work[0] for w in work),(name,work)
 values={k:{label:(max if k in max_metrics else statistics.median)(fn(x) for x in selected if x['label']==label) for label in bins} for k,fn in metrics.items()}
 comparisons={}
 for after,befores in plan['comparisons'].items():
  comparisons[after]={}
  for before in befores:
   comparisons[after][before]={k:{'percent':100*(v[after]/v[before]-1) if v[before] else (0 if v[after]==0 else None),'passed':v[after]<=v[before]*1.05} for k,v in values.items()}
 return {'case':name,'groups':len(selected)//4,'work':work[0],'values':values,'comparisons':comparisons,'passed':all(m['passed'] for v in comparisons.values() for c in v.values() for m in c.values())}
for name,args in cases:
 for group in range(24):
  if group==8:
   initial=summarize(name);(out/f'{name}-initial.json').write_text(json.dumps(initial,indent=2))
   if initial['passed']:break
  for label in orders[group%4]:
   usage=out/'usage.json';cmd=[str(Path('/workspace/scratch/perf-recovery/initial/measure')),str(usage),str(bins[label]),*args]
   p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=600)
   if p.returncode:
    (out/f'failure-{name}-{group}-{label}.json').write_text(json.dumps({'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2));raise RuntimeError((name,group,label,p.returncode))
   row={'case':name,'args':args,'group':group,'label':label,'result':json.loads(p.stdout),'usage':json.loads(usage.read_text())};rows.append(row)
   with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(name,group,label,'sec',round(row['result']['seconds'],5),'cpu',row['usage']['cpu'],'rss',row['usage']['rss'],'frames',row['result']['frames'],flush=True)
 summary=summarize(name);summaries.append(summary);(out/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',name,json.dumps(summary),flush=True)
# Reproducible capacity diagnostics: equal 1GiB and calls at 100M samples/s for 16/32/64-bit samples.
capacity=[]
for bits in [16,32,64]:
 for group in range(3):
  for label in orders[group]:
   rate=100_000_000*(bits//8)/1048576
   args=['concurrent',str(1<<30),'65536','64','8','8','4',str(rate),'resident']
   usage=out/'usage.json';p=subprocess.run([str(Path('/workspace/scratch/perf-recovery/initial/measure')),str(usage),str(bins[label]),*args],capture_output=True,text=True,env=env,timeout=600,check=True)
   row={'bits':bits,'group':group,'label':label,'result':json.loads(p.stdout),'usage':json.loads(usage.read_text())};capacity.append(row);(out/'capacity.json').write_text(json.dumps(capacity,indent=2));print('CAPACITY',bits,group,label,row['result']['ingest_mib_s'],row['result']['max_lag_seconds'],flush=True)
print('FINISHED',flush=True)
