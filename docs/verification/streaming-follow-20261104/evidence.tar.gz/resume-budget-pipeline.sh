set -euo pipefail
python3 -u /workspace/scratch/stream-cache/qualify-budget-resume.py 2>&1 | tee -a /workspace/scratch/stream-cache/budget-qualification.log
python3 -u /workspace/scratch/stream-cache/independent-budget-resume.py 2>&1 | tee -a /workspace/scratch/stream-cache/independent-budget-qualification.log
