use crate::TryClone;
#[path = "matrix_bulk.rs"]
mod matrix_bulk;

use std::borrow::Cow;
use std::collections::HashMap;
use std::ffi::OsString;
use std::fs::{File, OpenOptions, remove_file};
use std::hash::Hash;
use std::io::{Read, Seek, SeekFrom, Write};
use std::mem::size_of;
use std::path::{Path, PathBuf};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use crate::{
    BlockKind, BlockVec, CommitPolicy, CompressionAlgorithm, CompressionHeaderMode,
    CompressionLevel, CompressionPolicy, Endian, Error, FormatSpec, HeaderSlotIntegrity,
    IndexPolicy, IntegrityPolicy, IntegrityVerification, KeyedBlockVec, LivenessPolicy,
    ManifestPolicy, MatrixCellStatus, MatrixCommitEvent, MatrixDimensions, MatrixKey,
    MatrixRecoveryAction, MatrixRecoveryReport, MatrixResumeSignal, RecoveryPolicy, Result,
    SnapshotFile, VariableCompression, VarlitBlock, VarlitEncode, VarlitKeyedBlock,
    VarlitMatrixBlock, VarlitMerge, VarlitMigration, VarlitReplaceBlock, WireType,
    codec::encode_to_vec_limited,
    collections::MaterializationBudget,
    format::ReadLimitKey,
    native_layout::{
        decode_native_internal_key_envelope, decode_native_internal_op_envelope,
        decode_native_record_footer, encode_native_record_footer, encode_native_record_header,
        native_file_header_len, native_record_footer_len, native_record_header_len,
        read_native_file_header, read_native_record_header, write_native_file_header,
        write_native_record_header,
    },
    writer_permit::{GuardedWriter, MutationPermit, PoisonFlag},
};

pub const TOMBSTONE_BLOCK_ID: u32 = 0xFFFF_FFFE;
pub const OP_BLOCK_ID: u32 = 0xFFFF_FFFD;
pub const METADATA_BLOCK_ID: u32 = 0xFFFF_FFFC;
pub const INDEX_BLOCK_ID: u32 = 0xFFFF_FFFB;
pub const MANIFEST_BLOCK_ID: u32 = 0xFFFF_FFFA;
pub const COMMIT_BLOCK_ID: u32 = 0xFFFF_FFF9;
/// Carries the per-create nonce of a stream/indexed primary (STO-01).
pub const CREATION_NONCE_BLOCK_ID: u32 = 0xFFFF_FFF8;
/// Carries one internal segment: the records a single commit point added.
///
/// A segment is varlit's own lookup unit and has no declaration surface. See
/// [`IndexPolicy::segment_on_flush`].
pub const SEGMENT_BLOCK_ID: u32 = 0xFFFF_FFF7;
const RESERVED_BLOCK_ID_START: u32 = 0xFFFF_FF00;

/// Every block id varlit reserves for its own records, as one list.
///
/// It exists because a *count* of these was needed and was written down by
/// hand. `HEADER_TAILS_RESERVED_ENTRIES` was `8` against ten ids — it happened
/// to be enough, because three of the ten cannot co-occur with that option, but
/// nothing tied the number to the list and an eleventh id would have overflowed
/// the region silently: `flags = OVERFLOW`, `count = 0`, and the option doing
/// nothing for the life of every file written afterwards.
///
/// So the count is derived, the range membership is a compile-time assertion,
/// and `enforcement_gates` reads this file's source to require that every
/// `*_BLOCK_ID` constant appears here. The last of those is the one that
/// catches a new id, because the compiler cannot notice an omission.
pub(crate) const INTERNAL_BLOCK_IDS: &[u32] = &[
    TOMBSTONE_BLOCK_ID,
    OP_BLOCK_ID,
    METADATA_BLOCK_ID,
    INDEX_BLOCK_ID,
    MANIFEST_BLOCK_ID,
    COMMIT_BLOCK_ID,
    CREATION_NONCE_BLOCK_ID,
    SEGMENT_BLOCK_ID,
    MATRIX_CHUNK_BLOCK_ID,
    OPEN_DIGEST_BLOCK_ID,
];

const _: () = {
    let mut index = 0;
    while index < INTERNAL_BLOCK_IDS.len() {
        assert!(
            INTERNAL_BLOCK_IDS[index] >= RESERVED_BLOCK_ID_START,
            "an internal block id must be inside the reserved range"
        );
        let mut other = index + 1;
        while other < INTERNAL_BLOCK_IDS.len() {
            assert!(
                INTERNAL_BLOCK_IDS[index] != INTERNAL_BLOCK_IDS[other],
                "internal block ids must be distinct"
            );
            other += 1;
        }
        index += 1;
    }
};
pub(crate) const RECORD_HEADER_LEN: u64 = 32;
pub(crate) const RECORD_FOOTER_LEN: u64 = 32;

/// The record is dead: the writer marked it as no longer wanted, and a
/// defragmenting rewrite may drop it.
///
/// Advisory by construction — the word it lives in is outside the record
/// checksum, which is what makes it writable after the fact. It says "the
/// writer marked this", never "these bytes are sound".
pub const RECORD_MUTABLE_FLAG_DEAD: u32 = 0x0000_0001;

/// The width of the footer's trailing mutable word — the `reserved` field that
/// [`LivenessPolicy::FooterFlags`] turns into record flags and takes out of the
/// checksum. Named here because two places need to agree on it and a footer
/// layout change has to break both.
pub(crate) const RECORD_FOOTER_MUTABLE_LEN: u64 = 4;
const RECORD_FLAG_COMPRESSED: u16 = 0x0001;
pub(crate) const RECORD_FLAG_INTERNAL: u16 = 0x8000;
const RECORD_KNOWN_FLAGS: u16 = RECORD_FLAG_COMPRESSED | RECORD_FLAG_INTERNAL;
pub(crate) const RECORD_FOOTER_MAGIC: &[u8; 4] = b"VRF1";
pub(crate) const RECORD_FOOTER_VERSION: u16 = 1;
pub(crate) const RECORD_FOOTER_FLAG_PREV_SAME_BLOCK: u16 = 0x0001;
pub(crate) const RECORD_FOOTER_FLAG_PREV_SAME_KEY: u16 = 0x0002;
pub(crate) const RECORD_FOOTER_KNOWN_FLAGS: u16 =
    RECORD_FOOTER_FLAG_PREV_SAME_BLOCK | RECORD_FOOTER_FLAG_PREV_SAME_KEY;
const COMMIT_PAYLOAD_MAGIC: &[u8; 4] = b"VCMT";
const INDEX_CHECKPOINT_MAGIC: &[u8; 4] = b"VIDX";
const INDEX_CHECKPOINT_VERSION: u16 = 3;
const SEGMENT_MAGIC: &[u8; 4] = b"VSEG";
const SEGMENT_VERSION: u16 = 1;
/// magic(4) + version(2) + flags(2) + covered_start(8) + entry_count(8)
/// + preceding_records(8).
const SEGMENT_PREFIX_LEN: u64 = 4 + 2 + 2 + 8 + 8 + 8;
/// The segment record's own start offset, written at the end of its payload.
///
/// Open arrives at EOF holding a footer and nothing else: the footer carries
/// no self offset and the header that would give one is `payload_len` bytes
/// further back, a distance only the header states. This trailer is the one
/// value that closes that circle, and it costs eight bytes of payload rather
/// than a byte of format.
const SEGMENT_TRAILER_LEN: u64 = 8;
/// One serialized index entry, in the layout `read_index_entry_payload`
/// decodes at checkpoint version 3.
const SEGMENT_ENTRY_LEN: u64 = 4 + 2 + 2 + 8 + 8 + 8 + 8 + 4 + 4 + 8 + 8 + 8 + 1;
/// Carries the three facts an open needs that live in no single record.
///
/// A segment says *where every record is*, so it costs an entry per record. A
/// digest says only what an open cannot compute without walking: the sequence
/// the next append takes, and each block's newest record. It costs twelve bytes
/// per distinct block id and nothing per record. See
/// [`IndexPolicy::open_digest_on_flush`].
pub const OPEN_DIGEST_BLOCK_ID: u32 = 0xFFFF_FFF5;
const DIGEST_MAGIC: &[u8; 4] = b"VDIG";
const DIGEST_VERSION: u16 = 1;
/// magic(4) + version(2) + flags(2) + sequence_high_water(8) + tail_count(4).
///
/// `physical_end` is deliberately *not* in here. The digest is the last record
/// in the file, so the committed end is its own end — a number open already
/// holds once it has framed the digest, and one that cannot disagree with the
/// bytes the way a stored copy could.
const DIGEST_PREFIX_LEN: u64 = 4 + 2 + 2 + 8 + 4;
/// One block tail: the block id and its newest record's offset.
const DIGEST_TAIL_LEN: u64 = 4 + 8;
/// The digest record's own start offset, closing the same circle
/// [`SEGMENT_TRAILER_LEN`] closes: open arrives at EOF holding a footer, and
/// the header that would give the record's start is `payload_len` bytes back.
const DIGEST_TRAILER_LEN: u64 = 8;
/// `sequence_high_water` when the file holds no record that carries a sequence.
///
/// The sequence field carries a high-water mark; clear means there is none.
///
/// This was a `u64::MAX` sentinel in the value itself, on the reasoning that a
/// writer which reached `u64::MAX` is `Exhausted` and so could never report it
/// as a mark. Both halves of that were wrong. The digest takes a sequence of
/// its own, so a digest written as the last available record *does* have
/// `u64::MAX` as its mark — and `Exhausted` was then unrepresentable, colliding
/// with "no mark" and leaving the decode arm that maps it dead code.
///
/// A flag costs nothing here: the field it lives in was written as zero and
/// never read.
const DIGEST_FLAG_SEQUENCE: u16 = 0x0001;

/// Every flag bit this version defines. A digest that sets one outside this set
/// was written by something that means more by it than this build knows, and is
/// answered with the scan rather than half-understood.
const DIGEST_FLAGS_KNOWN: u16 = DIGEST_FLAG_SEQUENCE;

/// What one digest record says.
#[derive(Clone, Debug, PartialEq, Eq)]
struct OpenDigest {
    /// The end of the digest record itself, which is the committed end of the
    /// file it describes.
    physical_end: u64,
    sequence_high_water: Option<u64>,
    block_tails: BlockTails,
}

/// The payload length a digest covering `tails` distinct blocks occupies.
fn digest_payload_len(tails: u64) -> Result<u64> {
    tails
        .checked_mul(DIGEST_TAIL_LEN)
        .and_then(|bytes| bytes.checked_add(DIGEST_PREFIX_LEN))
        .and_then(|bytes| bytes.checked_add(DIGEST_TRAILER_LEN))
        .ok_or(Error::ResourceArithmeticOverflow {
            resource: "digest payload length",
        })
}

/// Serializes the digest for a file whose last committed record is already
/// down, and whose next record will be the digest itself at `record_offset`.
fn encode_digest_payload(
    spec: FormatSpec,
    sequence_high_water: Option<u64>,
    tails: &[(u32, u64)],
    record_offset: u64,
) -> Result<Vec<u8>> {
    let count = u32::try_from(tails.len()).map_err(|_| Error::ResourceArithmeticOverflow {
        resource: "digest block count",
    })?;
    let payload_len = digest_payload_len(u64::from(count))?;
    spec.read_limits
        .check(ReadLimitKey::RecordPayloadLen, payload_len)?;
    spec.read_limits
        .check(ReadLimitKey::LogicalPayloadLen, payload_len)?;
    let capacity =
        usize::try_from(payload_len).map_err(|_| Error::LengthOverflow { value: payload_len })?;
    let mut payload = Vec::new();
    payload
        .try_reserve_exact(capacity)
        .map_err(|_| Error::AllocationFailed {
            resource: "digest payload",
            requested: payload_len,
        })?;
    payload.extend_from_slice(DIGEST_MAGIC);
    payload.extend_from_slice(&DIGEST_VERSION.to_le_bytes());
    let (flags, sequence) = match sequence_high_water {
        Some(mark) => (DIGEST_FLAG_SEQUENCE, mark),
        None => (0, 0),
    };
    payload.extend_from_slice(&flags.to_le_bytes());
    payload.extend_from_slice(&sequence.to_le_bytes());
    payload.extend_from_slice(&count.to_le_bytes());
    for (block_id, offset) in tails {
        payload.extend_from_slice(&block_id.to_le_bytes());
        payload.extend_from_slice(&offset.to_le_bytes());
    }
    payload.extend_from_slice(&record_offset.to_le_bytes());
    Ok(payload)
}

/// Reads a digest out of a payload the caller has already framed and
/// checksum-verified, or reports that these bytes are not one.
///
/// Every field is checked against the file rather than trusted: the tail
/// offsets must name records inside the append log and before the digest, and
/// the ids must be strictly ascending so a corrupt count cannot make the walk
/// revisit. A payload that fails any of it is not a digest, and the caller
/// answers that with the scan.
fn decode_digest_payload(
    payload: &[u8],
    append_start: u64,
    record_offset: u64,
    physical_end: u64,
) -> Result<OpenDigest> {
    let prefix_len = DIGEST_PREFIX_LEN as usize;
    let trailer_len = DIGEST_TRAILER_LEN as usize;
    if payload.len() < prefix_len + trailer_len {
        return Err(Error::InvalidIndexSegment);
    }
    if &payload[..4] != DIGEST_MAGIC {
        return Err(Error::InvalidIndexSegment);
    }
    let mut u16_buf = [0; 2];
    u16_buf.copy_from_slice(&payload[4..6]);
    if u16::from_le_bytes(u16_buf) != DIGEST_VERSION {
        return Err(Error::InvalidIndexSegment);
    }
    u16_buf.copy_from_slice(&payload[6..8]);
    let flags = u16::from_le_bytes(u16_buf);
    if flags & !DIGEST_FLAGS_KNOWN != 0 {
        return Err(Error::InvalidIndexSegment);
    }
    let mut u64_buf = [0; 8];
    u64_buf.copy_from_slice(&payload[8..16]);
    let stored_sequence = u64::from_le_bytes(u64_buf);
    let mut u32_buf = [0; 4];
    u32_buf.copy_from_slice(&payload[16..20]);
    let count = u32::from_le_bytes(u32_buf) as usize;
    let body_len = count
        .checked_mul(DIGEST_TAIL_LEN as usize)
        .ok_or(Error::InvalidIndexSegment)?;
    if payload.len() != prefix_len + body_len + trailer_len {
        return Err(Error::InvalidIndexSegment);
    }
    u64_buf.copy_from_slice(&payload[payload.len() - trailer_len..]);
    if u64::from_le_bytes(u64_buf) != record_offset {
        return Err(Error::InvalidIndexSegment);
    }
    let mut tails: Vec<(u32, u64)> = Vec::new();
    tails
        .try_reserve_exact(count)
        .map_err(|_| Error::AllocationFailed {
            resource: "digest block tails",
            requested: body_len as u64,
        })?;
    let mut previous: Option<u32> = None;
    for index in 0..count {
        let at = prefix_len + index * DIGEST_TAIL_LEN as usize;
        u32_buf.copy_from_slice(&payload[at..at + 4]);
        let block_id = u32::from_le_bytes(u32_buf);
        u64_buf.copy_from_slice(&payload[at + 4..at + 12]);
        let offset = u64::from_le_bytes(u64_buf);
        if previous.is_some_and(|last| block_id <= last) {
            return Err(Error::InvalidIndexSegment);
        }
        // A tail must name a record of this file that is behind the digest.
        // The digest is the last record, so "before it" and "inside the append
        // log" together are the whole of what an offset can be here.
        if offset < append_start || offset >= record_offset {
            return Err(Error::InvalidIndexSegment);
        }
        previous = Some(block_id);
        tails.push((block_id, offset));
    }
    Ok(OpenDigest {
        physical_end,
        sequence_high_water: (flags & DIGEST_FLAG_SEQUENCE != 0).then_some(stored_sequence),
        block_tails: BlockTails::from_sorted(tails),
    })
}
/// Carries one matrix chunk: `rows_per_chunk` rows of every matrix block.
///
/// A chunk is what makes a matrix dimension grow past the extent declared at
/// create. Chunk 0 *is* the matrix region; chunk `k > 0` is a record with the
/// region's layout. See [`crate::GrowingMatrixDimension`].
pub const MATRIX_CHUNK_BLOCK_ID: u32 = 0xFFFF_FFF6;
const MATRIX_CHUNK_MAGIC: &[u8; 4] = b"VMCK";
const MATRIX_CHUNK_VERSION: u16 = 1;
/// Prefix flag: every block region is `commit map | crc table | slots`.
///
/// Set when the format's integrity policy is a crc32 one. A chunk read
/// otherwise has nothing to check: the record footer's crc covers the whole
/// payload and is verified on a *record* read, which a positional cell read is
/// not, so a single flipped bit in a written chunk came back as data. The matrix
/// region solves this with a per-cell checksum and so does a chunk.
const MATRIX_CHUNK_FLAG_CELL_CRC: u16 = 0x0001;
/// Prefix flag: every block's slot region is a sub-block index followed by
/// compressed sub-blocks, rather than plain cells.
///
/// A chunk is written whole, so an unfilled one costs its full size — measured
/// identical at 5% and 100% filled. Only the slot regions are compressed: the
/// prefix, the descriptors, the commit maps and the checksum tables stay plain,
/// so addressing a cell, reading its commit bit and checking its checksum are
/// unchanged, and only the `stride`-byte positional read becomes a sub-block
/// decode.
const MATRIX_CHUNK_FLAG_COMPRESSED_SLOTS: u16 = 0x0002;
const MATRIX_CHUNK_KNOWN_FLAGS: u16 =
    MATRIX_CHUNK_FLAG_CELL_CRC | MATRIX_CHUNK_FLAG_COMPRESSED_SLOTS;
/// Uncompressed bytes a slot sub-block covers, before rounding to whole cells.
///
/// A cell's sub-block is `ordinal / cells_per_sub_block(stride)` — arithmetic,
/// not a search — and both sides derive the divisor from `stride` alone so they
/// cannot disagree.
const MATRIX_CHUNK_SUB_BLOCK_BYTES: u64 = 8192;
/// One `u32` offset per sub-block, plus a terminator, so a sub-block's extent
/// is two reads and no prefix sum.
const MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN: u64 = 4;
/// Bytes of stored checksum per cell.
const MATRIX_CHUNK_CRC_LEN: u64 = 4;
/// magic(4) + version(2) + flags(2) + chunk_index(8) + first_row(8) + rows(8)
/// + block_count(4) + reserved(4).
const MATRIX_CHUNK_PREFIX_LEN: u64 = 4 + 2 + 2 + 8 + 8 + 8 + 4 + 4;
/// block_id(4) + reserved(4) + stride(8) + cells(8) + commit_len(8).
///
/// Every block's descriptor precedes every block's data, so a reader computes
/// any block's slot offset from the descriptors alone — one small positional
/// read, whatever the chunk's size. That is what keeps a cell read from
/// materialising the chunk.
const MATRIX_CHUNK_BLOCK_DESC_LEN: u64 = 4 + 4 + 8 + 8 + 8;
/// Descriptor bytes a cell read keeps on the stack.
///
/// Eighteen blocks. A chunked cell read must not allocate — that is the whole
/// point of addressing a chunk by arithmetic — and every format anyone has
/// declared fits well inside this.
const MATRIX_CHUNK_INLINE_DESCRIPTOR_BYTES: usize = 512;
/// Smallest live-tail growth that forces a fresh full index checkpoint.
///
/// Below this floor the geometric-spacing rule in [`VarlitFile::needs_index_checkpoint`]
/// would fire on nearly every flush, reintroducing the cumulative O(N^2)
/// checkpoint bytes that PERF-02 removes. The floor keeps small files cheap to
/// recover while capping the per-flush overhead of a rapidly growing append log.
const INDEX_CHECKPOINT_MIN_RECORDS: usize = 16;
const MANIFEST_PAYLOAD_VERSION: u16 = 5;
const WRITER_LOCK_MAGIC: &str = "varve-lock-v1";
const COMPRESSION_ENVELOPE_MAGIC: &[u8; 4] = b"VCMP";
const COMPRESSION_ENVELOPE_VERSION: u8 = 1;
const FILE_COMPRESSION_MAGIC: &[u8; 4] = b"VCHD";
const FILE_COMPRESSION_VERSION: u8 = 1;
/// `VCHD`'s payload, excluding its magic.
///
/// `VCHD` predates the block framing below and carries no length prefix, so its
/// length is fixed by its own layout: version, algorithm, level kind, and the
/// `only_if_smaller` flag, then the exact level and the two length bounds.
const FILE_COMPRESSION_PAYLOAD_LEN: usize = 1 + 1 + 1 + 1 + 4 + 8 + 8;
/// The header block holding each block's newest record offset
/// ([`IndexPolicy::header_tails`]).
const HEADER_TAILS_MAGIC: &[u8; 4] = b"VBTT";

/// The liveness block: a writer's open/close mark, in the file header.
///
/// One bit of real content. A writer sets `DIRTY` when it takes the object and
/// clears it when it releases cleanly, so a later open that *can* take the
/// object and still finds the bit set is looking at a file whose last writer
/// died without releasing. The writer lock supplies the other half of that
/// question — "is anybody holding it now" — and it is an object lock, so hard
/// links and path aliases cannot dodge it.
///
/// This is the only durable record varlit keeps of a writer's lifecycle. The
/// alternative signal, "does the file end exactly at a commit point", is
/// positional: it can only ever describe a suffix, never an interior record,
/// and the next read-write open truncates that suffix away before anyone can
/// ask. A bit in the header is neither pushed along nor truncated.
const LIVENESS_MAGIC: &[u8; 4] = b"VLIV";
const LIVENESS_BLOCK_VERSION: u16 = 1;
/// `version u16 | flags u16 | crc32 u32`.
const LIVENESS_PAYLOAD_LEN: usize = 8;
/// The whole `VLIV` block a spec would write, framing included, or zero when
/// the format declares no liveness word.
///
/// Exists so the layout plan can add the same term the writer emits. It was
/// missing from `native_file_header_plan_extension_len`, which published a
/// header length 16 bytes short of the real one for every `footer_flags`
/// format — the plan described the first record as starting inside this block.
/// Nothing inside this crate read that number (`append_log_start_for_file`
/// derives the boundary from the file's own region), so no file was written
/// wrong; a tool reading `FormatSpec::effective_layout` was told wrong.
pub(crate) fn liveness_region_len(spec: FormatSpec) -> u64 {
    if !matches!(spec.liveness_policy, LivenessPolicy::FooterFlags) {
        return 0;
    }
    (8 + LIVENESS_PAYLOAD_LEN) as u64
}
/// The writer holds this object and has not released it cleanly.
const LIVENESS_FLAG_DIRTY: u16 = 0x0001;
const HEADER_TAILS_VERSION: u16 = 1;
/// Two slots, written alternately.
///
/// The update is an in-place overwrite of a live file, so there is a window in
/// which the bytes being written are neither the old table nor the new one. A
/// single slot would make that window a hole: a crash inside it leaves nothing
/// readable and the open falls all the way back to a full scan. Two slots make
/// it a step back — the slot *not* being written still carries the previous
/// commit point's table, so the fallback is an earlier commit boundary rather
/// than no boundary.
const HEADER_TAILS_SLOTS: usize = 2;
/// Entries reserved beyond the declared blocks: one per internal block id.
///
/// Derived from [`INTERNAL_BLOCK_IDS`] rather than chosen, because the capacity
/// is fixed at create and a table that outgrows it is not truncated — it is
/// dropped, with `HEADER_TAILS_FLAG_OVERFLOW` and `count = 0`, and the option
/// then does nothing for the life of that file. A hand-picked number is a
/// silent expiry date; a derived one widens the region when the list grows.
///
/// Reserving all ten is deliberate over-reserving. Three of them cannot
/// co-occur with this option — the open digest and matrix chunks are refused
/// alongside it, and the creation nonce belongs to a path that is — so the true
/// need today is seven. Twelve bytes each is not worth the reasoning it would
/// take to keep "which ids can co-occur" correct as the refusals change.
const HEADER_TAILS_RESERVED_ENTRIES: usize = INTERNAL_BLOCK_IDS.len();
/// `version u16 | flags u16 | capacity u32 | count u32 | generation u64 |
/// commit_offset u64`.
///
/// `commit_offset` is what makes the table checkable. Every other field
/// describes the table; this one names the *commit marker record* the table was
/// written for, and a reader confirms it by framing that record and then
/// walking forward to the end of the file. See `adopt_header_tails`.
const HEADER_TAILS_SLOT_HEADER_LEN: usize = 2 + 2 + 4 + 4 + 8 + 8;
/// `block_id: u32 | tail_offset: u64`.
const HEADER_TAILS_ENTRY_LEN: usize = 4 + 8;
/// The slot's own crc32, over every byte of the slot before it.
const HEADER_TAILS_SLOT_TRAILER_LEN: usize = 4;
/// The table did not fit the slot's capacity: `count` is zero and the slot
/// claims nothing, rather than claiming a table that is silently partial.
const HEADER_TAILS_FLAG_OVERFLOW: u16 = 1;
const HEADER_TAILS_KNOWN_FLAGS: u16 = HEADER_TAILS_FLAG_OVERFLOW;
/// The block's own framing: `magic[4] | len: u32`.
const HEADER_TAILS_BLOCK_FRAMING_LEN: usize = 4 + 4;
const MATRIX_SIDECAR_MAGIC: &[u8; 4] = b"VSID";
// v2 bound the sidecar to the native file's OS-object identity and matrix
// layout generation (DUR-04/05). v3 additionally binds it to the per-create
// creation nonce stamped into the native matrix file, so recreating a matrix
// on the same OS file object invalidates every earlier sidecar (DUR2-03).
// v1/v2 envelopes are refused as stale/regenerable.
const MATRIX_SIDECAR_VERSION: u16 = 3;
// Fixed header: 48-byte v1 prefix + 32-byte native fingerprint + 8-byte matrix
// layout generation + 16-byte matrix creation nonce.
const MATRIX_SIDECAR_FIXED_LEN: usize = 104;
const MATRIX_SIDECAR_FINGERPRINT_OFFSET: usize = 48;
const MATRIX_SIDECAR_LAYOUT_GENERATION_OFFSET: usize = 80;
const MATRIX_SIDECAR_CREATION_NONCE_OFFSET: usize = 88;
// Per-create identity region stamped between the native file header and the
// matrix layout header of every matrix file (DUR2-03). `create_with_dims`
// reuses the OS file object when the pathname already exists, so OS identity,
// schema hash and layout offsets are all stable across a same-dims recreate;
// the nonce is the only value that distinguishes the new logical matrix from
// the one every existing sidecar was published against.
const MATRIX_CREATION_NONCE_MAGIC: &[u8; 4] = b"VMNC";
const MATRIX_CREATION_NONCE_VERSION: u16 = 1;
const MATRIX_CREATION_NONCE_LEN: usize = 16;
// Magic (4) + version (2) + reserved (2) + nonce (16).
const MATRIX_CREATION_NONCE_REGION_LEN: usize = 8 + MATRIX_CREATION_NONCE_LEN;
#[cfg(feature = "integrity")]
const STREAM_BUFFER_LEN: usize = 64 * 1024;
const WRITER_LOCK_MAX_LEN: u64 = 16 * 1024;
const PHYSICAL_PAYLOAD_RESOURCE: &str = "payload";
const LOGICAL_PAYLOAD_RESOURCE: &str = "logical payload";
const WRITER_POISON_CONTEXT: &str = "file";

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SchemaManifest {
    pub payload_version: u16,
    pub format_version: u16,
    pub endian: Endian,
    pub schema_hash: u64,
    pub extension: Option<String>,
    pub index_policy: IndexPolicy,
    pub commit_policy: CommitPolicy,
    pub integrity_policy: IntegrityPolicy,
    pub recovery_policy: RecoveryPolicy,
    pub manifest_policy: ManifestPolicy,
    pub compression_policy: CompressionPolicy,
    pub blocks: Vec<SchemaBlockDescriptor>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SchemaBlockDescriptor {
    pub id: u32,
    pub name: String,
    pub version: u16,
    pub kind: BlockKind,
    pub fields: Vec<SchemaFieldDescriptor>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SchemaFieldDescriptor {
    pub id: u32,
    pub name: String,
    pub wire_type: WireType,
    pub presence: crate::FieldPresence,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MatrixSidecarManifest {
    pub format_magic: Vec<u8>,
    pub format_version: u16,
    pub schema_hash: u64,
    pub category: String,
    pub generation: u64,
    pub payload_len: u64,
    pub payload_crc32: u32,
    /// Fingerprint of the native matrix file's OS object (volume + file ID on
    /// Windows, device + inode on Unix) folded with the schema hash. Binds the
    /// sidecar to one specific native file so a same-spec sibling cannot adopt
    /// it (DUR-04).
    pub native_fingerprint: [u8; 32],
    /// The matrix layout generation the sidecar was published against, so a
    /// reader whose native layout has changed rejects the stale sidecar.
    pub matrix_layout_generation: u64,
    /// The per-create creation nonce of the native matrix file the sidecar was
    /// published against. Recreating a matrix on the same OS file object keeps
    /// the OS identity and layout offsets stable, so this nonce is what makes
    /// every pre-recreate sidecar refusable as stale (DUR2-03).
    pub matrix_creation_nonce: [u8; MATRIX_CREATION_NONCE_LEN],
}

/// Identity of the native matrix file a sidecar is bound to.
///
/// Recomputed by every reader from its own open native file and matrix layout,
/// then compared against the values recorded in the sidecar envelope.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct MatrixNativeIdentity {
    fingerprint: [u8; 32],
    layout_generation: u64,
    creation_nonce: [u8; MATRIX_CREATION_NONCE_LEN],
}

pub trait MatrixNumeric: Copy {
    const BYTE_LEN: usize;

    fn read_matrix_numeric(bytes: &[u8], endian: Endian) -> Self;
}

macro_rules! impl_matrix_integer {
    ($ty:ty, $len:expr) => {
        impl MatrixNumeric for $ty {
            const BYTE_LEN: usize = $len;

            fn read_matrix_numeric(bytes: &[u8], endian: Endian) -> Self {
                let bytes: [u8; $len] = bytes.try_into().expect("validated matrix numeric width");
                match endian {
                    Endian::Little => <$ty>::from_le_bytes(bytes),
                    Endian::Big => <$ty>::from_be_bytes(bytes),
                }
            }
        }
    };
}

impl MatrixNumeric for u8 {
    const BYTE_LEN: usize = 1;

    fn read_matrix_numeric(bytes: &[u8], _endian: Endian) -> Self {
        bytes[0]
    }
}

impl MatrixNumeric for i8 {
    const BYTE_LEN: usize = 1;

    fn read_matrix_numeric(bytes: &[u8], _endian: Endian) -> Self {
        bytes[0] as i8
    }
}

impl_matrix_integer!(u16, 2);
impl_matrix_integer!(i16, 2);
impl_matrix_integer!(u32, 4);
impl_matrix_integer!(i32, 4);
impl_matrix_integer!(u64, 8);
impl_matrix_integer!(i64, 8);
impl_matrix_integer!(u128, 16);
impl_matrix_integer!(i128, 16);

impl MatrixNumeric for f32 {
    const BYTE_LEN: usize = 4;

    fn read_matrix_numeric(bytes: &[u8], endian: Endian) -> Self {
        let raw = u32::read_matrix_numeric(bytes, endian);
        Self::from_bits(raw)
    }
}

impl MatrixNumeric for f64 {
    const BYTE_LEN: usize = 8;

    fn read_matrix_numeric(bytes: &[u8], endian: Endian) -> Self {
        let raw = u64::read_matrix_numeric(bytes, endian);
        Self::from_bits(raw)
    }
}

/// Optional barriers for a durable matrix cell write. The file is the physical
/// generation store, not the logical matrix image: only synchronize it, do not
/// seek to matrix offsets or modify it. Both callbacks precede generation-head
/// publication. The notification hook runs only after publication and sync.
pub trait MatrixDurabilityBarrier {
    fn sync_matrix_data(&mut self, file: &mut File) -> Result<()>;
    fn sync_matrix_commit(&mut self, file: &mut File) -> Result<()>;
}

#[derive(Clone, Copy, Debug, Default)]
pub struct FileMatrixDurabilityBarrier;

impl MatrixDurabilityBarrier for FileMatrixDurabilityBarrier {
    fn sync_matrix_data(&mut self, file: &mut File) -> Result<()> {
        file.sync_data()?;
        Ok(())
    }

    fn sync_matrix_commit(&mut self, file: &mut File) -> Result<()> {
        file.sync_all()?;
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum OpenMode {
    ReadOnly,
    ReadWrite,
}

/// Mechanical enforcement for F-01: a replacement target cannot be addressed
/// without having been version-checked.
///
/// Every replacement entry point selects its target by block id and then
/// writes `T`'s payload into (or under) the stored record's header. Three of
/// the four copied the stored `block_version` while substituting the new
/// payload, which is a persistent type/version disagreement on disk whenever
/// `schema_hash = 0` lets a differently-versioned program open the file. Two
/// paths carried an ad-hoc check and two did not, and review alone had not
/// caught that in seven rounds.
///
/// The check is therefore no longer a step a path can forget: it is a
/// precondition of *writing* the target. [`ReplacementTarget`] has a private
/// field, lives in its own module so nothing else can name that field, and has
/// exactly one constructor - [`ReplacementTarget::resolve`], which performs
/// both the selection and the version refusal.
///
/// **What is and is not enforced, stated precisely.** Reading `self.index` is
/// not restricted: any code in this file may walk it and compute an ordinal,
/// and round 12's first attempt claimed otherwise. What a caller cannot do is
/// *act* on such an ordinal. The bytes of an already-indexed record are
/// reachable only through [`RecordFile::overwrite_indexed_record`], which takes
/// a [`RecordOverwrite`] by value; the only constructor of a [`RecordOverwrite`]
/// is [`RecordOverwrite::prepare`], which takes a [`ReplacementTarget`] by
/// value. So a replacement path added next month that resolves its own ordinal
/// over `self.index` has nothing it can hand to the writer, and does not
/// compile. See `mod record_file` for the other half (the raw handle is
/// unreachable, so the seek/write pair cannot be duplicated either).
///
/// Proved by `crates/varlit/tests/ui/fail_fabricated_replacement_target.rs` and
/// `fail_fabricated_record_overwrite.rs` (compile-fail), and by
/// `crates/varlit/tests/enforcement_gates.rs`.
#[path = "file/replacement_target.rs"]
pub(crate) mod replacement_target;

use replacement_target::{RecordOverwrite, ReplacementTarget};

/// Mechanical enforcement for shape A/B on the primary file handle: the record
/// bytes of an open generation cannot be written except through one of two
/// gated operations.
///
/// The round-12 review found that `overwrite_record_bytes_in_place` was "the
/// only function in the crate that rewrites the bytes of an already-indexed
/// record" — true of the code as written, and unenforced: a new
/// `self.file.seek(..)` / `self.file.write_all(..)` pair anywhere in this
/// ~12,000-line file compiled and skipped both the version refusal (F-01) and
/// the keyed-tail invalidation (F-02). That is the same "correct today,
/// described in prose" configuration that F-03 was in.
///
/// [`RecordFile`] owns the handle in a module that keeps the field unnameable,
/// and exposes no general-purpose write. `Write`, `Seek` and `Read` are not
/// implemented for it and it hands out no `&File` (`impl Write for &File` would
/// make that equivalent to a mutable handle). The only two ways to put record
/// bytes on disk are:
///
/// * [`RecordFile::append_record_at_end`], which seeks to the end itself and
///   refuses if the resulting offset is not the one the caller budgeted for, so
///   it structurally cannot land inside an existing record; and
/// * [`RecordFile::overwrite_indexed_record`], which consumes a
///   [`RecordOverwrite`] — see `mod replacement_target` for what producing one
///   costs.
///
/// One deliberate exception, named here rather than left to be discovered:
/// [`RecordFile::matrix_region`] hands `crate::matrix` the `&mut File` its
/// functions take. The matrix region is disjoint from the record region and has
/// its own shape-A gate (`matrix.rs`, `mod page_index`). The gate that keeps
/// that exception honest is a source assertion, not the compiler:
/// `crates/varlit/tests/enforcement_gates.rs::the_primary_handle_escape_is_only_for_the_matrix_region`.
#[path = "file/record_file.rs"]
mod record_file;

use record_file::RecordFile;

/// Owner-local record directory with a bounded buffer and private spill file.
/// Reservation performs allocation and spill I/O before the authoritative
/// append. The append requires its token; installation afterwards is infallible.
/// Follow stages validated rows and rolls back the logical directory length on
/// a scratch error. Positional reads keep independent snapshots independent.
#[path = "native_directory.rs"]
pub(crate) mod resident_index;

use resident_index::{ReservedIndexSlot, ResidentIndex};
#[path = "native_scan.rs"]
mod native_scan;
use native_scan::{BufferedScan, FollowScan, ScanBuffer};
#[path = "native_rewrite.rs"]
mod native_rewrite;
use native_rewrite::{IndexPayload, OffsetRemap, RewriteDirectory};
#[path = "external_merge.rs"]
mod external_merge;

/// Which route [`VarlitFile::open_readonly_lazy`] actually took.
///
/// Both open the same file and answer the same reads. They differ by roughly
/// four orders of magnitude in syscalls, which is a difference a caller that
/// asked for the lazy open is entitled to notice rather than infer from a
/// stopwatch.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LazyOpenSource {
    /// The tail table in the *file header* was read and the file corroborated
    /// it. A handful of records were framed — the commit marker it names, what
    /// follows that marker, and one per block tail — and no more.
    ///
    /// The route [`IndexPolicy::header_tails`] exists for: unlike the digest,
    /// nothing appended to the file can move this table or bury it.
    HeaderTails,
    /// The digest at the end of the file was read. No record was framed.
    Digest,
    /// No usable digest, so every record was framed. Correct, and expensive.
    FullScan,
}

/// Whether an open keeps a record directory of its own.
///
/// Not a policy on the format: two callers of the same file want different
/// answers, and the one that wants none has to take the directory in the same
/// call or it could not read positionally at all. See
/// [`VarlitFile::open_readonly_without_directory`].
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum DirectoryRetention {
    Keep,
    None,
}

/// Where a read resolves a record *position* to a record.
///
/// Every position-based read — `blocks`, `scan`, `keyed_blocks`, `metadata`,
/// `verify_all` and the rest — needs exactly two things from a directory: how
/// many records there are, and the entry at position `i`. Nothing else. Making
/// that a parameter rather than a field is what lets the directory stop being
/// the handle's business without any of those reads stopping working.
///
/// Two implementations, and they are the two answers to "who holds it":
///
/// * `ResidentIndex` — varlit holds it, and `record_at` faults the entry off
///   disk from a 16-byte slot.
/// * `[RecordIndexEntry]` — the host holds it, as
///   [`VarlitFile::index_entries_into`] or
///   [`VarlitFile::open_readonly_with_scratch`] left it. `record_at` is a
///   memcpy.
///
/// The second is the point, and it is stated plainly because the alternative
/// was nearly shipped: a handle that keeps no directory must not *lose* these
/// reads, it must *demand the directory from whoever has it*. That is the
/// difference between a capability with a cost and a capability withdrawn.
pub trait RecordDirectory {
    /// How many records this directory describes.
    fn record_count(&self) -> usize;

    /// The entry at `position`, or `UnexpectedEof` if there is none.
    fn record_at(&self, position: usize) -> Result<RecordIndexEntry>;

    /// The block id at `position`, when it can be told without building the
    /// entry. `None` means "ask `record_at`" and is always a correct answer.
    ///
    /// This exists for walks that want one block out of a directory. Producing
    /// an entry can read the file — the resident index rebuilds each one from
    /// its record header — so a walk that filters *after* `record_at` pays for
    /// every record in the file to keep the few that match. Directories that
    /// hold whole entries answer from those; the resident index answers from
    /// the field its slot carries; the default answers `None`, which costs a
    /// filtering caller nothing beyond what it already did.
    fn block_id_at(&self, _position: usize) -> Option<u32> {
        None
    }
}

/// Every entry of `dir` in order, fallible per item for the same reason
/// [`ResidentIndex::iter`] is: producing one may read a file.
///
/// A free function rather than a trait method with a default body, because a
/// `-> impl Iterator` method forces `Self: Sized` and the most useful directory
/// of all is `&[RecordIndexEntry]`, which is not.
pub fn directory_records<D: RecordDirectory + ?Sized>(
    dir: &D,
) -> impl Iterator<Item = Result<RecordIndexEntry>> + '_ {
    (0..dir.record_count()).map(|position| dir.record_at(position))
}

/// Whether the record at `position` can be passed over without building its
/// entry, given the block ids the caller is looking for.
///
/// Every walk that wants one block used to filter *after* `record_at`, which
/// was free when the resident index held whole entries and stopped being free
/// when it became one offset and one block id per record: producing an entry
/// is now a positional read of that record's header. A walk over a 600,000
/// record file that keeps five of them was reading 600,000 headers.
///
/// `false` when the directory cannot say (`block_id_at` returned `None`) —
/// the caller then does exactly what it did before, and its own check after
/// `record_at` is still the one that decides. This is an optimisation with no
/// authority: it never admits a record the caller's own filter would reject.
fn directory_skips<D: RecordDirectory + ?Sized>(dir: &D, position: usize, wanted: &[u32]) -> bool {
    match dir.block_id_at(position) {
        Some(id) => !wanted.contains(&id),
        None => false,
    }
}

impl RecordDirectory for ResidentIndex {
    fn record_count(&self) -> usize {
        self.len()
    }

    fn record_at(&self, position: usize) -> Result<RecordIndexEntry> {
        self.entry_at(position)
    }

    fn block_id_at(&self, position: usize) -> Option<u32> {
        ResidentIndex::block_id_at(self, position)
    }
}

impl RecordDirectory for [RecordIndexEntry] {
    fn record_count(&self) -> usize {
        self.len()
    }

    fn record_at(&self, position: usize) -> Result<RecordIndexEntry> {
        self.get(position).cloned().ok_or(Error::UnexpectedEof)
    }

    fn block_id_at(&self, position: usize) -> Option<u32> {
        self.get(position).map(|entry| entry.block_id)
    }
}

impl RecordDirectory for Vec<RecordIndexEntry> {
    fn record_count(&self) -> usize {
        self.len()
    }

    fn record_at(&self, position: usize) -> Result<RecordIndexEntry> {
        self.as_slice().record_at(position)
    }
}

/// A record index the caller owns the memory for, walked only as far as the
/// caller's question needed.
///
/// [`VarlitFile::index_entries_into`] answers one question — "give me the whole
/// index" — and it answers it the same way whatever was actually being looked
/// for: `N` entries and two positional reads per record, to the end of the
/// file. This answers "walk until you find it, then stop". A map that finds its
/// record at position 12 of a million has read twelve records.
///
/// Three things make it the caller's rather than varlit's:
///
/// * **The buffer comes in.** `record_map` takes `&mut Vec<RecordIndexEntry>`
///   and never allocates one. Nothing is copied out of it either — the map
///   *is* the buffer, viewed.
/// * **The walk resumes.** A second question continues from where the first
///   stopped, so asking twice costs the records between the two answers, not
///   two walks. [`find`](Self::find) searches what is already framed before it
///   reads anything at all.
/// * **The caller decides when it goes away.** [`clear`](Self::clear) empties
///   it and rewinds; [`release`](Self::release) empties it and keeps walking
///   forward, which is how a bounded-memory pass over a file larger than RAM is
///   written. Dropping the map hands the buffer straight back.
///
/// It implements [`RecordDirectory`], so a map is a directory: everything
/// [`VarlitFile::with_directory`] serves — `blocks`, `scan`, `keyed_blocks`, the
/// rest — is answered against the prefix walked so far. That is what the trait
/// being the currency, rather than `Vec`, buys.
///
/// ```ignore
/// let mut buffer = Vec::new();
/// let mut map = file.record_map(&mut buffer)?;         // no read yet
/// let hit = map.find(|entry| entry.block_id == Note::ID)?;
/// if let Some(entry) = hit {
///     let note: Note = file.decode_block_into(&entry, &mut payload)?;
/// }
/// let points = file.with_directory(&map)?.block_entries_into::<Note>(&mut out)?;
/// map.clear();                                         // the caller's call
/// ```
///
/// **What it walks, and what it therefore cannot see.** Records in file order,
/// from the start of the append log to the handle's snapshot end. That end is
/// already the committed, complete one — the open scan established it — so a
/// torn trailing record, and under a transaction-marker policy an uncommitted
/// tail, are outside the walk rather than filtered out of it. Non-resident
/// blocks are framed and skipped, exactly as the open scan skips them, so a
/// completed map equals [`VarlitFile::index_entries`] entry for entry.
///
/// **What a partial index does not check.** A full open validates sequence
/// uniqueness across every record in the file. A map validates nothing beyond
/// the prefix it has read, because that is all it has read: a duplicate
/// sequence past the stopping point is not detected until a walk reaches it.
/// That is the cost of not reading the rest, and it is the only correctness
/// difference between a completed map and an open scan.
pub struct RecordMap<'a> {
    entries: &'a mut Vec<RecordIndexEntry>,
    spec: FormatSpec,
    snapshot: SnapshotFile,
    /// Where the append log begins, and where [`Self::clear`] rewinds to.
    start: u64,
    /// The offset the next [`Self::advance`] will frame.
    next: u64,
    /// One past the last byte the walk may touch: the handle's snapshot end.
    end: u64,
    accounting: ScanAccounting,
}

impl<'a> RecordMap<'a> {
    fn new(file: &VarlitFile, entries: &'a mut Vec<RecordIndexEntry>) -> Result<Self> {
        let start = append_log_start_for_file(file)?;
        entries.clear();
        let mut accounting = ScanAccounting::default();
        // The header bytes the walk skips are charged the way the open scan
        // charges them, so a `ScanBytes` ceiling means the same number of bytes
        // whichever route reached the record.
        accounting.advance(file.spec, start)?;
        Ok(Self {
            entries,
            spec: file.spec,
            snapshot: file.snapshot.clone(),
            start,
            next: start,
            end: file.snapshot.len(),
            accounting,
        })
    }

    /// Frames the next record, appends it, and returns it; `None` at the end of
    /// the walk.
    ///
    /// One record, two positional reads — the header, and the footer if the
    /// format has one. Nothing else is touched: a record's payload is not read
    /// to frame it, whatever its size.
    pub fn advance(&mut self) -> Result<Option<RecordIndexEntry>> {
        loop {
            if self.next >= self.end {
                return Ok(None);
            }
            // Counted the way the open scan counts, because this is the same
            // unit of work: a header, an extent and a footer read to *build* an
            // index. `ResidentIndex::fault` deliberately does not count — it
            // rebuilds an entry of an index that already exists, and conflating
            // the two would make every `index_entries()` call look like a scan.
            note_record_framed();
            let entry = fault_record_entry(&self.snapshot, self.spec, self.next, true)?;
            let record_end =
                entry
                    .checked_physical_end()
                    .map_err(|_| Error::ResourceArithmeticOverflow {
                        resource: "record extent",
                    })?;
            // A record whose extent runs past the snapshot end is not a record
            // this handle may see. The open scan cannot produce one — its end
            // *is* a record boundary — so this is a torn-file guard, not a
            // routine branch, and it stops rather than reporting corruption
            // the scan already decided to tolerate.
            if record_end > self.end {
                self.next = self.end;
                return Ok(None);
            }
            self.accounting
                .advance(self.spec, record_end.saturating_sub(self.next))?;
            self.next = record_end;
            // Framed and skipped, exactly as the open scan skips it: a
            // non-resident block's records are on disk and not in the index.
            if !record_is_resident(self.spec, entry.block_id) {
                continue;
            }
            reserve_scanned_entry(self.spec, self.entries)?;
            self.entries.push(entry.clone());
            return Ok(Some(entry));
        }
    }

    /// Walks forward until `want` accepts a record, and stops there.
    ///
    /// Searches what is already framed first, so a question the last one
    /// already paid for costs no read at all.
    pub fn find(
        &mut self,
        mut want: impl FnMut(&RecordIndexEntry) -> bool,
    ) -> Result<Option<RecordIndexEntry>> {
        if let Some(found) = self.entries.iter().find(|entry| want(entry)) {
            return Ok(Some(found.clone()));
        }
        while let Some(entry) = self.advance()? {
            if want(&entry) {
                return Ok(Some(entry));
            }
        }
        Ok(None)
    }

    /// Walks until the map holds `count` entries, or the file ends first.
    ///
    /// Returns how many it holds, which is `count` unless the file ran out.
    pub fn fill_to(&mut self, count: usize) -> Result<usize> {
        while self.entries.len() < count {
            if self.advance()?.is_none() {
                break;
            }
        }
        Ok(self.entries.len())
    }

    /// Walks to the end of the file.
    ///
    /// This is [`VarlitFile::index_entries_into`] spelled as the case it is —
    /// the one where the answer really is every record — and it costs the same.
    pub fn fill(&mut self) -> Result<usize> {
        while self.advance()?.is_some() {}
        Ok(self.entries.len())
    }

    /// The records framed so far, in file order.
    pub fn entries(&self) -> &[RecordIndexEntry] {
        self.entries
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Whether the walk has reached the end of the file.
    ///
    /// A complete map is the whole index; an incomplete one is a prefix, and
    /// every read answered against it is answered against that prefix.
    pub fn is_complete(&self) -> bool {
        self.next >= self.end
    }

    /// The file offset the next [`Self::advance`] will frame.
    pub fn resume_offset(&self) -> u64 {
        self.next
    }

    /// Empties the buffer and rewinds the walk to the start of the file.
    ///
    /// The map is then what [`VarlitFile::record_map`] just returned. Use
    /// [`release`](Self::release) to free the entries without giving up the
    /// ground already covered.
    pub fn clear(&mut self) {
        self.entries.clear();
        self.next = self.start;
    }

    /// Empties the buffer but keeps the walk where it is.
    ///
    /// This is the bounded-memory pass: `fill_to(k)`, use them, `release()`,
    /// repeat. Memory is the caller's `k` entries however long the file is, and
    /// no record is read twice.
    pub fn release(&mut self) {
        self.entries.clear();
    }
}

impl RecordDirectory for RecordMap<'_> {
    fn record_count(&self) -> usize {
        self.entries.len()
    }

    fn record_at(&self, position: usize) -> Result<RecordIndexEntry> {
        self.entries.as_slice().record_at(position)
    }
}

impl std::fmt::Debug for RecordMap<'_> {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("RecordMap")
            .field("framed", &self.entries.len())
            .field("resume_offset", &self.next)
            .field("complete", &self.is_complete())
            .finish()
    }
}

/// An owned snapshot of a file's record index.
///
/// Derefs to `[RecordIndexEntry]`, so it reads exactly like the borrowed slice
/// this replaced.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct IndexEntries {
    entries: Vec<RecordIndexEntry>,
}

impl core::ops::Deref for IndexEntries {
    type Target = [RecordIndexEntry];

    fn deref(&self) -> &[RecordIndexEntry] {
        &self.entries
    }
}

impl IntoIterator for IndexEntries {
    type Item = RecordIndexEntry;
    type IntoIter = std::vec::IntoIter<RecordIndexEntry>;

    fn into_iter(self) -> Self::IntoIter {
        self.entries.into_iter()
    }
}

impl<'a> IntoIterator for &'a IndexEntries {
    type Item = &'a RecordIndexEntry;
    type IntoIter = std::slice::Iter<'a, RecordIndexEntry>;

    fn into_iter(self) -> Self::IntoIter {
        self.entries.iter()
    }
}

/// A [`VarlitFile`]'s reads, resolved through a caller-supplied directory.
///
/// Built by [`VarlitFile::with_directory`]. Every method is the handle's method
/// of the same name, answered against the borrowed directory; nothing here
/// allocates a directory of its own.
#[derive(Debug)]
pub struct DirectoryRead<'a, D: RecordDirectory + ?Sized> {
    file: &'a VarlitFile,
    directory: &'a D,
}

impl<D: RecordDirectory + ?Sized> DirectoryRead<'_, D> {
    /// How many records the supplied directory describes.
    pub fn record_count(&self) -> usize {
        self.directory.record_count()
    }

    pub fn scan(&self) -> impl Iterator<Item = Result<BlockEvent>> + '_ {
        VarlitFile::scan_in(self.directory)
    }

    pub fn metadata(&self, key: &str) -> Result<Option<Vec<u8>>> {
        self.file.metadata_in(self.directory, key)
    }

    pub fn all_metadata_into(&self, out: &mut Vec<(String, Vec<u8>)>) -> Result<()> {
        self.file.all_metadata_into_in(self.directory, out)
    }

    pub fn schema_manifest(&self) -> Result<Option<SchemaManifest>> {
        self.file.schema_manifest_in(self.directory)
    }

    pub fn blocks<T: VarlitBlock>(&self) -> Result<BlockVec<T>> {
        self.file.blocks_in(self.directory)
    }

    pub fn block_entries_into<T: VarlitBlock>(
        &self,
        out: &mut Vec<RecordIndexEntry>,
    ) -> Result<()> {
        self.file.block_entries_into_in::<T, _>(self.directory, out)
    }

    pub fn decode_blocks_into<T: VarlitBlock>(&self, out: &mut Vec<T>) -> Result<()> {
        self.file.decode_blocks_into_in::<T, _>(self.directory, out)
    }

    pub fn blocks_migrated_into<From, To, M>(&self, out: &mut Vec<To>) -> Result<()>
    where
        From: VarlitBlock,
        To: VarlitBlock,
        M: VarlitMigration<From, To>,
    {
        self.file
            .blocks_migrated_into_in::<From, To, M, _>(self.directory, out)
    }

    pub fn keyed_blocks_into<T>(
        &self,
        entries: &mut Vec<RecordIndexEntry>,
        by_key: &mut HashMap<T::Key, RecordIndexEntry>,
    ) -> Result<()>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash + Clone,
    {
        self.file
            .keyed_blocks_into_in::<T, _>(self.directory, entries, by_key)
    }

    pub fn materialized_keyed_blocks_into<T>(&self, out: &mut HashMap<T::Key, T>) -> Result<()>
    where
        T: VarlitMerge,
        T::Key: Eq + Hash,
    {
        self.file
            .materialized_keyed_blocks_into_in::<T, _>(self.directory, out)
    }

    pub fn key_tail_offsets_into<T>(&self, out: &mut HashMap<T::Key, u64>) -> Result<()>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        self.file
            .key_tail_offsets_into_in::<T, _>(self.directory, out)
    }

    pub fn index_entries_into(&self, out: &mut Vec<RecordIndexEntry>) -> Result<()> {
        self.file.index_entries_into_in(self.directory, out)
    }

    pub fn verify_all(&self) -> Result<usize> {
        self.file.verify_all_in(self.directory)
    }

    /// Reads through an entry the caller holds; see
    /// [`VarlitFile::decode_block_into`]. Present here so a directory-supplied
    /// walk needs no second handle.
    pub fn decode_block_into<T: VarlitBlock>(
        &self,
        entry: &RecordIndexEntry,
        scratch: &mut Vec<u8>,
    ) -> Result<T> {
        self.file.decode_block_into::<T>(entry, scratch)
    }
}

#[derive(Clone, Debug, Hash, PartialEq, Eq)]
pub struct RecordIndexEntry {
    pub block_id: u32,
    pub block_version: u16,
    pub flags: u16,
    pub sequence: u64,
    pub record_offset: u64,
    pub payload_offset: u64,
    pub payload_len: u64,
    pub checksum: u32,
    pub uncompressed_len_hint: u32,
    pub footer_offset: Option<u64>,
    pub prev_same_block_offset: Option<u64>,
    pub prev_same_key_offset: Option<u64>,
    /// The trailing footer word this record carries.
    ///
    /// Always `0` under [`LivenessPolicy::None`], which is every format that
    /// did not opt in. Under [`LivenessPolicy::FooterFlags`] it is the record's
    /// mutable flags — the only part of a written record that can change
    /// without rewriting it, and the only field here that is not covered by the
    /// record's checksum.
    pub mutable_flags: u32,
    pub committed: bool,
}

#[cfg(kani)]
#[path = "verification/record_extent.rs"]
mod record_extent_proofs;

impl RecordIndexEntry {
    /// Reads stored payload bytes by reopening the object currently named by
    /// `path`.
    ///
    /// This is a low-level, non-snapshot convenience API. It does not prove
    /// that the path still names the object from which this entry was indexed,
    /// does not establish index membership or checksum validity, and applies
    /// the standard physical payload ceiling. Prefer a typed
    /// reader/collection, which remains bound to its opened snapshot. For an
    /// explicitly path-based untrusted-input tool, use
    /// [`Self::read_payload_limited`] after establishing the entry's provenance.
    pub fn read_payload(&self, path: &Path) -> Result<Vec<u8>> {
        let mut file = File::open(path)?;
        let file_len = file.metadata()?.len();
        self.validate_payload_extent(file_len)?;
        crate::ReadLimits::STANDARD.check(ReadLimitKey::RecordPayloadLen, self.payload_len)?;
        self.read_payload_file_validated(&mut file)
    }

    /// Reads stored payload bytes from the object currently named by `path`
    /// after applying an allocation ceiling.
    ///
    /// This remains path-based and non-snapshot: pathname replacement can make
    /// it read a different object with a compatible extent. The limit does not
    /// establish index membership or checksum validity. High-level readers do
    /// not use this method.
    pub fn read_payload_limited(&self, path: &Path, limit: u64) -> Result<Vec<u8>> {
        let mut file = File::open(path)?;
        let file_len = file.metadata()?.len();
        self.validate_payload_extent(file_len)?;
        ensure_payload_limit(PHYSICAL_PAYLOAD_RESOURCE, self.payload_len, limit)?;
        self.read_payload_file_validated(&mut file)
    }

    pub fn is_compressed(&self) -> bool {
        self.flags & RECORD_FLAG_COMPRESSED != 0
    }

    /// Reads and decodes logical payload bytes through the current pathname.
    ///
    /// This low-level method is non-snapshot and resolves the format's runtime
    /// physical and logical allocation ceilings. It does not replace index-membership or record
    /// integrity validation. Use a typed snapshot reader for ordinary reads,
    /// or [`Self::read_logical_payload_limited`] for explicitly path-based
    /// tooling that has separately established entry provenance.
    pub fn read_logical_payload(&self, spec: FormatSpec, path: &Path) -> Result<Vec<u8>> {
        self.read_logical_payload_limited(spec, path, u64::MAX, u64::MAX)
    }

    /// Reads and decodes through the current pathname with separate stored and
    /// logical allocation ceilings.
    ///
    /// The limits bound allocation but do not turn this path-based helper into
    /// an opened-object snapshot API.
    pub fn read_logical_payload_limited(
        &self,
        spec: FormatSpec,
        path: &Path,
        physical_limit: u64,
        logical_limit: u64,
    ) -> Result<Vec<u8>> {
        let spec = spec.resolve_entrypoint();
        let mut file = File::open(path)?;
        let file_len = file.metadata()?.len();
        self.validate_payload_extent(file_len)?;
        spec.read_limits
            .check(ReadLimitKey::RecordPayloadLen, self.payload_len)?;
        ensure_payload_limit(PHYSICAL_PAYLOAD_RESOURCE, self.payload_len, physical_limit)?;
        let logical_len = self.logical_payload_len_before_allocation(spec, &mut file)?;
        spec.read_limits
            .check(ReadLimitKey::LogicalPayloadLen, logical_len)?;
        ensure_payload_limit(LOGICAL_PAYLOAD_RESOURCE, logical_len, logical_limit)?;
        let payload = self.read_payload_file_validated(&mut file)?;
        decode_record_payload(spec, self, payload)
    }

    pub(crate) fn logical_payload_len_snapshot(
        &self,
        spec: FormatSpec,
        snapshot: &SnapshotFile,
    ) -> Result<u64> {
        spec.read_limits
            .check(ReadLimitKey::RecordPayloadLen, self.payload_len)?;
        self.validate_payload_extent(snapshot.len())?;
        let logical_len = if !self.is_compressed() {
            self.payload_len
        } else {
            self.logical_payload_len_from_snapshot(spec, snapshot)?
        };
        spec.read_limits
            .check(ReadLimitKey::LogicalPayloadLen, logical_len)?;
        Ok(logical_len)
    }

    /// **This allocates.**
    /// [`read_payload_snapshot_into`](Self::read_payload_snapshot_into) takes
    /// the caller's buffer, which is what the per-record loops use.
    pub(crate) fn read_payload_snapshot(
        &self,
        spec: FormatSpec,
        snapshot: &SnapshotFile,
    ) -> Result<Vec<u8>> {
        let mut payload = Vec::new();
        self.read_payload_snapshot_into(spec, snapshot, &mut payload)?;
        Ok(payload)
    }

    /// Reads this record's stored bytes into the caller's buffer, verified.
    ///
    /// `out` ends exactly `payload_len` bytes long; see
    /// [`SnapshotFile::read_into_at`] for why that matters to the checksum.
    pub(crate) fn read_payload_snapshot_into(
        &self,
        spec: FormatSpec,
        snapshot: &SnapshotFile,
        out: &mut Vec<u8>,
    ) -> Result<()> {
        spec.read_limits
            .check(ReadLimitKey::RecordPayloadLen, self.payload_len)?;
        self.validate_payload_extent(snapshot.len())?;
        snapshot.read_into_at(
            self.payload_offset,
            self.payload_len,
            limit_or_max(spec.read_limits.require(ReadLimitKey::RecordPayloadLen)?),
            ReadLimitKey::RecordPayloadLen.resource(),
            out,
        )?;
        self.verify_snapshot_record(spec, snapshot, out)
    }

    /// **This allocates.**
    /// [`read_logical_payload_snapshot_into`](Self::read_logical_payload_snapshot_into)
    /// takes the caller's buffer.
    pub(crate) fn read_logical_payload_snapshot(
        &self,
        spec: FormatSpec,
        snapshot: &SnapshotFile,
    ) -> Result<Vec<u8>> {
        let mut decoded = Vec::new();
        self.read_logical_payload_snapshot_into(spec, snapshot, &mut decoded)?;
        Ok(decoded)
    }

    /// Reads this record's logical bytes into the caller's buffer.
    ///
    /// **Uncompressed records cost no copy.** That is the case worth designing
    /// for — it is every record of a format that declares no compression — and
    /// the obvious `_into` gets it wrong: reading into a scratch and copying
    /// into `out` adds a full `memcpy` per record to a path that today moves
    /// the buffer straight out. So the uncompressed arm reads directly into
    /// `out` and stops there.
    ///
    /// **Compressed records are unchanged, and no better.** The decompressor
    /// produces its own buffer, so `out`'s allocation is replaced rather than
    /// reused. That is what happens today too; this does not regress it, and it
    /// does not improve it either. Making it reuse `out` needs a decompression
    /// entry point that writes into a caller buffer, which is a change to
    /// `decompress_with_algorithm` and is not made here.
    pub(crate) fn read_logical_payload_snapshot_into(
        &self,
        spec: FormatSpec,
        snapshot: &SnapshotFile,
        out: &mut Vec<u8>,
    ) -> Result<()> {
        let logical_len = self.logical_payload_len_snapshot(spec, snapshot)?;
        if self.is_compressed() {
            let physical = self.read_payload_snapshot(spec, snapshot)?;
            *out = decode_record_payload(spec, self, physical)?;
        } else {
            self.read_payload_snapshot_into(spec, snapshot, out)?;
        }
        let actual =
            u64::try_from(out.len()).map_err(|_| Error::LengthOverflow { value: u64::MAX })?;
        if actual != logical_len {
            return Err(Error::DecompressedLengthMismatch {
                expected: logical_len,
                actual,
            });
        }
        Ok(())
    }

    /// Whether the writer marked this record dead.
    ///
    /// Always `false` for a format without `liveness: footer_flags`, where the
    /// word is a reserved field every reader requires to be zero.
    ///
    /// **Advisory.** The record is still here, still framed, and still read
    /// back by every collection; a defragmenting rewrite is what acts on this.
    /// Unknown bits in the word are ignored rather than refused — the word is
    /// outside the checksum, so there is nothing to tell a newer build's flag
    /// from a flipped bit, and refusing would turn a forward-compatible mark
    /// into an unreadable file.
    pub const fn is_dead(&self) -> bool {
        self.mutable_flags & RECORD_MUTABLE_FLAG_DEAD != 0
    }

    pub fn checked_physical_end(&self) -> Result<u64> {
        self.payload_offset
            .checked_add(self.payload_len)
            .and_then(|end| {
                end.checked_add(u64::from(self.footer_offset.is_some()) * RECORD_FOOTER_LEN)
            })
            .ok_or(Error::LengthOverflow {
                value: self.payload_len,
            })
    }

    pub fn physical_end(&self) -> u64 {
        self.payload_offset
            .saturating_add(self.payload_len)
            .saturating_add(u64::from(self.footer_offset.is_some()) * RECORD_FOOTER_LEN)
    }
}

impl From<&RecordIndexEntry> for AppendInfo {
    fn from(entry: &RecordIndexEntry) -> Self {
        Self {
            sequence: entry.sequence,
            record_offset: entry.record_offset,
            payload_offset: entry.payload_offset,
            payload_len: entry.payload_len,
            footer_offset: entry.footer_offset,
            prev_same_block_offset: entry.prev_same_block_offset,
            prev_same_key_offset: entry.prev_same_key_offset,
            committed: entry.committed,
        }
    }
}

#[derive(Clone, Debug)]
pub struct BlockEvent {
    pub block_id: u32,
    pub block_version: u16,
    pub sequence: u64,
    pub record_offset: u64,
    pub payload_offset: u64,
    pub payload_len: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AppendInfo {
    pub sequence: u64,
    pub record_offset: u64,
    pub payload_offset: u64,
    pub payload_len: u64,
    pub footer_offset: Option<u64>,
    pub prev_same_block_offset: Option<u64>,
    pub prev_same_key_offset: Option<u64>,
    pub committed: bool,
}

/// What a [`VarlitFile::defragment`] actually did.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct DefragmentReport {
    /// Records marked dead that the new generation does not contain.
    pub records_dropped: usize,
    pub bytes_before: u64,
    pub bytes_after: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ReplacementInfo {
    pub sequence: u64,
    pub record_offset: u64,
    pub old_payload_len: u64,
    pub new_payload_len: u64,
    pub old_physical_len: u64,
    pub new_physical_len: u64,
}

impl ReplacementInfo {
    pub fn translate_record_offset(&self, old: u64) -> Result<u64> {
        if old <= self.record_offset {
            return Ok(old);
        }
        if self.new_physical_len >= self.old_physical_len {
            old.checked_add(self.new_physical_len - self.old_physical_len)
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "replacement record offset",
                })
        } else {
            old.checked_sub(self.old_physical_len - self.new_physical_len)
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "replacement record offset",
                })
        }
    }
}

impl From<&RecordIndexEntry> for BlockEvent {
    fn from(entry: &RecordIndexEntry) -> Self {
        Self {
            block_id: entry.block_id,
            block_version: entry.block_version,
            sequence: entry.sequence,
            record_offset: entry.record_offset,
            payload_offset: entry.payload_offset,
            payload_len: entry.payload_len,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RecoveryReport {
    pub original_len: u64,
    pub recovered_len: u64,
    pub records_preserved: usize,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct WriterLockInfo {
    pub path: PathBuf,
    pub target_path: PathBuf,
    pub process_id: u32,
    pub created_unix_ms: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WriterLockBreakPolicy {
    Refuse,
    BreakIfProcessAbsent,
    BreakIfOlderThan(Duration),
    BreakIfProcessAbsentAndOlderThan(Duration),
}

/// What one user record actually stores, and where those bytes live.
///
/// `bytes` is a [`Cow`] rather than a `Vec` because the four uncompressed
/// routes through [`prepare_user_record_payload`] — no compression declared for
/// the block (the default), a non-`Variable` block kind, a payload under
/// `min_uncompressed_len`, and `only_if_smaller` losing — store the caller's
/// bytes unchanged. Owning them meant one payload-sized allocation, memcpy and
/// free on every append of every default configuration, for a buffer every
/// caller immediately reborrows as `&payload.bytes` and drops. Only the arm
/// that actually produces new bytes (compression, and the envelope around it)
/// owns them.
#[derive(Clone, Debug)]
struct StoredPayload<'a> {
    flags: u16,
    uncompressed_len_hint: u32,
    bytes: Cow<'a, [u8]>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum SequenceState {
    Available(u64),
    Exhausted,
}

impl SequenceState {
    fn available(self) -> Result<u64> {
        match self {
            Self::Available(sequence) => Ok(sequence),
            Self::Exhausted => Err(Error::SequenceExhausted),
        }
    }

    fn after_publishing(sequence: u64) -> Self {
        match sequence.checked_add(1) {
            Some(next) => Self::Available(next),
            None => Self::Exhausted,
        }
    }
}

/// O(1) writer-side state behind [`VarlitFile::needs_index_checkpoint`]
/// (PERF2-02).
///
/// The original predicate reverse-searched the resident index for the last
/// checkpoint and re-counted the suffix on every flush, which made the
/// cumulative flush CPU O(N^2) for flush-per-record workloads even after the
/// checkpoint *bytes* were made amortized O(N). This state mirrors exactly
/// what that scan recomputed and is maintained incrementally at the single
/// index append site, restored on append rollback, and recovered with one
/// bounded reverse walk wherever the resident index is loaded or replaced
/// wholesale (open, recovery, and generation rebinds).
///
/// Invariant: at all times this equals `CheckpointCadence::from_index(&index)`
/// for the current resident index.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct CheckpointCadence {
    /// Entries appended since the last full checkpoint whose presence would
    /// change the serialized checkpoint (everything but commit markers).
    eligible_since_checkpoint: usize,
    /// Geometric growth threshold derived from the last checkpoint's index
    /// position: `max(INDEX_CHECKPOINT_MIN_RECORDS, records_at_last_checkpoint / 2)`.
    next_threshold: usize,
}

impl CheckpointCadence {
    /// Cadence for a freshly created file with an empty resident index.
    fn new_empty() -> Self {
        Self {
            eligible_since_checkpoint: 0,
            next_threshold: INDEX_CHECKPOINT_MIN_RECORDS,
        }
    }

    /// Recovers the cadence with a single reverse walk that stops at the last
    /// checkpoint record, so reopen pays the live-tail length exactly once
    /// instead of every flush paying it again.
    /// The rule, kept as the specification `derive_index_state` must match.
    ///
    /// No longer called in production — one forward pass now derives this and
    /// the two structures beside it — but it is what the invariant above names,
    /// and `derived_state_matches_the_three_rules_it_replaced` compares the two
    /// on every shape that distinguishes them.
    #[cfg(test)]
    fn from_index(index: &[RecordIndexEntry]) -> Self {
        let mut eligible: usize = 0;
        let mut touched: u64 = 0;
        for (position, entry) in index.iter().enumerate().rev() {
            touched = touched.saturating_add(1);
            if entry.block_id == INDEX_BLOCK_ID {
                note_checkpoint_cadence_index_touches(touched);
                return Self {
                    eligible_since_checkpoint: eligible,
                    next_threshold: core::cmp::max(INDEX_CHECKPOINT_MIN_RECORDS, position / 2),
                };
            }
            if !matches!(entry.block_id, COMMIT_BLOCK_ID | SEGMENT_BLOCK_ID) {
                eligible = eligible.saturating_add(1);
            }
        }
        note_checkpoint_cadence_index_touches(touched);
        Self {
            eligible_since_checkpoint: eligible,
            next_threshold: INDEX_CHECKPOINT_MIN_RECORDS,
        }
    }

    /// Advances the cadence for the entry just pushed at `position` in the
    /// resident index. A checkpoint record resets the tail count and derives
    /// the next geometric threshold from its own position (the number of
    /// entries it serialized); commit markers, segment records and open digests
    /// never alter checkpoint identity; every other record grows the eligible
    /// tail by one.
    ///
    /// The digest belongs in that exemption for the reason the other two do: it
    /// is written *because* a commit point closed, not because a record was
    /// added, so counting it would make the checkpoint cadence a function of how
    /// often the file is flushed rather than of how much was written.
    fn note_appended(&mut self, position: usize, block_id: u32) {
        note_checkpoint_cadence_index_touches(1);
        if block_id == INDEX_BLOCK_ID {
            self.eligible_since_checkpoint = 0;
            self.next_threshold = core::cmp::max(INDEX_CHECKPOINT_MIN_RECORDS, position / 2);
        } else if !matches!(
            block_id,
            COMMIT_BLOCK_ID | SEGMENT_BLOCK_ID | OPEN_DIGEST_BLOCK_ID
        ) {
            self.eligible_since_checkpoint = self.eligible_since_checkpoint.saturating_add(1);
        }
    }
}

#[cfg(feature = "scalable-fault-injection")]
std::thread_local! {
    static CHECKPOINT_CADENCE_INDEX_TOUCHES: std::cell::Cell<u64> = const {
        std::cell::Cell::new(0)
    };
}

/// Counts resident index entries examined by the checkpoint flush-cadence
/// machinery on this thread (PERF2-02 regression evidence). Inert without the
/// `scalable-fault-injection` feature.
#[inline]
fn note_checkpoint_cadence_index_touches(count: u64) {
    #[cfg(feature = "scalable-fault-injection")]
    CHECKPOINT_CADENCE_INDEX_TOUCHES
        .with(|touches| touches.set(touches.get().saturating_add(count)));
    #[cfg(not(feature = "scalable-fault-injection"))]
    let _ = count;
}

/// The payload one written chunk occupies, given the declared dimensions.
///
/// Computed at create so the two ceilings a chunk crosses — the buffer it is
/// held in and the record it is written as — are reconciled before any write is
/// accepted rather than at the first write.
fn chunk_payload_len_for(spec: FormatSpec, dims: &MatrixDimensions) -> Result<u64> {
    let Some(growing) = spec.growing_matrix else {
        return Ok(0);
    };
    let cell_crc = !matches!(spec.integrity_policy, IntegrityPolicy::None);
    let mut len = MATRIX_CHUNK_PREFIX_LEN
        .checked_add(
            MATRIX_CHUNK_BLOCK_DESC_LEN
                .checked_mul(spec.matrix_blocks.len() as u64)
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk descriptors",
                })?,
        )
        .ok_or(Error::ResourceArithmeticOverflow {
            resource: "matrix chunk prefix",
        })?;
    for block in spec.matrix_blocks {
        let width = dims
            .get(block.dimensions[1])
            .ok_or_else(|| Error::MatrixDimensionMissing(block.dimensions[1].to_string()))?;
        let cells =
            growing
                .rows_per_chunk
                .checked_mul(width)
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk cells",
                })?;
        let slots =
            cells
                .checked_mul(block.slot_stride)
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk slot region",
                })?;
        let crc = if cell_crc {
            cells
                .checked_mul(MATRIX_CHUNK_CRC_LEN)
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk checksum table",
                })?
        } else {
            0
        };
        // The uncompressed size plus the sub-block index. Compression can only
        // make the written record smaller, so bounding the uncompressed form is
        // the conservative check — a spec must not depend on its data
        // compressing in order to fit.
        let index = if spec.chunk_compression.is_some() {
            sub_block_count(cells, compressed_cell_width(block.slot_stride, cell_crc))
                .checked_add(1)
                .and_then(|entries| entries.checked_mul(MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN))
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk sub-block index",
                })?
        } else {
            0
        };
        len = len
            .checked_add(cells.div_ceil(8))
            .and_then(|len| len.checked_add(crc))
            .and_then(|len| len.checked_add(index))
            .and_then(|len| len.checked_add(slots))
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "matrix chunk payload length",
            })?;
    }
    Ok(len)
}

/// Writes one block's slot region as a sub-block index plus compressed
/// sub-blocks.
///
/// The index is `sub_block_count + 1` little-endian `u32` offsets relative to
/// the end of the index, so a sub-block's extent is `off[i]..off[i + 1]` — two
/// four-byte reads and no prefix sum.
///
/// **A sub-block is stored raw when compressing it does not shrink it**, and
/// the reader tells the two apart by length alone: stored length equal to the
/// uncompressed length means raw. The writer therefore never emits a compressed
/// sub-block of exactly that length, which costs nothing — such a sub-block is
/// stored raw instead, byte for byte the same thing.
fn encode_compressed_slots(
    payload: &mut Vec<u8>,
    block: &OpenChunkBlock,
    compression: VariableCompression,
) -> Result<()> {
    let cell_crc = !block.crc.is_empty();
    let width = compressed_cell_width(block.stride, cell_crc);
    let per = cells_per_sub_block(width);
    let count = sub_block_count(block.cells, width);
    let count_usize = usize::try_from(count).map_err(|_| Error::InvalidMatrixChunk)?;
    let stride = usize::try_from(block.stride).map_err(|_| Error::InvalidMatrixChunk)?;
    let width_usize = usize::try_from(width).map_err(|_| Error::InvalidMatrixChunk)?;
    let per_usize = usize::try_from(per).map_err(|_| Error::InvalidMatrixChunk)?;
    let cells = usize::try_from(block.cells).map_err(|_| Error::InvalidMatrixChunk)?;

    let mut stored: Vec<Vec<u8>> = Vec::new();
    stored
        .try_reserve_exact(count_usize)
        .map_err(|_| Error::AllocationFailed {
            resource: "matrix chunk sub-blocks",
            requested: count,
        })?;
    let mut packed = Vec::new();
    for index in 0..count_usize {
        let first = index * per_usize;
        let last = ((index + 1) * per_usize).min(cells);
        packed.clear();
        packed
            .try_reserve((last.saturating_sub(first)) * width_usize)
            .map_err(|_| Error::AllocationFailed {
                resource: "matrix chunk sub-block",
                requested: width,
            })?;
        for cell in first..last {
            packed.extend_from_slice(&block.slots[cell * stride..(cell + 1) * stride]);
            if cell_crc {
                packed.extend_from_slice(&block.crc[cell * 4..(cell + 1) * 4]);
            }
        }
        let compressed =
            compress_with_algorithm(compression.algorithm, compression.level, &packed)?;
        if compressed.len() >= packed.len() {
            stored.push(packed.try_clone()?);
        } else {
            stored.push(compressed);
        }
    }

    let mut offset = 0u32;
    for bytes in &stored {
        payload.extend_from_slice(&offset.to_le_bytes());
        offset = offset
            .checked_add(u32::try_from(bytes.len()).map_err(|_| Error::InvalidMatrixChunk)?)
            .ok_or(Error::InvalidMatrixChunk)?;
    }
    payload.extend_from_slice(&offset.to_le_bytes());
    for bytes in &stored {
        payload.extend_from_slice(bytes);
    }
    Ok(())
}

/// Bytes a compressed sub-block holds per cell.
///
/// **The checksum travels with its cell.** Compressing only the slot region
/// left the per-cell checksum table — four bytes per cell, all zeros for every
/// never-written cell — as the dominant term: measured 1,606,396 B plain
/// against 1,083,604 B with slots-only compression, a 33% saving where the
/// slots alone are half the file. Packing each cell beside its checksum makes
/// one decode yield both and lets the zeros collapse together.
const fn compressed_cell_width(stride: u64, cell_crc: bool) -> u64 {
    if cell_crc {
        stride + MATRIX_CHUNK_CRC_LEN
    } else {
        stride
    }
}

/// Cells one compressed sub-block covers, for a given packed cell width.
///
/// Derived from the width alone so the writer and the reader cannot disagree
/// about where a cell lives.
const fn cells_per_sub_block(stride: u64) -> u64 {
    if stride == 0 || stride >= MATRIX_CHUNK_SUB_BLOCK_BYTES {
        1
    } else {
        MATRIX_CHUNK_SUB_BLOCK_BYTES / stride
    }
}

/// Sub-blocks a block's slot region is cut into.
fn sub_block_count(cells: u64, stride: u64) -> u64 {
    cells.div_ceil(cells_per_sub_block(stride)).max(1)
}

/// A zeroed buffer of `len` bytes, allocated fallibly.
///
/// A chunk's buffers are sized by a declared knob, so an over-large
/// `rows_per_chunk` must report `AllocationFailed` rather than abort.
fn try_zeroed_vec(len: u64, resource: &'static str) -> Result<Vec<u8>> {
    let capacity = usize::try_from(len).map_err(|_| Error::LengthOverflow { value: len })?;
    let mut buffer = Vec::new();
    buffer
        .try_reserve_exact(capacity)
        .map_err(|_| Error::AllocationFailed {
            resource,
            requested: len,
        })?;
    buffer.resize(capacity, 0);
    Ok(buffer)
}

/// Rebuilds a reloaded chunk block's write bitmap from what the record does
/// carry.
///
/// A cell counts as written if it is committed — a commit cannot have happened
/// without one — or if its slot bytes are not all zero. That second clause is
/// the region's own test (`matrix::commit_cell` scans the slot when its
/// session bitmap says nothing), so a reloaded chunk and a region row answer
/// "was this written" identically.
fn seed_written_map(commit: &[u8], slots: &[u8], cells: u64, stride: u64) -> Result<Vec<u8>> {
    let len = u64::try_from(commit.len()).map_err(|_| Error::ResourceArithmeticOverflow {
        resource: "matrix chunk write map",
    })?;
    let mut written = try_zeroed_vec(len, "matrix chunk write map")?;
    let stride = usize::try_from(stride).map_err(|_| Error::InvalidMatrixLayout)?;
    for ordinal in 0..cells {
        let byte = usize::try_from(ordinal / 8).map_err(|_| Error::InvalidMatrixLayout)?;
        let bit = 1u8 << (ordinal % 8);
        if commit
            .get(byte)
            .is_some_and(|committed| committed & bit != 0)
        {
            written[byte] |= bit;
            continue;
        }
        let start = usize::try_from(ordinal)
            .ok()
            .and_then(|ordinal| ordinal.checked_mul(stride))
            .ok_or(Error::InvalidMatrixLayout)?;
        let slot = slots
            .get(
                start
                    ..start
                        .checked_add(stride)
                        .ok_or(Error::InvalidMatrixLayout)?,
            )
            .ok_or(Error::InvalidMatrixChunk)?;
        if slot.iter().any(|byte| *byte != 0) {
            written[byte] |= bit;
        }
    }
    Ok(written)
}

/// One matrix block's slice of the chunk being filled.
#[derive(Debug)]
struct OpenChunkBlock {
    block_id: u32,
    stride: u64,
    /// `rows * dimension 1`, the cells this chunk holds for this block.
    cells: u64,
    /// One bit per cell: written this session, whatever the bytes say.
    ///
    /// The region keeps the same thing (`current_write_bits`) for the same
    /// reason. Without it, `commit_matrix_cell` decided "was this written" by
    /// testing whether the slot read as all zeros, so a legitimate value that
    /// encodes to zeros — `0u32`, an empty flag word, a zeroed struct — could
    /// never be committed in a chunk while committing fine in the region.
    /// Not written to disk: the commit map is what a reader consults.
    written: Vec<u8>,
    /// One bit per cell, the chunk-local form of the region's commit map.
    commit: Vec<u8>,
    /// `crc32` of each cell's slot bytes, or empty when the format declares no
    /// integrity policy. The chunk-local form of the region's checksum table.
    crc: Vec<u8>,
    /// `cells * stride` bytes, addressed exactly as the region's slot region is.
    slots: Vec<u8>,
}

/// A chunk record's prefix, decoded.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct ChunkPrefix {
    index: u64,
    first_row: u64,
    rows: u64,
    block_count: u32,
    cell_crc: bool,
    compressed_slots: bool,
}

/// One written chunk, located.
///
/// `block_count` is carried so a cell lookup does not re-read the prefix that
/// finding the chunk already read.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct ChunkLocator {
    index: u64,
    record_offset: u64,
    payload_len: u64,
    block_count: u32,
    cell_crc: bool,
    compressed_slots: bool,
    /// This record's position among the chunk records, counted in the order the
    /// resident index holds them — which is file order, not chunk-index order.
    ///
    /// It is what addresses the record for a rewrite, and it is stored rather
    /// than derived because the two orders are no longer the same: a chunk that
    /// was skipped and is written later sits at the end of the file with a
    /// lower index than its neighbours, and the directory is sorted by index.
    ordinal: usize,
}

/// Every written chunk, by chunk index, ordered once.
///
/// **This exists because the first version did not have it, and that is the
/// mistake this project keeps making.** `find_chunk_record` filtered the whole
/// resident index and collected it into a fresh `Vec` on *every chunked cell
/// read* — `O(total records)` plus a heap allocation per read, behind a doc
/// comment that claimed `O(log chunks)` and "no state built at open". It is the
/// same shape [`CheckpointCadence`] (PERF2-02), [`BlockTails`] (PERF2-05) and
/// [`SegmentCursor`] each exist to remove, in a file where all three are
/// already written down.
///
/// Built at most once per handle, on the first chunked access rather than at
/// open, and extended in place when the writer writes one. Lookup is a binary search
/// over memory: no walk, no allocation, no read.
///
/// Invariant: equals the `MATRIX_CHUNK_BLOCK_ID` entries of the resident index,
/// in index order, at all times.
#[derive(Debug, Default)]
struct ChunkDirectory {
    chunks: Vec<ChunkLocator>,
    next_ordinal: usize,
}

impl ChunkDirectory {
    fn find(&self, index: u64) -> Option<ChunkLocator> {
        self.chunks
            .binary_search_by_key(&index, |locator| locator.index)
            .ok()
            .map(|position| self.chunks[position])
    }

    /// Files a chunk record that was just appended.
    ///
    /// Inserted at its index position rather than pushed, because a chunk is no
    /// longer always written in ascending order: a chunk that committed nothing
    /// is never written, and a later write to one of its rows appends its
    /// record after higher-indexed ones. Ascending is still the common case and
    /// costs an insert at the end.
    ///
    /// Returns the number of chunk records now filed, which is the ordinal the
    /// *next* appended one will carry.
    fn note_written(&mut self, locator: ChunkLocator) {
        let position = self
            .chunks
            .partition_point(|filed| filed.index < locator.index);
        self.next_ordinal = self.next_ordinal.max(locator.ordinal.saturating_add(1));
        if self
            .chunks
            .get(position)
            .is_some_and(|old| old.index == locator.index)
        {
            self.chunks[position] = locator;
        } else {
            self.chunks.insert(position, locator);
        }
    }

    /// The ordinal an appended chunk record would carry: one past the last,
    /// because a record is appended at the end of the file and the ordinals
    /// count file order.
    fn next_ordinal(&self) -> usize {
        self.next_ordinal
    }
}

/// The chunk a growing matrix is currently filling.
///
/// Held in memory until it is written, which is the one cost this design has and the
/// reason `rows_per_chunk` is a declared knob rather than a constant. Sealing
/// writes it as one ordinary record, so nothing else in the file format learns
/// that chunks exist.
///
/// One chunk is open at a time, and which one is not fixed: writing a row that
/// belongs to an already-written chunk writes the open one out and loads that
/// chunk back — see `VarlitFile::reopen_written_chunk`.
#[derive(Debug)]
struct OpenChunk {
    index: u64,
    first_row: u64,
    rows: u64,
    /// How the slot regions are stored when this chunk is written.
    compression: Option<VariableCompression>,
    blocks: Vec<OpenChunkBlock>,
    /// Whether any cell has been committed since the chunk was opened. A chunk
    /// nothing committed is not written: an empty chunk and an absent chunk
    /// answer every read identically, and writing one would grow the file on
    /// every idle flush the way an empty segment once did.
    dirty: bool,
    /// The chunk-record ordinal this chunk was loaded from, when it was loaded
    /// rather than started empty.
    ///
    /// `Some` means a record for this chunk index already exists and holds
    /// these same bytes, so writing the chunk out must rewrite *that* record
    /// rather than append a second one. Two records claiming one chunk index is
    /// not a thing the directory can order, and `build_chunk_directory` refuses
    /// a file that carries them.
    ///
    /// An ordinal rather than an offset because that is what
    /// `ReplacementTarget` selects on: the nth record of `MATRIX_CHUNK_BLOCK_ID`
    /// is the nth entry of the chunk directory, which is built by walking the
    /// resident index in the same order.
    backing: Option<usize>,
}

impl OpenChunk {
    fn block_position(&self, block_id: u32) -> Option<usize> {
        self.blocks
            .iter()
            .position(|block| block.block_id == block_id)
    }

    fn payload_len(&self) -> Result<u64> {
        let mut len = MATRIX_CHUNK_PREFIX_LEN
            .checked_add(
                MATRIX_CHUNK_BLOCK_DESC_LEN
                    .checked_mul(u64::try_from(self.blocks.len()).map_err(|_| {
                        Error::ResourceArithmeticOverflow {
                            resource: "matrix chunk block count",
                        }
                    })?)
                    .ok_or(Error::ResourceArithmeticOverflow {
                        resource: "matrix chunk descriptors",
                    })?,
            )
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "matrix chunk prefix",
            })?;
        for block in &self.blocks {
            let commit = u64::try_from(block.commit.len()).map_err(|_| {
                Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk commit map",
                }
            })?;
            let slots = u64::try_from(block.slots.len()).map_err(|_| {
                Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk slot region",
                }
            })?;
            let crc =
                u64::try_from(block.crc.len()).map_err(|_| Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk checksum table",
                })?;
            let index = if self.compression.is_some() {
                sub_block_count(
                    block.cells,
                    compressed_cell_width(block.stride, !block.crc.is_empty()),
                )
                .checked_add(1)
                .and_then(|entries| entries.checked_mul(MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN))
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk sub-block index",
                })?
            } else {
                0
            };
            len = len
                .checked_add(commit)
                .and_then(|len| len.checked_add(crc))
                .and_then(|len| len.checked_add(index))
                .and_then(|len| len.checked_add(slots))
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk payload length",
                })?;
        }
        Ok(len)
    }

    fn encode(&self) -> Result<Vec<u8>> {
        // The uncompressed size, which is exact when plain and an upper bound
        // when compressing. Reserving the bound is the point: a compressed
        // chunk must never need more than the ceiling `create` checked.
        let payload_len = self.payload_len()?;
        let capacity = usize::try_from(payload_len)
            .map_err(|_| Error::LengthOverflow { value: payload_len })?;
        let mut payload = Vec::new();
        payload
            .try_reserve_exact(capacity)
            .map_err(|_| Error::AllocationFailed {
                resource: "matrix chunk payload",
                requested: payload_len,
            })?;
        let block_count =
            u32::try_from(self.blocks.len()).map_err(|_| Error::ResourceArithmeticOverflow {
                resource: "matrix chunk block count",
            })?;
        let mut flags = if self.blocks.iter().any(|block| !block.crc.is_empty()) {
            MATRIX_CHUNK_FLAG_CELL_CRC
        } else {
            0
        };
        if self.compression.is_some() {
            flags |= MATRIX_CHUNK_FLAG_COMPRESSED_SLOTS;
        }
        payload.extend_from_slice(MATRIX_CHUNK_MAGIC);
        payload.extend_from_slice(&MATRIX_CHUNK_VERSION.to_le_bytes());
        payload.extend_from_slice(&flags.to_le_bytes());
        payload.extend_from_slice(&self.index.to_le_bytes());
        payload.extend_from_slice(&self.first_row.to_le_bytes());
        payload.extend_from_slice(&self.rows.to_le_bytes());
        payload.extend_from_slice(&block_count.to_le_bytes());
        payload.extend_from_slice(&0u32.to_le_bytes());
        for block in &self.blocks {
            let commit_len = u64::try_from(block.commit.len()).map_err(|_| {
                Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk commit map",
                }
            })?;
            payload.extend_from_slice(&block.block_id.to_le_bytes());
            payload.extend_from_slice(&0u32.to_le_bytes());
            payload.extend_from_slice(&block.stride.to_le_bytes());
            payload.extend_from_slice(&block.cells.to_le_bytes());
            payload.extend_from_slice(&commit_len.to_le_bytes());
        }
        for block in &self.blocks {
            payload.extend_from_slice(&block.commit);
            match self.compression {
                Some(compression) => {
                    // No separate checksum table: each cell is packed beside
                    // its own, inside the sub-block.
                    encode_compressed_slots(&mut payload, block, compression)?;
                }
                None => {
                    payload.extend_from_slice(&block.crc);
                    payload.extend_from_slice(&block.slots);
                }
            }
        }
        Ok(payload)
    }
}

/// Where one block's bytes sit inside a chunk record's payload.
///
/// Produced by reading the prefix and the descriptors — a fixed, small read
/// whatever the chunk holds — so a cell read is that read plus one `stride`-byte
/// positional read, and never the chunk.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct ChunkBlockLocation {
    commit_offset: u64,
    /// `None` when the chunk carries no per-cell checksums.
    crc_offset: Option<u64>,
    slots_offset: u64,
    /// One past the last byte of this block's slot region, so a compressed
    /// sub-block's extent is bounded without consulting the record again.
    slots_end: u64,
    compressed_slots: bool,
    /// Whether cells carry a checksum at all, which a compressed block needs
    /// even though it has no separate table.
    cell_crc: bool,
    stride: u64,
    cells: u64,
}

/// O(1) writer-side state for the internal segment chain.
///
/// A segment covers the records one commit point added, so writing one needs
/// two things: where in the resident index that run begins, and where it begins
/// on disk. Both are derivable by walking back to the newest segment record,
/// and neither is derived that way — the walk would be `Theta(g)` per commit
/// point and `Theta(N)` on a file that has records but no segment record yet,
/// which is the same shape PERF2-02 and PERF2-05 removed from the flush and
/// append paths.
///
/// Invariant: at all times this equals `SegmentCursor::from_index(&index)` for
/// the current resident index.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct SegmentCursor {
    /// Resident-index position just past the newest segment record: the first
    /// entry the next segment covers.
    next_position: usize,
    /// File offset just past the newest segment record, or `None` when the file
    /// holds no segment record and coverage therefore starts at the append log.
    covered_start: Option<u64>,
}

impl SegmentCursor {
    fn new_empty() -> Self {
        Self {
            next_position: 0,
            covered_start: None,
        }
    }

    /// Recovers the cursor with one reverse walk that stops at the newest
    /// segment record, so a reopen or a generation rebind pays the live tail
    /// once instead of every commit point paying it again.
    ///
    /// `physical_end` saturates rather than overflowing. The entries here come
    /// from a completed scan or a validated generation, so it cannot saturate
    /// in practice; if it ever did, the next segment would record a coverage
    /// start the following open cannot match, and that open falls back to the
    /// full scan rather than trusting the chain.
    /// The rule, kept as the specification `derive_index_state` must match.
    #[cfg(test)]
    fn from_index(entries: &[RecordIndexEntry]) -> Self {
        match entries
            .iter()
            .rposition(|entry| entry.block_id == SEGMENT_BLOCK_ID)
        {
            Some(position) => Self {
                next_position: position + 1,
                covered_start: Some(entries[position].physical_end()),
            },
            None => Self::new_empty(),
        }
    }

    /// Advances the cursor for the entry just pushed at `position`.
    ///
    /// `record_end` is the physical end the append path budgeted and checked
    /// before writing, so this stays infallible on the far side of the
    /// authoritative write (INVARIANT 3).
    fn note_appended(&mut self, position: usize, block_id: u32, record_end: u64) {
        if block_id == SEGMENT_BLOCK_ID {
            self.next_position = position + 1;
            self.covered_start = Some(record_end);
        }
    }
}

/// O(1)-append / O(log B) resident block-offset tails (PERF2-05).
///
/// The append path used to reverse-scan the resident index for the newest
/// record of the same block, costing `Theta(g)` per append (`g` = distance
/// back to that record) and `O(N*B)` overall, degenerating to `Theta(N^2)`
/// when every record carries a distinct block id. This mirrors exactly what
/// that scan recomputed - the record offset of the newest entry per block id -
/// and never reads the resident index on the append path.
///
/// `B` is the number of distinct block ids present, which is bounded by the
/// format's declared block set plus varlit's internal ids, so the sorted vector
/// stays tiny and stops allocating once every block id has appeared.
///
/// Invariant: at all times this equals `BlockTails::from_index(&index)` for
/// the current resident index. It is maintained at the single index append
/// site and rebuilt wherever the resident index is replaced or truncated
/// wholesale (open, recovery, generation rebinds, append rollback).
#[derive(Clone, Debug, Default, PartialEq, Eq)]
struct BlockTails {
    /// Sorted by block id.
    tails: Vec<(u32, u64)>,
}

impl BlockTails {
    fn new_empty() -> Self {
        Self { tails: Vec::new() }
    }

    /// Recovers the tails with one forward pass over the resident index, so a
    /// reopen pays the pass exactly once instead of every append paying its own
    /// reverse scan.
    ///
    /// The pass keeps the newest offset per block id in a hash map and orders
    /// the distinct ids exactly once, so construction is `O(N + B log B)` time
    /// and `O(B)` memory. Replaying the pass through [`Self::note_appended`]
    /// instead - which is what this did originally - inserts every first-seen
    /// id into the sorted vector, and an index whose first appearances are in
    /// descending id order moves `0 + 1 + ... + (B - 1)` tuples. That made the
    /// real bound `O(N log B + B^2)`, not the `O(N log B)` the comment here
    /// used to claim (PERF3-03). The append path keeps the sorted-vector
    /// insertion: it pays at most one insertion per distinct id over the whole
    /// life of the file and buys `O(log B)` lookups with no hashing on the hot
    /// path.
    /// The rule, kept as the specification `derive_index_state` must match.
    #[cfg(test)]
    fn from_index(index: &[RecordIndexEntry]) -> Self {
        note_block_tail_index_touches(index.len() as u64);
        let mut newest: HashMap<u32, u64> = HashMap::new();
        for entry in index {
            newest.insert(entry.block_id, entry.record_offset);
        }
        Self::from_newest(&newest).expect("test tail allocation")
    }

    /// Orders an already-collected newest-per-block map.
    ///
    /// The scan collects into a map rather than replaying `note_appended`, for
    /// the reason `from_index` does: replaying inserts every first-seen id into
    /// the sorted vector, and an index whose first appearances are in descending
    /// id order moves `0 + 1 + ... + (B - 1)` tuples (PERF3-03).
    /// Adopts a table a digest already ordered.
    ///
    /// `decode_digest_payload` rejects a non-ascending id, so this cannot adopt
    /// an out-of-order table — which matters, because every lookup here is a
    /// binary search and an unsorted table would answer wrong rather than
    /// slowly.
    fn from_sorted(tails: Vec<(u32, u64)>) -> Self {
        debug_assert!(tails.windows(2).all(|pair| pair[0].0 < pair[1].0));
        Self { tails }
    }

    fn from_newest(newest: &HashMap<u32, u64>) -> Result<Self> {
        let mut tails = Vec::new();
        tails
            .try_reserve_exact(newest.len())
            .map_err(|_| Error::AllocationFailed {
                resource: "block tails",
                requested: (newest.len() as u64).saturating_mul(16),
            })?;
        tails.extend(newest.iter().map(|(id, offset)| (*id, *offset)));
        tails.sort_unstable_by_key(|(block_id, _)| *block_id);
        Ok(Self { tails })
    }

    fn tail(&self, block_id: u32) -> Option<u64> {
        self.position(block_id)
            .map(|position| self.tails[position].1)
    }

    /// The table itself, sorted by block id, for the digest encoder.
    fn as_slice(&self) -> &[(u32, u64)] {
        &self.tails
    }

    fn position(&self, block_id: u32) -> Option<usize> {
        self.tails
            .binary_search_by_key(&block_id, |(id, _)| *id)
            .ok()
    }

    /// Puts a block's tail back where it was before an append that rolled
    /// back. `None` means the block had no record yet, so the entry is removed.
    fn restore(&mut self, block_id: u32, previous: Option<u64>) {
        match (self.position(block_id), previous) {
            (Some(position), Some(offset)) => self.tails[position].1 = offset,
            (Some(position), None) => {
                self.tails.remove(position);
            }
            (None, _) => {}
        }
    }

    /// Advances the tail for the entry just pushed. Updating a block id the
    /// table already holds writes one `u64` and allocates nothing; a block id
    /// is inserted at most once per distinct id in the file.
    fn note_appended(&mut self, block_id: u32, record_offset: u64) {
        match self.tails.binary_search_by_key(&block_id, |(id, _)| *id) {
            Ok(position) => self.tails[position].1 = record_offset,
            Err(position) => {
                // Every insertion shifts the tuples above it; counting them is
                // what makes the historical quadratic construction term
                // observable to a regression test (PERF3-03).
                note_block_tail_entries_moved((self.tails.len() - position) as u64);
                self.tails.insert(position, (block_id, record_offset));
            }
        }
    }
}

#[cfg(feature = "scalable-fault-injection")]
std::thread_local! {
    static BLOCK_TAIL_INDEX_TOUCHES: std::cell::Cell<u64> = const {
        std::cell::Cell::new(0)
    };
}

/// Counts resident index entries examined by the block-offset-chain
/// predecessor machinery on this thread (PERF2-05 regression evidence). The
/// append path must never advance this counter. Inert without the
/// `scalable-fault-injection` feature.
#[inline]
fn note_block_tail_index_touches(count: u64) {
    #[cfg(feature = "scalable-fault-injection")]
    BLOCK_TAIL_INDEX_TOUCHES.with(|touches| touches.set(touches.get().saturating_add(count)));
    #[cfg(not(feature = "scalable-fault-injection"))]
    let _ = count;
}

#[cfg(feature = "scalable-fault-injection")]
std::thread_local! {
    static BLOCK_TAIL_ENTRIES_MOVED: std::cell::Cell<u64> = const {
        std::cell::Cell::new(0)
    };
}

/// Counts tuples displaced by sorted-vector insertion in the block-tail table
/// on this thread (PERF3-03 regression evidence). Index *visits* cannot see
/// this cost, which is why the quadratic construction term survived the
/// previous review. Inert without the `scalable-fault-injection` feature.
#[inline]
fn note_block_tail_entries_moved(count: u64) {
    #[cfg(feature = "scalable-fault-injection")]
    BLOCK_TAIL_ENTRIES_MOVED.with(|moved| moved.set(moved.get().saturating_add(count)));
    #[cfg(not(feature = "scalable-fault-injection"))]
    let _ = count;
}

/// Lazily built resident keyed tails for the generic keyed append path
/// (API2-05).
///
/// One tail map per keyed block id. The resident file is not generic over its
/// block types, so keys are held as their canonical internal key payload -
/// the same encoding tombstone records carry - rather than as `T::Key`. A map
/// is built on first use from [`VarlitFile::key_tail_offsets`] and then
/// maintained in O(1) per append, so the generic keyed entry points link
/// predecessors exactly like the generated keyed writer does. Any
/// caller-supplied predecessor (the generated writer's own path) invalidates
/// the cached map for that block id, because the file cannot learn which key
/// that record carried.
#[derive(Debug, Default)]
struct KeyedTails {
    tails: HashMap<u32, KeyedTailMap>,
}

/// One block id's tail map plus the running total of the key payload bytes it
/// owns (API3-02).
///
/// The total is maintained incrementally - one addition on the append that
/// introduces a key, nothing at all when an existing key is overwritten - so
/// charging the cache against [`ReadLimits::max_keyed_tail_bytes`] stays O(1)
/// per append. Recomputing it by summing key lengths would be Theta(distinct
/// keys) on the append hot path and is exactly what this field exists to
/// avoid.
#[derive(Debug, Default)]
struct KeyedTailMap {
    offsets: HashMap<Vec<u8>, u64>,
    key_payload_bytes: u64,
    spilled: Option<crate::disk_index::ScratchIndex>,
}

impl KeyedTailMap {
    fn get(&self, key: &[u8]) -> Result<Option<u64>> {
        if let Some(&offset) = self.offsets.get(key) {
            return Ok(Some(offset));
        }
        match &self.spilled {
            Some(index) => Ok(index
                .get(key)?
                .map(|row| u64::from_le_bytes(row[..8].try_into().unwrap()))),
            None => Ok(None),
        }
    }
    fn spill(&mut self) -> Result<()> {
        if self.offsets.is_empty() {
            return Ok(());
        }
        if self.spilled.is_none() {
            self.spilled = Some(crate::disk_index::ScratchIndex::new(0)?);
        }
        let updates = self
            .offsets
            .iter()
            .map(|(key, &offset)| {
                let mut row = [0; 52];
                row[..8].copy_from_slice(&offset.to_le_bytes());
                Ok((key.try_clone()?, row))
            })
            .collect::<Result<_>>()?;
        self.spilled.as_mut().unwrap().apply(&updates)?;
        self.offsets.clear();
        self.key_payload_bytes = 0;
        Ok(())
    }
    fn reserve(&mut self, spec: FormatSpec, key: &[u8]) -> Result<()> {
        let limit = spec
            .read_limits
            .require(ReadLimitKey::KeyedTailBytes)?
            .unwrap_or(2 * 1024 * 1024)
            .min(2 * 1024 * 1024);
        if !self.offsets.contains_key(key) && self.charge_for(1, key.len() as u64)? > limit {
            self.spill()?;
        }
        // One bounded key is the minimum work unit even with a zero cache.
        self.offsets
            .try_reserve(1)
            .map_err(|_| Error::AllocationFailed {
                resource: "keyed tail offsets",
                requested: key.len() as u64,
            })?;
        Ok(())
    }
    fn insert(&mut self, key: Vec<u8>, offset: u64) {
        let bytes = key.len() as u64;
        if self.offsets.insert(key, offset).is_none() {
            self.key_payload_bytes += bytes;
        }
    }
    /// Bytes this map is accountable for: its inline storage plus the key
    /// payload heap it owns. Excludes `HashMap` control bytes and load-factor
    /// slack, which the charge deliberately does not claim to cover.
    fn charge_for(&self, additional_entries: usize, additional_key_bytes: u64) -> Result<u64> {
        let inline = allocation_bytes::<(Vec<u8>, u64)>(
            self.offsets.len().saturating_add(additional_entries),
            "keyed tail offsets",
        )?;
        inline
            .checked_add(self.key_payload_bytes)
            .and_then(|total| total.checked_add(additional_key_bytes))
            .ok_or(Error::AllocationFailed {
                resource: "keyed tail offsets",
                requested: u64::MAX,
            })
    }
}

impl KeyedTails {
    fn new_empty() -> Self {
        Self {
            tails: HashMap::new(),
        }
    }

    fn invalidate(&mut self, block_id: u32) {
        self.tails.remove(&block_id);
    }

    fn invalidate_all(&mut self) {
        self.tails.clear();
    }
}

#[cfg(feature = "scalable-fault-injection")]
std::thread_local! {
    /// Armed pre-append keyed-tail reservation failures (API3-01).
    static INJECTED_KEYED_TAIL_RESERVATION_FAILURES: std::cell::Cell<u64> = const {
        std::cell::Cell::new(0)
    };
    /// Armed post-append keyed-tail reservation losses (API3-01).
    static INJECTED_KEYED_TAIL_COMMIT_LOSSES: std::cell::Cell<u64> = const {
        std::cell::Cell::new(0)
    };
    /// Armed post-commit-marker durability failures (round 10, invariant 3).
    static INJECTED_COMMIT_DURABILITY_FAILURES: std::cell::Cell<u64> = const {
        std::cell::Cell::new(0)
    };
}

/// Consumes one armed keyed-tail reservation failure (API3-01).
///
/// Inert without the `scalable-fault-injection` feature. Thread-local so
/// concurrently running tests cannot arm each other's writers.
#[inline]
fn take_injected_keyed_tail_reservation_failure(requested: u64) -> Result<()> {
    #[cfg(feature = "scalable-fault-injection")]
    {
        let armed = INJECTED_KEYED_TAIL_RESERVATION_FAILURES.with(|count| {
            let current = count.get();
            if current != 0 {
                count.set(current - 1);
            }
            current != 0
        });
        if armed {
            return Err(Error::AllocationFailed {
                resource: "keyed tail offsets",
                requested,
            });
        }
    }
    #[cfg(not(feature = "scalable-fault-injection"))]
    let _ = requested;
    Ok(())
}

/// Consumes one armed post-append keyed-tail reservation loss (API3-01).
///
/// Models the otherwise unreachable state in which the slot reserved before
/// the append is no longer usable afterwards, so the infallible commit's
/// discard-the-cache fallback can be exercised deterministically. Inert
/// without the `scalable-fault-injection` feature.
#[inline]
fn take_injected_keyed_tail_commit_loss() -> bool {
    #[cfg(feature = "scalable-fault-injection")]
    {
        INJECTED_KEYED_TAIL_COMMIT_LOSSES.with(|count| {
            let current = count.get();
            if current != 0 {
                count.set(current - 1);
            }
            current != 0
        })
    }
    #[cfg(not(feature = "scalable-fault-injection"))]
    {
        false
    }
}

/// Consumes one armed post-commit-marker durability failure (round 10).
///
/// Models a `flush`/`fsync` that fails *after* the commit marker has been
/// appended, which a real filesystem will not produce on demand. Inert without
/// the `scalable-fault-injection` feature.
#[inline]
fn take_injected_commit_durability_failure() -> Result<()> {
    #[cfg(feature = "scalable-fault-injection")]
    {
        let armed = INJECTED_COMMIT_DURABILITY_FAILURES.with(|count| {
            let current = count.get();
            if current != 0 {
                count.set(current - 1);
            }
            current != 0
        });
        if armed {
            return Err(Error::Io(std::io::Error::other(
                "injected post-commit durability failure",
            )));
        }
    }
    Ok(())
}

#[derive(Clone, Copy, Debug)]
struct AppendSnapshot {
    /// The end of file this append starts from, and the offset a rollback both
    /// truncates to and leaves the handle at.
    ///
    /// It used to carry a second number beside this one — the handle's actual
    /// offset, read with a per-record `stream_position` — so that a rollback
    /// could put the cursor back exactly where it found it. Reading it was an
    /// `lseek` per record; caching it instead was unsound, because the offset
    /// is shared with `VarlitFile::snapshot` (see `RecordFile`). Restoring `eof`
    /// costs neither: it is this field, and after any successful append the two
    /// numbers are the same one.
    eof: u64,
    sequence_state: SequenceState,
    index_len: usize,
    checkpoint_cadence: CheckpointCadence,
    segment_cursor: SegmentCursor,
    /// The block this append is about to move the tail of, and where that tail
    /// pointed before. Two words, so the rollback needs no allocation.
    block_id: u32,
    previous_block_tail: Option<u64>,
    uncommitted_since_commit: bool,
    /// Whether any record has been appended since the last digest was written.
    ///
    /// `needs_open_digest` used to answer this with `last_resident_block_id`,
    /// which only moves for records the resident index carries. A workload
    /// flushing only non-resident records therefore left the flag reading
    /// "the digest is still last" while records piled up behind it — the
    /// digest went permanently stale and every `open_readonly_lazy` silently
    /// full-scanned. Non-resident blocks are exactly what the digest's tail
    /// table exists to reach, so that combination disabled the feature for its
    /// own purpose.
    appended_since_digest: bool,
    /// The block id of the newest resident entry, maintained at the single
    /// index append site.
    ///
    /// Exists so that `needs_index_segment` and `needs_open_digest` can ask
    /// "is the last thing in this file already the record I am about to write"
    /// without faulting an entry off disk on every flush. A slot holds an
    /// offset and a committed bit, so the block id is not otherwise knowable
    /// without a read, and both predicates run on the append path.
    last_resident_block_id: Option<u32>,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
enum WriteFault {
    #[default]
    None,
    AppendAfterHeader,
    AppendAfterHeaderWithRollbackFailure,
    RollbackFailure,
    RebindAfterPublish,
    /// F-07 double fault: the parent-directory sync fails *and* the rebind
    /// that follows the same publication fails.
    ///
    /// One arming produces both, because taking the parent-sync failure re-arms
    /// the injector as [`WriteFault::RebindAfterPublish`]. That ordering is the
    /// one the code under test sees: `replace_path_atomically` syncs the parent
    /// directory before it returns, and the writer rebinds afterwards.
    ParentSyncThenRebindAfterPublish,
}

#[cfg(test)]
std::thread_local! {
    static WRITE_FAULT: std::cell::Cell<WriteFault> = const {
        std::cell::Cell::new(WriteFault::None)
    };
}

#[cfg(test)]
fn inject_write_fault(fault: WriteFault) {
    WRITE_FAULT.set(fault);
}

#[cfg(test)]
fn fail_append_after_header_if_requested() -> std::io::Result<()> {
    WRITE_FAULT.with(|fault| match fault.get() {
        WriteFault::AppendAfterHeader => {
            fault.set(WriteFault::None);
            Err(std::io::Error::other("injected append write failure"))
        }
        WriteFault::AppendAfterHeaderWithRollbackFailure => {
            fault.set(WriteFault::RollbackFailure);
            Err(std::io::Error::other("injected append write failure"))
        }
        _ => Ok(()),
    })
}

#[cfg(test)]
fn fail_rollback_if_requested() -> std::io::Result<()> {
    WRITE_FAULT.with(|fault| {
        if fault.get() == WriteFault::RollbackFailure {
            fault.set(WriteFault::None);
            Err(std::io::Error::other("injected rollback failure"))
        } else {
            Ok(())
        }
    })
}

/// F-07: injects a parent-directory sync failure and arms the rebind failure
/// that must follow it in the same publication.
#[cfg(test)]
fn fail_parent_sync_if_requested() -> Result<()> {
    WRITE_FAULT.with(|fault| {
        if fault.get() == WriteFault::ParentSyncThenRebindAfterPublish {
            fault.set(WriteFault::RebindAfterPublish);
            Err(Error::Io(std::io::Error::other(
                "injected parent-directory sync failure",
            )))
        } else {
            Ok(())
        }
    })
}

#[cfg(test)]
fn fail_rebind_after_publish_if_requested() -> std::io::Result<()> {
    WRITE_FAULT.with(|fault| {
        if fault.get() == WriteFault::RebindAfterPublish {
            fault.set(WriteFault::None);
            Err(std::io::Error::other(
                "injected post-publication rebind failure",
            ))
        } else {
            Ok(())
        }
    })
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct RecordHeaderFields {
    pub(crate) block_id: u32,
    pub(crate) block_version: u16,
    pub(crate) flags: u16,
    pub(crate) sequence: u64,
    pub(crate) payload_len: u64,
    pub(crate) checksum: u32,
    pub(crate) uncompressed_len_hint: u32,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct RecordFooterFields {
    pub(crate) prev_same_block_offset: Option<u64>,
    pub(crate) prev_same_key_offset: Option<u64>,
    /// The trailing footer word, which is the only part of a written record
    /// that can change afterwards.
    ///
    /// Zero under [`LivenessPolicy::None`], where it is the reserved word it has
    /// always been and a non-zero value is refused at decode. Under
    /// [`LivenessPolicy::FooterFlags`] it carries record flags and is excluded
    /// from the record checksum, which is what makes it writable in place
    /// without touching the payload.
    pub(crate) mutable_flags: u32,
}

/// Seals the open chunk on the way out.
///
/// **Every other byte a writer accepts is on disk before the call returns.** A
/// chunked cell is the one exception: it lives in the open chunk until it is written.
/// Without this, dropping a writer without `flush` lost every committed cell in
/// that chunk, silently, and this library had no other way to lose committed
/// data.
///
/// Best effort, and that is a real limitation rather than a hedge: `drop`
/// cannot report a failure, so a caller who needs to know the write succeeded
/// must call `flush`, `commit` or `sync` and read the error. What this
/// guarantees is that the ordinary case — a writer that goes out of scope —
/// does not lose data.
impl Drop for VarlitFile {
    fn drop(&mut self) {
        if self.mode == OpenMode::ReadWrite && self.open_chunk.is_some() {
            let _ = self.write_open_chunk_record();
        }
        // The clean-release half of the crash verdict. Best-effort by
        // necessity — `drop` cannot report — and that is the right shape here:
        // a clear that fails leaves the bit set, so the next open runs a
        // recovery pass it did not strictly need, which is the direction to
        // fail in. The opposite arrangement would let a crash read as clean.
        if self.mode == OpenMode::ReadWrite {
            let _ = self.mark_writer_closed();
        }
    }
}

/// A file handle with owner-local caches. Send + !Sync, including when the
/// selected format contains only records. Each thread opens its own reader.
#[derive(Debug)]
pub struct VarlitFile {
    spec: FormatSpec,
    path: PathBuf,
    // Shape A/B, mechanical enforcement: the primary handle is not a `File`.
    // See `mod record_file` for what that forbids.
    file: RecordFile,
    snapshot: SnapshotFile,
    mode: OpenMode,
    // Shape A, mechanical enforcement: the mirror is not a `Vec`.
    // See `mod resident_index` for what that forbids.
    index: ResidentIndex,
    // The extension region this file actually carries, which is not always the
    // one `spec` would write: an unknown block is skipped at open, so a file
    // from a later release has a longer region than this build produces. Every
    // header-derived offset comes from here, and a rewrite writes it back
    // verbatim rather than regenerating it — regenerating would drop the
    // unknown block and silently move the append log.
    header_extensions: Vec<u8>,
    matrix: Option<crate::matrix::MatrixLayout>,
    // Present exactly when `matrix` is present: read once at open/create time
    // so sidecar identity checks never touch the file per operation (DUR2-03).
    matrix_creation_nonce: Option<[u8; MATRIX_CREATION_NONCE_LEN]>,
    sequence_state: SequenceState,
    // O(1) flush-cadence state for `needs_index_checkpoint`; must equal
    // `CheckpointCadence::from_index(&index)` at all times (PERF2-02).
    checkpoint_cadence: CheckpointCadence,
    // O(1) append-side block-offset-chain predecessors; must equal
    // `BlockTails::from_index(&index)` at all times (PERF2-05).
    block_tails: BlockTails,
    // The matrix chunk being filled, when a growing dimension is declared. See
    // `OpenChunk`; `None` until a write lands past the declared extent.
    open_chunk: Option<OpenChunk>,
    // Every written chunk, ordered once and searched in memory. Empty until the
    // first chunked access, so a handle that never touches a chunk builds
    // nothing. See `ChunkDirectory` for why this is not derived per read.
    //
    // `OnceCell` rather than `Option`, because building it happens on a read
    // path and every read entry point takes `&self` — that is a standing design
    // policy, not a convenience.
    chunk_directory: std::cell::OnceCell<ChunkDirectory>,
    // O(1) commit-point state for the internal segment chain; must equal
    // `SegmentCursor::from_index(&index)` at all times.
    segment_cursor: SegmentCursor,
    // Whether a record that a commit marker would cover has been appended since
    // the last one. Tracked here rather than read off the resident index,
    // because a non-resident block's records are not in it: deriving the answer
    // from the index made `flush` decide there was nothing to commit and skip
    // the marker, which left every such record permanently uncommitted and
    // invisible to every reader.
    uncommitted_since_commit: bool,
    /// Scratch the logical payload is encoded into, reused across records.
    ///
    /// `StreamWriter` and `IndexedStreamWriter` have had this since their
    /// allocation contracts were written; `VarlitFile` never got it and
    /// allocated a fresh `Vec` per push through `encode_to_vec_limited`. The
    /// append hot path admits no per-record allocation, and this was one of the
    /// two payload-proportional ones the allocation-contract test records as
    /// outstanding.
    record_buffer: Vec<u8>,
    immediate_state: crate::immediate::ImmediateState,
    /// Whether any record has been appended since the last digest was written.
    ///
    /// `needs_open_digest` used to answer this with `last_resident_block_id`,
    /// which only moves for records the resident index carries. A workload
    /// flushing only non-resident records therefore left the flag reading
    /// "the digest is still last" while records piled up behind it — the
    /// digest went permanently stale and every `open_readonly_lazy` silently
    /// full-scanned. Non-resident blocks are exactly what the digest's tail
    /// table exists to reach, so that combination disabled the feature for its
    /// own purpose.
    appended_since_digest: bool,
    /// The block id of the newest resident entry, maintained at the single
    /// index append site.
    ///
    /// Exists so that `needs_index_segment` and `needs_open_digest` can ask
    /// "is the last thing in this file already the record I am about to write"
    /// without faulting an entry off disk on every flush. A slot holds an
    /// offset and a committed bit, so the block id is not otherwise knowable
    /// without a read, and both predicates run on the append path.
    last_resident_block_id: Option<u32>,
    // Lazily built keyed-offset-chain predecessors for the generic keyed
    // append path; a cached map is either absent or exact (API2-05).
    keyed_tails: KeyedTails,
    // True while this handle has created a pathname whose directory entry has
    // not been made durable yet. Cleared by the first successful durability
    // request, so the parent sync happens once per created file and never on
    // the append path (DUR3-01).
    pending_pathname_parent_sync: bool,
    /// Whether the file's liveness block said `DIRTY` when this handle opened
    /// it — i.e. whether the previous writer died without releasing.
    ///
    /// Read *before* this open sets the bit for itself, so it describes the
    /// predecessor rather than this handle. Always `false` for a format without
    /// `liveness: footer_flags` and for every read-only handle, which never
    /// takes the object and so cannot tell "held" from "abandoned".
    opened_after_crash: bool,
    poison: PoisonFlag,
    _lock: Option<WriterLock>,
    // Keep pending discovery private to this reader; committed state above
    // remains usable after a failed follow or a discarded tentative scan.
    follow_scan: Option<Box<FollowScan>>,
}

/// A reader with private caches: Send + !Sync. Move ownership to a worker
/// or open a separate reader for each thread; ordinary reads take `&self`.
#[derive(Debug)]
pub struct VarlitReader {
    file: VarlitFile,
}

impl VarlitReader {
    pub fn matrix_generation(&self) -> Option<u64> {
        self.file.matrix_generation()
    }
    /// Required companion file for matrix storage; copy/rename it with the primary.
    pub fn matrix_generation_path(&self) -> Option<&Path> {
        self.file.matrix_generation_path()
    }

    pub fn open<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::open_readonly(spec, path)?,
        })
    }

    /// See [`VarlitFile::follow`].
    ///
    /// The one `&mut self` method on this type, and deliberately so: every read
    /// takes `&self` and stays available to concurrent callers, and advancing
    /// the handle to a later state is the one operation that is not a read.
    pub fn follow(&mut self) -> Result<u64> {
        self.file.follow()
    }

    /// See [`VarlitFile::is_current`].
    pub fn is_current(&self) -> Result<bool> {
        self.file.is_current()
    }

    /// A fresh reader on whatever the pathname resolves to now. See
    /// [`VarlitFile::reopen_readonly`].
    ///
    /// Takes `&self` and returns a separate reader with its own caches.
    pub fn reopen(&self) -> Result<Self> {
        Ok(Self {
            file: self.file.reopen_readonly()?,
        })
    }

    /// See [`VarlitFile::open_readonly_with_scratch`].
    pub fn open_with_scratch<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        scratch: &mut Vec<RecordIndexEntry>,
    ) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::open_readonly_with_scratch(spec, path, scratch)?,
        })
    }

    /// See [`VarlitFile::open_readonly_without_directory`].
    pub fn open_without_directory<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        index: &mut Vec<RecordIndexEntry>,
    ) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::open_readonly_without_directory(spec, path, index)?,
        })
    }

    pub fn into_inner(self) -> VarlitFile {
        self.file
    }

    pub fn spec(&self) -> FormatSpec {
        self.file.spec()
    }

    pub fn path(&self) -> &Path {
        self.file.path()
    }

    /// The open file this reader holds, borrowed rather than consumed.
    pub fn file(&self) -> &VarlitFile {
        &self.file
    }

    /// Reads a block out of the editable header region.
    /// See [`VarlitFile::read_header_block`].
    ///
    /// `&self` and no I/O: the region is part of the header this handle already
    /// read at open, which is what makes it usable as a seed for a walk.
    pub fn read_header_block<T: VarlitBlock>(&self) -> Result<Option<T>> {
        self.file.read_header_block::<T>()
    }

    /// The declared size of the editable header region; `0` when undeclared.
    pub fn header_slots_capacity(&self) -> usize {
        self.file.header_slots_capacity()
    }

    /// How much of the region the current blocks occupy.
    pub fn header_slots_used(&self) -> Result<usize> {
        self.file.header_slots_used()
    }

    /// How much of the region is left.
    pub fn header_slots_free_bytes(&self) -> Result<usize> {
        self.file.header_slots_free_bytes()
    }

    /// Whether the region's seal is down.
    pub fn header_slots_sealed(&self) -> Result<bool> {
        self.file.header_slots_sealed()
    }

    pub fn mode(&self) -> OpenMode {
        self.file.mode()
    }

    pub fn metadata(&self, key: &str) -> Result<Option<Vec<u8>>> {
        self.file.metadata(key)
    }

    pub fn all_metadata(&self) -> Result<Vec<(String, Vec<u8>)>> {
        self.file.all_metadata()
    }

    /// See [`VarlitFile::all_metadata_into`].
    pub fn all_metadata_into(&self, out: &mut Vec<(String, Vec<u8>)>) -> Result<()> {
        self.file.all_metadata_into(out)
    }

    pub fn schema_manifest(&self) -> Result<Option<SchemaManifest>> {
        self.file.schema_manifest()
    }

    pub fn blocks<T: VarlitBlock>(&self) -> Result<BlockVec<T>> {
        self.file.blocks::<T>()
    }

    /// See [`VarlitFile::block_entries_into`].
    pub fn block_entries_into<T: VarlitBlock>(
        &self,
        out: &mut Vec<RecordIndexEntry>,
    ) -> Result<()> {
        self.file.block_entries_into::<T>(out)
    }

    /// See [`VarlitFile::decode_blocks_into`] — including why it is not the
    /// `_into` twin of [`blocks`](Self::blocks).
    pub fn decode_blocks_into<T: VarlitBlock>(&self, out: &mut Vec<T>) -> Result<()> {
        self.file.decode_blocks_into::<T>(out)
    }

    pub fn blocks_migrated<From, To, M>(&self) -> Result<Vec<To>>
    where
        From: VarlitBlock,
        To: VarlitBlock,
        M: VarlitMigration<From, To>,
    {
        self.file.blocks_migrated::<From, To, M>()
    }

    /// See [`VarlitFile::blocks_migrated_into`].
    pub fn blocks_migrated_into<From, To, M>(&self, out: &mut Vec<To>) -> Result<()>
    where
        From: VarlitBlock,
        To: VarlitBlock,
        M: VarlitMigration<From, To>,
    {
        self.file.blocks_migrated_into::<From, To, M>(out)
    }

    pub fn keyed_blocks<T>(&self) -> Result<KeyedBlockVec<T::Key, T>>
    where
        T: VarlitKeyedBlock,
    {
        self.file.keyed_blocks::<T>()
    }

    /// See [`VarlitFile::keyed_blocks_into`], including which of the three
    /// collections it does not hand over.
    pub fn keyed_blocks_into<T>(
        &self,
        entries: &mut Vec<RecordIndexEntry>,
        by_key: &mut HashMap<T::Key, RecordIndexEntry>,
    ) -> Result<()>
    where
        T: VarlitKeyedBlock,
    {
        self.file.keyed_blocks_into::<T>(entries, by_key)
    }

    pub fn materialized_keyed_blocks<T>(&self) -> Result<HashMap<T::Key, T>>
    where
        T: VarlitMerge,
        T::Key: Eq + Hash,
    {
        self.file.materialized_keyed_blocks::<T>()
    }

    /// See [`VarlitFile::materialized_keyed_blocks_into`].
    pub fn materialized_keyed_blocks_into<T>(&self, out: &mut HashMap<T::Key, T>) -> Result<()>
    where
        T: VarlitMerge,
        T::Key: Eq + Hash,
    {
        self.file.materialized_keyed_blocks_into::<T>(out)
    }

    pub fn scan(&self) -> impl Iterator<Item = Result<BlockEvent>> + '_ {
        self.file.scan()
    }

    /// Verifies every record's stored checksum. See [`VarlitFile::verify_all`].
    pub fn verify_all(&self) -> Result<usize> {
        self.file.verify_all()
    }

    pub fn index_entries(&self) -> IndexEntries {
        self.file.index_entries()
    }

    /// Fills the caller's buffer with the record index; see
    /// [`VarlitFile::index_entries_into`].
    pub fn index_entries_into(&self, out: &mut Vec<RecordIndexEntry>) -> Result<()> {
        self.file.index_entries_into(out)
    }

    /// See [`VarlitFile::with_directory`].
    pub fn with_directory<'a, D: RecordDirectory + ?Sized>(
        &'a self,
        directory: &'a D,
    ) -> Result<DirectoryRead<'a, D>> {
        self.file.with_directory(directory)
    }

    /// See [`VarlitFile::record_map`].
    pub fn record_map<'a>(&self, buffer: &'a mut Vec<RecordIndexEntry>) -> Result<RecordMap<'a>> {
        self.file.record_map(buffer)
    }

    /// See [`VarlitFile::read_payload_into`].
    pub fn read_payload_into(&self, entry: &RecordIndexEntry, out: &mut Vec<u8>) -> Result<()> {
        self.file.read_payload_into(entry, out)
    }

    /// See [`VarlitFile::read_logical_payload_into`].
    pub fn read_logical_payload_into(
        &self,
        entry: &RecordIndexEntry,
        out: &mut Vec<u8>,
    ) -> Result<()> {
        self.file.read_logical_payload_into(entry, out)
    }

    /// See [`VarlitFile::decode_block_into`].
    pub fn decode_block_into<T: VarlitBlock>(
        &self,
        entry: &RecordIndexEntry,
        scratch: &mut Vec<u8>,
    ) -> Result<T> {
        self.file.decode_block_into::<T>(entry, scratch)
    }

    pub fn key_tail_offsets<T>(&self) -> Result<HashMap<T::Key, u64>>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        self.file.key_tail_offsets::<T>()
    }

    /// See [`VarlitFile::key_tail_offsets_into`].
    pub fn key_tail_offsets_into<T>(&self, out: &mut HashMap<T::Key, u64>) -> Result<()>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        self.file.key_tail_offsets_into::<T>(out)
    }

    pub fn read_matrix_cell<T: VarlitMatrixBlock>(&self, key: MatrixKey) -> Result<T> {
        self.file.read_matrix_cell(key)
    }

    /// See [`VarlitFile::read_matrix_run_into`].
    pub fn read_matrix_run_into<T: VarlitMatrixBlock>(
        &self,
        start: MatrixKey,
        out: &mut [T],
    ) -> Result<()> {
        self.file.read_matrix_run_into(start, out)
    }

    /// See [`VarlitFile::read_matrix_run_bytes_into`].
    pub fn read_matrix_run_bytes_into<T: VarlitMatrixBlock>(
        &self,
        start: MatrixKey,
        out: &mut [u8],
    ) -> Result<()> {
        self.file.read_matrix_run_bytes_into::<T>(start, out)
    }

    /// See [`VarlitFile::read_matrix_column_into`].
    pub fn read_matrix_column_into<T: VarlitMatrixBlock>(
        &self,
        start: MatrixKey,
        out: &mut [T],
    ) -> Result<()> {
        self.file.read_matrix_column_into(start, out)
    }

    /// See [`VarlitFile::read_matrix_column_bytes_into`].
    pub fn read_matrix_column_bytes_into<T: VarlitMatrixBlock>(
        &self,
        start: MatrixKey,
        out: &mut [u8],
    ) -> Result<()> {
        self.file.read_matrix_column_bytes_into::<T>(start, out)
    }

    /// See [`VarlitFile::read_matrix_row_into`].
    pub fn read_matrix_row_into<T: VarlitMatrixBlock>(
        &self,
        row: u64,
        out: &mut [T],
    ) -> Result<()> {
        self.file.read_matrix_row_into(row, out)
    }

    pub fn matrix_cell_payload<T: VarlitMatrixBlock>(&self, key: MatrixKey) -> Result<Vec<u8>> {
        self.file.matrix_cell_payload::<T>(key)
    }

    pub fn matrix_aux_len(&self, name: &str) -> Result<u64> {
        self.file.matrix_aux_len(name)
    }

    pub fn read_matrix_aux(&self, name: &str, offset: u64, len: u64) -> Result<Vec<u8>> {
        self.file.read_matrix_aux(name, offset, len)
    }

    pub fn matrix_cell_status<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
    ) -> Result<MatrixCellStatus> {
        self.file.matrix_cell_status::<T>(key)
    }

    pub fn is_matrix_single_committed(&self, name: &str) -> Result<bool> {
        self.file.is_matrix_single_committed(name)
    }

    pub fn is_matrix_channel_committed(&self, name: &str, channel: u64) -> Result<bool> {
        self.file.is_matrix_channel_committed(name, channel)
    }

    pub fn matrix_resume_signal(&self, category: &str) -> Result<MatrixResumeSignal> {
        self.file.matrix_resume_signal(category)
    }

    pub fn matrix_sidecar_resume_signal<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
    ) -> Result<MatrixResumeSignal> {
        self.file
            .matrix_sidecar_resume_signal(category, sidecar_path)
    }

    pub fn matrix_verified_sidecar_resume_signal<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
    ) -> Result<MatrixResumeSignal> {
        self.file
            .matrix_verified_sidecar_resume_signal(category, sidecar_path)
    }

    pub fn matrix_verified_sidecar_resume_signal_with_generation<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
        expected_generation: u64,
    ) -> Result<MatrixResumeSignal> {
        self.file
            .matrix_verified_sidecar_resume_signal_with_generation(
                category,
                sidecar_path,
                expected_generation,
            )
    }

    pub fn read_matrix_sidecar<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
    ) -> Result<(MatrixSidecarManifest, Vec<u8>)> {
        self.file.read_matrix_sidecar(category, sidecar_path)
    }

    pub fn read_matrix_sidecar_with_generation<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
        expected_generation: u64,
    ) -> Result<(MatrixSidecarManifest, Vec<u8>)> {
        self.file
            .read_matrix_sidecar_with_generation(category, sidecar_path, expected_generation)
    }

    pub fn matrix_recovery_report(&self) -> MatrixRecoveryReport {
        self.file.matrix_recovery_report()
    }
    /// Per-file sparse/allocation observations captured at create/open.
    pub fn matrix_storage_diagnostics(&self) -> Option<crate::MatrixStorageDiagnostics> {
        self.file.matrix_storage_diagnostics()
    }

    /// Verifies this matrix's commit metadata now, and reports what was found.
    ///
    /// See [`VarlitFile::verify_matrix_metadata`]: the same pass a
    /// `MatrixMetadataVerification::AtOpen` open runs, on demand, retaining one
    /// page buffer. It reports; it does not arm the quarantine.
    pub fn verify_matrix_metadata(&self) -> Result<MatrixRecoveryReport> {
        self.file.verify_matrix_metadata()
    }

    #[cfg(feature = "mmap")]
    /// Maps the file's indexed record payloads as a read-only snapshot.
    ///
    /// # Safety
    ///
    /// The caller must prevent mutation, truncation, replacement, backing-file
    /// invalidation, and any other modification through every handle, thread,
    /// and process for the full lifetime of the returned mapping.
    ///
    /// Once that condition holds, Varlit keeps safe accessors sound by cloning
    /// the existing backing handle, creating a read-only mapping, validating
    /// every indexed extent with checked arithmetic, rejecting entries outside
    /// the copied snapshot, and tying every returned slice to the mapping owner.
    /// Use owned reads instead when external immutability cannot be guaranteed.
    ///
    /// **The file header is not mapped.** The mapping begins at the start of
    /// the append log, so the bytes a commit can rewrite — the
    /// `IndexPolicy::header_tails` region among them — are outside every
    /// reference this type constructs. Current growing chunks append immutable
    /// record versions rather than rewriting an existing chunk record. This
    /// does not waive the safety condition: exclusive in-place replacement,
    /// liveness updates, truncation and external writes can still change the
    /// mapped backing object. Use owned reads when those operations cannot be
    /// excluded for the mapping's lifetime.
    pub unsafe fn mmap_payloads(&self) -> Result<MmapPayloads> {
        // SAFETY: The caller accepts the complete file-backed mapping contract.
        unsafe { self.file.mmap_payloads() }
    }

    #[cfg(feature = "mmap")]
    /// Maps one committed cell; see [`VarlitFile::mmap_matrix_cell`].
    ///
    /// # Safety
    ///
    /// The backing object must remain immutable and valid for the mapping's lifetime.
    pub unsafe fn mmap_matrix_cell<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
    ) -> Result<MmapPayloadWindow> {
        // SAFETY: the caller upholds the underlying constructor's contract.
        unsafe { self.file.mmap_matrix_cell::<T>(key) }
    }

    #[cfg(feature = "mmap")]
    /// Maps the file's matrix regions as a read-only snapshot.
    ///
    /// # Safety
    ///
    /// The caller must prevent mutation, truncation, replacement, backing-file
    /// invalidation, and any other modification through every handle, thread,
    /// and process for the full lifetime of the returned mapping.
    ///
    /// Once that condition holds, Varlit keeps safe accessors sound by cloning
    /// the existing backing handle, creating a read-only mapping, validating
    /// the complete matrix extent, checking every requested slot, and tying
    /// every returned slice to the mapping owner. Use owned reads instead when
    /// external immutability cannot be guaranteed.
    ///
    /// Unlike [`Self::mmap_payloads`] this mapping *does* start at byte 0 and so
    /// covers the file header: the matrix region it exists to serve sits between
    /// the header and the append log, so there is no base to move it to. That is
    /// sound because the one option that rewrites header bytes,
    /// `IndexPolicy::header_tails`, is refused for a format declaring matrix
    /// blocks — the two cannot meet.
    pub unsafe fn mmap_matrix(&self) -> Result<MmapMatrix> {
        // SAFETY: The caller accepts the complete file-backed mapping contract.
        unsafe { self.file.mmap_matrix() }
    }
}

#[derive(Debug)]
pub struct VarlitWriter {
    file: VarlitFile,
}

impl VarlitWriter {
    pub fn compact_matrix(&mut self) -> Result<()> {
        self.file.compact_matrix()
    }

    pub fn matrix_generation(&self) -> Option<u64> {
        self.file.matrix_generation()
    }
    /// Required companion file for matrix storage; copy/rename it with the primary.
    pub fn matrix_generation_path(&self) -> Option<&Path> {
        self.file.matrix_generation_path()
    }

    pub fn create<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::create(spec, path)?,
        })
    }

    /// Creates a new native file, failing if `path` already exists.
    ///
    /// See [`VarlitFile::create_new`].
    pub fn create_new<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::create_new(spec, path)?,
        })
    }

    pub fn create_with_dims<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        dims: MatrixDimensions,
    ) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::create_with_dims(spec, path, dims)?,
        })
    }

    /// Creates a new native matrix file, failing if `path` already exists.
    ///
    /// See [`VarlitFile::create_new_with_dims`].
    pub fn create_new_with_dims<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        dims: MatrixDimensions,
    ) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::create_new_with_dims(spec, path, dims)?,
        })
    }

    pub fn open<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::open(spec, path)?,
        })
    }

    /// See [`VarlitFile::open_lazy`].
    pub fn open_lazy<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::open_lazy(spec, path)?,
        })
    }

    /// See [`VarlitFile::open_lazy_with_report`].
    pub fn open_lazy_with_report<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
    ) -> Result<(Self, LazyOpenSource)> {
        let (file, source) = VarlitFile::open_lazy_with_report(spec, path)?;
        Ok((Self { file }, source))
    }

    /// See [`VarlitFile::open_with_scratch`].
    pub fn open_with_scratch<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        scratch: &mut Vec<RecordIndexEntry>,
    ) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::open_with_scratch(spec, path, scratch)?,
        })
    }

    pub fn open_with_lock_policy<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        policy: WriterLockBreakPolicy,
    ) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::open_with_lock_policy(spec, path, policy)?,
        })
    }

    pub fn open_recover<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Ok(Self {
            file: VarlitFile::open_recover(spec, path)?,
        })
    }

    pub fn open_recover_with_report<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
    ) -> Result<(Self, RecoveryReport)> {
        let (file, report) = VarlitFile::open_recover_with_report(spec, path)?;
        Ok((Self { file }, report))
    }

    pub fn into_inner(self) -> VarlitFile {
        self.file
    }

    pub fn spec(&self) -> FormatSpec {
        self.file.spec()
    }

    pub fn path(&self) -> &Path {
        self.file.path()
    }

    pub fn mode(&self) -> OpenMode {
        self.file.mode()
    }

    /// Verifies every record's stored checksum. See [`VarlitFile::verify_all`].
    pub fn verify_all(&self) -> Result<usize> {
        self.file.verify_all()
    }

    /// The open file this writer holds, borrowed rather than consumed.
    ///
    /// `into_inner` is the only other route to it and it takes `self`, which
    /// makes every `&mut self` entry point on [`VarlitFile`] unreachable from a
    /// writer that is still being written through. Reaching one is what a
    /// caller wants when the capability has no forwarding method here yet;
    /// the header-slot family below is forwarded precisely so that this is not
    /// needed for it.
    pub fn file_mut(&mut self) -> &mut VarlitFile {
        &mut self.file
    }

    /// The open file this writer holds, borrowed for reading.
    pub fn file(&self) -> &VarlitFile {
        &self.file
    }

    /// Reads a block out of the editable header region.
    /// See [`VarlitFile::read_header_block`].
    ///
    /// Forwarded because the writer is the handle that knows what to record
    /// there: an append returns its own `record_offset`, and writing that
    /// offset into the region is what lets a later reader seed a walk without
    /// rebuilding an index. Reaching `write_header_block` used to mean
    /// `into_inner`, which ends the writer.
    pub fn read_header_block<T: VarlitBlock>(&self) -> Result<Option<T>> {
        self.file.read_header_block::<T>()
    }

    /// Writes a block into the editable header region, replacing any earlier
    /// value for the same block id. See [`VarlitFile::write_header_block`].
    pub fn write_header_block<T: VarlitBlock>(&mut self, block: &T) -> Result<()> {
        self.file.write_header_block(block)
    }

    /// Removes a block from the editable header region, freeing its bytes.
    /// See [`VarlitFile::remove_header_block`].
    pub fn remove_header_block<T: VarlitBlock>(&mut self) -> Result<()> {
        self.file.remove_header_block::<T>()
    }

    /// Fixes the region's checksum and refuses every later write.
    /// See [`VarlitFile::seal_header_slots`].
    pub fn seal_header_slots(&mut self) -> Result<()> {
        self.file.seal_header_slots()
    }

    /// The declared size of the editable header region; `0` when undeclared.
    pub fn header_slots_capacity(&self) -> usize {
        self.file.header_slots_capacity()
    }

    /// How much of the region the current blocks occupy.
    pub fn header_slots_used(&self) -> Result<usize> {
        self.file.header_slots_used()
    }

    /// How much of the region is left.
    pub fn header_slots_free_bytes(&self) -> Result<usize> {
        self.file.header_slots_free_bytes()
    }

    /// Whether the region's seal is down.
    pub fn header_slots_sealed(&self) -> Result<bool> {
        self.file.header_slots_sealed()
    }

    pub fn index_entries(&self) -> IndexEntries {
        self.file.index_entries()
    }

    /// Fills the caller's buffer with the record index; see
    /// [`VarlitFile::index_entries_into`].
    pub fn index_entries_into(&self, out: &mut Vec<RecordIndexEntry>) -> Result<()> {
        self.file.index_entries_into(out)
    }

    /// See [`VarlitFile::with_directory`].
    pub fn with_directory<'a, D: RecordDirectory + ?Sized>(
        &'a self,
        directory: &'a D,
    ) -> Result<DirectoryRead<'a, D>> {
        self.file.with_directory(directory)
    }

    /// See [`VarlitFile::record_map`].
    pub fn record_map<'a>(&self, buffer: &'a mut Vec<RecordIndexEntry>) -> Result<RecordMap<'a>> {
        self.file.record_map(buffer)
    }

    /// See [`VarlitFile::read_payload_into`].
    pub fn read_payload_into(&self, entry: &RecordIndexEntry, out: &mut Vec<u8>) -> Result<()> {
        self.file.read_payload_into(entry, out)
    }

    /// See [`VarlitFile::read_logical_payload_into`].
    pub fn read_logical_payload_into(
        &self,
        entry: &RecordIndexEntry,
        out: &mut Vec<u8>,
    ) -> Result<()> {
        self.file.read_logical_payload_into(entry, out)
    }

    /// See [`VarlitFile::decode_block_into`].
    pub fn decode_block_into<T: VarlitBlock>(
        &self,
        entry: &RecordIndexEntry,
        scratch: &mut Vec<u8>,
    ) -> Result<T> {
        self.file.decode_block_into::<T>(entry, scratch)
    }

    pub fn key_tail_offsets<T>(&self) -> Result<HashMap<T::Key, u64>>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        self.file.key_tail_offsets::<T>()
    }

    /// See [`VarlitFile::key_tail_offsets_into`].
    pub fn key_tail_offsets_into<T>(&self, out: &mut HashMap<T::Key, u64>) -> Result<()>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        self.file.key_tail_offsets_into::<T>(out)
    }

    // F-01 (round 9): `VarlitWriter::reserve_keyed_tail_slot` has been
    // removed.
    //
    // It existed so a generated keyed writer could reserve a slot in its own
    // `HashMap<T::Key, u64>` before the append that would fill it. That
    // reserved the map's inline table, but it could not stop the *later*
    // `HashMap::insert` from invoking the caller's `Hash` or `Eq` after the
    // record was already authoritative - a stateful or panicking
    // implementation could therefore fail after publication and leave the
    // writer holding a stale predecessor, which makes the next same-key
    // mutation link *around* the committed event.
    //
    // The generated writers no longer own a typed tail map at all. They route
    // through `VarlitWriter::push_keyed_info` and `VarlitWriter::delete_info`,
    // which maintain the same byte-keyed resident cache the generic keyed API
    // uses (`VarlitFile::push_keyed_info`): its keys are the canonical
    // internal key payload, so the only step after the authoritative append is
    // a `HashMap<Vec<u8>, u64>` insert into a slot reserved beforehand. No
    // user-defined trait method can run there.
    //
    pub fn push<T: VarlitBlock>(&mut self, block: &T) -> Result<u64> {
        self.file.push(block)
    }

    pub fn push_info<T: VarlitBlock>(&mut self, block: &T) -> Result<AppendInfo> {
        self.file.push_info(block)
    }

    /// Appends a keyed block through the generic API while maintaining the
    /// keyed predecessor chain. See [`VarlitFile::push_keyed`].
    pub fn push_keyed<T>(&mut self, block: &T) -> Result<u64>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        self.file.push_keyed(block)
    }

    /// Appends a keyed block through the generic API while maintaining the
    /// keyed predecessor chain. See [`VarlitFile::push_keyed_info`].
    pub fn push_keyed_info<T>(&mut self, block: &T) -> Result<AppendInfo>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        self.file.push_keyed_info(block)
    }

    pub fn push_with_prev_key_info<T: VarlitBlock>(
        &mut self,
        block: &T,
        prev_same_key_offset: Option<u64>,
    ) -> Result<AppendInfo> {
        self.file
            .push_with_prev_key_info(block, prev_same_key_offset)
    }

    pub fn delete<T>(&mut self, key: &T::Key) -> Result<u64>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        self.file.delete::<T>(key)
    }

    /// Appends a tombstone through the maintained keyed path. See
    /// [`VarlitFile::delete_info`]. This is the entry point the generated
    /// `delete_<block>` writer methods use.
    pub fn delete_info<T>(&mut self, key: &T::Key) -> Result<AppendInfo>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        self.file.delete_info::<T>(key)
    }

    /// Builds `T`'s keyed tail map now. See [`VarlitFile::prime_keyed_tails`].
    /// The generated keyed writers call this once per keyed block at
    /// construction.
    #[doc(hidden)]
    pub fn prime_keyed_tails<T>(&mut self) -> Result<()>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        self.file.prime_keyed_tails::<T>()
    }

    pub fn delete_with_prev_key_info<T>(
        &mut self,
        key: &T::Key,
        prev_same_key_offset: Option<u64>,
    ) -> Result<AppendInfo>
    where
        T: VarlitKeyedBlock,
    {
        self.file
            .delete_with_prev_key_info::<T>(key, prev_same_key_offset)
    }

    pub fn push_op<T>(&mut self, key: &T::Key, op: &T::Op) -> Result<u64>
    where
        T: VarlitMerge,
    {
        self.file.push_op::<T>(key, op)
    }

    pub fn write_metadata(&mut self, key: &str, value: &[u8]) -> Result<u64> {
        self.file.write_metadata(key, value)
    }

    /// Replaces a native user record while preserving its sequence number.
    ///
    /// [`Error::PublishedButRebindFailed`] means publication already succeeded.
    /// Do not retry blindly; discard this poisoned writer and reopen the path.
    ///
    /// [`Error::PublishedButParentSyncPending`] also means publication already
    /// succeeded; the writer was rebound to the published generation and stays
    /// usable, but the rename is not yet guaranteed durable against power loss
    /// until the parent directory is synced (for example by a later successful
    /// publication or an explicit directory sync).
    pub fn replace_block<T: VarlitReplaceBlock>(
        &mut self,
        index: usize,
        block: &T,
    ) -> Result<ReplacementInfo> {
        self.file.replace_block(index, block)
    }

    /// Publishes a same-size fixed replacement through a copy-on-write file
    /// generation.
    ///
    /// [`Error::PublishedButRebindFailed`] means publication already succeeded.
    /// Do not retry blindly; discard this poisoned writer and reopen the path.
    ///
    /// [`Error::PublishedButParentSyncPending`] also means publication already
    /// succeeded; the writer was rebound to the published generation and stays
    /// usable, but the rename is not yet guaranteed durable against power loss
    /// until the parent directory is synced (for example by a later successful
    /// publication or an explicit directory sync).
    /// See [`VarlitFile::defragment`].
    pub fn defragment(&mut self) -> Result<DefragmentReport> {
        self.file.defragment()
    }

    /// See [`VarlitFile::mark_record_dead`].
    pub fn mark_record_dead(&mut self, record_offset: u64) -> Result<()> {
        self.file.mark_record_dead(record_offset)
    }

    /// See [`VarlitFile::record_is_dead`].
    pub fn record_is_dead(&self, record_offset: u64) -> Result<bool> {
        self.file.record_is_dead(record_offset)
    }

    /// See [`VarlitFile::opened_after_crash`].
    pub const fn opened_after_crash(&self) -> bool {
        self.file.opened_after_crash()
    }

    pub fn replace_fixed<T: VarlitBlock>(&mut self, index: usize, block: &T) -> Result<u64> {
        self.file.replace_fixed(index, block)
    }

    /// Replaces a fixed record by mutating the backing object directly.
    ///
    /// # Errors
    ///
    /// See [`VarlitFile::replace_fixed_in_place_exclusive`]: a stored record
    /// whose version differs from `T::VERSION` is refused with
    /// [`Error::BlockVersionMismatch`] (F-01).
    ///
    /// # Safety
    ///
    /// See [`VarlitFile::replace_fixed_in_place_exclusive`] for the full
    /// contract, including the requirement that a keyed record's key must not
    /// change (F-02).
    ///
    /// The caller must exclude every reader, writer, mapping, raw reference,
    /// handle, thread, and process for this operation and for the lifetime of
    /// every view that could observe the affected object.
    pub unsafe fn replace_fixed_in_place_exclusive<T: VarlitBlock>(
        &mut self,
        index: usize,
        block: &T,
    ) -> Result<u64> {
        // SAFETY: The caller accepts the exclusivity contract documented above.
        unsafe { self.file.replace_fixed_in_place_exclusive(index, block) }
    }

    /// Publishes a replacement by rewriting the complete file generation.
    ///
    /// # Not for a format that writes a record footer
    ///
    /// Refused with `InvalidFormatSpec("replace is not supported for
    /// record-footer formats")`, which is every format declaring an offset
    /// chain, `segment_on_flush`, or any commit policy other than
    /// [`CommitPolicy::None`]. Use [`replace_block`](Self::replace_block)
    /// there: it does the same whole-file republish and does maintain the
    /// footer, translating both chain offsets and checking each predecessor
    /// against the prefix it has already written.
    ///
    /// The refusal is a statement about *this* routine rather than about the
    /// operation. Its record writer emits header and payload and stops — no
    /// footer, and both chain fields cleared — so a file it produced for such a
    /// format would frame perfectly and carry no chain at all.
    ///
    /// [`Error::PublishedButRebindFailed`] means publication already succeeded.
    /// Do not retry blindly; discard this poisoned writer and reopen the path.
    ///
    /// [`Error::PublishedButParentSyncPending`] also means publication already
    /// succeeded; the writer was rebound to the published generation and stays
    /// usable, but the rename is not yet guaranteed durable against power loss
    /// until the parent directory is synced (for example by a later successful
    /// publication or an explicit directory sync).
    pub fn replace_rewrite<T: VarlitBlock>(&mut self, index: usize, block: &T) -> Result<u64> {
        self.file.replace_rewrite(index, block)
    }

    /// See [`VarlitFile::replace`].
    pub fn replace<T: VarlitReplaceBlock>(&mut self, index: usize, block: &T) -> Result<u64> {
        self.file.replace(index, block)
    }

    pub fn flush(&mut self) -> Result<()> {
        self.file.flush()
    }

    pub fn commit(&mut self) -> Result<AppendInfo> {
        self.file.commit()
    }

    pub fn commit_durable(&mut self) -> Result<AppendInfo> {
        self.file.commit_durable()
    }

    pub fn sync(&mut self) -> Result<()> {
        self.file.sync()
    }

    pub fn immediate(&mut self) -> Result<()> {
        self.file.immediate()
    }

    pub fn set_immediate_policy(&mut self, policy: crate::ImmediatePolicy) -> Result<()> {
        self.file.set_immediate_policy(policy)
    }

    pub fn write_matrix_cell<T: VarlitMatrixBlock>(
        &mut self,
        key: MatrixKey,
        value: &T,
    ) -> Result<()> {
        self.file.write_matrix_cell(key, value)
    }

    /// Copies one cell's bytes out of `source`.
    ///
    /// `source` is a **shared** borrow: the read side of a byte copy needs no
    /// exclusive handle, so a copy may run while other threads are reading the
    /// same source handle. Callers that were passing `&mut VarlitReader` still
    /// compile — `&mut T` coerces to `&T`.
    pub fn copy_matrix_cell_bytes_from<From, To>(
        &mut self,
        source: &VarlitReader,
        key: MatrixKey,
    ) -> Result<()>
    where
        From: VarlitMatrixBlock,
        To: VarlitMatrixBlock,
    {
        ensure_matrix_byte_copy_compatible::<From, To>()?;
        let payload = source.matrix_cell_payload::<From>(key)?;
        self.file.write_matrix_cell_payload::<To>(key, &payload)?;
        self.file.commit_matrix_cell::<To>(key)
    }

    /// Writes a cell, runs the barriers, publishes and syncs its generation,
    /// then calls `hook`. Other pending matrix changes are published too.
    ///
    /// Barrier failures are pre-publication errors and poison the writer.
    /// [`Error::MatrixPublicationUncertain`] requires reopening and inspecting
    /// the confirmed generation before retrying. A complete head whose final
    /// durability request failed yields [`Error::MatrixCommittedButDurabilityUnproven`].
    /// Both skip the hook. After successful durable publication, hook failure
    /// yields [`Error::MatrixCommittedButHookFailed`]; retry only the notification.
    /// Outcome boxes are reserved fallibly before mutation; a late error needs
    /// no further allocation. See "Allocator Failure And Published Outcomes"
    /// in `docs/durability-model.md`.
    pub fn write_matrix_cell_durable<T, F>(
        &mut self,
        key: MatrixKey,
        value: &T,
        hook: F,
    ) -> Result<()>
    where
        T: VarlitMatrixBlock,
        F: FnOnce(MatrixCommitEvent) -> Result<()>,
    {
        self.file.write_matrix_cell_durable(key, value, hook)
    }

    /// [`Self::write_matrix_cell_durable`] with a caller-supplied durability
    /// barrier; the same post-commit contract applies, including
    /// [`Error::MatrixCommittedButHookFailed`] and
    /// [`Error::MatrixCommittedButDurabilityUnproven`]. Both barrier callbacks
    /// precede generation publication and receive the physical generation file.
    pub fn write_matrix_cell_durable_with_barrier<T, B, F>(
        &mut self,
        key: MatrixKey,
        value: &T,
        barrier: &mut B,
        hook: F,
    ) -> Result<()>
    where
        T: VarlitMatrixBlock,
        B: MatrixDurabilityBarrier + ?Sized,
        F: FnOnce(MatrixCommitEvent) -> Result<()>,
    {
        self.file
            .write_matrix_cell_durable_with_barrier(key, value, barrier, hook)
    }

    pub fn read_matrix_cell<T: VarlitMatrixBlock>(&self, key: MatrixKey) -> Result<T> {
        self.file.read_matrix_cell(key)
    }

    /// See [`VarlitFile::read_matrix_run_into`].
    pub fn read_matrix_run_into<T: VarlitMatrixBlock>(
        &self,
        start: MatrixKey,
        out: &mut [T],
    ) -> Result<()> {
        self.file.read_matrix_run_into(start, out)
    }

    /// See [`VarlitFile::read_matrix_run_bytes_into`].
    pub fn read_matrix_run_bytes_into<T: VarlitMatrixBlock>(
        &self,
        start: MatrixKey,
        out: &mut [u8],
    ) -> Result<()> {
        self.file.read_matrix_run_bytes_into::<T>(start, out)
    }

    /// See [`VarlitFile::read_matrix_column_into`].
    pub fn read_matrix_column_into<T: VarlitMatrixBlock>(
        &self,
        start: MatrixKey,
        out: &mut [T],
    ) -> Result<()> {
        self.file.read_matrix_column_into(start, out)
    }

    /// See [`VarlitFile::read_matrix_column_bytes_into`].
    pub fn read_matrix_column_bytes_into<T: VarlitMatrixBlock>(
        &self,
        start: MatrixKey,
        out: &mut [u8],
    ) -> Result<()> {
        self.file.read_matrix_column_bytes_into::<T>(start, out)
    }

    /// See [`VarlitFile::read_matrix_row_into`].
    pub fn read_matrix_row_into<T: VarlitMatrixBlock>(
        &self,
        row: u64,
        out: &mut [T],
    ) -> Result<()> {
        self.file.read_matrix_row_into(row, out)
    }

    pub fn matrix_cell_payload<T: VarlitMatrixBlock>(&self, key: MatrixKey) -> Result<Vec<u8>> {
        self.file.matrix_cell_payload::<T>(key)
    }

    pub fn matrix_aux_len(&self, name: &str) -> Result<u64> {
        self.file.matrix_aux_len(name)
    }

    pub fn read_matrix_aux(&self, name: &str, offset: u64, len: u64) -> Result<Vec<u8>> {
        self.file.read_matrix_aux(name, offset, len)
    }

    pub fn write_matrix_aux(&mut self, name: &str, offset: u64, payload: &[u8]) -> Result<()> {
        self.file.write_matrix_aux(name, offset, payload)
    }

    pub fn matrix_cell_status<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
    ) -> Result<MatrixCellStatus> {
        self.file.matrix_cell_status::<T>(key)
    }

    pub fn commit_matrix_cell<T: VarlitMatrixBlock>(&mut self, key: MatrixKey) -> Result<()> {
        self.file.commit_matrix_cell::<T>(key)
    }

    pub fn clear_matrix_cell<T: VarlitMatrixBlock>(&mut self, key: MatrixKey) -> Result<()> {
        self.file.clear_matrix_cell::<T>(key)
    }

    pub fn clear_matrix_cell_by_category(&mut self, category: &str, key: MatrixKey) -> Result<()> {
        self.file.clear_matrix_cell_by_category(category, key)
    }

    pub fn clear_matrix_category(&mut self, category: &str) -> Result<u64> {
        self.file.clear_matrix_category(category)
    }

    pub fn apply_matrix_recovery_action(&mut self, action: &MatrixRecoveryAction) -> Result<()> {
        self.file.apply_matrix_recovery_action(action)
    }

    pub fn rebuild_matrix_commit_from_crc<T: VarlitMatrixBlock>(&mut self) -> Result<u64> {
        self.file.rebuild_matrix_commit_from_crc::<T>()
    }

    pub fn is_matrix_single_committed(&self, name: &str) -> Result<bool> {
        self.file.is_matrix_single_committed(name)
    }

    pub fn set_matrix_single_committed(&mut self, name: &str, value: bool) -> Result<()> {
        self.file.set_matrix_single_committed(name, value)
    }

    pub fn is_matrix_channel_committed(&self, name: &str, channel: u64) -> Result<bool> {
        self.file.is_matrix_channel_committed(name, channel)
    }

    pub fn set_matrix_channel_committed(
        &mut self,
        name: &str,
        channel: u64,
        value: bool,
    ) -> Result<()> {
        self.file.set_matrix_channel_committed(name, channel, value)
    }

    pub fn matrix_resume_signal(&self, category: &str) -> Result<MatrixResumeSignal> {
        self.file.matrix_resume_signal(category)
    }

    pub fn matrix_sidecar_resume_signal<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
    ) -> Result<MatrixResumeSignal> {
        self.file
            .matrix_sidecar_resume_signal(category, sidecar_path)
    }

    pub fn matrix_verified_sidecar_resume_signal<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
    ) -> Result<MatrixResumeSignal> {
        self.file
            .matrix_verified_sidecar_resume_signal(category, sidecar_path)
    }

    pub fn matrix_verified_sidecar_resume_signal_with_generation<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
        expected_generation: u64,
    ) -> Result<MatrixResumeSignal> {
        self.file
            .matrix_verified_sidecar_resume_signal_with_generation(
                category,
                sidecar_path,
                expected_generation,
            )
    }

    pub fn write_matrix_sidecar<P: AsRef<Path>>(
        &mut self,
        category: &str,
        sidecar_path: P,
        generation: u64,
        payload: &[u8],
    ) -> Result<MatrixSidecarManifest> {
        self.file
            .write_matrix_sidecar(category, sidecar_path, generation, payload)
    }

    pub fn read_matrix_sidecar<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
    ) -> Result<(MatrixSidecarManifest, Vec<u8>)> {
        self.file.read_matrix_sidecar(category, sidecar_path)
    }

    pub fn read_matrix_sidecar_with_generation<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
        expected_generation: u64,
    ) -> Result<(MatrixSidecarManifest, Vec<u8>)> {
        self.file
            .read_matrix_sidecar_with_generation(category, sidecar_path, expected_generation)
    }

    pub fn matrix_recovery_report(&self) -> MatrixRecoveryReport {
        self.file.matrix_recovery_report()
    }
    /// Per-file sparse/allocation observations captured at create/open.
    pub fn matrix_storage_diagnostics(&self) -> Option<crate::MatrixStorageDiagnostics> {
        self.file.matrix_storage_diagnostics()
    }

    /// Verifies this matrix's commit metadata now, and reports what was found.
    ///
    /// See [`VarlitFile::verify_matrix_metadata`]: the same pass a
    /// `MatrixMetadataVerification::AtOpen` open runs, on demand, retaining one
    /// page buffer. It reports; it does not arm the quarantine.
    pub fn verify_matrix_metadata(&self) -> Result<MatrixRecoveryReport> {
        self.file.verify_matrix_metadata()
    }
}

/// The witness this file writer's disk-touching methods demand, typed by the
/// writer it speaks for. See `crate::writer_permit`.
pub(crate) type FileMutationPermit<'a> = MutationPermit<'a, VarlitFile>;

impl GuardedWriter for VarlitFile {
    fn poison_flag(&self) -> &PoisonFlag {
        &self.poison
    }
    fn poison_flag_mut(&mut self) -> &mut PoisonFlag {
        &mut self.poison
    }
}

impl VarlitFile {
    pub fn create<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Self::create_impl(spec, path.as_ref(), false)
    }

    /// Creates a new native file, failing if `path` already exists.
    ///
    /// Unlike [`VarlitFile::create`], this never truncates or reuses an
    /// existing file, so callers that must prove they created and own the
    /// file (for example diagnostic scaffolding) cannot destroy caller data.
    pub fn create_new<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Self::create_impl(spec, path.as_ref(), true)
    }

    fn create_impl(spec: FormatSpec, path: &Path, exclusive: bool) -> Result<Self> {
        let spec = spec.resolve_entrypoint();
        spec.validate()?;
        ensure_native_write_limits(spec)?;
        if spec.has_matrix_blocks() {
            return Err(Error::MatrixDimensionsRequired);
        }
        let path = path.to_path_buf();
        let lock = WriterLock::acquire(&path)?;
        // Everything past the acquisition runs inside `with_writer_lock`, so a
        // failure gives the claim back before the error propagates instead of at
        // scope exit; see `release_writer_lock_after_failure`.
        with_writer_lock(lock, |lock| {
            Self::create_locked(spec, path, exclusive, lock)
        })
    }

    fn create_locked(
        spec: FormatSpec,
        path: PathBuf,
        exclusive: bool,
        lock: &mut WriterLock,
    ) -> Result<Self> {
        let mut options = OpenOptions::new();
        options.read(true).write(true);
        if exclusive {
            options.create_new(true);
        } else {
            options.create(true);
        }
        let mut file = options.open(&path)?;
        // DUR2-05: bind the single-writer object lock before any destructive
        // initialization. Opening with `.truncate(true)` would clear the new
        // object inside the pre-bind window where a concurrent creator that
        // lost the race could still hold an unbound handle to it.
        lock.bind_native(&file, &path)?;
        file.set_len(0)?;
        file.seek(SeekFrom::Start(0))?;
        let header_extensions = write_file_header(spec, &mut file)?;
        let snapshot = SnapshotFile::new(file.try_clone()?)?;
        let mut file = Self {
            spec,
            path,
            file: RecordFile::new(file),
            index: ResidentIndex::empty(snapshot.clone(), spec),
            snapshot,
            mode: OpenMode::ReadWrite,
            follow_scan: None,
            header_extensions,
            matrix: None,
            matrix_creation_nonce: None,
            sequence_state: SequenceState::Available(0),
            checkpoint_cadence: CheckpointCadence::new_empty(),
            block_tails: BlockTails::new_empty(),
            segment_cursor: SegmentCursor::new_empty(),
            uncommitted_since_commit: false,
            record_buffer: Vec::new(),
            immediate_state: Default::default(),
            appended_since_digest: false,
            last_resident_block_id: None,
            keyed_tails: KeyedTails::new_empty(),
            // DUR3-01: this handle established the pathname, so its
            // directory entry is not durable until the first durability
            // request syncs the parent directory.
            open_chunk: None,
            chunk_directory: std::cell::OnceCell::new(),
            pending_pathname_parent_sync: true,
            opened_after_crash: false,
            poison: PoisonFlag::healthy(),
            _lock: None,
        };
        file.write_embedded_manifest_if_needed()?;
        file.mark_writer_open()?;
        Ok(file)
    }

    pub fn create_with_dims<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        dims: MatrixDimensions,
    ) -> Result<Self> {
        Self::create_with_dims_impl(spec, path.as_ref(), dims, false)
    }

    /// Creates a new native matrix file, failing if `path` already exists.
    ///
    /// Unlike [`VarlitFile::create_with_dims`], this never reuses or truncates
    /// an existing file object: the exclusive create *is* the ownership claim,
    /// and the same handle is kept locked from that claim through the complete
    /// matrix initialization. Diagnostic scaffolding (the format self-test)
    /// must use this instead of claiming the pathname with a separate handle
    /// and then re-opening it by name (API2-02).
    pub fn create_new_with_dims<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        dims: MatrixDimensions,
    ) -> Result<Self> {
        Self::create_with_dims_impl(spec, path.as_ref(), dims, true)
    }

    fn create_with_dims_impl(
        spec: FormatSpec,
        path: &Path,
        dims: MatrixDimensions,
        exclusive: bool,
    ) -> Result<Self> {
        let spec = spec.resolve_entrypoint();
        spec.validate()?;
        ensure_native_write_limits(spec)?;
        if !spec.has_matrix_blocks() {
            return Self::create_impl(spec, path, exclusive);
        }
        // Chunk 0 *is* the matrix region, and `chunk_for_row` divides by
        // `rows_per_chunk` to find it. If the declared extent were any other
        // value the two would disagree: with an extent of 100 and chunks of 4,
        // row 50 routes to chunk 12 while the region already holds it, and the
        // region's rows 4..100 become unreachable. Refused at create, where the
        // dimension value first exists.
        if let Some(growing) = spec.growing_matrix {
            let declared = dims
                .get(growing.name)
                .ok_or_else(|| Error::MatrixDimensionMissing(growing.name.to_string()))?;
            if declared != growing.rows_per_chunk {
                return Err(Error::MatrixSizeMismatch {
                    expected: growing.rows_per_chunk,
                    actual: declared,
                });
            }
            // A chunk is buffered against `MatrixSlotRegionLen` and written
            // against `RecordPayloadLen`, and nothing reconciled them: a spec
            // could pass `validate`, accept writes, and then die at the first
            // write with the data already in RAM and no way to get it out.
            // Refused here, before a byte is accepted.
            let written = chunk_payload_len_for(spec, &dims)?;
            spec.read_limits
                .check(ReadLimitKey::RecordPayloadLen, written)?;
            spec.read_limits
                .check(ReadLimitKey::MatrixSlotRegionLen, written)?;
        }
        let path = path.to_path_buf();
        let lock = WriterLock::acquire(&path)?;
        // As in `create_impl`: a failure past the acquisition gives the claim
        // back before the error propagates.
        with_writer_lock(lock, |lock| {
            Self::create_with_dims_locked(spec, path, dims, exclusive, lock)
        })
    }

    fn create_with_dims_locked(
        spec: FormatSpec,
        path: PathBuf,
        dims: MatrixDimensions,
        exclusive: bool,
        lock: &mut WriterLock,
    ) -> Result<Self> {
        let mut options = OpenOptions::new();
        options.read(true).write(true);
        if exclusive {
            options.create_new(true);
        } else {
            options.create(true);
        }
        let mut file = options.open(&path)?;
        // DUR2-05: bind the single-writer object lock before any destructive
        // initialization; see `create_impl`.
        lock.bind_native(&file, &path)?;
        file.set_len(0)?;
        file.seek(SeekFrom::Start(0))?;
        let header_extensions = write_file_header(spec, &mut file)?;
        // DUR2-03: stamp a fresh creation nonce so this logical matrix is
        // distinguishable from any earlier matrix that lived in the same OS
        // file object at the same layout offsets.
        let creation_nonce = fresh_matrix_creation_nonce();
        write_matrix_creation_nonce_region(&mut file, creation_nonce)?;
        let header_len = file.stream_position()?;
        let matrix = crate::matrix::create_layout(spec, &mut file, header_len, &dims)?;
        let mut matrix_pages = crate::matrix_generation::MatrixFile::create(
            &path,
            &file,
            matrix.append_log_start(),
            creation_nonce,
            matrix_pending_limit(spec),
        )?;
        matrix_pages.set_cache_bytes(spec.read_limits.matrix_generation_cache_budget());
        matrix_pages.set_traversal_bytes(limit_or_max(
            spec.read_limits.require(ReadLimitKey::ScanBytes)?,
        ));
        let snapshot = SnapshotFile::new(file.try_clone()?)?;
        let mut file = Self {
            spec,
            path,
            file: RecordFile::new(file).with_matrix(Some(matrix_pages)),
            index: ResidentIndex::empty(snapshot.clone(), spec),
            snapshot,
            mode: OpenMode::ReadWrite,
            follow_scan: None,
            header_extensions,
            matrix: Some(matrix),
            matrix_creation_nonce: Some(creation_nonce),
            sequence_state: SequenceState::Available(0),
            checkpoint_cadence: CheckpointCadence::new_empty(),
            block_tails: BlockTails::new_empty(),
            segment_cursor: SegmentCursor::new_empty(),
            uncommitted_since_commit: false,
            record_buffer: Vec::new(),
            immediate_state: Default::default(),
            appended_since_digest: false,
            last_resident_block_id: None,
            keyed_tails: KeyedTails::new_empty(),
            // DUR3-01: this handle established the pathname, so its
            // directory entry is not durable until the first durability
            // request syncs the parent directory.
            open_chunk: None,
            chunk_directory: std::cell::OnceCell::new(),
            pending_pathname_parent_sync: true,
            opened_after_crash: false,
            poison: PoisonFlag::healthy(),
            _lock: None,
        };
        file.write_embedded_manifest_if_needed()?;
        file.mark_writer_open()?;
        Ok(file)
    }

    /// Opens a read-only handle that keeps **no** record directory, and hands
    /// the directory to the caller.
    ///
    /// The last thing about an open that still scales with the file is the
    /// 16-byte directory slot per record. This is the option that removes it
    /// from varlit's side. It is not a reduction in capability: `blocks`,
    /// `scan`, `keyed_blocks`, `metadata`, `verify_all` and the rest all still
    /// work — through [`with_directory`](Self::with_directory), which is where
    /// the directory now is.
    ///
    /// ```ignore
    /// let mut index = Vec::new();
    /// let file = VarlitFile::open_readonly_without_directory(spec, path, &mut index)?;
    /// let points = file.with_directory(&index)?.blocks::<Point>()?;
    /// // and `file.blocks::<Point>()` refuses with `NoResidentDirectory`,
    /// // naming `with_directory`, rather than answering as if empty.
    /// ```
    ///
    /// **`index` is output, not scratch** — the one place in this crate where a
    /// caller-supplied buffer is kept rather than reused. That is deliberate
    /// and it is why the parameter is not optional: a handle that keeps no
    /// directory cannot produce one afterwards, so a caller who did not take it
    /// here would have no way to read the file positionally at all. Taking the
    /// buffer is what makes the option impossible to half-use.
    ///
    /// Read-only. A writer keeps its directory unconditionally: the checkpoint
    /// cadence, the segment cursor and the append rollback all resolve
    /// positions through it, so there is nothing to hand over.
    pub fn open_readonly_without_directory<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        index: &mut Vec<RecordIndexEntry>,
    ) -> Result<Self> {
        Self::open_readonly_inner(spec, path, index, DirectoryRetention::None)
    }

    /// Opens a read-write handle.
    ///
    /// **This allocates the scan's entry buffer.**
    /// [`open_with_scratch`](Self::open_with_scratch) takes the caller's
    /// instead; see [`open_readonly_with_scratch`](Self::open_readonly_with_scratch)
    /// for what that buffer is and why the caller owns it.
    pub fn open<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Self::open_with_lock_policy(spec, path, WriterLockBreakPolicy::Refuse)
    }

    /// Opens a read-write handle, scanning into the caller's buffer.
    ///
    /// See [`open_readonly_with_scratch`](Self::open_readonly_with_scratch):
    /// `scratch` is scratch, not output, and is cleared on entry.
    pub fn open_with_scratch<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        scratch: &mut Vec<RecordIndexEntry>,
    ) -> Result<Self> {
        let spec = spec.resolve_entrypoint();
        spec.validate()?;
        ensure_native_open_limits(spec)?;
        let path = path.as_ref().to_path_buf();
        let lock = WriterLock::acquire(&path)?;
        // Every way this open can fail - a rejected header, a version or schema
        // mismatch, a read-limit refusal, a corrupt tail - happens after the
        // claim was taken, so all of them release it here. See
        // `with_writer_lock`.
        with_writer_lock(lock, |lock| {
            Self::open_locked_with_scratch(spec, path, lock, scratch)
        })
    }

    fn open_locked(spec: FormatSpec, path: PathBuf, lock: &mut WriterLock) -> Result<Self> {
        let mut scratch = BufferedScan::new(spec);
        Self::open_locked_with_scratch(spec, path, lock, &mut scratch)
    }

    fn open_locked_with_scratch<B: ScanBuffer>(
        spec: FormatSpec,
        path: PathBuf,
        lock: &mut WriterLock,
        scratch: &mut B,
    ) -> Result<Self> {
        let mut file = OpenOptions::new().read(true).write(true).open(&path)?;
        lock.bind_native(&file, &path)?;
        let captured_len = check_open_file_len(spec, &file)?;
        let (header_len, header_extensions) = read_file_header_parts(spec, &mut file)?;
        let (matrix, matrix_creation_nonce, matrix_pages) = split_matrix_state(
            read_matrix_layout_if_needed(&path, true, spec, &mut file, header_len, captured_len)?,
        );
        let append_start = append_log_start(header_len, matrix.as_ref());
        let index = load_generation_index(
            spec,
            &mut file,
            append_start,
            ScanIntent::Writer,
            scratch,
            matrix_pages.as_ref(),
        )?;
        // The sequence high-water mark and the block tails come from the scan
        // rather than from the index, because the index is filtered: a
        // non-resident block's records are on disk and not in it.
        let sequence_state = index.sequence_state();
        let block_tails = index.block_tails()?;
        let frames_verified = index.frames_verified;
        let index = &*scratch;
        // The crash verdict has to be read *before* the handle exists, because
        // truncation happens here and would destroy the evidence it decides
        // about. `mark_writer_open` re-reads it for the handle's own field; the
        // two agree because nothing has written the block in between.
        let previous_writer_crashed = decode_liveness_flags(header_len, &header_extensions)?
            .is_some_and(|flags| flags & LIVENESS_FLAG_DIRTY != 0);
        let pending_mark = truncate_uncommitted_tail_if_needed(
            spec,
            &mut file,
            append_start,
            index,
            previous_writer_crashed,
        )?;
        let derived = derive_index_state(index.entries(), false)?;
        let checkpoint_cadence = derived.checkpoint_cadence;
        let segment_cursor = derived.segment_cursor;
        let snapshot = SnapshotFile::from_file_with_len(
            file.try_clone()?,
            matrix_pages
                .as_ref()
                .map_or(file.metadata()?.len(), |p| p.head().native_eof),
        )?;
        let mut opened = Self {
            spec,
            path,
            file: RecordFile::new(file).with_matrix(matrix_pages),
            index: ResidentIndex::adopt_generation(
                index,
                snapshot.clone(),
                spec,
                frames_verified,
            )?,
            snapshot,
            mode: OpenMode::ReadWrite,
            follow_scan: None,
            header_extensions,
            matrix,
            matrix_creation_nonce,
            sequence_state,
            checkpoint_cadence,
            block_tails,
            open_chunk: None,
            chunk_directory: std::cell::OnceCell::new(),
            segment_cursor,
            uncommitted_since_commit: false,
            record_buffer: Vec::new(),
            immediate_state: Default::default(),
            appended_since_digest: false,
            last_resident_block_id: index.last_entry()?.map(|entry| entry.block_id),
            keyed_tails: KeyedTails::new_empty(),
            pending_pathname_parent_sync: false,
            opened_after_crash: false,
            poison: PoisonFlag::healthy(),
            _lock: None,
        };
        opened.mark_writer_open()?;
        if let Some(from) = pending_mark {
            opened.recover_marked_tail(from)?;
        }
        Ok(opened)
    }

    pub fn open_with_lock_policy<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        policy: WriterLockBreakPolicy,
    ) -> Result<Self> {
        let spec = spec.resolve_entrypoint();
        spec.validate()?;
        ensure_native_open_limits(spec)?;
        let path = path.as_ref().to_path_buf();
        let lock = WriterLock::acquire_with_policy(&path, policy)?;
        // A broken stale claim that then fails to open must not become a new
        // stale claim of this process's own making.
        with_writer_lock(lock, |lock| Self::open_locked(spec, path, lock))
    }

    /// Opens a read-only handle.
    ///
    /// Uses bounded scan/directory buffers and private temporary spill files.
    /// [`open_readonly_with_scratch`](Self::open_readonly_with_scratch) instead
    /// fills a reusable caller-owned entry array, which retains its result-size limit.
    pub fn open_readonly<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        let mut scratch = BufferedScan::new(spec);
        Self::open_readonly_inner(spec, path, &mut scratch, DirectoryRetention::Keep)
    }

    /// Opens a read-only handle, scanning into the caller's buffer.
    ///
    /// `scratch` is where the open path builds the entries it reads out of the
    /// file. It is **scratch, not output**: the handle keeps a 16-byte
    /// directory slot per record and rebuilds each entry from the record when
    /// asked, so nothing in `scratch` is retained past this call and the caller
    /// may clear it, reuse it for the next open, or drop it.
    ///
    /// Taking it here is the point. The entry buffer is the largest allocation
    /// an open makes — it scales with record count — and a library that sizes
    /// and owns it decides the caller's memory for them. Opening a thousand
    /// files through one buffer allocates once, not a thousand times.
    ///
    /// The buffer is cleared on entry, so its previous contents never leak into
    /// this file's index.
    pub fn open_readonly_with_scratch<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
        scratch: &mut Vec<RecordIndexEntry>,
    ) -> Result<Self> {
        Self::open_readonly_inner(spec, path, scratch, DirectoryRetention::Keep)
    }

    fn open_readonly_inner<P: AsRef<Path>, B: ScanBuffer>(
        spec: FormatSpec,
        path: P,
        scratch: &mut B,
        retention: DirectoryRetention,
    ) -> Result<Self> {
        let spec = spec.resolve_entrypoint();
        spec.validate()?;
        ensure_native_open_limits(spec)?;
        let path = path.as_ref().to_path_buf();
        let mut file = OpenOptions::new().read(true).open(&path)?;
        let captured_len = check_open_file_len(spec, &file)?;
        let (header_len, header_extensions) = read_file_header_parts(spec, &mut file)?;
        let (matrix, matrix_creation_nonce, matrix_pages) = split_matrix_state(
            read_matrix_layout_if_needed(&path, false, spec, &mut file, header_len, captured_len)?,
        );
        let append_start = append_log_start(header_len, matrix.as_ref());
        let scanned = load_generation_index(
            spec,
            &mut file,
            append_start,
            ScanIntent::ReadOnly,
            scratch,
            matrix_pages.as_ref(),
        )?;
        let sequence_state = scanned.sequence_state();
        let block_tails = scanned.block_tails()?;
        let frames_verified = scanned.frames_verified;
        // The snapshot comes from the scan, not from the resident list. The
        // list is filtered — a non-resident block's records are on disk and not
        // in it, exactly as `open_locked`'s comment says — so binding the
        // snapshot to its last entry stopped a read-only handle at the last
        // *resident* record. Under a markerless policy that ends on a
        // non-resident block, that is before every record of that block, and
        // `block_chain`, the published way to reach one, walks through the
        // snapshot.
        //
        // It is still not the file's physical length: a torn trailing record
        // must leave the snapshot at the end of the last complete record, and
        // under a marker policy the uncommitted tail a writer open would delete
        // must not be visible here either. Both facts belong to the scan.
        let logical_len = scanned.physical_end(append_start);
        let index = &*scratch;
        let derived = derive_index_state(index.entries(), false)?;
        let checkpoint_cadence = derived.checkpoint_cadence;
        let segment_cursor = derived.segment_cursor;
        let snapshot = SnapshotFile::from_file_with_len(file.try_clone()?, logical_len)?;
        Ok(Self {
            spec,
            path,
            file: RecordFile::new(file).with_matrix(matrix_pages),
            index: match retention {
                // Not "built and then dropped": a caller that asked for no
                // directory never has one allocated on its behalf. `N` slots is
                // the largest thing an open would have taken, and the point of
                // the option is that varlit does not take it.
                DirectoryRetention::None => ResidentIndex::none_retained(snapshot.clone(), spec),
                DirectoryRetention::Keep => ResidentIndex::adopt_generation(
                    index,
                    snapshot.clone(),
                    spec,
                    frames_verified,
                    )?,
            },
            snapshot,
            mode: OpenMode::ReadOnly,
            follow_scan: None,
            header_extensions,
            matrix,
            matrix_creation_nonce,
            sequence_state,
            checkpoint_cadence,
            block_tails,
            open_chunk: None,
            chunk_directory: std::cell::OnceCell::new(),
            segment_cursor,
            uncommitted_since_commit: false,
            record_buffer: Vec::new(),
            immediate_state: Default::default(),
            appended_since_digest: false,
            last_resident_block_id: index.last_entry()?.map(|entry| entry.block_id),
            keyed_tails: KeyedTails::new_empty(),
            pending_pathname_parent_sync: false,
            opened_after_crash: false,
            poison: PoisonFlag::healthy(),
            _lock: None,
        })
    }

    /// Opens read-only **without reading the records at all**, using the open
    /// digest at the end of the file.
    ///
    /// The three facts an open needs — where the committed file ends, the next
    /// append's sequence, each block's newest record — are the by-product of
    /// walking every record, and that walk is the only reason an open that keeps
    /// no index still reads the whole file. `IndexPolicy::open_digest_on_flush`
    /// writes them down at each commit point; this reads them back.
    ///
    /// Measured, 50,000 records:
    ///
    /// | open | read syscalls | bytes read | file overhead |
    /// | --- | --- | --- | --- |
    /// | `open_readonly` (scan) | 100,316 | 3,207,102 | — |
    /// | `open_readonly` (segment chain) | 516 | 7,332,522 | +3.67 MB |
    /// | this, from a digest | **20** | **516** | **+12.8 KB** |
    ///
    /// The last column is the one that decides which of the two tail records a
    /// format wants. A segment writes an entry per record it covers, so its
    /// overhead grows with the file; a digest writes twelve bytes per distinct
    /// block id, so the 12.8 KB above is a hundred flushes' worth and would be
    /// the same at a billion records. What the segment buys for its size is an
    /// open that *builds the index*; a digest deliberately does not.
    ///
    /// The handle keeps **no directory**, because there is none to keep — no
    /// record was framed. Position-based reads (`blocks`, `scan`,
    /// `keyed_blocks`) refuse with `NoResidentDirectory` naming
    /// [`with_directory`](Self::with_directory), and the index the caller
    /// actually needs is built with [`record_map`](Self::record_map), which
    /// walks only as far as the question. That pairing is the point: an open
    /// that reads nothing, and an index that reads only what was asked for.
    ///
    /// What still works with no directory at all, because none of it goes
    /// through positions: [`block_chain`](Self::block_chain) and
    /// [`block_tail_offset`](Self::block_tail_offset) — the digest carries the
    /// tails, which is why it carries them — [`read_block_at`](Self::read_block_at),
    /// and every `_into` read that takes an entry.
    ///
    /// **Falls back to the full scan** when the file has no usable digest: one
    /// written before the option was enabled, one whose writer appended past
    /// its last commit, one truncated or rotted. That is not an error — the
    /// file is readable and this opens it — but it is the difference between
    /// eleven syscalls and a hundred thousand, so
    /// [`open_readonly_lazy_with_report`](Self::open_readonly_lazy_with_report)
    /// says which happened.
    pub fn open_readonly_lazy<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Ok(Self::open_readonly_lazy_with_report(spec, path)?.0)
    }

    /// [`open_readonly_lazy`](Self::open_readonly_lazy), and which of the two
    /// routes it took.
    pub fn open_readonly_lazy_with_report<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
    ) -> Result<(Self, LazyOpenSource)> {
        let spec = spec.resolve_entrypoint();
        spec.validate()?;
        ensure_native_open_limits(spec)?;
        let path = path.as_ref().to_path_buf();
        // The header table first, because nothing appended can hide it; the
        // digest second, because a file written before the option existed has
        // only that. Each failure is a fall-through, not an error, exactly as
        // the digest already falls through to the scan.
        if spec.index_policy.header_tails
            && let Ok(file) =
                Self::open_readonly_from_digest(spec, &path, LazyOpenSource::HeaderTails)
        {
            return Ok((file, LazyOpenSource::HeaderTails));
        }
        match Self::open_readonly_from_digest(spec, &path, LazyOpenSource::Digest) {
            Ok(file) => Ok((file, LazyOpenSource::Digest)),
            // Only a *spec-level* refusal propagates, exactly as it does for
            // the segment chain: those describe the caller's configuration and
            // the scan would give the same answer.
            Err(error @ Error::MissingResourceLimit { .. })
            | Err(error @ Error::TrustedUnboundedRequiresExplicitApi { .. }) => Err(error),
            Err(_) => {
                // The scan needs somewhere to put the entries it frames. This
                // buffer is transient — the handle keeps no directory either
                // way — but it is `N` entries while it lives, which is the cost
                // of the fallback and is why the report exists.
                let mut scratch = BufferedScan::new(spec);
                let file =
                    Self::open_readonly_inner(spec, path, &mut scratch, DirectoryRetention::None)?;
                Ok((file, LazyOpenSource::FullScan))
            }
        }
    }

    /// Opens a **read-write** handle from the digest, without scanning.
    ///
    /// The writer twin of [`open_readonly_lazy`](Self::open_readonly_lazy), and
    /// the half that was missing. Every other writer open calls `load_index`
    /// with `ScanIntent::Writer`, so it is `O(records)` in time and in retained
    /// memory at any file size — which put the standing "TB-scale files must
    /// work, memory bounded by the working set" requirement on the read side
    /// only, while the workload that requirement names as primary is
    /// continuous append, and a continuous appender reopens its writer on every
    /// restart.
    ///
    /// **Falls back to the scanning open** on any file whose digest is not
    /// usable, exactly as the read-only route does, and
    /// [`open_lazy_with_report`](Self::open_lazy_with_report) says which
    /// happened.
    ///
    /// # What this handle does not have
    ///
    /// No resident directory, the same as the read-only digest open:
    /// `blocks::<T>()` refuses with `NoResidentDirectory` and
    /// [`record_map`](Self::record_map) is the way to walk records. Appending
    /// is unaffected — the append path maintains `block_tails` and the sequence
    /// itself, and the digest supplied both.
    ///
    /// # Why `checkpoint_on_flush` and `segment_on_flush` are refused
    ///
    /// Not because their state is hard to recover — that was the reading of
    /// `open_readonly_from_digest`'s comment about the walk, and it is the
    /// wrong one. `CheckpointCadence` is two `usize`s and `SegmentCursor`'s
    /// `next_position` is *a position in the resident index*. Both records
    /// serialize that index: a checkpoint writes the whole of it, a segment one
    /// entry per record. A handle that keeps no index has nothing to write, so
    /// the cadence is not approximate here, it has no referent. Refusing the
    /// combination at open is honest where writing nothing would leave files
    /// that open slower than their spec claims.
    pub fn open_lazy<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Ok(Self::open_lazy_with_report(spec, path)?.0)
    }

    /// [`open_lazy`](Self::open_lazy), and which of the two routes it took.
    pub fn open_lazy_with_report<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
    ) -> Result<(Self, LazyOpenSource)> {
        let spec = spec.resolve_entrypoint();
        spec.validate()?;
        ensure_native_open_limits(spec)?;
        if spec.index_policy.checkpoint_on_flush {
            return Err(Error::LazyWriterIndexPolicy {
                policy: "checkpoint_on_flush",
            });
        }
        if spec.index_policy.segment_on_flush {
            return Err(Error::LazyWriterIndexPolicy {
                policy: "segment_on_flush",
            });
        }
        let path = path.as_ref().to_path_buf();
        let lock = WriterLock::acquire(&path)?;
        // The claim is taken before either route runs and released by
        // `with_writer_lock_value` on every failure, the same as the scanning
        // open — a lazy attempt that falls back must not hold two claims, and a
        // refused one must not leave a stale claim behind.
        let ((mut file, source), lock) = with_writer_lock_value(lock, |lock| {
            if spec.index_policy.header_tails
                && let Ok(file) =
                    Self::open_writer_from_digest(spec, &path, lock, LazyOpenSource::HeaderTails)
            {
                return Ok((file, LazyOpenSource::HeaderTails));
            }
            match Self::open_writer_from_digest(spec, &path, lock, LazyOpenSource::Digest) {
                Ok(file) => Ok((file, LazyOpenSource::Digest)),
                // Only a spec-level refusal propagates, exactly as it does for
                // the read-only route: those describe the caller's
                // configuration and the scan would answer the same.
                Err(error @ Error::MissingResourceLimit { .. })
                | Err(error @ Error::TrustedUnboundedRequiresExplicitApi { .. }) => Err(error),
                Err(_) => {
                    let mut scratch = BufferedScan::new(spec);
                    let file = Self::open_locked_with_scratch(
                        spec,
                        path.try_clone()?,
                        lock,
                        &mut scratch,
                    )?;
                    Ok((file, LazyOpenSource::FullScan))
                }
            }
        })?;
        // Installed here rather than inside the body, the same as
        // `with_writer_lock` does it: the body runs twice on the fallback path
        // and must not claim the lock either time.
        file._lock = Some(lock);
        Ok((file, source))
    }

    /// The digest route for a writer: no scan, no directory, and the writer
    /// lock already bound by the caller.
    fn open_writer_from_digest(
        spec: FormatSpec,
        path: &Path,
        lock: &mut WriterLock,
        source: LazyOpenSource,
    ) -> Result<Self> {
        let mut file = OpenOptions::new().read(true).write(true).open(path)?;
        lock.bind_native(&file, path)?;
        let captured_len = check_open_file_len(spec, &file)?;
        let (header_len, header_extensions) = read_file_header_parts(spec, &mut file)?;
        let (matrix, matrix_creation_nonce, matrix_pages) = split_matrix_state(
            read_matrix_layout_if_needed(path, true, spec, &mut file, header_len, captured_len)?,
        );
        let append_start = append_log_start(header_len, matrix.as_ref());
        // No `truncate_uncommitted_tail_if_needed`, and both routes earn that
        // the same way — by requiring the thing they read to account for the
        // file all the way to its last byte.
        //
        // The digest does it by position: `frame_open_digest` refuses a digest
        // whose extent does not end exactly at the file's length, so a digest
        // that was found is the last record and was written at a commit point.
        //
        // The header table cannot do it by position — it is at a fixed offset
        // and is always "last" — so it does it by walking:
        // `corroborate_header_tails` frames the commit marker the slot names
        // and steps forward through at most a segment and a digest, and refuses
        // unless that lands exactly on the file's length. A file with records
        // past its last marker overshoots and this route fails into the scan,
        // which is the open that does truncate.
        //
        // Either way a file that reaches the line below has no uncommitted tail
        // to cut. `a_file_with_an_uncommitted_tail_is_truncated_by_the_scan`
        // is what holds that for the header route.
        let captured_len = matrix_pages
            .as_ref()
            .map_or(captured_len, |pages| pages.head().native_eof);
        let digest = read_lazy_block_tails(
            spec,
            &mut file,
            append_start,
            captured_len,
            header_len,
            &header_extensions,
            source,
        )?;
        let snapshot = SnapshotFile::from_file_with_len(file.try_clone()?, digest.physical_end)?;
        Ok(Self {
            spec,
            path: path.to_path_buf(),
            file: RecordFile::new(file).with_matrix(matrix_pages),
            index: ResidentIndex::none_retained(snapshot.clone(), spec),
            snapshot,
            mode: OpenMode::ReadWrite,
            follow_scan: None,
            header_extensions,
            matrix,
            matrix_creation_nonce,
            sequence_state: match digest.sequence_high_water {
                None => SequenceState::Available(0),
                Some(u64::MAX) => SequenceState::Exhausted,
                Some(sequence) => SequenceState::Available(sequence + 1),
            },
            // Both are refused above rather than approximated: see
            // `open_lazy`'s doc. Empty is what "never used" looks like.
            checkpoint_cadence: CheckpointCadence::new_empty(),
            segment_cursor: SegmentCursor::new_empty(),
            block_tails: digest.block_tails,
            open_chunk: None,
            chunk_directory: std::cell::OnceCell::new(),
            uncommitted_since_commit: false,
            record_buffer: Vec::new(),
            immediate_state: Default::default(),
            // The file ends with a digest describing everything before it, so
            // there is nothing to describe until something is appended. Both
            // terms of `needs_open_digest` are false here, which is right.
            appended_since_digest: false,
            last_resident_block_id: None,
            keyed_tails: KeyedTails::new_empty(),
            pending_pathname_parent_sync: false,
            opened_after_crash: false,
            poison: PoisonFlag::healthy(),
            _lock: None,
        })
    }

    fn open_readonly_from_digest(
        spec: FormatSpec,
        path: &Path,
        source: LazyOpenSource,
    ) -> Result<Self> {
        let mut file = OpenOptions::new().read(true).open(path)?;
        let captured_len = check_open_file_len(spec, &file)?;
        let (header_len, header_extensions) = read_file_header_parts(spec, &mut file)?;
        let (matrix, matrix_creation_nonce, matrix_pages) = split_matrix_state(
            read_matrix_layout_if_needed(path, false, spec, &mut file, header_len, captured_len)?,
        );
        let append_start = append_log_start(header_len, matrix.as_ref());
        let captured_len = matrix_pages
            .as_ref()
            .map_or(captured_len, |pages| pages.head().native_eof);
        let digest = read_lazy_block_tails(
            spec,
            &mut file,
            append_start,
            captured_len,
            header_len,
            &header_extensions,
            source,
        )?;
        let snapshot = SnapshotFile::from_file_with_len(file.try_clone()?, digest.physical_end)?;
        Ok(Self {
            spec,
            path: path.to_path_buf(),
            file: RecordFile::new(file).with_matrix(matrix_pages),
            index: ResidentIndex::none_retained(snapshot.clone(), spec),
            snapshot,
            mode: OpenMode::ReadOnly,
            follow_scan: None,
            header_extensions,
            matrix,
            matrix_creation_nonce,
            sequence_state: match digest.sequence_high_water {
                None => SequenceState::Available(0),
                Some(u64::MAX) => SequenceState::Exhausted,
                Some(sequence) => SequenceState::Available(sequence + 1),
            },
            // Both are writer state — when the next checkpoint is due, which
            // records the next segment covers — and this handle is read-only.
            // Recovering them is what would have required the walk.
            checkpoint_cadence: CheckpointCadence::new_empty(),
            segment_cursor: SegmentCursor::new_empty(),
            block_tails: digest.block_tails,
            open_chunk: None,
            chunk_directory: std::cell::OnceCell::new(),
            uncommitted_since_commit: false,
            record_buffer: Vec::new(),
            immediate_state: Default::default(),
            appended_since_digest: false,
            // No record was framed, so there is nothing to seed this from — and
            // nothing to seed it for: it is append-path state and this handle is
            // read-only.
            last_resident_block_id: None,
            keyed_tails: KeyedTails::new_empty(),
            pending_pathname_parent_sync: false,
            opened_after_crash: false,
            poison: PoisonFlag::healthy(),
            _lock: None,
        })
    }

    pub fn open_recover<P: AsRef<Path>>(spec: FormatSpec, path: P) -> Result<Self> {
        Ok(Self::open_recover_with_report(spec, path)?.0)
    }

    pub fn open_recover_with_report<P: AsRef<Path>>(
        spec: FormatSpec,
        path: P,
    ) -> Result<(Self, RecoveryReport)> {
        let spec = spec.resolve_entrypoint();
        spec.validate()?;
        ensure_native_open_limits(spec)?;
        let path = path.as_ref().to_path_buf();
        let lock = WriterLock::acquire(&path)?;
        // This shape is a pair, not a bare `VarlitFile`, so it uses
        // `with_writer_lock_value` and installs the claim itself.
        let ((mut file, report), lock) =
            with_writer_lock_value(lock, |lock| Self::open_recover_locked(spec, path, lock))?;
        file._lock = Some(lock);
        Ok((file, report))
    }

    fn open_recover_locked(
        spec: FormatSpec,
        path: PathBuf,
        lock: &mut WriterLock,
    ) -> Result<(Self, RecoveryReport)> {
        let mut scratch = BufferedScan::new(spec);
        Self::open_recover_locked_with_scratch(spec, path, lock, &mut scratch)
    }

    fn open_recover_locked_with_scratch<B: ScanBuffer>(
        spec: FormatSpec,
        path: PathBuf,
        lock: &mut WriterLock,
        scratch: &mut B,
    ) -> Result<(Self, RecoveryReport)> {
        let mut file = OpenOptions::new().read(true).write(true).open(&path)?;
        lock.bind_native(&file, &path)?;
        let original_len = file.metadata()?.len();
        let (header_len, header_extensions) = read_file_header_parts(spec, &mut file)?;
        let (matrix, matrix_creation_nonce, matrix_pages) = split_matrix_state(
            read_matrix_layout_if_needed(&path, true, spec, &mut file, header_len, original_len)?,
        );
        let append_start = append_log_start(header_len, matrix.as_ref());
        let index = load_generation_index(
            spec,
            &mut file,
            append_start,
            ScanIntent::Recover,
            scratch,
            matrix_pages.as_ref(),
        )?;
        let sequence_state = index.sequence_state();
        let block_tails = index.block_tails()?;
        let frames_verified = index.frames_verified;
        let index = &*scratch;
        // No mark here: this route reaches a file that already ended at a
        // commit point, so there is no tail. See the digest's frame check.
        truncate_uncommitted_tail_if_needed(spec, &mut file, append_start, index, false)?;
        let recovered_len = file.metadata()?.len();
        let derived = derive_index_state(index.entries(), false)?;
        let checkpoint_cadence = derived.checkpoint_cadence;
        let segment_cursor = derived.segment_cursor;
        let records_preserved = index.record_count();
        let snapshot = SnapshotFile::from_file_with_len(
            file.try_clone()?,
            matrix_pages
                .as_ref()
                .map_or(file.metadata()?.len(), |p| p.head().native_eof),
        )?;
        Ok((
            Self {
                spec,
                path,
                file: RecordFile::new(file).with_matrix(matrix_pages),
                index: ResidentIndex::adopt_generation(
                    index,
                    snapshot.clone(),
                    spec,
                    frames_verified,
                    )?,
                snapshot,
                mode: OpenMode::ReadWrite,
                follow_scan: None,
                header_extensions,
                matrix,
                matrix_creation_nonce,
                sequence_state,
                checkpoint_cadence,
                block_tails,
                open_chunk: None,
                chunk_directory: std::cell::OnceCell::new(),
                segment_cursor,
                uncommitted_since_commit: false,
                record_buffer: Vec::new(),
                immediate_state: Default::default(),
                appended_since_digest: false,
                last_resident_block_id: index.last_entry()?.map(|entry| entry.block_id),
                keyed_tails: KeyedTails::new_empty(),
                pending_pathname_parent_sync: false,
                opened_after_crash: false,
                poison: PoisonFlag::healthy(),
                _lock: None,
            },
            RecoveryReport {
                original_len,
                recovered_len,
                records_preserved,
            },
        ))
    }

    pub fn spec(&self) -> FormatSpec {
        self.spec.ordinary_read()
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub(crate) fn snapshot(&self) -> &SnapshotFile {
        &self.snapshot
    }

    pub fn mode(&self) -> OpenMode {
        self.mode
    }

    pub fn push<T: VarlitBlock>(&mut self, block: &T) -> Result<u64> {
        Ok(self.push_info(block)?.sequence)
    }

    /// Appends a block without a keyed predecessor link.
    ///
    /// API2-05: a keyed block cannot go through this entry point when the
    /// format enables `keyed_offset_chain`. `T: VarlitBlock` exposes no key, so
    /// this path can only write `prev_same_key_offset = None`, which silently
    /// truncates the physical keyed chain as soon as a second record shares a
    /// key. Such calls are rejected with
    /// [`Error::KeyedChainRequiresKeyedApi`]; use the generated keyed writer
    /// method or [`VarlitFile::push_keyed_info`], both of which maintain the
    /// chain. The bounded streaming and indexed writers already reject the
    /// same combination.
    pub fn push_info<T: VarlitBlock>(&mut self, block: &T) -> Result<AppendInfo> {
        if self.spec.index_policy.keyed_offset_chain && T::IS_KEYED {
            return Err(Error::KeyedChainRequiresKeyedApi { block_id: T::ID });
        }
        self.push_with_prev_key_info(block, None)
    }

    /// Appends a keyed block through the generic API, linking it to the
    /// previous record with the same key.
    ///
    /// This is the generic equivalent of the generated `push_<block>` writer
    /// method. The predecessor comes from a per-block-id tail map that is
    /// built once from the resident index on first use for a given block type
    /// (`O(N)` decode of that block's records, exactly what the generated
    /// writer pays at open) and then maintained in O(1) per append. Formats
    /// without `keyed_offset_chain` skip the map entirely.
    ///
    /// Interleaving this with [`VarlitFile::push_with_prev_key_info`] for the
    /// same block id is supported but drops the cached map: a caller-supplied
    /// link carries no key the file can observe, so the next call here rebuilds.
    pub fn push_keyed<T>(&mut self, block: &T) -> Result<u64>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        Ok(self.push_keyed_info(block)?.sequence)
    }

    /// Appends a keyed block through the generic API, linking it to the
    /// previous record with the same key. See [`VarlitFile::push_keyed`].
    pub fn push_keyed_info<T>(&mut self, block: &T) -> Result<AppendInfo>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        // API2-03: keyed generic entry points evaluate the compile-time
        // keyedness contract post-monomorphization.
        let () = crate::traits::KeyedBlockContract::<T>::OK;
        if !self.spec.index_policy.keyed_offset_chain {
            return self.push_with_prev_key_info_unlinked(block, None);
        }
        let _permit = self.ensure_write()?;
        let key = encode_internal_key_payload::<T>(self.spec, &block.key())?;
        // API3-01: every fallible part of the tail-cache update happens here,
        // strictly before the append that the update describes. See
        // [`VarlitFile::reserve_keyed_tail_slot`].
        let previous = self.reserve_keyed_tail_slot::<T>(&key)?;
        let info = self.push_with_prev_key_info_unlinked(block, previous)?;
        self.commit_keyed_tail(T::ID, key, info.record_offset);
        Ok(info)
    }

    /// Returns the maintained keyed tails for `T`, building them from the
    /// resident index the first time this block type is used.
    fn keyed_tail_map<T>(&mut self) -> Result<&mut KeyedTailMap>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        if !self.keyed_tails.tails.contains_key(&T::ID) {
            let spec = self.spec;
            crate::collections::ensure_registered_block::<T>(spec)?;
            let mut built = KeyedTailMap::default();
            let mut payload = Vec::new();
            let mut consume = |entry: RecordIndexEntry| -> Result<()> {
                let mut budget = MaterializationBudget::new(spec);
                let key = if entry.block_id == T::ID {
                    if entry.block_version != T::VERSION {
                        return Err(Error::BlockVersionMismatch {
                            block_id: T::ID,
                            expected: T::VERSION,
                            actual: entry.block_version,
                        });
                    }
                    budget.consume(entry.logical_payload_len_snapshot(spec, &self.snapshot)?)?;
                    entry.read_logical_payload_snapshot_into(spec, &self.snapshot, &mut payload)?;
                    let block: T = budget.decode(&payload, T::ENDIAN.unwrap_or(spec.endian))?;
                    Some(block.key())
                } else if entry.block_id == TOMBSTONE_BLOCK_ID {
                    budget.consume(entry.logical_payload_len_snapshot(spec, &self.snapshot)?)?;
                    entry.read_payload_snapshot_into(spec, &self.snapshot, &mut payload)?;
                    decode_internal_key_payload::<T>(spec.endian, &payload, &mut budget)?
                } else {
                    None
                };
                if let Some(key) = key {
                    let key = encode_internal_key_payload::<T>(spec, &key)?;
                    if let Some(offset) = built.get(&key)? {
                        let previous = fault_record_entry(&self.snapshot, spec, offset, true)?;
                        if (previous.sequence, previous.record_offset)
                            > (entry.sequence, entry.record_offset)
                        {
                            return Ok(());
                        }
                    }
                    built.reserve(spec, &key)?;
                    built.insert(key, entry.record_offset);
                }
                Ok(())
            };
            if self.index.is_retained() {
                for ordinal in 0..self.index.len() {
                    if !directory_skips(&self.index, ordinal, &[T::ID, TOMBSTONE_BLOCK_ID]) {
                        consume(self.index.record_at(ordinal)?)?;
                    }
                }
            } else {
                // Walk chains directly; no temporary directory proportional to
                // the records of a block is required to build the tail index.
                for id in [T::ID, TOMBSTONE_BLOCK_ID] {
                    for entry in self.block_chain(id)? {
                        consume(entry?)?;
                    }
                }
            }
            self.keyed_tails
                .tails
                .try_reserve(1)
                .map_err(|_| Error::AllocationFailed {
                    resource: "keyed tail cache",
                    requested: std::mem::size_of::<KeyedTailMap>() as u64,
                })?;
            self.keyed_tails.tails.insert(T::ID, built);
        }
        Ok(self.keyed_tails.tails.get_mut(&T::ID).unwrap())
    }

    /// Resolves `key`'s current predecessor *and* reserves the tail-cache slot
    /// the append that follows will occupy (API3-01).
    ///
    /// The generic keyed mutation paths used to append first and only then
    /// grow the resident tail cache. That ordering could return `Err` from a
    /// cache reservation after the record or tombstone was already written,
    /// indexed and published in writer state: the caller read "nothing
    /// happened" while the record existed, and - worse - the stale cached
    /// predecessor survived, so the next generic keyed mutation on the same
    /// writer linked *around* the record that had in fact succeeded, silently
    /// truncating the physical keyed chain.
    ///
    /// Every fallible step - building the map from the resident index,
    /// the allocation arithmetic, and the `try_reserve` - therefore happens
    /// here, before the append. Only the infallible
    /// [`VarlitFile::commit_keyed_tail`] runs afterwards, so a generic keyed
    /// mutation can no longer fail after it has become authoritative.
    ///
    /// A key already present needs no capacity: its slot is overwritten in
    /// place.
    ///
    /// API3-02: the growth is additionally *charged*, before it is taken,
    /// against [`ReadLimits::max_keyed_tail_bytes`]. `try_reserve` alone only
    /// reports an allocation the allocator refuses; the charge is what makes a
    /// large-but-satisfiable cache refusable by configured policy.
    ///
    /// The charged value is the map's inline storage,
    /// `(len + 1) * size_of::<(Vec<u8>, u64)>()`, plus the key payload bytes
    /// the map owns - here the payloads already resident plus the one about to
    /// be inserted. It is checked per keyed block id, not summed across block
    /// ids, and it excludes `HashMap` control bytes and load-factor slack.
    fn reserve_keyed_tail_slot<T>(&mut self, key: &[u8]) -> Result<Option<u64>>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        let spec = self.spec;
        let tails = self.keyed_tail_map::<T>()?;
        let previous = tails.get(key)?;
        if tails.offsets.contains_key(key) {
            return Ok(previous);
        }
        let requested = tails.charge_for(1, key.len() as u64)?;
        take_injected_keyed_tail_reservation_failure(requested)?;
        tails.reserve(spec, key)?;
        Ok(previous)
    }

    /// Records `key`'s new tail after the append became authoritative
    /// (API3-01). Infallible by construction.
    ///
    /// [`VarlitFile::reserve_keyed_tail_slot`] already reserved the slot, so the
    /// insert cannot allocate. If the reservation is nevertheless not
    /// observable - the map was dropped in between, or capacity is somehow
    /// gone - the cached map for this block id is *discarded* rather than left
    /// holding the superseded predecessor. Dropping it is allocation-free and
    /// always safe: the next generic keyed mutation rebuilds it from the
    /// resident index, which already contains this record. The one outcome
    /// this must never produce is a surviving stale predecessor.
    fn commit_keyed_tail(&mut self, block_id: u32, key: Vec<u8>, record_offset: u64) {
        let reservation_lost = take_injected_keyed_tail_commit_loss();
        match self.keyed_tails.tails.get_mut(&block_id) {
            Some(tails)
                if !reservation_lost
                    && (tails.offsets.contains_key(&key)
                        || tails.offsets.capacity() > tails.offsets.len()) =>
            {
                let payload_len = key.len() as u64;
                if tails.offsets.insert(key, record_offset).is_none() {
                    tails.key_payload_bytes = tails.key_payload_bytes.saturating_add(payload_len);
                }
            }
            _ => self.keyed_tails.invalidate(block_id),
        }
    }

    pub fn push_with_prev_key_info<T: VarlitBlock>(
        &mut self,
        block: &T,
        prev_same_key_offset: Option<u64>,
    ) -> Result<AppendInfo> {
        // API2-05: the caller owns this block's keyed chain, so any tail map
        // this file cached for the block id can no longer be trusted - the
        // record's key is not observable here.
        self.keyed_tails.invalidate(T::ID);
        self.push_with_prev_key_info_unlinked(block, prev_same_key_offset)
    }

    fn push_with_prev_key_info_unlinked<T: VarlitBlock>(
        &mut self,
        block: &T,
        prev_same_key_offset: Option<u64>,
    ) -> Result<AppendInfo> {
        self.check_write()?;
        let mandatory = T::IMMEDIATE || block.immediate_if();
        self.ensure_user_block::<T>()?;
        if T::KIND == BlockKind::Matrix {
            return Err(Error::BlockKindMismatch {
                expected: BlockKind::Fixed,
                actual: T::KIND,
            });
        }
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        let endian = T::ENDIAN.unwrap_or(self.spec.endian);
        // Taken out and put back on every path, including the error one: the
        // buffer belongs to the writer, and a failed encode must not cost it.
        // Same shape as `StreamWriter::push_info`.
        let mut buffer = std::mem::take(&mut self.record_buffer);
        let result =
            match encode_logical_payload_limited_into(self.spec, block, endian, &mut buffer) {
                Ok(()) => self.ensure_write()?.write_user_record(
                    T::ID,
                    T::VERSION,
                    T::KIND,
                    &buffer,
                    prev_same_key_offset,
                ),
                Err(error) => Err(error),
            };
        self.record_buffer = buffer;
        let info = result?;
        self.apply_immediate::<T>(info, crate::ImmediateOperation::Append, mandatory)?;
        Ok(info)
    }

    /// Appends a tombstone for `key`, linking it to the previous record with
    /// the same key.
    ///
    /// API2-05: this used to write `prev_same_key_offset = None` and truncate
    /// the physical keyed chain. It now resolves and maintains the predecessor
    /// through the same tail map as [`VarlitFile::push_keyed_info`].
    pub fn delete<T>(&mut self, key: &T::Key) -> Result<u64>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        Ok(self.delete_info::<T>(key)?.sequence)
    }

    /// Appends a tombstone for `key` and returns the full [`AppendInfo`].
    ///
    /// This is [`VarlitFile::delete`] with the append description the generated
    /// keyed writers return, and it is the single implementation both routes
    /// use. Its ordering is the one property that matters: every fallible step
    /// (the tail-map build, the key encoding, the slot charge and reservation)
    /// happens strictly before the tombstone is appended, and the only step
    /// after the authoritative mutation is the infallible, allocation-free,
    /// user-code-free `VarlitFile::commit_keyed_tail` (invariant 3).
    pub fn delete_info<T>(&mut self, key: &T::Key) -> Result<AppendInfo>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        let () = crate::traits::KeyedBlockContract::<T>::OK;
        if !self.spec.index_policy.keyed_offset_chain {
            return self.delete_with_prev_key_info_unlinked::<T>(key, None);
        }
        let _permit = self.ensure_write()?;
        // The tombstone payload *is* the canonical internal key payload, and
        // it is also the tail map's key. Encoding it once here and handing the
        // same bytes to both consumers keeps the delete path at one key
        // encoding per record; it used to encode twice.
        let key_payload = encode_internal_key_payload::<T>(self.spec, key)?;
        // API3-01: reserve before the tombstone becomes authoritative; see
        // [`VarlitFile::reserve_keyed_tail_slot`].
        let previous = self.reserve_keyed_tail_slot::<T>(&key_payload)?;
        let info = self.write_tombstone_payload::<T>(&key_payload, previous)?;
        self.commit_keyed_tail(T::ID, key_payload, info.record_offset);
        Ok(info)
    }

    /// Builds the keyed tail map for `T` now rather than on first keyed
    /// mutation (F-01).
    ///
    /// Generated keyed writers call this at construction. The cache spills to
    /// a private temporary index when `max_keyed_tail_bytes` is reached; key
    /// cardinality does not refuse the open. Formats without `keyed_offset_chain`
    /// maintain no tail map, so this is a no-op for them.
    pub fn prime_keyed_tails<T>(&mut self) -> Result<()>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        if !self.spec.index_policy.keyed_offset_chain {
            return Ok(());
        }
        self.keyed_tail_map::<T>()?;
        Ok(())
    }

    pub fn delete_with_prev_key_info<T>(
        &mut self,
        key: &T::Key,
        prev_same_key_offset: Option<u64>,
    ) -> Result<AppendInfo>
    where
        T: VarlitKeyedBlock,
    {
        // API2-05: the caller owns this block's keyed chain; drop the cached
        // tail map so a later maintained append rebuilds it.
        self.keyed_tails.invalidate(T::ID);
        self.delete_with_prev_key_info_unlinked::<T>(key, prev_same_key_offset)
    }

    fn delete_with_prev_key_info_unlinked<T>(
        &mut self,
        key: &T::Key,
        prev_same_key_offset: Option<u64>,
    ) -> Result<AppendInfo>
    where
        T: VarlitKeyedBlock,
    {
        // API2-03: keyed generic entry points evaluate the compile-time
        // keyedness contract post-monomorphization; the registration below
        // stays as the runtime backstop. This terminal site also covers the
        // VarlitFile::delete and VarlitReader/VarlitWriter delete wrappers.
        let () = crate::traits::KeyedBlockContract::<T>::OK;
        let _permit = self.ensure_write()?;
        self.ensure_user_block::<T>()?;
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        let payload = encode_internal_key_payload::<T>(self.spec, key)?;
        self.write_tombstone_payload::<T>(&payload, prev_same_key_offset)
    }

    /// Appends a tombstone whose canonical internal key payload is already
    /// encoded.
    ///
    /// Split out of `delete_with_prev_key_info_unlinked` so the maintained
    /// delete path can encode the key exactly once and use the same bytes for
    /// the tail map and for the record.
    fn write_tombstone_payload<T>(
        &mut self,
        payload: &[u8],
        prev_same_key_offset: Option<u64>,
    ) -> Result<AppendInfo>
    where
        T: VarlitKeyedBlock,
    {
        let () = crate::traits::KeyedBlockContract::<T>::OK;
        self.check_write()?;
        self.ensure_user_block::<T>()?;
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        let info = self.ensure_write()?.write_record_with_prev_key(
            TOMBSTONE_BLOCK_ID,
            1,
            RECORD_FLAG_INTERNAL,
            0,
            payload,
            prev_same_key_offset,
        )?;
        self.apply_immediate::<T>(info, crate::ImmediateOperation::Delete, T::IMMEDIATE)?;
        Ok(info)
    }

    pub fn push_op<T>(&mut self, key: &T::Key, op: &T::Op) -> Result<u64>
    where
        T: VarlitMerge,
    {
        let _permit = self.ensure_write()?;
        self.ensure_user_block::<T>()?;
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        let payload = encode_internal_op_payload::<T>(self.spec, key, op)?;
        self.write_record(OP_BLOCK_ID, 1, RECORD_FLAG_INTERNAL, &payload)
    }

    pub fn write_metadata(&mut self, key: &str, value: &[u8]) -> Result<u64> {
        // Encoded as (String, Vec<u8>): an 8-byte length prefix per part.
        const METADATA_ENVELOPE_LEN: u64 = 16;
        let _permit = self.ensure_write()?;
        // DEF-02: reject an oversized entry with the typed limit error before
        // the caller's key and value are cloned or encoded.
        let entry_len = (key.len() as u64)
            .checked_add(value.len() as u64)
            .and_then(|len| len.checked_add(METADATA_ENVELOPE_LEN))
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "metadata entry length",
            })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::LogicalPayloadLen, entry_len)?;
        let payload = encode_logical_payload_limited(
            self.spec,
            &(key.to_string(), value.to_vec()),
            self.spec.endian,
        )?;
        self.write_record(METADATA_BLOCK_ID, 1, RECORD_FLAG_INTERNAL, &payload)
    }

    /// The newest value written for `key`, or `None`.
    ///
    /// Visits every metadata record — latest-wins needs the whole walk, so
    /// there is no early break — but only *materializes* the ones it returns.
    /// `split_metadata_payload` compares the stored key against the borrowed
    /// payload, and the decode that allocates a `String` and a `Vec<u8>` runs
    /// only for a record that matches and wins.
    ///
    /// `max_materialized_bytes` bounds one record here, not the sum over the
    /// walk: a lookup keeps at most one value alive, and charging the sum
    /// refused a healthy file whose *total* metadata exceeded the ceiling
    /// (`STANDARD` sets it to 1 GiB) even when the requested entry was the
    /// first record in the file.
    pub fn metadata(&self, key: &str) -> Result<Option<Vec<u8>>> {
        self.metadata_in(self.resident_directory("metadata")?, key)
    }

    fn metadata_in<D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
        key: &str,
    ) -> Result<Option<Vec<u8>>> {
        let mut found = None;
        let mut budget = MaterializationBudget::new(self.spec);
        // One payload buffer for the whole walk. It used to be one per record,
        // and the walk is over every record in the file.
        let mut payload = Vec::new();
        for record_ordinal in 0..dir.record_count() {
            if directory_skips(dir, record_ordinal, &[METADATA_BLOCK_ID]) {
                continue;
            }
            let entry = dir.record_at(record_ordinal)?;
            if entry.block_id != METADATA_BLOCK_ID {
                continue;
            }
            budget.reset();
            let logical_len = entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
            budget.consume(logical_len)?;
            entry.read_payload_snapshot_into(self.spec, &self.snapshot, &mut payload)?;
            let (stored_key, _) = split_metadata_payload(&payload, self.spec.endian)?;
            if stored_key != key {
                continue;
            }
            let order = MergeOrder::for_record(0, entry.sequence, record_ordinal);
            let should_replace = found
                .as_ref()
                .is_none_or(|(old_order, _): &(MergeOrder, Vec<u8>)| order >= *old_order);
            if should_replace {
                // Decoded through the accounted decoder exactly as before, so
                // what a returned value costs the budget is unchanged.
                let (_, value): (String, Vec<u8>) = budget.decode(&payload, self.spec.endian)?;
                found = Some((order, value));
            }
        }
        Ok(found.map(|(_, value)| value))
    }

    /// **This allocates.** [`all_metadata_into`](Self::all_metadata_into) takes
    /// the caller's buffer instead.
    pub fn all_metadata(&self) -> Result<Vec<(String, Vec<u8>)>> {
        let mut values = Vec::new();
        self.all_metadata_into(&mut values)?;
        Ok(values)
    }

    /// Fills the caller's buffer with every metadata pair.
    ///
    /// `out` is cleared and then extended, so a caller that reuses one buffer
    /// across calls allocates once and never again.
    pub fn all_metadata_into(&self, out: &mut Vec<(String, Vec<u8>)>) -> Result<()> {
        self.all_metadata_into_in(self.resident_directory("all_metadata")?, out)
    }

    fn all_metadata_into_in<D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
        out: &mut Vec<(String, Vec<u8>)>,
    ) -> Result<()> {
        out.clear();
        let mut budget = MaterializationBudget::new(self.spec);
        let mut payload = Vec::new();
        for position in 0..dir.record_count() {
            if directory_skips(dir, position, &[METADATA_BLOCK_ID]) {
                continue;
            }
            let entry = dir.record_at(position)?;
            if entry.block_id != METADATA_BLOCK_ID {
                continue;
            }
            let logical_len = entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
            budget.consume(logical_len)?;
            entry.read_payload_snapshot_into(self.spec, &self.snapshot, &mut payload)?;
            out.try_reserve(1).map_err(|_| Error::AllocationFailed {
                resource: "metadata entries",
                requested: logical_len,
            })?;
            out.push(budget.decode(&payload, self.spec.endian)?);
        }
        Ok(())
    }

    pub fn schema_manifest(&self) -> Result<Option<SchemaManifest>> {
        self.schema_manifest_in(self.resident_directory("schema_manifest")?)
    }

    fn schema_manifest_in<D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
    ) -> Result<Option<SchemaManifest>> {
        let mut newest: Option<(MergeOrder, RecordIndexEntry)> = None;
        for record_ordinal in 0..dir.record_count() {
            if directory_skips(dir, record_ordinal, &[MANIFEST_BLOCK_ID]) {
                continue;
            }
            let entry = dir.record_at(record_ordinal)?;
            if entry.block_id != MANIFEST_BLOCK_ID {
                continue;
            }
            let order = MergeOrder::for_record(0, entry.sequence, record_ordinal);
            // `>=`, not `>`: this replaced a `max_by_key`, which returns the
            // *last* of several equal maxima.
            if newest.as_ref().is_none_or(|(best, _)| order >= *best) {
                newest = Some((order, entry));
            }
        }
        let Some((_, entry)) = newest else {
            return Ok(None);
        };
        let mut budget = MaterializationBudget::new(self.spec);
        let logical_len = entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
        budget.consume(logical_len)?;
        let payload = entry.read_payload_snapshot(self.spec, &self.snapshot)?;
        Ok(Some(decode_schema_manifest(&payload, &mut budget)?))
    }

    /// Replaces a native user record while preserving its sequence number.
    ///
    /// The new generation is validated and synced before atomic publication.
    /// Existing readers remain attached to the old generation.
    /// Rewrites the file without the records marked dead.
    ///
    /// Publishes by the same route `replace_*` uses — a temp file in the same
    /// directory, synced, then renamed over the pathname — so a reader open
    /// across it keeps its own generation whole and `is_current` /
    /// `reopen_readonly` are how it moves. The cost of that route is peak disk:
    /// both generations exist at once.
    ///
    /// Every internal record is kept. Commit markers stay where they are, and
    /// the derived ones — index checkpoints, segments, open digests — are
    /// rebuilt from the records already written rather than copied, because
    /// their payloads *are* record offsets and this moves them.
    ///
    /// # The part that is not a delta
    ///
    /// `replace_block` resizes one record and removes none, so a single
    /// subtraction translates every chain link. Here each survivor moves by a
    /// different amount and some predecessors are gone, so the links are
    /// remapped through a table per chain. Substituting a uniform delta does
    /// not publish a corrupt file: it is refused at write time with
    /// `InvalidRecordFooter`, because every link is resolved against the prefix
    /// already written and must name an earlier record of the same block.
    /// Measured, rather than assumed.
    ///
    /// A link whose whole chain was dropped is **cleared**, not pointed
    /// somewhere plausible.
    ///
    /// # Cost
    ///
    /// One rewritten generation and private page-compressed metadata. The
    /// directory and chain remapping share the existing index buffer budget;
    /// their temporary disk storage scales with record count. Publication
    /// adopts the completed directory without writing a second copy. It needs
    /// the resident directory, so a lazily opened handle refuses by name.
    pub fn defragment(&mut self) -> Result<DefragmentReport> {
        let _permit = self.ensure_write()?;
        if self.spec.liveness_policy != LivenessPolicy::FooterFlags {
            return Err(Error::InvalidFormatSpec(
                "defragment requires liveness: footer_flags — without it no record is ever dead",
            ));
        }
        if !self.spec.layout.is_varlit_native_default() {
            return Err(Error::InvalidFormatSpec(
                "defragment is not supported for custom physical layouts",
            ));
        }
        if self.matrix.is_some() {
            return Err(Error::InvalidFormatSpec(
                "defragment is not supported for matrix storage",
            ));
        }
        let _ = self.resident_directory("defragment")?;
        self.ensure_generation_rewrite_allowed()?;

        let bytes_before = self.file.metadata()?.len();
        let mut new_index = RewriteDirectory::new(self.spec);
        // One entry per record, per chain: a survivor maps its old offset to
        // its new one, and a dropped record inherits whatever its own
        // predecessor in that chain resolved to. Absent means "nothing in this
        // chain survived".
        let mut remap = OffsetRemap::new(self.spec);

        let rewrite_append_start = append_log_start_for_file(self)?;
        let mut segment_start = 0usize;
        let mut segment_covered_start: Option<u64> = None;
        let mut dropped = 0usize;
        let (temp_path, mut temp_file) = create_rewrite_temp_file(&self.path)?;
        let prepare_result = (|| -> Result<()> {
            if let Ok(metadata) = self.file.metadata() {
                temp_file.set_permissions(metadata.permissions())?;
            }
            let replacement_extensions =
                header_extensions_for_replacement(self.spec, &self.header_extensions)?;
            write_native_file_header(&mut temp_file, self.spec, &replacement_extensions)?;
            let mut source_end = rewrite_append_start;
            for source_entry in self.index.iter() {
                let source_entry = source_entry?;
                let old_offset = source_entry.record_offset;
                // Prove directory coverage while copying, including records
                // dropped below. Serialized rows cannot skip bytes or name an
                // embedded header. This reuses headers already read here.
                if old_offset != source_end {
                    return Err(Error::InvalidCanonicalEncoding(
                        "defragment source directory is not contiguous",
                    ));
                }
                source_end = source_entry.checked_physical_end()?;
                // Internal records carry commit and navigation state, never
                // user liveness. Refuse a damaged mark before publishing a
                // generation that could erase its commit boundary.
                if source_entry.block_id >= RESERVED_BLOCK_ID_START && source_entry.is_dead() {
                    return Err(Error::InvalidRecordFooter {
                        offset: source_entry.footer_offset.unwrap_or(old_offset),
                    });
                }
                if source_entry.is_dead() {
                    // Dropped. A link that pointed here has to reach past it to
                    // whatever this record itself pointed at, in the same
                    // chain — which is already resolved, because predecessors
                    // are written before their successors.
                    let block = source_entry
                        .prev_same_block_offset
                        .map(|offset| remap.get(offset, Chain::Block))
                        .transpose()?
                        .flatten();
                    let key = source_entry
                        .prev_same_key_offset
                        .map(|offset| remap.get(offset, Chain::Key))
                        .transpose()?
                        .flatten();
                    remap.push(old_offset, block, key)?;
                    dropped += 1;
                    continue;
                }
                let mut updated = source_entry.clone();
                let checkpoint_payload;
                let payload = if source_entry.block_id == INDEX_BLOCK_ID {
                    RewritePayload::Index(IndexPayload {
                        entries: &new_index,
                        start: 0,
                        covered_start: None,
                        record_offset: temp_file.stream_position()?,
                    })
                } else if source_entry.block_id == SEGMENT_BLOCK_ID {
                    let record_offset = temp_file.stream_position()?;
                    RewritePayload::Index(IndexPayload {
                        entries: &new_index,
                        start: segment_start,
                        covered_start: Some(segment_covered_start.unwrap_or(rewrite_append_start)),
                        record_offset,
                    })
                } else if source_entry.block_id == OPEN_DIGEST_BLOCK_ID {
                    let record_offset = temp_file.stream_position()?;
                    checkpoint_payload = rebuilt_open_digest_payload(
                        self.spec,
                        &new_index,
                        source_entry.sequence,
                        record_offset,
                    )?;
                    RewritePayload::Bytes(&checkpoint_payload)
                } else {
                    RewritePayload::Snapshot {
                        offset: source_entry.payload_offset,
                        len: source_entry.payload_len,
                    }
                };
                updated = rewrite_replacement_record_streaming(
                    self.spec,
                    &self.snapshot,
                    &mut temp_file,
                    updated,
                    payload,
                    ChainRemap::Tables(&remap),
                    &new_index,
                )?;
                remap.push(
                    old_offset,
                    Some(updated.record_offset),
                    Some(updated.record_offset),
                )?;
                if updated.block_id == SEGMENT_BLOCK_ID {
                    segment_covered_start = Some(updated.checked_physical_end()?);
                    segment_start = new_index.len() + 1;
                }
                debug_assert!(
                    new_index
                        .last()
                        .is_none_or(|last| last.record_offset < updated.record_offset)
                );
                new_index.push(updated)?;
            }
            if source_end != self.snapshot.len() {
                return Err(Error::CorruptTail { offset: source_end });
            }
            temp_file.flush()?;
            temp_file.sync_all()?;
            validate_replacement_generation_file(
                self.spec,
                &mut temp_file,
                rewrite_append_start,
                &new_index,
            )?;
            Ok(())
        })();
        if let Err(error) = prepare_result {
            drop(temp_file);
            let _ = remove_file(&temp_path);
            return Err(error);
        }
        drop(temp_file);
        // All chain links and replacement coverage have been validated. The
        // remap is no longer needed; release its heap and spill file before
        // adopting (and optionally compacting) the new private directory.
        drop(remap);

        // Only the two fields the rebind actually reads: it returns this value
        // (which this operation discards in favour of its own report) and names
        // `sequence` in the poisoned-publication error. `record_offset` and the
        // payload lengths would describe a single replaced record, which this
        // operation does not have — so they are zero rather than plausible, and
        // the value never leaves this function.
        let info = ReplacementInfo {
            sequence: new_index.maximum_sequence(),
            record_offset: 0,
            old_payload_len: 0,
            new_payload_len: 0,
            old_physical_len: bytes_before,
            new_physical_len: 0,
        };
        match replace_path_atomically(&temp_path, &self.path) {
            Ok(ReplaceDurability::Durable) => {
                self.rebind_replacement_generation(info, new_index)?;
            }
            Ok(ReplaceDurability::ParentSyncPending(sync_error)) => {
                return match self.rebind_replacement_generation(info, new_index) {
                    Ok(_) => Err(crate::fallible::boxed_path_error(
                        sync_error,
                        &self.path,
                        Error::ErrorContextAllocationFailed {
                            context: crate::AllocationFailureContext::ParentSyncPending,
                        },
                        |path, source| Error::PublishedButParentSyncPending { path, source },
                    )),
                    Err(rebind_error) => Err(rebind_error.with_pending_parent_sync(sync_error)),
                };
            }
            Err(error) => return Err(self.fail_publication(&temp_path, error)),
        }
        Ok(DefragmentReport {
            records_dropped: dropped,
            bytes_before,
            bytes_after: self.file.metadata()?.len(),
        })
    }

    pub fn replace_block<T: VarlitReplaceBlock>(
        &mut self,
        index: usize,
        block: &T,
    ) -> Result<ReplacementInfo> {
        let _permit = self.ensure_write()?;
        if !self.spec.layout.is_varlit_native_default() {
            return Err(Error::InvalidFormatSpec(
                "replacement is not supported for custom physical layouts",
            ));
        }
        if self.matrix.is_some() || T::KIND == BlockKind::Matrix {
            return Err(Error::InvalidFormatSpec(
                "replacement is not supported for matrix storage",
            ));
        }
        self.ensure_user_block::<T>()?;
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        // F-01: resolution and the target-version refusal are one step, and
        // there is no other way to address the target. See `ReplacementTarget`.
        let target_position = ReplacementTarget::resolve::<T>(&self.index, index)?.position();
        let target = self.index.entry_at(target_position)?;
        let mut materialization = MaterializationBudget::new(self.spec);
        let old_logical_len = target.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
        materialization.consume(old_logical_len)?;
        let old_payload = target.read_logical_payload_snapshot(self.spec, &self.snapshot)?;
        let old: T = materialization.decode(&old_payload, T::ENDIAN.unwrap_or(self.spec.endian))?;
        T::validate_replacement(&old, block)?;

        let encoded = encode_logical_payload_limited(
            self.spec,
            block,
            T::ENDIAN.unwrap_or(self.spec.endian),
        )?;
        let replacement = prepare_user_record_payload(self.spec, T::ID, T::KIND, &encoded)?;
        let replacement_len = u64::try_from(replacement.bytes.len())
            .map_err(|_| Error::LengthOverflow { value: u64::MAX })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::RecordPayloadLen, replacement_len)?;
        let old_physical_len = target
            .checked_physical_end()?
            .checked_sub(target.record_offset)
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "replacement physical length",
            })?;
        let new_physical_len = RECORD_HEADER_LEN
            .checked_add(replacement_len)
            .and_then(|len| len.checked_add(record_footer_len(self.spec)))
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "replacement physical length",
            })?;
        let info = ReplacementInfo {
            sequence: target.sequence,
            record_offset: target.record_offset,
            old_payload_len: target.payload_len,
            new_payload_len: replacement_len,
            old_physical_len,
            new_physical_len,
        };

        self.ensure_generation_rewrite_allowed()?;
        self.validate_source_generation()?;
        let mut new_index = RewriteDirectory::new(self.spec);

        let rewrite_append_start = append_log_start_for_file(self)?;
        // Segment coverage in the new generation, tracked exactly as the
        // writer's `SegmentCursor` tracks it in the old one.
        let mut segment_start = 0usize;
        let mut segment_covered_start: Option<u64> = None;
        let (temp_path, mut temp_file) = create_rewrite_temp_file(&self.path)?;
        let prepare_result = (|| -> Result<()> {
            if let Ok(metadata) = self.file.metadata() {
                temp_file.set_permissions(metadata.permissions())?;
            }
            // Write back the region this file carries, not the one `spec`
            // would generate: regenerating drops any block this build does not
            // know and moves the append log out from under the index. The one
            // exception is a mutable block, which is reset to cold rather than
            // carried forward describing offsets this file will not have.
            let replacement_extensions =
                header_extensions_for_replacement(self.spec, &self.header_extensions)?;
            write_native_file_header(&mut temp_file, self.spec, &replacement_extensions)?;
            for (position, source_entry) in self.index.iter().enumerate() {
                let source_entry = source_entry?;
                let mut updated = source_entry.clone();
                let checkpoint_payload;
                let payload = if position == target_position {
                    updated.flags = replacement.flags;
                    updated.uncompressed_len_hint = replacement.uncompressed_len_hint;
                    RewritePayload::Bytes(&replacement.bytes)
                } else if source_entry.block_id == INDEX_BLOCK_ID {
                    RewritePayload::Index(IndexPayload {
                        entries: &new_index,
                        start: 0,
                        covered_start: None,
                        record_offset: temp_file.stream_position()?,
                    })
                } else if source_entry.block_id == SEGMENT_BLOCK_ID {
                    // A segment payload is record offsets, and this rewrite
                    // moves them. Copying the bytes would publish a generation
                    // whose chain describes the file it replaced.
                    let record_offset = temp_file.stream_position()?;
                    RewritePayload::Index(IndexPayload {
                        entries: &new_index,
                        start: segment_start,
                        covered_start: Some(segment_covered_start.unwrap_or(rewrite_append_start)),
                        record_offset,
                    })
                } else if source_entry.block_id == OPEN_DIGEST_BLOCK_ID {
                    // A digest payload is block-tail offsets and its own
                    // start offset, and a rewrite moves both, so copying the
                    // bytes would publish a generation whose digest describes
                    // the file it replaced.
                    //
                    // It is rebuilt including this record's own sequence. The
                    // claim that stood here — that a digest "closes a commit
                    // point and never describes itself" — is what made the
                    // high-water mark one too low; see
                    // `rebuilt_open_digest_payload`. The trailer check does
                    // not catch it: the lazy open accepts the digest and
                    // resumes on a sequence that is already taken.
                    let record_offset = temp_file.stream_position()?;
                    checkpoint_payload = rebuilt_open_digest_payload(
                        self.spec,
                        &new_index,
                        source_entry.sequence,
                        record_offset,
                    )?;
                    RewritePayload::Bytes(&checkpoint_payload)
                } else {
                    RewritePayload::Snapshot {
                        offset: source_entry.payload_offset,
                        len: source_entry.payload_len,
                    }
                };
                updated = rewrite_replacement_record_streaming(
                    self.spec,
                    &self.snapshot,
                    &mut temp_file,
                    updated,
                    payload,
                    ChainRemap::Uniform(info),
                    &new_index,
                )?;
                if updated.block_id == SEGMENT_BLOCK_ID {
                    segment_covered_start = Some(updated.checked_physical_end()?);
                    segment_start = new_index.len() + 1;
                }
                // What makes the rewrite directory's binary search legal:
                // each record is written at `output.stream_position()` and
                // pushed in that order, so the prefix is strictly increasing in
                // `record_offset`. Asserted here, where the invariant is made,
                // because that is O(1) — asserting sortedness inside the lookup
                // would reintroduce the O(N) it exists to remove.
                debug_assert!(
                    new_index
                        .last()
                        .is_none_or(|last| last.record_offset < updated.record_offset)
                );
                new_index.push(updated)?;
            }
            temp_file.flush()?;
            temp_file.sync_all()?;
            validate_replacement_generation_file(
                self.spec,
                &mut temp_file,
                append_log_start_for_file(self)?,
                &new_index,
            )?;
            Ok(())
        })();
        if let Err(error) = prepare_result {
            drop(temp_file);
            let _ = remove_file(&temp_path);
            return Err(error);
        }
        drop(temp_file);

        match replace_path_atomically(&temp_path, &self.path) {
            Ok(ReplaceDurability::Durable) => self.rebind_replacement_generation(info, new_index),
            Ok(ReplaceDurability::ParentSyncPending(sync_error)) => {
                // Publication already happened: the pathname resolves to the
                // new generation, so the writer must move there regardless.
                //
                // F-07: `?` here would drop `sync_error` if the rebind failed
                // too, and `PublishedButRebindFailed` alone cannot say that
                // the published pathname is not yet durable. Both facts are
                // preserved instead.
                match self.rebind_replacement_generation(info, new_index) {
                    Ok(_) => Err(crate::fallible::boxed_path_error(
                        sync_error,
                        &self.path,
                        Error::ErrorContextAllocationFailed {
                            context: crate::AllocationFailureContext::ParentSyncPending,
                        },
                        |path, source| Error::PublishedButParentSyncPending { path, source },
                    )),
                    Err(rebind_error) => Err(rebind_error.with_pending_parent_sync(sync_error)),
                }
            }
            Err(error) => Err(self.fail_publication(&temp_path, error)),
        }
    }

    /// Publishes a same-size fixed replacement through a copy-on-write file
    /// generation.
    ///
    /// [`Error::PublishedButRebindFailed`] means publication already succeeded.
    /// Do not retry blindly; discard this poisoned writer and reopen the path.
    ///
    /// [`Error::PublishedButParentSyncPending`] also means publication already
    /// succeeded; the writer was rebound to the published generation and stays
    /// usable, but the rename is not yet guaranteed durable against power loss
    /// until the parent directory is synced (for example by a later successful
    /// publication or an explicit directory sync).
    /// Refuses an in-place record mutation on a segment-chained format.
    ///
    /// A segment payload records the header fields of every record it covers,
    /// and an in-place replacement restamps the sequence and checksum of a
    /// record that is already covered. Nothing rewrites the segment behind it,
    /// so the chain would keep describing the record as it was - and open would
    /// have no way to notice, because it reads no data record.
    ///
    /// Patching the covering segment instead was considered and is the shape
    /// §4A.5 rejected for the index anchor: an in-place rewrite of a derived
    /// structure, with a tear window a lock-free `open_readonly` can observe.
    /// So this is a capability trade rather than a repair: in-place fixed
    /// replacement and the segment chain are alternatives, and
    /// `replace_block` - which publishes a whole new generation, and re-encodes
    /// every segment payload against the new offsets - is available under both.
    /// Refuses a whole-generation rewrite for a format with a non-resident
    /// block.
    ///
    /// Both rewrite paths rebuild the new generation by iterating the resident
    /// index, which no longer mirrors every record: a non-resident block's
    /// records would be absent from the copy and silently dropped from the
    /// published file. This is a format-level refusal rather than a per-block
    /// one, because the loss is of blocks the caller did not name.
    fn ensure_generation_rewrite_allowed(&self) -> Result<()> {
        if self.matrix.is_some() {
            return Err(Error::InvalidFormatSpec(
                "record generation replacement is not supported for matrix storage",
            ));
        }
        if self.spec.has_non_resident_blocks() {
            return Err(Error::InvalidFormatSpec(
                "a generation rewrite is not supported for a format with a non-resident block",
            ));
        }
        Ok(())
    }

    fn ensure_in_place_replacement_allowed(&self) -> Result<()> {
        if self.spec.index_policy.segment_on_flush {
            return Err(Error::InvalidFormatSpec(
                "in-place replacement is not supported for segment_on_flush formats",
            ));
        }
        // The digest is the same shape of hazard as the segment above, and it
        // is worse in what it costs. `replace_fixed` publishes by copying the
        // generation byte for byte and patching one record, so it rewrites no
        // derived record at all - while assigning the replacement a *fresh*
        // sequence, which raises the file's true maximum above the mark the
        // copied digest still reports.
        //
        // A scan recounts and is unaffected, which is why `checkpoint_on_flush`
        // needs no refusal here and was measured not to. The digest is the one
        // derived record a lazy open *trusts instead of recounting*: it seeds
        // its writer with `sequence_high_water + 1`, so the next append lands
        // on the sequence the replacement took and the file stops opening with
        // `InvalidCanonicalEncoding("duplicate native record sequence")`.
        //
        // Measured before this refusal, on `crc32 + open_digest_on_flush`, 64
        // records: `replace_fixed` gave the replacement sequence 65, the digest
        // went on reporting 64, and the next lazy append also took 65.
        //
        // A capability trade, not a loss: `open_digest_on_flush` forces
        // `block_offset_chain` on, so `replace` routes such a format to
        // `replace_block`, which republishes and rebuilds the digest. Only a
        // caller naming this method directly sees the refusal.
        if self.spec.index_policy.open_digest_on_flush {
            return Err(Error::InvalidFormatSpec(
                "in-place replacement is not supported for open_digest_on_flush formats",
            ));
        }
        Ok(())
    }

    /// Marks the record at `record_offset` dead.
    ///
    /// The one mutation varlit makes to a record that is not a rewrite of it.
    /// It sets a bit in the footer's trailing word — four bytes, outside the
    /// record checksum — and touches nothing else: the payload is not read, no
    /// checksum is recomputed, no record moves, and the file does not grow.
    ///
    /// # What a dead record is, and is not
    ///
    /// It is **advisory**. The record is still framed, still read back by
    /// `blocks`, `scan` and `record_map`, and still part of every chain that
    /// points at it. Nothing is hidden, because hiding it would silently change
    /// what a chain walk means and would make the mark a data-loss operation
    /// rather than a note. What consumes it is a defragmenting rewrite, which
    /// is the operation that can actually drop a record and rebuild the chains
    /// that named it.
    ///
    /// Read it back with [`RecordIndexEntry::is_dead`].
    ///
    /// # Refusals
    ///
    /// - `InvalidFormatSpec` unless the format declares
    ///   `liveness: footer_flags`; without it the word is a reserved field that
    ///   every reader requires to be zero.
    /// - `ReservedBlockId` for an internal record. Marking a commit marker or a
    ///   segment dead would make a defragmenter drop the very records that say
    ///   where the commit boundary is.
    /// - Whatever framing the record at `record_offset` fails with, if it is
    ///   not a record.
    ///
    /// Membership is checked in the private offset directory. Unproven lazy,
    /// serialized-directory and non-resident offsets use an incremental boundary
    /// directory. Each frame is discovered once per snapshot lineage; reverse,
    /// random and repeated requests reuse exact membership. The first request
    /// can scan a prefix. Boundary rows borrow the existing index-buffer budget
    /// and spill eight bytes per discovered record to temporary storage as needed.
    /// A small stack window amortizes reads of adjacent small records; large
    /// payloads are skipped. No payload-sized allocation is made.
    ///
    /// # Durability
    ///
    /// Not synced here. The mark rides the next `flush`/`commit`/`sync` like
    /// any other write; a crash before one leaves the record alive, which is
    /// the safe direction — a defragmenter that has not been told keeps data it
    /// could have dropped.
    pub fn mark_record_dead(&mut self, record_offset: u64) -> Result<()> {
        self.set_record_mutable_flags(record_offset, RECORD_MUTABLE_FLAG_DEAD)
    }

    fn set_record_mutable_flags(&mut self, record_offset: u64, set: u32) -> Result<()> {
        let _permit = self.ensure_write()?;
        if self.spec.liveness_policy != LivenessPolicy::FooterFlags {
            return Err(Error::InvalidFormatSpec(
                "marking a record requires liveness: footer_flags",
            ));
        }
        if !self.index.has_verified_boundary(record_offset)? {
            let append_start = append_log_start_for_file(self)?;
            self.index.verify_boundary(append_start, record_offset)?;
        }
        let entry = fault_record_entry_for_mark_with(
            self.snapshot.len(),
            self.index.len(),
            self.spec,
            record_offset,
            |at, bytes| self.snapshot.read_exact_at(at, bytes),
        )?;
        self.write_framed_record_flags(&entry, set)
    }

    // The caller must have a boundary witness: directory membership, or the
    // next frame of a sequential recovery walk anchored at the commit end.
    // Recheck identity here before every write, including recovery.
    #[inline]
    fn write_framed_record_flags(&mut self, entry: &RecordIndexEntry, set: u32) -> Result<()> {
        validate_record_entry(&self.spec, entry)?;
        if entry.block_id >= RESERVED_BLOCK_ID_START {
            return Err(Error::ReservedBlockId(entry.block_id));
        }
        let Some(footer_offset) = entry.footer_offset else {
            return Err(Error::InvalidFormatSpec(
                "marking a record requires a record footer",
            ));
        };
        let Some(word_offset) =
            footer_offset.checked_add(RECORD_FOOTER_LEN - RECORD_FOOTER_MUTABLE_LEN)
        else {
            return Err(Error::ResourceArithmeticOverflow {
                resource: "record footer offset",
            });
        };
        let updated = entry.mutable_flags | set;
        if updated == entry.mutable_flags {
            // Already marked. Skipping the write is not an optimisation — it
            // keeps a repeated mark from being a repeated dirtying of a page
            // that readers may be faulting.
            return Ok(());
        }
        self.file
            .overwrite_record_mutable_flags(word_offset, updated.to_le_bytes())?;
        Ok(())
    }

    /// Whether the record at `record_offset` is marked dead.
    ///
    /// Frames the record and reads its footer, so this costs one record's
    /// worth of positional reads. Reading a run of entries through
    /// [`record_map`](Self::record_map) and asking each
    /// [`RecordIndexEntry::is_dead`] costs the same framing once.
    pub fn record_is_dead(&self, record_offset: u64) -> Result<bool> {
        let entry = fault_record_entry(&self.snapshot, self.spec, record_offset, false)?;
        Ok(entry.is_dead())
    }

    pub fn replace_fixed<T: VarlitBlock>(&mut self, index: usize, block: &T) -> Result<u64> {
        let _permit = self.ensure_write()?;
        self.ensure_in_place_replacement_allowed()?;
        self.ensure_user_block::<T>()?;
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        if T::KIND != BlockKind::Fixed {
            return Err(Error::BlockKindMismatch {
                expected: BlockKind::Fixed,
                actual: T::KIND,
            });
        }
        // F-01: resolution and the target-version refusal are one step, and
        // there is no other way to address the target. See `ReplacementTarget`.
        let target_position = ReplacementTarget::resolve::<T>(&self.index, index)?.position();

        let endian = T::ENDIAN.unwrap_or(self.spec.endian);
        let payload = encode_logical_payload_limited(self.spec, block, endian)?;
        let payload_len =
            u64::try_from(payload.len()).map_err(|_| Error::LengthOverflow { value: u64::MAX })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::RecordPayloadLen, payload_len)?;
        self.spec
            .read_limits
            .check(ReadLimitKey::LogicalPayloadLen, payload_len)?;
        let old_len = self.index.entry_at(target_position)?.payload_len;
        if old_len != payload_len {
            return Err(Error::ReplaceSizeMismatch {
                old: old_len,
                new: payload_len,
            });
        }
        self.ensure_generation_rewrite_allowed()?;
        self.validate_source_generation()?;

        let sequence = self.sequence_state.available()?;
        let entry = self.index.entry_at(target_position)?;
        let mut footer_bytes = [0; RECORD_FOOTER_LEN as usize];
        let footer = if let Some(footer_offset) = entry.footer_offset {
            self.snapshot
                .read_exact_at(footer_offset, &mut footer_bytes)?;
            &footer_bytes[..]
        } else {
            &[]
        };
        let header = RecordHeaderFields {
            block_id: entry.block_id,
            block_version: entry.block_version,
            flags: entry.flags,
            sequence,
            payload_len: entry.payload_len,
            checksum: 0,
            uncompressed_len_hint: entry.uncompressed_len_hint,
        };
        let checksum =
            checksum_record_fields(self.spec, entry.record_offset, header, &payload, footer)?;
        let header_bytes = encode_native_record_header(
            RecordHeaderFields { checksum, ..header },
            entry.record_offset,
            record_footer_len(self.spec),
        )?;
        let record_offset = entry.record_offset;
        let payload_offset = entry.payload_offset;

        let mut new_index = RewriteDirectory::new(self.spec);
        for (position, source) in self.index.iter().enumerate() {
            let mut updated = source?;
            if position == target_position {
                updated.sequence = sequence;
                updated.checksum = checksum;
            }
            new_index.push(updated)?;
        }

        // The copy below reproduces the header verbatim, warm region included,
        // and that table would describe a file whose true sequence maximum is
        // no longer the one it can be derived from. See
        // `header_tails_invalidation`.
        let cold_tails = self.header_tails_invalidation()?;

        let (temp_path, mut temp_file) = create_rewrite_temp_file(&self.path)?;
        let prepare_result = (|| -> Result<()> {
            if let Ok(metadata) = self.file.metadata() {
                temp_file.set_permissions(metadata.permissions())?;
            }
            self.snapshot
                .copy_range_to(0, self.snapshot.len(), &mut temp_file)?;
            temp_file.seek(SeekFrom::Start(record_offset))?;
            temp_file.write_all(&header_bytes)?;
            temp_file.seek(SeekFrom::Start(payload_offset))?;
            temp_file.write_all(&payload)?;
            if let Some((offset, cold)) = cold_tails.as_ref() {
                temp_file.seek(SeekFrom::Start(*offset))?;
                temp_file.write_all(cold)?;
            }
            temp_file.flush()?;
            temp_file.sync_all()?;
            validate_generation_file(
                self.spec,
                &mut temp_file,
                append_log_start_for_file(self)?,
                &new_index,
            )?;
            Ok(())
        })();
        match prepare_result {
            Ok(()) => {}
            Err(error) => {
                drop(temp_file);
                let _ = remove_file(&temp_path);
                return Err(error);
            }
        }
        drop(temp_file);

        match replace_path_atomically(&temp_path, &self.path) {
            Ok(ReplaceDurability::Durable) => self.rebind_published_generation(sequence, new_index),
            Ok(ReplaceDurability::ParentSyncPending(sync_error)) => {
                // Publication already happened: the pathname resolves to the
                // new generation, so the writer must move there regardless.
                //
                // F-07: `?` here would drop `sync_error` if the rebind failed
                // too, and `PublishedButRebindFailed` alone cannot say that
                // the published pathname is not yet durable. Both facts are
                // preserved instead.
                match self.rebind_published_generation(sequence, new_index) {
                    Ok(_) => Err(crate::fallible::boxed_path_error(
                        sync_error,
                        &self.path,
                        Error::ErrorContextAllocationFailed {
                            context: crate::AllocationFailureContext::ParentSyncPending,
                        },
                        |path, source| Error::PublishedButParentSyncPending { path, source },
                    )),
                    Err(rebind_error) => Err(rebind_error.with_pending_parent_sync(sync_error)),
                }
            }
            Err(error) => Err(self.fail_publication(&temp_path, error)),
        }
    }

    /// Replaces a fixed record by mutating this file object directly.
    ///
    /// # Errors
    ///
    /// F-01: the target is selected by block id, so a version mismatch between
    /// `T` and the stored record is refused with
    /// [`Error::BlockVersionMismatch`], exactly as [`VarlitFile::replace_fixed`]
    /// does. Otherwise `T`'s payload would be written under the stored
    /// record's older version header. The refusal is not a step this function
    /// performs; it is a precondition of resolving the target at all. See
    /// `ReplacementTarget`.
    ///
    /// # Safety
    ///
    /// The caller must exclude every reader, writer, mapping, raw reference,
    /// handle, thread, and process for this operation and for the lifetime of
    /// every view that could observe the affected object.
    ///
    /// For a keyed block in a format with `keyed_offset_chain`, the caller
    /// must additionally **not change the record's key** (F-02). This entry
    /// point takes `T: VarlitBlock`, which exposes no key, so the requirement
    /// cannot be checked here, and unlike the copy-on-write paths there is no
    /// new generation in which the chain could be rebuilt: records appended
    /// after this one already carry `prev_same_key_offset` pointers into it,
    /// and rewriting its key in place would leave them linking a record that
    /// now claims a different key. Ordinary keyed replacement enforces the
    /// same-key contract through
    /// [`crate::VarlitReplaceBlock::validate_replacement`]; here it is part of
    /// the unsafe contract.
    ///
    /// What this function *does* guarantee, whether or not the contract is
    /// honoured, is that no resident keyed-tail cache survives the mutation:
    /// the affected block's tail map is dropped **before** the first byte is
    /// written, so a stale predecessor can never be read afterwards, not even
    /// if the write fails part-way or the contract above is violated.
    pub unsafe fn replace_fixed_in_place_exclusive<T: VarlitBlock>(
        &mut self,
        index: usize,
        block: &T,
    ) -> Result<u64> {
        self.check_write()?;
        self.ensure_in_place_replacement_allowed()?;
        self.ensure_user_block::<T>()?;
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        if T::KIND != BlockKind::Fixed {
            return Err(Error::BlockKindMismatch {
                expected: BlockKind::Fixed,
                actual: T::KIND,
            });
        }
        // F-01: resolution and the target-version refusal are one step, and
        // there is no other way to address the target. See `ReplacementTarget`.
        let target = ReplacementTarget::resolve::<T>(&self.index, index)?;
        let target_position = target.position();
        let payload = encode_logical_payload_limited(
            self.spec,
            block,
            T::ENDIAN.unwrap_or(self.spec.endian),
        )?;
        let payload_len =
            u64::try_from(payload.len()).map_err(|_| Error::LengthOverflow { value: u64::MAX })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::RecordPayloadLen, payload_len)?;
        self.spec
            .read_limits
            .check(ReadLimitKey::LogicalPayloadLen, payload_len)?;
        let entry = self.index.entry_at(target_position)?;
        if entry.payload_len != payload_len {
            return Err(Error::ReplaceSizeMismatch {
                old: entry.payload_len,
                new: payload_len,
            });
        }
        self.ensure_generation_rewrite_allowed()?;
        self.validate_source_generation()?;
        let sequence = self.sequence_state.available()?;
        let entry = self.index.entry_at(target_position)?;
        let mut footer_bytes = [0; RECORD_FOOTER_LEN as usize];
        let footer = if let Some(footer_offset) = entry.footer_offset {
            self.snapshot
                .read_exact_at(footer_offset, &mut footer_bytes)?;
            &footer_bytes[..]
        } else {
            &[]
        };
        let header = RecordHeaderFields {
            block_id: entry.block_id,
            block_version: entry.block_version,
            flags: entry.flags,
            sequence,
            payload_len,
            checksum: 0,
            uncompressed_len_hint: entry.uncompressed_len_hint,
        };
        let checksum =
            checksum_record_fields(self.spec, entry.record_offset, header, &payload, footer)?;
        let header_bytes = encode_native_record_header(
            RecordHeaderFields { checksum, ..header },
            entry.record_offset,
            record_footer_len(self.spec),
        )?;
        // Before the record changes, not after: this mutates the live file, so
        // the ordering is the only thing standing between a crash here and a
        // file whose header table outlives the invariant it was derived under.
        // See `header_tails_invalidation`.
        self.retire_header_tails_in_place()?;
        let write_result =
            self.ensure_write()?
                .overwrite_record_bytes_in_place(target, &header_bytes, &payload);
        if let Err(error) = write_result {
            self.poison.poison();
            return Err(error);
        }
        // No index update. `overwrite_record_bytes_in_place` above wrote and
        // flushed a header carrying this sequence and this checksum, and the
        // entry for this position is rebuilt from that header — so the restamp
        // this used to perform would copy the file's own bytes onto themselves.
        self.publish_sequence(sequence);
        Ok(sequence)
    }

    /// Publishes a replacement by rewriting the complete file generation.
    ///
    /// # Not for a format that writes a record footer
    ///
    /// Refused with `InvalidFormatSpec("replace is not supported for
    /// record-footer formats")`, which is every format declaring an offset
    /// chain, `segment_on_flush`, or any commit policy other than
    /// [`CommitPolicy::None`]. Use [`replace_block`](Self::replace_block)
    /// there: it does the same whole-file republish and does maintain the
    /// footer, translating both chain offsets and checking each predecessor
    /// against the prefix it has already written.
    ///
    /// The refusal is a statement about *this* routine rather than about the
    /// operation. Its record writer emits header and payload and stops — no
    /// footer, and both chain fields cleared — so a file it produced for such a
    /// format would frame perfectly and carry no chain at all.
    ///
    /// [`Error::PublishedButRebindFailed`] means publication already succeeded.
    /// Do not retry blindly; discard this poisoned writer and reopen the path.
    ///
    /// [`Error::PublishedButParentSyncPending`] also means publication already
    /// succeeded; the writer was rebound to the published generation and stays
    /// usable, but the rename is not yet guaranteed durable against power loss
    /// until the parent directory is synced (for example by a later successful
    /// publication or an explicit directory sync).
    pub fn replace_rewrite<T: VarlitBlock>(&mut self, index: usize, block: &T) -> Result<u64> {
        let _permit = self.ensure_write()?;
        if self.spec.spec_needs_record_footer() {
            return Err(Error::InvalidFormatSpec(
                "replace is not supported for record-footer formats",
            ));
        }
        if self.matrix.is_some() {
            return Err(Error::InvalidFormatSpec(
                "native rewrite is not supported for matrix files",
            ));
        }
        self.ensure_user_block::<T>()?;
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        // F-01: resolution and the target-version refusal are one step, and
        // there is no other way to address the target. See `ReplacementTarget`.
        let target_position = ReplacementTarget::resolve::<T>(&self.index, index)?.position();
        let sequence = self.sequence_state.available()?;
        let endian = T::ENDIAN.unwrap_or(self.spec.endian);
        let encoded = encode_logical_payload_limited(self.spec, block, endian)?;
        let replacement = prepare_user_record_payload(self.spec, T::ID, T::KIND, &encoded)?;
        let replacement_len = u64::try_from(replacement.bytes.len())
            .map_err(|_| Error::LengthOverflow { value: u64::MAX })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::RecordPayloadLen, replacement_len)?;
        self.ensure_generation_rewrite_allowed()?;
        self.validate_source_generation()?;

        let mut new_index = RewriteDirectory::new(self.spec);

        let (temp_path, mut temp_file) = create_rewrite_temp_file(&self.path)?;
        let prepare_result = (|| -> Result<()> {
            if let Ok(metadata) = self.file.metadata() {
                temp_file.set_permissions(metadata.permissions())?;
            }
            // Write back the region this file carries, not the one `spec`
            // would generate: regenerating drops any block this build does not
            // know and moves the append log out from under the index. The one
            // exception is a mutable block, which is reset to cold rather than
            // carried forward describing offsets this file will not have.
            let replacement_extensions =
                header_extensions_for_replacement(self.spec, &self.header_extensions)?;
            write_native_file_header(&mut temp_file, self.spec, &replacement_extensions)?;
            for (position, source_entry) in self.index.iter().enumerate() {
                let source_entry = source_entry?;
                let mut updated = source_entry.clone();
                let checkpoint_payload;
                let payload = if position == target_position {
                    updated.sequence = sequence;
                    updated.flags = replacement.flags;
                    updated.uncompressed_len_hint = replacement.uncompressed_len_hint;
                    RewritePayload::Bytes(&replacement.bytes)
                } else if source_entry.block_id == INDEX_BLOCK_ID {
                    RewritePayload::Index(IndexPayload {
                        entries: &new_index,
                        start: 0,
                        covered_start: None,
                        record_offset: temp_file.stream_position()?,
                    })
                } else if source_entry.block_id == OPEN_DIGEST_BLOCK_ID {
                    // A digest payload is block-tail offsets and its own
                    // start offset, and a rewrite moves both, so copying the
                    // bytes would publish a generation whose digest describes
                    // the file it replaced.
                    //
                    // It is rebuilt including this record's own sequence. The
                    // claim that stood here — that a digest "closes a commit
                    // point and never describes itself" — is what made the
                    // high-water mark one too low; see
                    // `rebuilt_open_digest_payload`. The trailer check does
                    // not catch it: the lazy open accepts the digest and
                    // resumes on a sequence that is already taken.
                    let record_offset = temp_file.stream_position()?;
                    checkpoint_payload = rebuilt_open_digest_payload(
                        self.spec,
                        &new_index,
                        source_entry.sequence,
                        record_offset,
                    )?;
                    RewritePayload::Bytes(&checkpoint_payload)
                } else {
                    RewritePayload::Snapshot {
                        offset: source_entry.payload_offset,
                        len: source_entry.payload_len,
                    }
                };
                updated = rewrite_record_streaming(
                    self.spec,
                    &self.snapshot,
                    &mut temp_file,
                    updated,
                    payload,
                )?;
                new_index.push(updated)?;
            }
            temp_file.flush()?;
            temp_file.sync_all()?;
            validate_generation_file(
                self.spec,
                &mut temp_file,
                append_log_start_for_file(self)?,
                &new_index,
            )?;
            Ok(())
        })();
        match prepare_result {
            Ok(()) => {}
            Err(error) => {
                drop(temp_file);
                let _ = remove_file(&temp_path);
                return Err(error);
            }
        }
        drop(temp_file);

        match replace_path_atomically(&temp_path, &self.path) {
            Ok(ReplaceDurability::Durable) => self.rebind_published_generation(sequence, new_index),
            Ok(ReplaceDurability::ParentSyncPending(sync_error)) => {
                // Publication already happened: the pathname resolves to the
                // new generation, so the writer must move there regardless.
                //
                // F-07: `?` here would drop `sync_error` if the rebind failed
                // too, and `PublishedButRebindFailed` alone cannot say that
                // the published pathname is not yet durable. Both facts are
                // preserved instead.
                match self.rebind_published_generation(sequence, new_index) {
                    Ok(_) => Err(crate::fallible::boxed_path_error(
                        sync_error,
                        &self.path,
                        Error::ErrorContextAllocationFailed {
                            context: crate::AllocationFailureContext::ParentSyncPending,
                        },
                        |path, source| Error::PublishedButParentSyncPending { path, source },
                    )),
                    Err(rebind_error) => Err(rebind_error.with_pending_parent_sync(sync_error)),
                }
            }
            Err(error) => Err(self.fail_publication(&temp_path, error)),
        }
    }

    /// Replaces the record at `index`, by whichever route the format supports.
    ///
    /// **The route is not a choice the caller can make.** It used to be — this
    /// took a `ReplaceStrategy` — and that was wrong in a way measurable rather
    /// than stylistic: on a format declaring an offset chain or a commit
    /// policy, *both* of the two strategies refused, and the implementation
    /// that works was reachable only by naming
    /// [`replace_block`](Self::replace_block) directly. What decides is the
    /// declaration, so the declaration decides here:
    ///
    /// | format | route | why |
    /// | --- | --- | --- |
    /// | writes a record footer | [`replace_block`](Self::replace_block) | it is the only route that maintains the offset chains a footer carries |
    /// | no footer, fixed block | [`replace_fixed`](Self::replace_fixed) | cheapest — copies the generation and patches one same-length record |
    /// | no footer, otherwise | [`replace_rewrite`](Self::replace_rewrite) | a whole-file republish, with no footer to maintain |
    ///
    /// All three stay public for a caller who wants to name one and be refused
    /// loudly if the format cannot serve it. This is the door for a caller who
    /// wants the replacement rather than a particular mechanism.
    ///
    /// # Bound
    ///
    /// `VarlitReplaceBlock` rather than `VarlitBlock`, which the footer route
    /// needs for its key-preservation check. That costs derived blocks nothing:
    /// the macro emits the impl for every one — trivially `Ok` where there is
    /// no key, and a `ReplacementKeyMismatch` check where there is. Only a
    /// hand-written block needs the one-line impl.
    ///
    /// Returns the replacement record's sequence.
    pub fn replace<T: VarlitReplaceBlock>(&mut self, index: usize, block: &T) -> Result<u64> {
        if self.spec.spec_needs_record_footer() {
            return self.replace_block(index, block).map(|info| info.sequence);
        }
        if T::KIND == BlockKind::Fixed {
            return self.replace_fixed(index, block);
        }
        self.replace_rewrite(index, block)
    }

    pub fn flush(&mut self) -> Result<()> {
        let _permit = self.ensure_not_poisoned()?;
        self.write_embedded_manifest_if_needed()?;
        // First, before the checkpoint and before the marker. A chunk is an
        // ordinary record: writing the chunk after the marker would leave it outside the
        // committed prefix, and writing it after the checkpoint would leave it out
        // of the index that checkpoint serialises.
        if self.mode == OpenMode::ReadWrite {
            self.write_open_chunk_record()?;
        }
        if self.mode == OpenMode::ReadWrite
            && self.spec.index_policy.checkpoint_on_flush
            && self.needs_index_checkpoint()
        {
            self.write_index_checkpoint()?;
        }
        if self.mode == OpenMode::ReadWrite
            && self.spec.commit_policy.marker_on_flush()
            && self.has_uncommitted_since_last_commit()
        {
            self.write_commit_marker()?;
        }
        // Last, and after the marker: the chain is found from the end of the
        // file, so anything appended behind this record hides it.
        self.close_commit_point();
        self.file.flush()?;
        Ok(())
    }

    pub fn commit(&mut self) -> Result<AppendInfo> {
        let _permit = self.ensure_write()?;
        if !self.spec.commit_policy.is_transaction_marker() {
            return Err(Error::InvalidFormatSpec(
                "commit markers require transaction_marker commit policy",
            ));
        }
        self.write_embedded_manifest_if_needed()?;
        self.write_open_chunk_record()?;
        if self.spec.index_policy.checkpoint_on_flush && self.needs_index_checkpoint() {
            self.write_index_checkpoint()?;
        }
        if !self.has_uncommitted_since_last_commit()
            && let Some(entry) = self.index.last_entry_of_block(COMMIT_BLOCK_ID)?
        {
            let info = AppendInfo::from(&entry);
            self.close_commit_point();
            return Ok(info);
        }
        let info = self.write_commit_marker()?;
        self.close_commit_point();
        Ok(info)
    }

    pub fn commit_durable(&mut self) -> Result<AppendInfo> {
        let _permit = self.ensure_write()?;
        if !self.spec.commit_policy.is_transaction_marker() {
            return Err(Error::InvalidFormatSpec(
                "commit markers require transaction_marker commit policy",
            ));
        }
        self.write_embedded_manifest_if_needed()?;
        self.write_open_chunk_record()?;
        if self.spec.index_policy.checkpoint_on_flush && self.needs_index_checkpoint() {
            self.write_index_checkpoint()?;
        }
        if !self.has_uncommitted_since_last_commit()
            && let Some(entry) = self.index.last_entry_of_block(COMMIT_BLOCK_ID)?
        {
            let info = AppendInfo::from(&entry);
            self.close_commit_point();
            self.file.flush()?;
            self.file.sync_all()?;
            // DUR3-01: a durable commit on a file this handle created must
            // also establish the pathname; this happens once, not per commit.
            let publication = self.publish_matrix_generation();
            self.poison_after_started_matrix_error(publication)?;
            self.sync_created_pathname_once()?;
            self.immediate_state.reset();
            return Ok(info);
        }
        self.file.flush()?;
        self.file.sync_data()?;
        let info = self.write_commit_marker()?;
        // The segment closes the commit point, so it is appended after the
        // marker and before the durability request that makes both durable.
        // `close_commit_point` cannot report a failure for the same
        // reason the two steps below do not report theirs as a bare `Err`: the
        // commit has happened.
        self.close_commit_point();
        // INVARIANT 3: `write_commit_marker` is the authoritative commit. From
        // here the marker record is in the file and a reader that opens it
        // after a clean process exit sees the transaction as committed, so a
        // failure of the durability request that follows must not be reported
        // as a bare `Err` — that would entitle the caller to believe nothing
        // happened and re-run the transaction, appending a second marker for
        // work already recorded. Both remaining steps therefore report typed
        // published outcomes: content durability as
        // `CommittedButDurabilityUnproven`, and the created pathname's
        // directory entry as `PublishedButParentSyncPending`, which
        // `sync_created_pathname_once` already produces and which leaves the
        // request pending so a later `sync` retries it.
        if let Err(source) = self.flush_and_sync_all() {
            return Err(crate::fallible::boxed_error(
                source,
                Error::ErrorContextAllocationFailed {
                    context: crate::AllocationFailureContext::Committed {
                        sequence: info.sequence,
                    },
                },
                |source| Error::CommittedButDurabilityUnproven {
                    sequence: info.sequence,
                    source,
                },
            ));
        }
        let publication = self.publish_matrix_generation();
        self.poison_after_started_matrix_error(publication)?;
        self.sync_created_pathname_once()?;
        self.immediate_state.reset();
        Ok(info)
    }

    /// Flushes the buffered writer and syncs the file contents.
    ///
    /// Split out so the post-commit-marker durability request in
    /// [`Self::commit_durable`] has exactly one failure point to classify.
    fn flush_and_sync_all(&mut self) -> Result<()> {
        take_injected_commit_durability_failure()?;
        self.file.flush()?;
        self.file.sync_all()?;
        Ok(())
    }

    fn publish_matrix_generation(&mut self) -> Result<()> {
        let Some(pages) = self.file.matrix_pages() else {
            return Ok(());
        };
        let previous_end = pages.head().native_eof;
        let end = if self.spec.commit_policy.is_transaction_marker()
            && self.has_uncommitted_since_last_commit()
        {
            // A matrix-only sync must not publish an append tail that writer
            // recovery would later truncate. Keep at least the old confirmed
            // EOF, including its segment/digest, and any newly written marker.
            match self.block_tails.tail(COMMIT_BLOCK_ID) {
                Some(offset) if offset >= previous_end => {
                    fault_record_entry(&self.snapshot, self.spec, offset, false)?
                        .checked_physical_end()?
                }
                _ => previous_end,
            }
        } else {
            self.file.metadata()?.len()
        };
        self.file.publish_matrix(end)
    }

    /// Requests durable persistence of everything written so far.
    ///
    /// This syncs the file's contents and, for a pathname this handle created,
    /// its parent directory entry exactly once (DUR3-01). Without the second
    /// step a power loss could leave a fully synced object with no name on
    /// platforms that require an explicit directory sync, which would not be
    /// "durably persisted" in any useful sense; the atomic replacement path
    /// already syncs the parent and reports a pending parent sync, so creation
    /// now makes the same guarantee through the same machinery.
    ///
    /// The parent sync costs one directory fsync per created file, never
    /// recurs, and is not on the append path. A failed parent sync is reported
    /// as [`Error::PublishedButParentSyncPending`] - the contents are durable
    /// and the pathname is visible, only its directory entry's durability is
    /// unconfirmed - and leaves the request pending, so a later `sync` retries
    /// it.
    pub fn sync(&mut self) -> Result<()> {
        let _permit = self.ensure_not_poisoned()?;
        // A committed chunked cell lives in memory until its chunk is written,
        // so syncing the file without writing the chunk made `sync()` return `Ok` having
        // made nothing durable — while the same call on a region row did.
        if self.mode == OpenMode::ReadWrite {
            self.write_open_chunk_record()?;
            // The write is an ordinary record append, so it lands *past* any
            // digest or segment this file already ends with — and a digest that
            // is not the last record is one no lazy open can use. `flush` writes out
            // before it closes the commit point for exactly this reason; `sync`
            // written and stopped, silently demoting every later
            // `open_readonly_lazy` on the file to a full scan.
            //
            // Re-closing is cheap but no longer free, and the count matters:
            // the segment and the digest are each predicated on there being
            // something new to describe, so an idle close appends nothing. The
            // header tail region is not — it has no such predicate, because its
            // write is an overwrite of a fixed extent rather than an append, so
            // an idle close costs one seek and one slot-sized write — 176
            // bytes on a two-block format, 12 more per declared block; the 360
            // the author guide quotes is the whole two-slot region — and advances
            // the slot generation. It never grows the file and it is never on
            // the append path; `the_region_write_is_one_seek_per_commit_point`
            // is what holds that to a count.
            self.close_commit_point();
        }
        self.file.sync_all()?;
        if self.mode == OpenMode::ReadWrite
            && let Err(error) = self.publish_matrix_generation()
        {
            self.poison.poison();
            return Err(error);
        }
        self.sync_created_pathname_once()?;
        self.immediate_state.reset();
        Ok(())
    }

    /// Persist all preceding writes. Does not append a transaction commit marker.
    pub fn immediate(&mut self) -> Result<()> {
        self.sync()
    }

    /// Install OR-combined conditions for native user appends and deletions.
    pub fn set_immediate_policy(&mut self, policy: crate::ImmediatePolicy) -> Result<()> {
        let _permit = self.ensure_write()?;
        self.immediate_state.policy = policy.validate()?;
        Ok(())
    }

    fn apply_immediate<T: VarlitBlock>(
        &mut self,
        info: AppendInfo,
        operation: crate::ImmediateOperation,
        mandatory: bool,
    ) -> Result<()> {
        let bytes = self.snapshot.len().saturating_sub(info.record_offset);
        self.immediate_state.advance(1, bytes);
        let event = self
            .immediate_state
            .event(T::ID, operation, info, bytes, 0, 0);
        if (mandatory || self.immediate_state.policy.matches(event))
            && let Err(error) = self.immediate()
        {
            // Keyed wrappers have not updated their tail caches yet.
            self.poison.poison();
            return Err(crate::immediate::appended_immediate_error(
                info.sequence,
                error,
            ));
        }
        Ok(())
    }

    /// Makes a pathname created by this handle durable, at most once.
    fn sync_created_pathname_once(&mut self) -> Result<()> {
        if !self.pending_pathname_parent_sync {
            return Ok(());
        }
        match sync_parent_directory(&self.path) {
            Ok(()) => {
                self.pending_pathname_parent_sync = false;
                Ok(())
            }
            Err(error) => Err(crate::fallible::boxed_path_error(
                error,
                &self.path,
                Error::ErrorContextAllocationFailed {
                    context: crate::AllocationFailureContext::ParentSyncPending,
                },
                |path, source| Error::PublishedButParentSyncPending { path, source },
            )),
        }
    }

    /// The record offset of the newest record of `block_id`, or `None` if the
    /// file holds none.
    ///
    /// H2. The entry point of the block offset chain, and the only way to reach
    /// a non-resident block: from here each record's footer names its
    /// predecessor. `&self`, answered from the maintained tail table without
    /// touching the resident index (PERF2-05).
    pub fn block_tail_offset(&self, block_id: u32) -> Option<u64> {
        self.block_tails.tail(block_id)
    }

    /// Walks a block's records newest-first through the footer chain.
    ///
    /// H2, and the only way to read a non-resident block. Takes `&self`, reads
    /// positionally through the open snapshot, and materialises one entry at a
    /// time — the resident index is never consulted and never grown, so this
    /// costs the working set rather than the record count.
    ///
    /// Refuses without `block_offset_chain`: without it the footer carries no
    /// predecessor, and a walk would silently stop after one record rather than
    /// report that it cannot answer.
    pub fn block_chain(&self, block_id: u32) -> Result<BlockChain<'_>> {
        if !self.spec.index_policy.block_offset_chain {
            return Err(Error::InvalidFormatSpec(
                "block_chain requires block_offset_chain",
            ));
        }
        Ok(BlockChain {
            spec: self.spec,
            snapshot: &self.snapshot,
            block_id,
            next: self.block_tails.tail(block_id),
            visited: 0,
        })
    }

    /// Walks one key's records, newest first, from `from`.
    ///
    /// Seed it with that key's newest offset --
    /// [`key_tail_offsets`](Self::key_tail_offsets) is where those come from --
    /// and the iterator follows
    /// [`prev_same_key_offset`](RecordIndexEntry::prev_same_key_offset) back
    /// through every earlier generation of the key. Turn an entry into a value
    /// with [`read_block_at`](Self::read_block_at) or
    /// [`decode_block_into`](Self::decode_block_into).
    ///
    /// **It crosses block ids, and that is deliberate** -- the one way it
    /// differs from [`Self::block_chain`], which refuses a step that leaves its
    /// block. A delete writes its tombstone under [`TOMBSTONE_BLOCK_ID`], and
    /// that tombstone carries a live predecessor and becomes the key's tail, so
    /// a walk that refused it would stop at the first deleted generation and
    /// look like an answer. Filter on `entry.block_id` yourself; the walk will
    /// not filter for you.
    ///
    /// **Merge ops are not on this chain.** [`Self::push_op`] appends under
    /// [`OP_BLOCK_ID`] with `prev_same_key_offset` set to `None` and does not
    /// move the key's tail, so this walk never surfaces one. A history
    /// reconstructed from it alone omits every op-applied mutation; a caller
    /// using [`VarlitMerge`] has to fold the ops in by another route.
    /// Measured by `an_op_record_is_not_on_the_chain` in
    /// `crates/varlit/tests/keyed_chain_walk.rs`.
    ///
    /// Lazy and `&self`, exactly like `block_chain`: one offset is held, so a
    /// key with more generations than memory is still walkable. Each step is
    /// charged against `max_records`, and the chain must strictly decrease, so a
    /// crafted or damaged file cannot make the walk loop.
    ///
    /// Refuses without `keyed_offset_chain`: without it the writer records no
    /// predecessor at all
    /// ([`prev_same_key_offset`](RecordIndexEntry::prev_same_key_offset) is
    /// `None` on every record), so a walk would stop after one record rather
    /// than report that it cannot answer. Same refusal, for the same reason,
    /// that `block_chain` carries.
    pub fn keyed_chain(&self, from: u64) -> Result<KeyedChain<'_>> {
        if !self.spec.index_policy.keyed_offset_chain {
            return Err(Error::InvalidFormatSpec(
                "keyed_chain requires keyed_offset_chain",
            ));
        }
        Ok(KeyedChain {
            spec: self.spec,
            snapshot: &self.snapshot,
            next: Some(from),
            visited: 0,
        })
    }

    /// Decodes the record at `record_offset` as `T`.
    ///
    /// The companion to [`Self::block_chain`]: the walk yields offsets and
    /// entries, this turns one into a value. Positional and `&self`, so a
    /// non-resident block is read without anything entering the resident index.
    pub fn read_block_at<T: VarlitBlock>(&self, record_offset: u64) -> Result<T> {
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        let entry = read_record_entry_positional(self.spec, &self.snapshot, record_offset)?;
        if entry.block_id != T::ID {
            return Err(Error::UnregisteredBlock(entry.block_id));
        }
        if entry.block_version != T::VERSION {
            return Err(Error::BlockVersionMismatch {
                block_id: T::ID,
                expected: T::VERSION,
                actual: entry.block_version,
            });
        }
        let mut budget = MaterializationBudget::new(self.spec);
        let logical_len = entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
        budget.consume(logical_len)?;
        let payload = entry.read_logical_payload_snapshot(self.spec, &self.snapshot)?;
        budget.decode(&payload, T::ENDIAN.unwrap_or(self.spec.endian))
    }

    /// Frames the record at `record_offset` into its index entry.
    ///
    /// The other half of [`Self::read_block_at`]. That one turns an offset into
    /// a *value* and discards the entry it framed to get there; this returns the
    /// entry, which is what a caller following a chain of their own needs -- the
    /// entry is where the next offset lives
    /// ([`prev_same_key_offset`](RecordIndexEntry::prev_same_key_offset),
    /// [`prev_same_block_offset`](RecordIndexEntry::prev_same_block_offset)).
    /// Without it a hand-written walk reads the value at hop one and has nowhere
    /// to go for hop two.
    ///
    /// It publishes no information [`Self::block_chain`] does not already hand
    /// out; it hands out the same entries by a route the caller steers.
    ///
    /// Positional and `&self`: two fixed-size reads through the snapshot, no
    /// allocation, and nothing enters the resident index -- so a walk over a
    /// file larger than memory costs the hops and not the file.
    ///
    /// **The offset is not trusted.** It is the caller's, so it may name
    /// anything; an extent outside this handle's snapshot is refused, and bytes
    /// that do not frame a record are refused. What it cannot do is reach
    /// outside this file, so the worst a wrong offset buys is an error or some
    /// other record of the same file. Identical in that respect to
    /// [`Self::read_payload_into`], which takes a whole caller-supplied entry.
    pub fn record_entry_at(&self, record_offset: u64) -> Result<RecordIndexEntry> {
        read_record_entry_positional(self.spec, &self.snapshot, record_offset)
    }

    /// Reads the stored bytes of a record the caller already holds an entry
    /// for, into a buffer the caller already owns.
    ///
    /// This is the half of "the host manages the memory" that the `_into`
    /// family alone does not give you. [`index_entries_into`](Self::index_entries_into)
    /// hands a host the index; without this, using one of those entries meant
    /// [`RecordIndexEntry::read_payload`], which reopens the file **by path** —
    /// a different object if the path was replaced — and allocates. So the two
    /// halves of the pattern are: take the index into your buffer once, then
    /// read through it into your buffer as often as you like, both bound to
    /// this open handle.
    ///
    /// `out` ends exactly the record's stored length, and the checksum is
    /// verified over it, identically to every internal read.
    ///
    /// **The entry is not trusted.** It is the caller's, so it may name
    /// anything: an extent past the end of the snapshot is refused, and bytes
    /// that do not match the entry's checksum are refused. What it cannot do is
    /// reach outside this file — every offset is validated against this
    /// handle's snapshot bounds — so the worst a wrong entry buys is an error
    /// or some other record of the same file.
    pub fn read_payload_into(&self, entry: &RecordIndexEntry, out: &mut Vec<u8>) -> Result<()> {
        entry.read_payload_snapshot_into(self.spec, &self.snapshot, out)
    }

    /// The same, decompressed if the record is compressed.
    ///
    /// For an uncompressed record this is a read straight into `out` with no
    /// copy. For a compressed one the decompressor produces its own buffer and
    /// `out` is replaced — said here because it is the one case where handing
    /// in a buffer does not save the allocation.
    pub fn read_logical_payload_into(
        &self,
        entry: &RecordIndexEntry,
        out: &mut Vec<u8>,
    ) -> Result<()> {
        entry.read_logical_payload_snapshot_into(self.spec, &self.snapshot, out)
    }

    /// Decodes a record the caller already holds an entry for, reading its
    /// bytes through the caller's buffer.
    ///
    /// `scratch` is scratch, not output: the decoded value is returned and the
    /// buffer keeps the last record's bytes. Reusing it across a walk is the
    /// difference between one allocation and one per record — which is what
    /// makes "cache the index, then read through it" cost no more than the
    /// reads themselves.
    ///
    /// Refuses an entry whose block id or version is not `T`'s, exactly as
    /// [`read_block_at`](Self::read_block_at) does. Unlike `read_block_at` it
    /// does not re-read the record header to find that out — the caller's entry
    /// already says it, which is the point of having kept the entry.
    pub fn decode_block_into<T: VarlitBlock>(
        &self,
        entry: &RecordIndexEntry,
        scratch: &mut Vec<u8>,
    ) -> Result<T> {
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        if entry.block_id != T::ID {
            return Err(Error::UnregisteredBlock(entry.block_id));
        }
        if entry.block_version != T::VERSION {
            return Err(Error::BlockVersionMismatch {
                block_id: T::ID,
                expected: T::VERSION,
                actual: entry.block_version,
            });
        }
        let mut budget = MaterializationBudget::new(self.spec);
        let logical_len = entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
        budget.consume(logical_len)?;
        entry.read_logical_payload_snapshot_into(self.spec, &self.snapshot, scratch)?;
        budget.decode(scratch, T::ENDIAN.unwrap_or(self.spec.endian))
    }

    /// This handle's own record directory, or the typed refusal that says who
    /// has it instead.
    ///
    /// Every position-based read goes through here rather than touching
    /// `self.index`, so a handle opened without a directory refuses by name
    /// instead of answering as though the file were empty.
    fn resident_directory(&self, operation: &'static str) -> Result<&ResidentIndex> {
        if self.index.is_retained() {
            Ok(&self.index)
        } else {
            Err(Error::NoResidentDirectory { operation })
        }
    }

    /// Reads that resolve positions through a directory **the caller supplies**.
    ///
    /// Every method on the returned view is the same read the handle offers,
    /// answered against `directory` instead of against the handle's own. The
    /// directory is anything implementing [`RecordDirectory`] — in practice the
    /// `Vec<RecordIndexEntry>` that [`index_entries_into`](Self::index_entries_into)
    /// or [`open_readonly_with_scratch`](Self::open_readonly_with_scratch)
    /// filled.
    ///
    /// ```ignore
    /// let mut index = Vec::new();
    /// let file = VarlitFile::open_readonly_with_scratch(spec, path, &mut index)?;
    /// // `index` is the file's record index; the handle has its own copy too.
    /// let blocks = file.with_directory(&index).blocks::<Point>()?;
    /// ```
    ///
    /// **Why this exists.** The handle keeps a 16-byte directory slot per
    /// record, and that is the last thing about a read that still scales with
    /// the file. A handle that stopped keeping it must not lose `blocks`,
    /// `scan` and the rest — it must ask whoever has the directory for it.
    /// This is that ask, and it is available whether or not the handle also
    /// has one, so the two can be compared on the same file.
    pub fn with_directory<'a, D: RecordDirectory + ?Sized>(
        &'a self,
        directory: &'a D,
    ) -> Result<DirectoryRead<'a, D>> {
        self.check_directory_describes_this_file(directory)?;
        Ok(DirectoryRead {
            file: self,
            directory,
        })
    }

    /// Refuses a directory whose entries are not where it says they are.
    ///
    /// A supplied directory is trusted offsets, and trusting an offset is
    /// correct — it is what makes handing over the scan buffer cheaper than
    /// keeping a resident index. What was never bounded is *which file* the
    /// offsets are trusted against. `reopen_readonly` made the unbounded
    /// version reachable in an ordinary sequence rather than by a mistake:
    /// build a directory, let a `replace_*` republish the pathname, reopen, and
    /// read through the directory you already had. Measured on an
    /// `integrity: none` format, eight records read back as zeros.
    ///
    /// # Why it is derived rather than declared
    ///
    /// The obvious fix — a provenance tag on the directory — cannot be applied
    /// to the directory that matters most. `Vec<RecordIndexEntry>` *is* the
    /// scan buffer, it is a foreign type, and no field can be added to it. So
    /// the check asks the file instead: re-frame what the directory claims and
    /// require the record to still be there. Same shape as the header-tail
    /// slot, which re-frames every offset it adopts rather than believing the
    /// table.
    ///
    /// # What it costs, and what it therefore does not check
    ///
    /// Two record headers, at `with_directory` rather than per read, so a walk
    /// of 600,000 records pays it once. Checking every entry would be a second
    /// full pass and would cost exactly what the supplied directory exists to
    /// avoid. The two checked are the first and the last, which is what catches
    /// the case this exists for: a republish moves every record by a uniform
    /// delta, so an entry at either end lands on a different record — a
    /// different sequence above all, since sequences are file-global and a
    /// rewrite preserves them per record rather than per offset.
    ///
    /// Be exact about the residual: this is a **disagreement detector, not an
    /// authenticator**. A directory that is wrong only in the middle passes, and
    /// a caller who fabricates entries that happen to frame correctly is not
    /// stopped. It converts the common accident into a typed refusal; it does
    /// not make a supplied directory a trusted input.
    ///
    /// An empty directory describes nothing and is accepted: there is no claim
    /// to disagree with, and refusing it would break the legitimate "I want no
    /// records" call.
    fn check_directory_describes_this_file<D: RecordDirectory + ?Sized>(
        &self,
        directory: &D,
    ) -> Result<()> {
        let count = directory.record_count();
        let Some(last) = count.checked_sub(1) else {
            return Ok(());
        };
        let limit = self.snapshot.len();
        for position in if last == 0 { vec![0] } else { vec![0, last] } {
            let stated = directory.record_at(position)?;
            let mismatch = || Error::DirectoryDoesNotDescribeThisFile {
                position,
                offset: stated.record_offset,
            };
            // Outside the snapshot is the same disagreement seen from the other
            // end, and it has to be answered before the read rather than by it:
            // a positional read past the logical length is already refused, but
            // as `UnexpectedEof`, which says nothing about the directory.
            if stated.checked_physical_end().map_err(|_| mismatch())? > limit {
                return Err(mismatch());
            }
            // The header only. Building a whole entry through
            // `fault_record_entry` would also read the footer and would charge
            // the record-entry fault counter, which several tests measure as a
            // cost model — this probe is not a fault, it is a check.
            let mut header_bytes = [0; RECORD_HEADER_LEN as usize];
            self.snapshot
                .read_exact_at(stated.record_offset, &mut header_bytes)?;
            let actual =
                read_native_record_header(&mut header_bytes.as_slice(), stated.record_offset)?
                    .fields;
            // `sequence` is the discriminator that carries this: it is
            // file-global and strictly increasing, and a republish preserves it
            // per *record*, so a record that moved leaves a different one at
            // the offset it vacated.
            if !record_header_describes(&actual, &stated) {
                return Err(mismatch());
            }
        }
        Ok(())
    }

    /// Whether the pathname still resolves to the object this handle opened.
    ///
    /// A handle is bound to an *object*, not to a name. The replacement paths
    /// publish by renaming a new file over the pathname, and on a system where
    /// that leaves an open descriptor reading the old object — which is what
    /// makes a republish safe for readers in flight — a handle goes on serving
    /// a complete, self-consistent generation with nothing to announce that a
    /// newer one exists. [`follow`](Self::follow) answers `0` forever there by
    /// design. This is how a caller learns why.
    ///
    /// `false` also for a pathname that no longer exists: the handle is still
    /// readable, but nothing at that name is it.
    ///
    /// # `false` does not always mean "republished"
    ///
    /// It means "this name did not resolve to my object", and *any* failure to
    /// reach the name produces it — a descriptor limit, a permission change, a
    /// filesystem that went away. This never errs toward calling a stale handle
    /// fresh, which is the direction that matters, but it does mean a caller
    /// must not treat `false` as proof that a newer generation is there to be
    /// had. Concretely: if [`reopen_readonly`](Self::reopen_readonly) then
    /// fails, keep the handle you have and ask again later. It is still a
    /// complete, self-consistent view; discarding it because a transient
    /// `open` failed loses a working reader to a condition that has already
    /// passed.
    ///
    /// **This is a question, not a subscription.** Varlit does not check on
    /// every read — the check is a syscall and reads are the path that must
    /// stay cheap and take `&self` — so a handle that never asks is never told.
    /// A reader that loops has a natural place to ask (see
    /// [`follow`](Self::follow)); one that does not loop has to decide for
    /// itself when freshness matters.
    ///
    /// # Why the comparison is sound
    ///
    /// It compares the operating system's object identity — device and inode on
    /// Unix, volume and file index on Windows — and those are reused once the
    /// object they named is gone. That cannot fool this check, because *this
    /// handle holds the object open*: a live descriptor pins it, so its
    /// identity cannot be handed to a different file while there is anything
    /// here to compare against.
    ///
    /// # Cost
    ///
    /// One `open` and two metadata calls. Nothing is read and nothing is
    /// framed, so this is cheap enough to ask before each round of a polling
    /// loop — but it *is* a syscall, so it is a question the caller asks rather
    /// than one every read answers.
    pub fn is_current(&self) -> Result<bool> {
        let mine = self.file.object_identity()?;
        // Any failure to reach the pathname is `false`, not an error, and it
        // has to be *any* rather than `NotFound` alone. On Windows a file
        // deleted while this handle still holds it open goes delete-pending
        // with its directory entry intact, and `CreateFile` on that name then
        // fails `ERROR_ACCESS_DENIED` — so mapping only `NotFound` turned the
        // documented "removed pathname answers false" into a hard error on the
        // one platform where the case is easiest to hit, and would have failed
        // the ungated test for it on the Windows CI job.
        //
        // Same shape as `path_resolves_to_object`, which this is the public
        // half of: a name we cannot open is not this object.
        //
        // The cost of "any" is that a *transient* failure — a descriptor limit,
        // a permission change, a network filesystem blip — is reported as
        // "not current" too, and the caller cannot tell it from a republish.
        // That is the safe direction to be wrong in (it never claims a stale
        // handle is fresh), and the rustdoc tells callers what to do about it:
        // a `reopen_readonly` that then fails is a reason to keep the handle
        // and retry, not to discard it.
        Ok(path_resolves_to_object(&self.path, &mine))
    }

    /// A fresh read-only handle on whatever the pathname resolves to now.
    ///
    /// The other half of [`is_current`](Self::is_current). The new handle has
    /// independent caches; this reader stays usable until its owner drops it.
    /// Each thread manages its own reader and chooses when to replace it.
    ///
    /// # Which route it takes
    ///
    /// The one this handle is using. A handle that retains a record directory
    /// reopens with one; a handle that keeps none reopens without one, through
    /// the lazy route, so a format carrying `index: header_tails` or an open
    /// digest reopens at a cost that does not grow with the file.
    ///
    /// # Always read-only
    ///
    /// Including from a read-write handle, which is why the name says so. A
    /// second writer is refused by the object lock this one holds, and a read
    /// view of the published generation is the useful thing to hand back.
    pub fn reopen_readonly(&self) -> Result<Self> {
        if self.index.is_retained() {
            Self::open_readonly(self.spec, &self.path)
        } else {
            Ok(Self::open_readonly_lazy_with_report(self.spec, &self.path)?.0)
        }
    }

    /// Reclaims obsolete matrix pages without waiting for existing readers.
    /// Requires a clean, explicitly synced writer. Existing readers retain their
    /// old file until follow/drop; their generation remains readable.
    pub fn compact_matrix(&mut self) -> Result<()> {
        let _permit = self.ensure_write()?;
        let pages = self.file.matrix_pages().ok_or(Error::MatrixLayoutMissing)?;
        if self.open_chunk_is_unwritten()
            || pages.is_dirty()
            || pages.head().native_eof != self.snapshot.len()
        {
            return Err(Error::InvalidFormatSpec(
                "sync matrix changes before compaction",
            ));
        }
        if let Err(error) = self.file.compact_matrix() {
            self.poison.poison();
            return Err(error);
        }
        let source = crate::matrix_generation::MatrixIo::source(self.file.matrix_pages().unwrap())?;
        crate::matrix::rebind_generation_backing(self.matrix.as_mut().unwrap(), &source);
        Ok(())
    }

    /// Confirmed generation captured by this handle. Queries never advance it.
    pub fn matrix_generation(&self) -> Option<u64> {
        self.file.matrix_pages().map(|p| p.head().generation)
    }
    /// Required companion file; its name includes the primary's creation nonce.
    pub fn matrix_generation_path(&self) -> Option<&Path> {
        self.file.matrix_pages().map(|p| p.path())
    }

    /// Extends this handle to records appended since it opened.
    ///
    /// A handle fixes its snapshot length when it opens, and every read is
    /// positional against that length. Each reader queries through `&self`
    /// while the separate writer appends: a reader can
    /// never observe a record the writer has not finished. The cost is that it
    /// never observes one the writer *has* finished either — measured on a
    /// five-record file grown to fifteen, the open handle went on reporting 6
    /// records while a fresh open of the same path reported 18.
    ///
    /// Follows the committed tail without reopening. With a cooperating current
    /// writer, private pending progress visits only new complete frames; unchanged
    /// polls do not reframe them. Publication revalidates a cached batch once.
    /// Limits apply to that range; recovery or an unknown writer resets the cache.
    ///
    /// Matrix readers also adopt the confirmed page root, even if no record
    /// bytes were appended. Compare `matrix_generation()` to observe that case.
    /// Matrix metadata verification runs again according to the open policy.
    /// Returns the record bytes gained.
    ///
    /// # `0` is not one answer
    ///
    /// Four things produce it, and the return value does not say which:
    ///
    /// 1. Nothing was appended.
    /// 2. Bytes were appended but no commit boundary covers them yet — see
    ///    *Uncommitted records* below.
    /// 3. This handle's generation is finished: the pathname was republished
    ///    and the object this handle holds will never grow again, so every
    ///    later call answers `0` too.
    /// 4. This is a read-write handle, which gains nothing — see the last
    ///    section.
    ///
    /// Only (3) is a reason to do something, and only (3) is durable; (1) and
    /// (2) both resolve on their own when the writer gets there.
    /// [`is_current`](Self::is_current) is what separates it from the rest, and
    /// a streaming reader asks it exactly here, on a path that is idle by
    /// definition:
    ///
    /// ```text
    /// if reader.follow()? == 0 {
    ///     if !reader.is_current()? { reader = reader.reopen_readonly()?; }
    ///     wait();
    /// }
    /// ```
    ///
    /// **That idiom serves a reader that is looping, and only that reader.** A
    /// handle that never calls this — one that opened, and reads on demand
    /// without following anything — is never informed of a republish by any
    /// mechanism varlit has, because a handle learns it only by asking. See
    /// `known-limitations.md` §4.2b for what each shape of reader needs.
    ///
    /// # Uncommitted records are still not visible
    ///
    /// Under a `transaction_marker` policy a record becomes visible when a
    /// marker covers it, exactly as at open — the same `committed_prefix_len`
    /// boundary decides both. A file whose tail is appended but not yet
    /// committed answers `0`, and the same call answers the whole run once the
    /// marker lands.
    ///
    /// # What it deliberately does not do
    ///
    /// **Primary-file replacement requires reopening.** Follow retains the
    /// primary file object this handle opened. Matrix companion compaction is
    /// different: its persisted compaction epoch explicitly permits adopting
    /// the replacement companion while retaining that same primary object.
    ///
    /// **Matrix generations advance atomically with their confirmed log EOF.**
    /// Ordinary publications diff immutable roots and update only changed bitmap
    /// index entries, verification pages and cache entries. Only a changed
    /// compaction epoch rebuilds the whole layout. Failed preparation leaves
    /// the captured generation intact. Matrix-only advancement returns zero
    /// appended bytes; inspect `matrix_generation()` to distinguish it.
    ///
    /// **A read-write handle gains nothing and answers `0`.** varlit admits one
    /// writer per object, and that writer's own appends already extend its
    /// snapshot, so its end is the object's end by construction.
    pub fn follow(&mut self) -> Result<u64> {
        let _permit = self.ensure_not_poisoned()?;
        if self.mode == OpenMode::ReadWrite {
            return Ok(0);
        }
        // One short-lived staged value; keep ordinary follow allocation-free here.
        #[allow(clippy::large_enum_variant)]
        enum MatrixFollow {
            Compacted(crate::matrix::MatrixLayout),
            Delta(crate::matrix::MatrixDelta),
        }
        impl MatrixFollow {
            fn apply(self, layout: &mut Option<crate::matrix::MatrixLayout>) {
                match self {
                    Self::Compacted(next) => *layout = Some(next),
                    Self::Delta(delta) => delta.apply(layout.as_mut().unwrap()),
                }
            }
        }
        let mut matrix_next = if let Some(pages) = self.file.matrix_pages() {
            let mut next = pages.refreshed()?;
            if next.head().generation <= pages.head().generation {
                return Ok(0);
            }
            let mut base = self.snapshot.try_clone_file()?;
            let header_len = read_file_header(self.spec, &mut base)?;
            let layout_start = header_len
                .checked_add(MATRIX_CREATION_NONCE_REGION_LEN as u64)
                .ok_or(Error::InvalidMatrixLayout)?;
            let len = next.head().native_eof;
            let layout = if next.head().compaction_epoch != pages.head().compaction_epoch {
                MatrixFollow::Compacted(crate::matrix::read_layout_at_len(
                    self.spec,
                    &mut next,
                    layout_start,
                    len,
                )?)
            } else {
                MatrixFollow::Delta(crate::matrix::MatrixDelta::prepare(
                    self.matrix.as_mut().ok_or(Error::InvalidMatrixLayout)?,
                    pages,
                    &next,
                    layout_start,
                )?)
            };
            Some((layout, next))
        } else {
            None
        };
        let from = self.snapshot.len();
        // The object, not the pathname. A rename may have put a different file
        // at the path, and framing *that* file's bytes at this handle's offsets
        // is the one thing this must never do.
        let mut file = self.snapshot.try_clone_file()?;
        let physical_metadata = file.metadata()?;
        let file_len = matrix_next
            .as_ref()
            .map_or(physical_metadata.len(), |(_, p)| p.head().native_eof);
        if file_len < from {
            return Err(Error::InvalidMatrixLayout);
        }
        if file_len == from {
            if let Some((layout, pages)) = matrix_next.take() {
                layout.apply(&mut self.matrix);
                self.file.adopt_matrix(pages);
                self.chunk_directory = std::cell::OnceCell::new();
            }
            return Ok(0);
        }
        let modified = physical_metadata.modified().ok();
        let mut pending = match self.follow_scan.take() {
            Some(pending) => pending,
            None => crate::try_box(FollowScan::new(self.spec, from, &self.path)?)?,
        };
        let mut progress = pending.progress.take().expect("pending scan owns progress");
        let cached = progress.next > from;
        let epoch = pending.epoch();
        let unchanged_input = progress.from == from
            && pending.observed_len > from
            && file_len == pending.observed_len
            && modified.is_some()
            && modified == pending.observed_modified
            && epoch == pending.writer_epoch;
        if unchanged_input {
            pending.progress = Some(progress);
            self.follow_scan = Some(pending);
            if let Some((layout, pages)) = matrix_next.take() {
                layout.apply(&mut self.matrix);
                self.file.adopt_matrix(pages);
                self.chunk_directory = std::cell::OnceCell::new();
            }
            return Ok(0);
        }
        let reusable = progress.from == from
            && file_len >= pending.observed_len
            && (file_len != pending.observed_len || modified == pending.observed_modified)
            && (!cached || (epoch.is_some() && epoch == pending.writer_epoch));
        if !reusable {
            pending.rows.reset();
            progress = ScanProgress::new(self.spec, from, 0, Some(from))?;
        }
        let resumed = progress.next > from;
        progress = resume_record_scan(
            self.spec,
            &mut file,
            progress,
            ScanIntent::ReadOnly,
            &mut pending.rows,
            file_len,
        )?;
        // A pending prefix can change before it is committed (replacement or
        // writer recovery). Cached parse state must never authorize publication.
        // Replay once when a new commit is discovered, not on every idle poll.
        if resumed
            && progress
                .scanned
                .physical_end_at_commit
                .is_some_and(|end| end > from)
        {
            pending.rows.rewind_for_replay();
            drop(progress);
            progress = resume_record_scan(
                self.spec,
                &mut file,
                ScanProgress::new(self.spec, from, 0, Some(from))?,
                ScanIntent::ReadOnly,
                &mut pending.rows,
                file_len,
            )?;
        }
        pending.observed_len = file_len;
        pending.observed_modified = modified;
        pending.writer_epoch = epoch;
        let has_commit = !self.spec.commit_policy.is_transaction_marker()
            || progress
                .scanned
                .physical_end_at_commit
                .is_some_and(|end| end > from);
        if !has_commit {
            pending.progress = Some(progress);
            self.follow_scan = Some(pending);
            if let Some((layout, pages)) = matrix_next.take() {
                layout.apply(&mut self.matrix);
                self.file.adopt_matrix(pages);
                self.chunk_directory = std::cell::OnceCell::new();
            }
            return Ok(0);
        }
        pending.rows.finish(self.spec, &mut progress.scanned)?;
        let ScanProgress {
            scanned,
            all_sequences,
            ..
        } = progress;
        drop(all_sequences);
        let framed = &pending.rows;
        let logical_len = scanned.physical_end(from);
        if logical_len <= from {
            // A matrix generation can advance without a record commit marker.
            if let Some((layout, pages)) = matrix_next.take() {
                layout.apply(&mut self.matrix);
                self.file.adopt_matrix(pages);
                self.chunk_directory = std::cell::OnceCell::new();
            }
            return Ok(0);
        }
        // Sequences are file-global and strictly increasing, and the scan's own
        // uniqueness check only sees the run it framed. The run begins after
        // everything this handle already holds, so its lowest sequence must
        // too. This is the check that the run really is this object's
        // continuation rather than bytes that came from somewhere else.
        let last_entry = framed.last_entry()?;
        if scanned
            .minimum_sequence
            .is_some_and(|lowest| match self.sequence_state {
                SequenceState::Available(next) => lowest < next,
                SequenceState::Exhausted => true,
            })
        {
            return Err(Error::InvalidCanonicalEncoding(
                "followed records repeat a sequence this handle already holds",
            ));
        }
        let next_progress = ScanProgress::new(self.spec, logical_len, 0, Some(logical_len))?;
        let snapshot = self.snapshot.with_len(logical_len)?;
        if self.index.is_retained() {
            let first = self.index.len();
            let holding = first.checked_add(framed.record_count()).ok_or(
                Error::ResourceArithmeticOverflow {
                    resource: "record count",
                },
            )?;
            self.spec
                .read_limits
                .check(ReadLimitKey::Records, holding as u64)?;
            let mut checkpoint = self.checkpoint_cadence;
            let mut segment = self.segment_cursor;
            for (at, entry) in framed.entries().enumerate() {
                let entry = entry?;
                checkpoint.note_appended(first + at, entry.block_id);
                segment.note_appended(first + at, entry.block_id, entry.checked_physical_end()?);
            }
            // Fallible staging ends here. On scratch I/O failure extend rolls
            // back its logical length, preserving the complete old snapshot.
            self.index.extend(framed.entries())?;
            self.checkpoint_cadence = checkpoint;
            self.segment_cursor = segment;
        }
        self.snapshot = snapshot;
        // The entries just installed describe records past the end the old
        // snapshot allowed, and a read beyond a snapshot's logical length is
        // refused rather than served.
        let snapshot = self.snapshot.clone();
        self.index.rebind(snapshot);
        // Merged, not replaced: a block with no record in this range keeps the
        // tail it already had.
        for (block_id, record_offset) in scanned.newest_pairs() {
            self.block_tails.note_appended(block_id, record_offset);
        }
        self.sequence_state = scanned.sequence_state();
        if let Some(entry) = last_entry {
            self.last_resident_block_id = Some(entry.block_id);
        }
        // A record just adopted may be the newest of its key.
        self.keyed_tails.invalidate_all();
        pending.rows.reset();
        pending.progress = Some(next_progress);
        self.follow_scan = Some(pending);
        // And a matrix chunk record is an ordinary append-log record, so a run
        // may have brought new chunks. The chunk directory is built once and
        // cached in a `OnceCell`, which was sound to keep forever only while a
        // handle's snapshot could not grow — it can now. Measured before this
        // line existed: a followed handle answered `MatrixNotCommitted` for a
        // cell a fresh open of the same file read back.
        self.chunk_directory = std::cell::OnceCell::new();
        if let Some((layout, pages)) = matrix_next.take() {
            layout.apply(&mut self.matrix);
            self.file.adopt_matrix(pages);
        }
        Ok(logical_len - from)
    }

    /// A [`RecordMap`] over the caller's buffer: an index built one record at a
    /// time, only as far as the caller asks.
    ///
    /// **Reads nothing.** The walk starts on the first
    /// [`advance`](RecordMap::advance), [`find`](RecordMap::find) or
    /// [`fill_to`](RecordMap::fill_to), so a map that is never asked a question
    /// costs one `Vec::clear`.
    ///
    /// This is the third answer to "who holds the index", next to the handle's
    /// own 16-byte directory and the caller's full
    /// [`index_entries_into`](Self::index_entries_into) buffer: **nobody holds
    /// all of it, because nobody read all of it.** The map borrows the buffer
    /// rather than the handle, so reads through the handle
    /// (`read_payload_into`, `decode_block_into`) stay available while the map
    /// is alive.
    ///
    /// Available on a handle opened without a directory
    /// ([`open_readonly_without_directory`](Self::open_readonly_without_directory)),
    /// which is the pairing it exists for: the handle keeps nothing, and the
    /// caller builds exactly the part of the index its question needed.
    pub fn record_map<'a>(&self, buffer: &'a mut Vec<RecordIndexEntry>) -> Result<RecordMap<'a>> {
        RecordMap::new(self, buffer)
    }

    /// The block's records as a lazy collection: one decoded value at a time.
    ///
    /// **This allocates** one index entry per matching record, which is what
    /// makes `get(i)` positional.
    /// [`block_entries_into`](Self::block_entries_into) fills the caller's
    /// buffer with those same entries instead.
    ///
    /// Deliberately *not* pointing at
    /// [`decode_blocks_into`](Self::decode_blocks_into): that one decodes every
    /// matching record, so it is bounded by the caller's buffer and not by the
    /// file, which is the opposite of what this collection is for.
    pub fn blocks<T: VarlitBlock>(&self) -> Result<BlockVec<T>> {
        self.blocks_in(self.resident_directory("blocks")?)
    }

    fn blocks_in<T: VarlitBlock, D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
    ) -> Result<BlockVec<T>> {
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        // A non-resident block has no entries here, and an empty collection
        // would say "nothing was written" rather than "not through this door".
        crate::collections::ensure_resident_block::<T>(self.spec)?;
        // **One traversal, charged per entry.** This used to walk the index
        // once to count and once to copy, so that `IndexBytes` could be charged
        // for the exact total before the first copy. That was nearly free when
        // the index was a `Vec` in memory. It is not free now: each traversal
        // faults every entry off disk, so the second pass was `N` extra
        // positional reads to learn a number the first pass already knew.
        //
        // The charge still precedes the memory — it is now per entry, the same
        // shape `key_tail_offsets` uses for `KeyedTailBytes` — so a file that
        // exceeds the ceiling is still refused during the build rather than
        // after the whole array is resident.
        let mut entries: Vec<RecordIndexEntry> = Vec::new();
        for position in 0..dir.record_count() {
            if directory_skips(dir, position, &[T::ID]) {
                continue;
            }
            let entry = dir.record_at(position)?;
            if entry.block_id != T::ID {
                continue;
            }
            let requested = index_bytes_for_count(entries.len().saturating_add(1))?;
            self.spec
                .read_limits
                .check(ReadLimitKey::IndexBytes, requested)?;
            entries
                .try_reserve(1)
                .map_err(|_| Error::AllocationFailed {
                    resource: "block index",
                    requested,
                })?;
            entries.push(entry);
        }
        Ok(BlockVec::new(self.spec, self.snapshot.clone(), entries))
    }

    /// Fills the caller's buffer with the index entry of every record of type
    /// `T` — the entries [`blocks`](Self::blocks) would have allocated.
    ///
    /// `out` is cleared and then extended. This is the caller-supplied-buffer
    /// form of `blocks()`: same entries, same per-entry `IndexBytes` charge,
    /// same laziness — no payload is read and nothing is decoded.
    pub fn block_entries_into<T: VarlitBlock>(
        &self,
        out: &mut Vec<RecordIndexEntry>,
    ) -> Result<()> {
        self.block_entries_into_in::<T, _>(self.resident_directory("block_entries_into")?, out)
    }

    fn block_entries_into_in<T: VarlitBlock, D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
        out: &mut Vec<RecordIndexEntry>,
    ) -> Result<()> {
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        crate::collections::ensure_resident_block::<T>(self.spec)?;
        out.clear();
        for position in 0..dir.record_count() {
            if directory_skips(dir, position, &[T::ID]) {
                continue;
            }
            let entry = dir.record_at(position)?;
            if entry.block_id != T::ID {
                continue;
            }
            let requested = index_bytes_for_count(out.len().saturating_add(1))?;
            self.spec
                .read_limits
                .check(ReadLimitKey::IndexBytes, requested)?;
            out.try_reserve(1).map_err(|_| Error::AllocationFailed {
                resource: "block index",
                requested,
            })?;
            out.push(entry);
        }
        Ok(())
    }

    /// Decodes **every** record of type `T` into the caller's buffer.
    ///
    /// `out` is cleared and then extended.
    ///
    /// **Not the `_into` twin of [`blocks`](Self::blocks), and named so it
    /// cannot be mistaken for one.** `blocks()` returns a lazy collection whose
    /// peak is one payload however many records it covers; this materializes
    /// all of them, so what it costs is bounded by the caller's buffer and not
    /// by the file. For a block carrying a `String` or a `Vec` that is
    /// unbounded in the heap as well as in the buffer.
    ///
    /// It shipped for one round as `blocks_into`, with `blocks()`'s
    /// documentation recommending it as the memory-friendly form. That was
    /// backwards and is corrected here: reach for it when you want all of them
    /// anyway, and for [`block_entries_into`](Self::block_entries_into) when
    /// you want what `blocks()` holds.
    ///
    /// The per-record charge is unchanged from `BlockVec::get`: the
    /// materialization ceiling bounds one payload, not the sum over the walk.
    pub fn decode_blocks_into<T: VarlitBlock>(&self, out: &mut Vec<T>) -> Result<()> {
        self.decode_blocks_into_in::<T, _>(self.resident_directory("decode_blocks_into")?, out)
    }

    fn decode_blocks_into_in<T: VarlitBlock, D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
        out: &mut Vec<T>,
    ) -> Result<()> {
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        crate::collections::ensure_resident_block::<T>(self.spec)?;
        out.clear();
        let mut budget = MaterializationBudget::new(self.spec);
        let mut payload = Vec::new();
        for position in 0..dir.record_count() {
            if directory_skips(dir, position, &[T::ID]) {
                continue;
            }
            let entry = dir.record_at(position)?;
            if entry.block_id != T::ID {
                continue;
            }
            if entry.block_version != T::VERSION {
                return Err(Error::BlockVersionMismatch {
                    block_id: T::ID,
                    expected: T::VERSION,
                    actual: entry.block_version,
                });
            }
            // One record's materialization at a time, exactly as `BlockVec::get`
            // and `BlockIter::next` charge it: the ceiling bounds one payload,
            // not the sum over the walk.
            budget.reset();
            let logical_len = entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
            budget.consume(logical_len)?;
            entry.read_logical_payload_snapshot_into(self.spec, &self.snapshot, &mut payload)?;
            out.try_reserve(1).map_err(|_| Error::AllocationFailed {
                resource: "decoded blocks",
                requested: logical_len,
            })?;
            out.push(budget.decode(&payload, T::ENDIAN.unwrap_or(self.spec.endian))?);
        }
        Ok(())
    }

    /// **This allocates.** [`blocks_migrated_into`](Self::blocks_migrated_into)
    /// takes the caller's buffer instead.
    pub fn blocks_migrated<From, To, M>(&self) -> Result<Vec<To>>
    where
        From: VarlitBlock,
        To: VarlitBlock,
        M: VarlitMigration<From, To>,
    {
        let mut migrated = Vec::new();
        self.blocks_migrated_into::<From, To, M>(&mut migrated)?;
        Ok(migrated)
    }

    /// Fills the caller's buffer with every migrated block.
    ///
    /// `out` is cleared and then extended. The peak is still one payload at a
    /// time — the decode is per record and the decoded value is moved straight
    /// into `out` — so what the caller now owns is the only thing that grows.
    pub fn blocks_migrated_into<From, To, M>(&self, out: &mut Vec<To>) -> Result<()>
    where
        From: VarlitBlock,
        To: VarlitBlock,
        M: VarlitMigration<From, To>,
    {
        self.blocks_migrated_into_in::<From, To, M, _>(
            self.resident_directory("blocks_migrated")?,
            out,
        )
    }

    fn blocks_migrated_into_in<From, To, M, D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
        out: &mut Vec<To>,
    ) -> Result<()>
    where
        From: VarlitBlock,
        To: VarlitBlock,
        M: VarlitMigration<From, To>,
    {
        if From::ID != To::ID {
            return Err(Error::MigrationBlockIdMismatch {
                from: From::ID,
                to: To::ID,
            });
        }
        out.clear();
        let mut budget = MaterializationBudget::new(self.spec);
        let mut payload = Vec::new();
        for position in 0..dir.record_count() {
            if directory_skips(dir, position, &[From::ID]) {
                continue;
            }
            let entry = dir.record_at(position)?;
            if entry.block_id != From::ID || entry.block_version != From::VERSION {
                continue;
            }
            let logical_len = entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
            budget.consume(logical_len)?;
            entry.read_logical_payload_snapshot_into(self.spec, &self.snapshot, &mut payload)?;
            let from: From = budget.decode(&payload, From::ENDIAN.unwrap_or(self.spec.endian))?;
            out.try_reserve(1).map_err(|_| Error::AllocationFailed {
                resource: "migrated blocks",
                requested: logical_len,
            })?;
            out.push(M::migrate(from)?);
        }
        Ok(())
    }

    /// **This allocates** two collections that scale with the file: an index
    /// entry per matching record, and a map entry per distinct key.
    /// [`keyed_blocks_into`](Self::keyed_blocks_into) fills the caller's.
    pub fn keyed_blocks<T>(&self) -> Result<KeyedBlockVec<T::Key, T>>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash + Clone,
    {
        // API2-03, evaluated here as well as in `keyed_blocks_into`. It is not
        // redundant: this is a `const` assertion, and the compile error names
        // the function whose instantiation first forced it. Leaving it only in
        // the callee moved `fail_keyed_contradiction`'s diagnostic off the
        // user's own call and into this file, which is a worse error for a
        // mistake the user made.
        let () = crate::traits::KeyedBlockContract::<T>::OK;
        let mut entries = Vec::new();
        let mut by_key = HashMap::new();
        self.keyed_blocks_into::<T>(&mut entries, &mut by_key)?;
        let blocks = BlockVec::new(self.spec, self.snapshot.clone(), entries);
        Ok(KeyedBlockVec::from_parts(blocks, by_key))
    }

    /// Fills the caller's two collections: the block's index entries in file
    /// order, and the newest entry per key.
    ///
    /// Both are cleared and then filled. They are exactly what
    /// [`keyed_blocks`](Self::keyed_blocks) would have allocated, and
    /// `KeyedBlockVec::from_parts` reassembles a collection from them if that
    /// is what the caller wants.
    ///
    /// **Two of three, and here is the third.** The walk also builds a
    /// transient `HashMap<T::Key, (MergeOrder, Option<RecordIndexEntry>)>`,
    /// which is what decides "newest" when a key repeats. It cannot be the
    /// caller's without putting `MergeOrder` — a private ordering type — into a
    /// public signature. So this removes one map of `distinct keys` and the
    /// entry vector, and leaves that one. Stated rather than implied, because
    /// the saving is two thirds and not all of it.
    pub fn keyed_blocks_into<T>(
        &self,
        entries: &mut Vec<RecordIndexEntry>,
        by_key: &mut HashMap<T::Key, RecordIndexEntry>,
    ) -> Result<()>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash + Clone,
    {
        self.keyed_blocks_into_in::<T, _>(self.resident_directory("keyed_blocks")?, entries, by_key)
    }

    fn keyed_blocks_into_in<T, D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
        entries: &mut Vec<RecordIndexEntry>,
        by_key: &mut HashMap<T::Key, RecordIndexEntry>,
    ) -> Result<()>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash + Clone,
    {
        // API2-03: compile-time keyedness contract (also covers the
        // VarlitReader::keyed_blocks wrapper); registration is the runtime
        // backstop.
        let () = crate::traits::KeyedBlockContract::<T>::OK;
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        entries.clear();
        by_key.clear();
        let mut state: HashMap<T::Key, (MergeOrder, Option<RecordIndexEntry>)> = HashMap::new();
        let mut budget = MaterializationBudget::new(self.spec);
        // One payload buffer for the whole walk, not one per record.
        let mut payload = Vec::new();
        for record_ordinal in 0..dir.record_count() {
            if directory_skips(dir, record_ordinal, &[T::ID, TOMBSTONE_BLOCK_ID]) {
                continue;
            }
            let entry = dir.record_at(record_ordinal)?;
            // One record's materialization at a time. Every decoded block is
            // dropped once its key is taken; what survives the loop is index
            // entries and keys, each charged as it is taken through
            // `index_bytes_for_count`. See `MaterializationBudget`.
            budget.reset();
            let order = MergeOrder::for_record(0, entry.sequence, record_ordinal);
            match entry.block_id {
                id if id == T::ID => {
                    if entry.block_version != T::VERSION {
                        return Err(Error::BlockVersionMismatch {
                            block_id: T::ID,
                            expected: T::VERSION,
                            actual: entry.block_version,
                        });
                    }
                    let logical_len =
                        entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
                    budget.consume(logical_len)?;
                    entry.read_logical_payload_snapshot_into(
                        self.spec,
                        &self.snapshot,
                        &mut payload,
                    )?;
                    let block: T =
                        budget.decode(&payload, T::ENDIAN.unwrap_or(self.spec.endian))?;
                    let key = block.key();
                    if should_apply(state.get(&key), order) {
                        let requested = index_bytes_for_count(state.len().saturating_add(1))?;
                        state.try_reserve(1).map_err(|_| Error::AllocationFailed {
                            resource: "keyed index",
                            requested,
                        })?;
                        state.insert(key, (order, Some(entry.clone())));
                    }
                    let requested = index_bytes_for_count(entries.len().saturating_add(1))?;
                    entries
                        .try_reserve(1)
                        .map_err(|_| Error::AllocationFailed {
                            resource: "block index",
                            requested,
                        })?;
                    entries.push(entry.clone());
                }
                TOMBSTONE_BLOCK_ID => {
                    let logical_len =
                        entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
                    budget.consume(logical_len)?;
                    entry.read_payload_snapshot_into(self.spec, &self.snapshot, &mut payload)?;
                    if let Some(key) =
                        decode_internal_key_payload::<T>(self.spec.endian, &payload, &mut budget)?
                        && should_apply(state.get(&key), order)
                    {
                        let requested = index_bytes_for_count(state.len().saturating_add(1))?;
                        state.try_reserve(1).map_err(|_| Error::AllocationFailed {
                            resource: "keyed index",
                            requested,
                        })?;
                        state.insert(key, (order, None));
                    }
                }
                _ => {}
            }
        }
        let requested = index_bytes_for_count(state.len())?;
        by_key
            .try_reserve(state.len())
            .map_err(|_| Error::AllocationFailed {
                resource: "keyed index",
                requested,
            })?;
        for (key, (_, entry)) in state {
            if let Some(entry) = entry {
                by_key.insert(key, entry);
            }
        }
        Ok(())
    }

    /// **This allocates.**
    /// [`materialized_keyed_blocks_into`](Self::materialized_keyed_blocks_into)
    /// takes the caller's map instead.
    pub fn materialized_keyed_blocks<T>(&self) -> Result<HashMap<T::Key, T>>
    where
        T: VarlitMerge,
        T::Key: Eq + Hash,
    {
        let mut values = HashMap::new();
        self.materialized_keyed_blocks_into::<T>(&mut values)?;
        Ok(values)
    }

    /// Fills the caller's map with the merged live value per key.
    ///
    /// `out` is cleared and then filled. The transient merge state is still
    /// this crate's — it holds a `MergeOrder` beside each value and cannot be
    /// the caller's map without leaking that ordering into the signature — so
    /// what this saves is the second map, not the first. Said plainly rather
    /// than implied: reusing `out` across calls removes one allocation of
    /// `distinct keys`, not both.
    pub fn materialized_keyed_blocks_into<T>(&self, out: &mut HashMap<T::Key, T>) -> Result<()>
    where
        T: VarlitMerge,
        T::Key: Eq + Hash,
    {
        self.materialized_keyed_blocks_into_in::<T, _>(
            self.resident_directory("materialized_keyed_blocks")?,
            out,
        )
    }

    fn materialized_keyed_blocks_into_in<T, D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
        out: &mut HashMap<T::Key, T>,
    ) -> Result<()>
    where
        T: VarlitMerge,
        T::Key: Eq + Hash,
    {
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        let mut state: HashMap<T::Key, (MergeOrder, Option<T>)> = HashMap::new();
        let mut budget = MaterializationBudget::new(self.spec);
        apply_merge_entries::<T, _>(
            self.spec,
            &self.snapshot,
            dir,
            MergeShard::single_file(),
            &mut state,
            &mut budget,
            u64::MAX,
        )?;
        out.clear();
        let requested = allocation_bytes::<(T::Key, T)>(state.len(), "materialized keyed map")?;
        out.try_reserve(state.len())
            .map_err(|_| Error::AllocationFailed {
                resource: "materialized keyed map",
                requested,
            })?;
        for (key, (_, value)) in state {
            if let Some(value) = value {
                out.insert(key, value);
            }
        }
        Ok(())
    }

    /// Every record's block identity and extent, in file order.
    ///
    /// **Each item is fallible, and the iterator is lazy.** Producing an event
    /// means producing the index entry behind it, which is a read on a store
    /// that does not keep them all in memory; the two ways to hide that are to
    /// materialize the whole scan into a `Vec` first — the eager load this
    /// exists not to do — or to swallow a read error as an early `None`, which
    /// would report a truncated file as a short one. So the `Result` is here,
    /// on each item, and nothing is read until the item is asked for.
    /// **One item, and it is the refusal**, when this handle keeps no directory.
    /// `scan` returns an iterator rather than a `Result`, so there is nowhere
    /// else to put it — and an empty iterator would say "no records", which is
    /// the answer a directory-less handle must never give.
    pub fn scan(&self) -> impl Iterator<Item = Result<BlockEvent>> + '_ {
        let refusal = self.resident_directory("scan").err().map(Err).into_iter();
        let events = self
            .index
            .is_retained()
            .then(|| Self::scan_in(&self.index))
            .into_iter()
            .flatten();
        refusal.chain(events)
    }

    fn scan_in<D: RecordDirectory + ?Sized>(
        dir: &D,
    ) -> impl Iterator<Item = Result<BlockEvent>> + '_ {
        directory_records(dir).map(|entry| entry.map(|entry| BlockEvent::from(&entry)))
    }

    /// Verifies every record's stored checksum against its bytes.
    ///
    /// Available on demand so that choosing
    /// [`IntegrityVerification::OnDemand`] defers the announcement
    /// [`IntegrityVerification::AtOpen`] makes while opening, rather than
    /// losing it. Reads every payload, so it costs a full pass over the file;
    /// that cost is the reason it is not the default at open.
    ///
    /// **What "every record" covers.** Two passes, because two things hold the
    /// records: the resident index, and — for a block declared
    /// `resident: false` — that block's footer chain, which is the only way
    /// back to records the index deliberately does not mirror
    /// ([`Self::block_chain`]). The chain pass used to be missing, so a
    /// non-resident block's records were silently omitted; a file whose only
    /// appends were non-resident reported `Ok(0)`, indistinguishable from an
    /// empty file. Both passes call the same `read_payload_snapshot` the read
    /// path calls, so there is still exactly one verification in the crate.
    ///
    /// This is *not* bit-for-bit what `AtOpen` does. `AtOpen` verifies every
    /// physical record as scan frames it, including records after the commit
    /// boundary that this handle excludes; this pass answers for the records
    /// the handle can see.
    ///
    /// **Bounded by the snapshot.** The chain pass reads through the same
    /// snapshot as every other read on this handle, and a read-only handle
    /// sizes that snapshot from the last *resident* record. Under a commit
    /// policy that leaves no resident record after the block's newest one —
    /// [`CommitPolicy::None`], which is what a format declaring no commit
    /// policy gets — the walk therefore reports
    /// [`Error::SnapshotRangeOutOfBounds`] rather than a clean verdict over
    /// bytes it never read. That is the refusal [`Self::block_chain`] already
    /// gives on the same handle: such a block is unreachable read-only in that
    /// configuration, and only `verify_all`'s `Ok` said otherwise. A read-write
    /// handle sizes the snapshot from the file and is unaffected, as is any
    /// policy that ends the file with a resident record
    /// (`transaction_marker`). Measured, 12 non-resident records under
    /// `CommitPolicy::None`: read-write `Ok(12)`, read-only
    /// `Err(SnapshotRangeOutOfBounds { offset: 1347, len: 32, snapshot_len: 27 })`.
    ///
    /// Takes `&self` and reads positionally within the owning thread.
    /// One entry and one payload are materialised
    /// at a time; nothing enters the resident index.
    ///
    /// Returns the number of records verified. A mismatch is
    /// [`Error::ChecksumMismatch`] naming the offending record's offset.
    pub fn verify_all(&self) -> Result<usize> {
        self.verify_all_in(self.resident_directory("verify_all")?)
    }

    fn verify_all_in<D: RecordDirectory + ?Sized>(&self, dir: &D) -> Result<usize> {
        if self.spec.integrity_policy == IntegrityPolicy::None {
            return Ok(0);
        }
        let mut verified = 0usize;
        // The bytes are read to check their checksum and then dropped, so one
        // buffer serves the whole pass. This was an allocation per record.
        let mut payload = Vec::new();
        for entry in directory_records(dir) {
            let entry = entry?;
            // `read_payload_snapshot` is the same check the read path performs,
            // which is exactly the point: there is one verification in the
            // crate, and this method chooses when it runs rather than adding a
            // second copy of it.
            entry.read_payload_snapshot_into(self.spec, &self.snapshot, &mut payload)?;
            verified += 1;
        }
        // A non-resident block's records are never in `self.index` (a
        // descriptor may only name a declared user block, and only ids below
        // `RESERVED_BLOCK_ID_START` can be declared), so this adds to the pass
        // above and cannot double-count it.
        for descriptor in self.spec.block_residency {
            if descriptor.resident {
                continue;
            }
            // `FormatSpec::validate` refuses a non-resident block without
            // `block_offset_chain`, so this cannot be the refusal `block_chain`
            // raises for a format that has no chain; it is propagated rather
            // than asserted away.
            for entry in self.block_chain(descriptor.block_id)? {
                let entry = entry?;
                entry.read_payload_snapshot_into(self.spec, &self.snapshot, &mut payload)?;
                verified += 1;
            }
        }
        Ok(verified)
    }

    /// A snapshot of every index entry, owned by the caller.
    ///
    /// **Owned rather than borrowed, and that is the point.** Returning
    /// `&[RecordIndexEntry]` required the entries to live contiguously inside
    /// this handle for as long as any caller held the borrow — which is exactly
    /// the requirement that keeps the whole index resident and makes a
    /// demand-filled store impossible. An owned snapshot only has to exist
    /// while its holder does.
    ///
    /// `IndexEntries` derefs to `[RecordIndexEntry]`, so `len()`, indexing,
    /// `iter()` and passing it where a slice is expected all read the same as
    /// before. What changed is who owns the bytes.
    ///
    /// **This allocates.** [`index_entries_into`](Self::index_entries_into)
    /// takes the caller's buffer instead and is the form to use in a loop: the
    /// storage is the caller's business, and a library that decides it for them
    /// allocates once per call for no reason.
    pub fn index_entries(&self) -> IndexEntries {
        let mut entries = Vec::new();
        // The infallible surface is kept because 100-odd call sites read it as
        // a slice; a caller that wants the refusal calls `_into`.
        let _ = self.index_entries_into(&mut entries);
        IndexEntries { entries }
    }

    /// Fills the caller's buffer with the record index.
    ///
    /// `out` is cleared and then extended, so a caller that reuses one buffer
    /// across calls allocates once and never again. The same shape the append
    /// path uses for record staging, and for the same reason: the library does
    /// not get to decide where the caller's data lives.
    ///
    /// The copy is charged against `ReadLimitKey::IndexBytes`, like the index
    /// it copies.
    pub fn index_entries_into(&self, out: &mut Vec<RecordIndexEntry>) -> Result<()> {
        self.index_entries_into_in(self.resident_directory("index_entries")?, out)
    }

    /// Visits the retained directory without copying it into an owned result.
    pub(crate) fn record_entries(
        &self,
    ) -> Result<impl Iterator<Item = Result<RecordIndexEntry>> + '_> {
        Ok(self.resident_directory("record_entries")?.iter())
    }

    fn index_entries_into_in<D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
        out: &mut Vec<RecordIndexEntry>,
    ) -> Result<()> {
        out.clear();
        let count = dir.record_count();
        let requested = index_bytes_for_count(count)?;
        self.spec
            .read_limits
            .check(ReadLimitKey::IndexBytes, requested)?;
        out.try_reserve(count)
            .map_err(|_| Error::AllocationFailed {
                resource: "index entry snapshot",
                requested,
            })?;
        for entry in directory_records(dir) {
            out.push(entry?);
        }
        Ok(())
    }

    /// Builds the per-key tail offsets for `T` from the resident index.
    ///
    /// API3-05: every entry this admits is charged to
    /// [`crate::ReadLimits::max_keyed_tail_bytes`] *before* the memory is taken, so
    /// the configured ceiling bounds the **peak** of the build and not merely
    /// what is retained afterwards.
    ///
    /// This is the entry point `VarlitFile::keyed_tail_map` uses to seed the
    /// resident keyed-tail cache - the cache the generic keyed API maintains
    /// and the one the generated keyed writers prime at construction through
    /// [`VarlitFile::prime_keyed_tails`] (F-01). Before
    /// this charge existed, both were guarded by `try_reserve` alone: a file
    /// with `N` distinct keys forced an `N`-entry resident map whatever the
    /// configured ceiling said, and `max_keyed_tail_bytes` - including
    /// `UNTRUSTED`'s 256 MiB - only refused *further* growth within the
    /// session.
    ///
    /// The charged value is the structural peak of this function, which is
    /// larger than the map it returns: the build keeps a transient
    /// `(MergeOrder, u64)` per key so it can resolve the winning record, and
    /// that map is still alive when the returned map is reserved. The charge
    /// is therefore `n * size_of::<(T::Key, (MergeOrder, u64))>()` while the
    /// transient map grows to `n`, and the sum of both maps' inline storage at
    /// the final reservation. Opening a file consequently charges more than
    /// the steady-state map costs; the charge is a conservative model of what
    /// is actually allocated, not of what survives.
    ///
    /// This build can only account for inline storage, because the map it
    /// returns holds `T::Key` rather than a canonical byte payload; heap owned
    /// by a `T::Key` is not charged here. The *retained* cache this seeds is
    /// byte-keyed, and its charge does include the key payload heap it owns
    /// (see `KeyedTailMap::charge_for`).
    /// **This allocates.**
    /// [`key_tail_offsets_into`](Self::key_tail_offsets_into) takes the
    /// caller's map instead.
    pub fn key_tail_offsets<T>(&self) -> Result<HashMap<T::Key, u64>>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        let mut offsets = HashMap::new();
        self.key_tail_offsets_into::<T>(&mut offsets)?;
        Ok(offsets)
    }

    /// Fills the caller's map with the newest record offset per key.
    ///
    /// `out` is cleared and then filled. As with
    /// [`materialized_keyed_blocks_into`](Self::materialized_keyed_blocks_into),
    /// the transient ordering map stays this crate's — it carries a
    /// `MergeOrder` the caller has no use for — so this removes the second map
    /// of `distinct keys`, not the first. The `KeyedTailBytes` charge below
    /// still accounts for both being alive at once, unchanged.
    /// # Without a resident directory
    ///
    /// A lazy handle keeps none, so this used to be one of the entry points it
    /// simply could not serve — and because a generated writer primes one keyed
    /// tail map per keyed block at construction, that refusal arrived before
    /// the caller had done anything at all.
    ///
    /// The chains hold the answer. `prev_same_block_offset` links each record
    /// to the previous record of its block, so walking one block's chain
    /// newest-first reaches every record of that block, reading nothing else in
    /// the file. `keyed_chain_directory` collects those records and the
    /// tombstones into file order and hands them to the same builder the
    /// resident path uses, so the two produce the same map by construction
    /// rather than by two implementations agreeing.
    pub fn key_tail_offsets_into<T>(&self, out: &mut HashMap<T::Key, u64>) -> Result<()>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        if let Some(dir) = self.index.is_retained().then_some(&self.index) {
            return self.key_tail_offsets_into_in::<T, _>(dir, out);
        }
        let chained = self.keyed_chain_directory(T::ID, "key_tail_offsets")?;
        self.key_tail_offsets_into_in::<T, _>(&chained, out)
    }

    /// The records that can move `block_id`'s keyed tails, in file order.
    ///
    /// Two chains, because two block ids move a keyed tail: the block itself,
    /// and [`TOMBSTONE_BLOCK_ID`], whose records may name any keyed block's
    /// key. The tombstone chain is shared by every keyed block, so it is not
    /// filtered here — the builder decodes each one against `T` exactly as it
    /// does on the resident path.
    ///
    /// # Why file order matters
    ///
    /// The builder breaks sequence ties with the record's *position in the
    /// directory* (`MergeOrder::for_record`). A chain yields records
    /// newest-first with no position at all, so the sort is what makes the two
    /// paths agree: records are appended at strictly increasing offsets and
    /// directory position is append order, so sorting by offset reconstructs
    /// exactly the ordinals the resident path would have used.
    ///
    /// # What this is bounded by
    ///
    /// The records of one keyed block plus the tombstones — not the file. That
    /// is the whole point, and it is why this may be materialised at all: the
    /// keyed blocks a format declares are the small ones by design, and
    /// [`BlockChain`] already charges its walk against `ReadLimitKey::Records`.
    fn keyed_chain_directory(
        &self,
        block_id: u32,
        operation: &'static str,
    ) -> Result<Vec<RecordIndexEntry>> {
        if !self.spec.index_policy.block_offset_chain {
            // Without the block chain there is no second route to these
            // records, so the refusal the caller would have had stands.
            return Err(Error::NoResidentDirectory { operation });
        }
        let mut records = Vec::new();
        for id in [block_id, TOMBSTONE_BLOCK_ID] {
            for entry in self.block_chain(id)? {
                let entry = entry?;
                let requested = index_bytes_for_count(records.len().saturating_add(1))?;
                self.spec
                    .read_limits
                    .check(ReadLimitKey::IndexBytes, requested)?;
                records
                    .try_reserve(1)
                    .map_err(|_| Error::AllocationFailed {
                        resource: "keyed chain directory",
                        requested,
                    })?;
                records.push(entry);
            }
        }
        records.sort_unstable_by_key(|entry| entry.record_offset);
        Ok(records)
    }

    fn key_tail_offsets_into_in<T, D: RecordDirectory + ?Sized>(
        &self,
        dir: &D,
        out: &mut HashMap<T::Key, u64>,
    ) -> Result<()>
    where
        T: VarlitKeyedBlock,
        T::Key: Eq + Hash,
    {
        // API2-03: compile-time keyedness contract (also covers the
        // VarlitReader/VarlitWriter key_tail_offsets wrappers); registration is
        // the runtime backstop.
        let () = crate::traits::KeyedBlockContract::<T>::OK;
        crate::collections::ensure_registered_block::<T>(self.spec)?;
        let mut tails: HashMap<T::Key, (MergeOrder, u64)> = HashMap::new();
        let mut budget = MaterializationBudget::new(self.spec);
        // One payload buffer for the whole walk, not one per record.
        let mut payload = Vec::new();
        for record_ordinal in 0..dir.record_count() {
            // Only two block ids can move `T`'s tail: `T` itself, and a
            // tombstone, which may name one of `T`'s keys. When the directory
            // can say which a record is without building the entry, every
            // other record is skipped here — before `record_at`, which for the
            // resident index is a positional read of that record's header.
            //
            // This is what makes a generated writer's construction affordable.
            // It primes one map per keyed block, so a format with four of them
            // read every record header four times to keep four small maps. The
            // walk is still O(records); what it no longer does is read them.
            //
            // `record_ordinal` stays the position in the directory rather than
            // a count of what survived the filter, because `MergeOrder` uses it
            // to break ties between records that share a sequence.
            if directory_skips(dir, record_ordinal, &[T::ID, TOMBSTONE_BLOCK_ID]) {
                continue;
            }
            let entry = dir.record_at(record_ordinal)?;
            // One record's materialization at a time (see
            // `MaterializationBudget`). Every decoded block is dropped once its
            // key is taken, so the peak here is one payload however many
            // records the block has; what the build retains is keys and
            // offsets, and those are charged to `max_keyed_tail_bytes` below.
            //
            // This is on the *write* path — `push_keyed` seeds the tail cache
            // from here — so a budget that drained across the walk could refuse
            // the first append to an undamaged file whose records for `T` total
            // more than `max_materialized_bytes` (`STANDARD`: 1 GiB).
            budget.reset();
            let order = MergeOrder::for_record(0, entry.sequence, record_ordinal);
            match entry.block_id {
                id if id == T::ID => {
                    let logical_len =
                        entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
                    budget.consume(logical_len)?;
                    entry.read_logical_payload_snapshot_into(
                        self.spec,
                        &self.snapshot,
                        &mut payload,
                    )?;
                    let block: T =
                        budget.decode(&payload, T::ENDIAN.unwrap_or(self.spec.endian))?;
                    let key = block.key();
                    if tails.get(&key).is_none_or(|(old, _)| order >= *old) {
                        let requested = allocation_bytes::<(T::Key, (MergeOrder, u64))>(
                            tails.len().saturating_add(1),
                            "key tail offsets",
                        )?;
                        // API3-05: charge the growth before it is taken, so a
                        // file whose distinct key count alone exceeds the
                        // configured ceiling is refused during the build
                        // rather than after the whole map is resident.
                        self.spec
                            .read_limits
                            .check(ReadLimitKey::KeyedTailBytes, requested)?;
                        tails.try_reserve(1).map_err(|_| Error::AllocationFailed {
                            resource: "key tail offsets",
                            requested,
                        })?;
                        tails.insert(key, (order, entry.record_offset));
                    }
                }
                TOMBSTONE_BLOCK_ID => {
                    let logical_len =
                        entry.logical_payload_len_snapshot(self.spec, &self.snapshot)?;
                    budget.consume(logical_len)?;
                    entry.read_payload_snapshot_into(self.spec, &self.snapshot, &mut payload)?;
                    if let Some(key) =
                        decode_internal_key_payload::<T>(self.spec.endian, &payload, &mut budget)?
                        && tails.get(&key).is_none_or(|(old, _)| order >= *old)
                    {
                        let requested = allocation_bytes::<(T::Key, (MergeOrder, u64))>(
                            tails.len().saturating_add(1),
                            "key tail offsets",
                        )?;
                        // API3-05: charge the growth before it is taken, so a
                        // file whose distinct key count alone exceeds the
                        // configured ceiling is refused during the build
                        // rather than after the whole map is resident.
                        self.spec
                            .read_limits
                            .check(ReadLimitKey::KeyedTailBytes, requested)?;
                        tails.try_reserve(1).map_err(|_| Error::AllocationFailed {
                            resource: "key tail offsets",
                            requested,
                        })?;
                        tails.insert(key, (order, entry.record_offset));
                    }
                }
                _ => {}
            }
        }
        let requested = allocation_bytes::<(T::Key, u64)>(tails.len(), "key tail offsets")?;
        // API3-05: the transient ordering map is still alive while the
        // returned map is reserved, so the peak charged here is the sum of
        // both.
        let peak =
            allocation_bytes::<(T::Key, (MergeOrder, u64))>(tails.len(), "key tail offsets")?
                .checked_add(requested)
                .ok_or(Error::AllocationFailed {
                    resource: "key tail offsets",
                    requested: u64::MAX,
                })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::KeyedTailBytes, peak)?;
        out.clear();
        out.try_reserve(tails.len())
            .map_err(|_| Error::AllocationFailed {
                resource: "key tail offsets",
                requested,
            })?;
        out.extend(tails.into_iter().map(|(key, (_, offset))| (key, offset)));
        Ok(())
    }

    // -----------------------------------------------------------------------
    // Growing matrices: chunk routing
    // -----------------------------------------------------------------------

    /// The two gates every region path passes before addressing a cell.
    ///
    /// `ensure_fatal_access_allowed` is the layout-wide stop, and
    /// `ensure_commit_publishable` is the per-category quarantine. The chunk
    /// path consulted neither, so a file whose matrix had been fenced off was
    /// still readable and writable through any chunked row.
    fn ensure_chunk_access_allowed(&self, category: &str) -> Result<()> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::ensure_chunk_access_allowed(matrix, category)
    }

    /// The whole of what a region path does before it addresses a cell, for a
    /// typed chunk path: validate `T` against the file's schema, then gate on
    /// **the spec's** category for `T::ID`.
    ///
    /// Both halves were missing on the read side, and the fix for the write
    /// side was itself incomplete: it gated on `T::CATEGORY`, a constant the
    /// caller declares, so the type under inspection chose which quarantine
    /// applied to it. `ensure_matrix_block` returns the descriptor's category,
    /// which is the one the file's schema hash covers.
    fn ensure_chunk_block_access<T: VarlitMatrixBlock>(&self) -> Result<&'static str> {
        let category = crate::matrix::ensure_matrix_block::<T>(self.spec)?;
        self.ensure_chunk_access_allowed(category)?;
        Ok(category)
    }

    /// The same gate for the paths that address a block by id rather than by
    /// type — `clear_matrix_cell_by_category` reaches the chunk that way, and
    /// went through no gate at all.
    fn ensure_chunk_access_by_block_id(&self, block_id: u32) -> Result<()> {
        let category = self
            .spec
            .matrix_blocks
            .iter()
            .find(|block| block.block_id == block_id)
            .ok_or(Error::MatrixBlockMissing(block_id))?
            .category;
        self.ensure_chunk_access_allowed(category)
    }

    /// Which chunk a row belongs to, and its row inside that chunk.
    ///
    /// `None` when no dimension grows, or when the row is inside the declared
    /// extent — chunk 0 is the matrix region, so those rows take the path they
    /// always took and this feature is invisible to them.
    fn chunk_for_row(&self, row: u64) -> Option<(u64, u64)> {
        let rows = self.spec.growing_rows_per_chunk()?;
        let chunk = row / rows;
        if chunk == 0 {
            return None;
        }
        Some((chunk, row % rows))
    }

    /// Cells per row for one matrix block, i.e. the extent of dimension 1.
    fn chunk_row_width(&self, block: &crate::format::MatrixBlockDescriptor) -> Result<u64> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        matrix
            .dimension(block.dimensions[1])
            .ok_or_else(|| Error::MatrixDimensionMissing(block.dimensions[1].to_string()))
    }

    /// Opens chunk `index`, writing the chunk whatever chunk was open before it.
    ///
    /// Refuses a chunk older than the open one. That refusal is the whole
    /// contract of writing the chunk: a value that arrives late is reported, not dropped.
    /// Makes chunk `index` the open one, loading it back from its record when
    /// one exists.
    ///
    /// **Both halves of this used to be a refusal.** Writing a row that belonged
    /// to an already-written chunk — or to any chunk older than the open one —
    /// returned `MatrixChunkClosed`, which made a written chunk permanently
    /// unmodifiable and, worse, made the rows of a chunk that was merely
    /// *skipped* permanently unwritable. A reader-writer that can edit a written
    /// region row could not edit a written chunk row, for no reason in the
    /// format: a chunk record is an ordinary record and `RecordFile` has had a
    /// route for rewriting one of those in place since round 12.
    ///
    /// The cost of the reload, stated: the chunk record's commit map, checksum
    /// table and slot region are read into the buffer — one chunk's worth of
    /// bytes, the same ceiling `rows_per_chunk` already sets on holding one
    /// open, so the memory bound is unchanged. It is a cold path (a chunk
    /// transition, not a record), and a format that never revisits an old row
    /// never takes it.
    fn open_chunk_at(&mut self, index: u64) -> Result<()> {
        match &self.open_chunk {
            Some(open) if open.index == index => return Ok(()),
            Some(_) => self.write_open_chunk_record()?,
            None => {}
        }
        if let Some(locator) = self.chunk_directory()?.find(index) {
            return self.reopen_written_chunk(locator);
        }
        let rows = self
            .spec
            .growing_rows_per_chunk()
            .ok_or(Error::MatrixLayoutMissing)?;
        let first_row = index
            .checked_mul(rows)
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "matrix chunk first row",
            })?;
        let cell_crc = !matches!(self.spec.integrity_policy, IntegrityPolicy::None);
        let mut blocks = Vec::new();
        blocks
            .try_reserve_exact(self.spec.matrix_blocks.len())
            .map_err(|_| Error::AllocationFailed {
                resource: "matrix chunk blocks",
                requested: self.spec.matrix_blocks.len() as u64,
            })?;
        for descriptor in self.spec.matrix_blocks {
            let width = self.chunk_row_width(descriptor)?;
            let cells = rows
                .checked_mul(width)
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk cells",
                })?;
            self.spec
                .read_limits
                .check(ReadLimitKey::MatrixCells, cells)?;
            let slot_len = cells.checked_mul(descriptor.slot_stride).ok_or(
                Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk slot region",
                },
            )?;
            self.spec
                .read_limits
                .check(ReadLimitKey::MatrixSlotRegionLen, slot_len)?;
            let commit_len = cells.div_ceil(8);
            blocks.push(OpenChunkBlock {
                block_id: descriptor.block_id,
                stride: descriptor.slot_stride,
                cells,
                written: try_zeroed_vec(commit_len, "matrix chunk write map")?,
                commit: try_zeroed_vec(commit_len, "matrix chunk commit map")?,
                crc: if cell_crc {
                    try_zeroed_vec(
                        cells.checked_mul(MATRIX_CHUNK_CRC_LEN).ok_or(
                            Error::ResourceArithmeticOverflow {
                                resource: "matrix chunk checksum table",
                            },
                        )?,
                        "matrix chunk checksum table",
                    )?
                } else {
                    Vec::new()
                },
                slots: try_zeroed_vec(slot_len, "matrix chunk slot region")?,
            });
        }
        self.open_chunk = Some(OpenChunk {
            index,
            first_row,
            rows,
            compression: self.spec.chunk_compression,
            blocks,
            dirty: false,
            backing: None,
        });
        Ok(())
    }

    /// Loads a written chunk's record back into the buffer as the open chunk.
    ///
    /// Every geometry field was already checked against the spec by
    /// `build_chunk_directory` (rows, first row, block count, checksum policy,
    /// compression policy) and by `chunk_block_location` (per-block stride and
    /// cell count), so this reads bytes rather than re-deriving trust.
    ///
    /// **`written` is not on disk, and this is what that costs.** The record
    /// carries the commit map, the checksums and the slot bytes; the
    /// write-this-session bitmap is buffer state, so it cannot be restored. The
    /// buffer is seeded the way the region answers the same question — a cell
    /// counts as written if it is committed, or if its slot bytes are not all
    /// zero (`matrix::commit_cell`). The one case that differs from an
    /// uninterrupted session: a cell written with an all-zero value and never
    /// committed reads as unwritten after a reload, so committing it needs the
    /// value written again. That is exactly the region's behaviour for the same
    /// cell, and the alternative — persisting a second bitmap — would grow every
    /// chunk record for a distinction that only a discarded write can observe.
    fn reopen_written_chunk(&mut self, locator: ChunkLocator) -> Result<()> {
        if locator.compressed_slots {
            return Err(Error::MatrixChunkNotReopenable {
                chunk: locator.index,
                reason: "chunk compression",
            });
        }
        if self.spec.index_policy.segment_on_flush {
            return Err(Error::MatrixChunkNotReopenable {
                chunk: locator.index,
                reason: "segment_on_flush",
            });
        }
        let rows = self
            .spec
            .growing_rows_per_chunk()
            .ok_or(Error::MatrixLayoutMissing)?;
        let first_row =
            locator
                .index
                .checked_mul(rows)
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "matrix chunk first row",
                })?;
        let mut blocks = Vec::new();
        blocks
            .try_reserve_exact(self.spec.matrix_blocks.len())
            .map_err(|_| Error::AllocationFailed {
                resource: "matrix chunk blocks",
                requested: self.spec.matrix_blocks.len() as u64,
            })?;
        for descriptor in self.spec.matrix_blocks {
            let location = self
                .chunk_block_location(
                    locator.record_offset,
                    locator.payload_len,
                    locator.block_count,
                    locator.cell_crc,
                    false,
                    descriptor.block_id,
                )?
                // A block this spec declares and the record does not: the
                // record was written by a different layout, and every cell
                // address derived from it would name another block's bytes.
                .ok_or(Error::InvalidMatrixChunk)?;
            let cells = location.cells;
            self.spec
                .read_limits
                .check(ReadLimitKey::MatrixCells, cells)?;
            let slot_len =
                cells
                    .checked_mul(location.stride)
                    .ok_or(Error::ResourceArithmeticOverflow {
                        resource: "matrix chunk slot region",
                    })?;
            self.spec
                .read_limits
                .check(ReadLimitKey::MatrixSlotRegionLen, slot_len)?;
            // The stored commit map, at its stored length. Re-encoding it at
            // the canonical `cells.div_ceil(8)` would be a different number of
            // bytes for a record whose map is longer than that — which
            // `chunk_block_location` permits, checking only that it covers the
            // cells — and the rewrite must reproduce the payload length exactly.
            let commit_len = location
                .crc_offset
                .unwrap_or(location.slots_offset)
                .checked_sub(location.commit_offset)
                .ok_or(Error::InvalidMatrixChunk)?;
            let mut commit = try_zeroed_vec(commit_len, "matrix chunk commit map")?;
            self.snapshot
                .read_exact_at(location.commit_offset, &mut commit)?;
            note_chunk_bytes_read(commit_len);
            let crc = match location.crc_offset {
                Some(crc_offset) => {
                    let crc_len = cells.checked_mul(MATRIX_CHUNK_CRC_LEN).ok_or(
                        Error::ResourceArithmeticOverflow {
                            resource: "matrix chunk checksum table",
                        },
                    )?;
                    let mut crc = try_zeroed_vec(crc_len, "matrix chunk checksum table")?;
                    self.snapshot.read_exact_at(crc_offset, &mut crc)?;
                    note_chunk_bytes_read(crc_len);
                    crc
                }
                None => Vec::new(),
            };
            let mut slots = try_zeroed_vec(slot_len, "matrix chunk slot region")?;
            self.snapshot
                .read_exact_at(location.slots_offset, &mut slots)?;
            note_chunk_bytes_read(slot_len);
            let written = seed_written_map(&commit, &slots, cells, location.stride)?;
            blocks.push(OpenChunkBlock {
                block_id: descriptor.block_id,
                stride: location.stride,
                cells,
                written,
                commit,
                crc,
                slots,
            });
        }
        self.open_chunk = Some(OpenChunk {
            index: locator.index,
            first_row,
            rows,
            compression: None,
            blocks,
            // The buffer equals the record it came from. Writing it out now
            // would rewrite a record with its own bytes, and an idle flush
            // between a reopen and the first edit must stay a no-op.
            dirty: false,
            backing: Some(locator.ordinal),
        });
        Ok(())
    }

    /// Writes the open chunk as one ordinary internal record.
    ///
    /// **The chunk is released only after the record is on disk.** The first
    /// version `take()`d it up front and then ran three fallible steps — the
    /// encode, the payload ceiling, the append — so any failure destroyed the
    /// data *and* left `open_chunk` empty, which made a retried `flush()`
    /// return `Ok(())` for a chunk that no longer existed anywhere. Silent loss
    /// reported as success.
    ///
    /// **A chunk with no committed cell stays open rather than being dropped.**
    /// It was dropped before, so `write` → `flush` → `commit` lost the write on
    /// a chunked row while working on a region row, and the row could become
    /// permanently unwritable once a later chunk written past it. There is
    /// nothing to publish — a reader cannot see an uncommitted cell — so
    /// holding it costs a commit point nothing, and an idle flush still writes
    /// no record, which is the property this guard was for.
    fn write_open_chunk_record(&mut self) -> Result<()> {
        let (payload, index, block_count, cell_crc, compressed_slots) = {
            let Some(chunk) = self.open_chunk.as_ref() else {
                return Ok(());
            };
            if !chunk.dirty {
                return Ok(());
            }
            (
                chunk.encode()?,
                chunk.index,
                u32::try_from(chunk.blocks.len()).map_err(|_| {
                    Error::ResourceArithmeticOverflow {
                        resource: "matrix chunk block count",
                    }
                })?,
                chunk.blocks.iter().any(|block| !block.crc.is_empty()),
                chunk.compression.is_some(),
            )
        };
        let payload_len = payload.len() as u64;
        self.spec
            .read_limits
            .check(ReadLimitKey::RecordPayloadLen, payload_len)?;
        // Taken from the append itself, not from a second `metadata()` call:
        // the two would disagree if anything landed between them.
        self.check_write()?;
        // Append a new immutable version; confirmed EOF controls its visibility.
        let info = self.ensure_write()?.write_record_with_prev_key(
            MATRIX_CHUNK_BLOCK_ID,
            MATRIX_CHUNK_VERSION,
            RECORD_FLAG_INTERNAL,
            0,
            &payload,
            None,
        )?;
        let record_offset = info.record_offset;
        // Extend the directory rather than invalidate it: a writer writing the chunk its
        // millionth chunk must not pay a rebuild, and the newest entry is what
        // answers "which chunks are written" on the next write.
        //
        // `get_mut`, never `chunk_directory()`. Asking for the directory here
        // *builds* it, and building it needs a growing-matrix spec — so a
        // format that declares none, which can still reach this through a
        // hand-built chunk, got `InvalidMatrixChunk` out of a write that had
        // already succeeded. The ordinal is only needed to back the buffer
        // below, and a handle that has no directory yet has not looked one up:
        // it will build it on the next chunk access and find this record there.
        let mut ordinal = None;
        if let Some(directory) = self.chunk_directory.get_mut() {
            let at = directory.next_ordinal();
            ordinal = Some(at);
            directory.note_written(ChunkLocator {
                index,
                record_offset,
                payload_len,
                block_count,
                cell_crc,
                compressed_slots,
                ordinal: at,
            });
        }
        // **On disk, and the buffer stays.** Releasing it here lost data, and
        // the loss was invisible: the write bitmap is buffer state that no
        // record carries, so a chunk released at a flush and reloaded at the
        // next commit came back with `written` rebuilt from "is the slot
        // non-zero" — and a cell holding a legitimate all-zero value therefore
        // read as never written. `write` → `flush` → `commit` on such a cell
        // returned `MatrixCellNotWritten` on a chunked row while succeeding on
        // the identical region row (measured 2026-08-09), which is the exact
        // defect a zero-valued cell was already fixed for once this round.
        //
        // Keeping it is also cheaper — no reload on the next edit — and costs
        // nothing in memory, because one chunk buffer is the ceiling this design
        // already sets. It is released on a transition to a different chunk
        // index, which is the only point where a second buffer would be needed.
        //
        // The backing ordinal addresses the newest appended chunk version.
        // Keep session-only write evidence with the buffer across flushes.
        // Normal chunk access builds the directory before opening the buffer.
        match ordinal {
            Some(at) => {
                if let Some(chunk) = self.open_chunk.as_mut() {
                    chunk.dirty = false;
                    chunk.backing = Some(at);
                }
            }
            None => self.open_chunk = None,
        }
        Ok(())
    }

    /// Whether the open chunk holds anything the file does not.
    ///
    /// The question `open_chunk.is_some()` used to stand in for, and stopped
    /// answering when a written chunk began staying open: a clean backed chunk
    /// is byte-for-byte its record, so a handle that dropped now would lose
    /// nothing.
    fn open_chunk_is_unwritten(&self) -> bool {
        self.open_chunk
            .as_ref()
            .is_some_and(|chunk| chunk.dirty || chunk.backing.is_none())
    }

    fn chunk_block_slice<T: VarlitMatrixBlock>(
        &mut self,
        chunk_index: u64,
        local_row: u64,
        key: MatrixKey,
    ) -> Result<(usize, u64)> {
        // Every region path goes through these before touching a cell and the
        // chunk path went through none of them: a quarantined category stayed
        // writable through a chunked row, a layout whose fatal-access gate had
        // fired was still addressable, and `T` was never checked against the
        // file's schema at all.
        self.ensure_chunk_block_access::<T>()?;
        self.open_chunk_at(chunk_index)?;
        let width = self
            .spec
            .matrix_blocks
            .iter()
            .find(|block| block.block_id == T::ID)
            .ok_or(Error::MatrixBlockMissing(T::ID))
            .and_then(|block| self.chunk_row_width(block))?;
        if key.ch >= width {
            return Err(Error::MatrixKeyOutOfBounds {
                scan: key.scan,
                ch: key.ch,
            });
        }
        let ordinal = local_row
            .checked_mul(width)
            .and_then(|base| base.checked_add(key.ch))
            .ok_or(Error::InvalidMatrixLayout)?;
        let chunk = self.open_chunk.as_ref().ok_or(Error::InvalidMatrixChunk)?;
        let position = chunk
            .block_position(T::ID)
            .ok_or(Error::MatrixBlockMissing(T::ID))?;
        Ok((position, ordinal))
    }

    /// Writes one already-encoded cell into the open chunk.
    ///
    /// The shared tail of both write entry points: `write_matrix_cell` encodes
    /// and calls this, `write_matrix_cell_payload` calls it directly. Keeping
    /// one body is the point — the payload entry point spent its first version
    /// unrouted, refusing a chunked row with `MatrixKeyOutOfBounds` while
    /// `write_matrix_cell` accepted the same key.
    fn write_chunk_cell_payload<T: VarlitMatrixBlock>(
        &mut self,
        key: MatrixKey,
        chunk_index: u64,
        local_row: u64,
        payload: &[u8],
    ) -> Result<()> {
        let (position, ordinal) = self.chunk_block_slice::<T>(chunk_index, local_row, key)?;
        let chunk = self.open_chunk.as_mut().ok_or(Error::InvalidMatrixChunk)?;
        let block = &mut chunk.blocks[position];
        if payload.len() as u64 != block.stride {
            return Err(Error::MatrixSizeMismatch {
                expected: block.stride,
                actual: payload.len() as u64,
            });
        }
        let start = usize::try_from(
            ordinal
                .checked_mul(block.stride)
                .ok_or(Error::InvalidMatrixChunk)?,
        )
        .map_err(|_| Error::InvalidMatrixLayout)?;
        block.slots[start..start + payload.len()].copy_from_slice(payload);
        if !block.crc.is_empty() {
            let at = usize::try_from(
                ordinal
                    .checked_mul(MATRIX_CHUNK_CRC_LEN)
                    .ok_or(Error::InvalidMatrixChunk)?,
            )
            .map_err(|_| Error::InvalidMatrixLayout)?;
            let checksum = crc32_bytes(payload)?;
            block.crc[at..at + 4].copy_from_slice(&checksum.to_le_bytes());
        }
        let byte = usize::try_from(ordinal / 8).map_err(|_| Error::InvalidMatrixLayout)?;
        block.written[byte] |= 1u8 << (ordinal % 8);
        // A-7. A write, not just a commit, now makes the buffer differ from the
        // file, and a chunk that is not `dirty` is dropped on the next chunk
        // transition — so without this a write into a reloaded chunk vanished
        // silently, which is strictly worse than the refusal it replaced.
        //
        // Widening `dirty` to "has content" was tried before reopening existed
        // and had to be reverted: it made an uncommitted write force the chunk
        // out, and a chunk that had gone out could never be opened again, so a
        // `write` → `flush` sequence *locked the rest of its rows forever*. That
        // is no longer the case — a written chunk comes back — which is what
        // makes this the honest meaning rather than a trap.
        chunk.dirty = true;
        Ok(())
    }

    pub fn write_matrix_cell<T: VarlitMatrixBlock>(
        &mut self,
        key: MatrixKey,
        value: &T,
    ) -> Result<()> {
        let _permit = self.ensure_write()?;
        if let Some((chunk_index, local_row)) = self.chunk_for_row(key.scan) {
            let (position, ordinal) = self.chunk_block_slice::<T>(chunk_index, local_row, key)?;
            let stride = self
                .open_chunk
                .as_ref()
                .ok_or(Error::InvalidMatrixChunk)?
                .blocks[position]
                .stride;
            // Bounded exactly as the region path bounds it (DEF-02): one byte
            // past the stride is enough to report the true length, and no
            // further buffering is possible whatever the encode does.
            let encoded = match crate::codec::encode_to_vec_limited(
                value,
                T::ENDIAN.unwrap_or(self.spec.endian),
                stride.saturating_add(1),
                "matrix chunk slot payload",
            ) {
                Ok(encoded) => encoded,
                Err(Error::LimitExceeded { actual, .. }) => {
                    return Err(Error::MatrixSizeMismatch {
                        expected: stride,
                        actual,
                    });
                }
                Err(error) => return Err(error),
            };
            // One body, shared with `write_matrix_cell_payload`. This branch
            // used to keep its own copy of the store, and when the write
            // bitmap arrived only the shared one learned to set it — so the
            // typed write silently stopped marking cells written.
            let _ = (position, ordinal);
            return self.write_chunk_cell_payload::<T>(key, chunk_index, local_row, &encoded);
        }
        let result = {
            let matrix = self.matrix.as_mut().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::write_cell(self.spec, matrix, self.file.matrix_region(), key, value)
        };
        self.finish_matrix_mutation(result)
    }

    pub fn write_matrix_cell_payload<T: VarlitMatrixBlock>(
        &mut self,
        key: MatrixKey,
        payload: &[u8],
    ) -> Result<()> {
        let _permit = self.ensure_write()?;
        if let Some((chunk_index, local_row)) = self.chunk_for_row(key.scan) {
            return self.write_chunk_cell_payload::<T>(key, chunk_index, local_row, payload);
        }
        let result = {
            let matrix = self.matrix.as_mut().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::write_cell_payload::<T>(
                self.spec,
                matrix,
                self.file.matrix_region(),
                key,
                payload,
            )
        };
        self.finish_matrix_mutation(result)
    }

    /// Copies one cell's bytes out of `source`; see the note on
    /// [`VarlitWriter::copy_matrix_cell_bytes_from`] for why the source borrow is
    /// shared.
    pub fn copy_matrix_cell_bytes_from<From, To>(
        &mut self,
        source: &VarlitFile,
        key: MatrixKey,
    ) -> Result<()>
    where
        From: VarlitMatrixBlock,
        To: VarlitMatrixBlock,
    {
        ensure_matrix_byte_copy_compatible::<From, To>()?;
        let payload = source.matrix_cell_payload::<From>(key)?;
        self.write_matrix_cell_payload::<To>(key, &payload)?;
        self.commit_matrix_cell::<To>(key)
    }

    /// Writes a cell, runs the barriers, publishes and syncs its generation,
    /// then calls `hook`. Other pending matrix changes are published too.
    ///
    /// Barrier failures are pre-publication errors and poison the writer.
    /// [`Error::MatrixPublicationUncertain`] requires reopening and inspecting
    /// the confirmed generation before retrying. A complete head whose final
    /// durability request failed yields [`Error::MatrixCommittedButDurabilityUnproven`].
    /// Both skip the hook. After successful durable publication, hook failure
    /// yields [`Error::MatrixCommittedButHookFailed`]; retry only the notification.
    /// Outcome boxes are reserved fallibly before mutation; a late error needs
    /// no further allocation. See "Allocator Failure And Published Outcomes"
    /// in `docs/durability-model.md`.
    pub fn write_matrix_cell_durable<T, F>(
        &mut self,
        key: MatrixKey,
        value: &T,
        hook: F,
    ) -> Result<()>
    where
        T: VarlitMatrixBlock,
        F: FnOnce(MatrixCommitEvent) -> Result<()>,
    {
        let mut barrier = FileMatrixDurabilityBarrier;
        self.write_matrix_cell_durable_with_barrier(key, value, &mut barrier, hook)
    }

    /// [`Self::write_matrix_cell_durable`] with a caller-supplied durability
    /// barrier; the same post-commit contract applies, including
    /// [`Error::MatrixCommittedButHookFailed`] and
    /// [`Error::MatrixCommittedButDurabilityUnproven`]. Both barrier callbacks
    /// precede generation publication and receive the physical generation file.
    pub fn write_matrix_cell_durable_with_barrier<T, B, F>(
        &mut self,
        key: MatrixKey,
        value: &T,
        barrier: &mut B,
        hook: F,
    ) -> Result<()>
    where
        T: VarlitMatrixBlock,
        B: MatrixDurabilityBarrier + ?Sized,
        F: FnOnce(MatrixCommitEvent) -> Result<()>,
    {
        // A chunked row has no durability point of its own: the cell lives in
        // memory until its chunk is written, and the write is what a barrier
        // could make durable. Refused by name rather than left to fail as
        // `MatrixKeyOutOfBounds`, which said nothing about why.
        if self.chunk_for_row(key.scan).is_some() {
            return Err(Error::InvalidFormatSpec(
                "a per-cell durability barrier does not apply to a chunked row; \
                 a chunk becomes durable when it is written",
            ));
        }
        // INVARIANT 3 (F-04). The commit event is pure layout geometry - block
        // index, ordinal, slot offset and stride - so it is derived *before*
        // the authoritative commit rather than after it. Previously
        // `commit_event` ran after the commit was durable and could return a
        // bare `Err` (fatal-forensics gating, block lookup, ordinal
        // arithmetic) for a cell that was already committed and synced.
        let event = {
            let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::commit_event::<T>(self.spec, matrix, key)?
        };
        // Allocate existing public error payloads before any mutation, so a
        // late hook/durability error needs no allocation and Error stays small.
        let event = crate::fallible::try_box(event)?;
        let mut error_slot = crate::fallible::try_box(Error::InvalidImmediatePolicy)?;
        self.write_matrix_cell(key, value)?;
        // Pre-publication. Nothing is committed yet, so a failure here is a
        // plain refusal: the slot bytes may be on disk but the commit bit is
        // not, and an uncommitted slot is not visible to any reader.
        let sync_data = barrier.sync_matrix_data(self.file.matrix_barrier_file()?);
        self.poison_after_started_matrix_error(sync_data)?;
        // Commit bits are still private working pages. Both caller barriers
        // run before the generation head is published; failure keeps readers
        // on the preceding generation and poisons this writer.
        self.commit_matrix_cell::<T>(key)?;
        let sync_commit = barrier.sync_matrix_commit(self.file.matrix_barrier_file()?);
        self.poison_after_started_matrix_error(sync_commit)?;
        let previous_generation = self.matrix_generation();
        if let Err(source) = self.sync() {
            self.poison.poison();
            *error_slot = source;
            return Err(if self.matrix_generation() != previous_generation {
                Error::MatrixCommittedButDurabilityUnproven {
                    event,
                    source: error_slot,
                }
            } else {
                Error::MatrixPublicationUncertain {
                    event,
                    source: error_slot,
                }
            });
        }
        // Step 2 of 2. The cell is committed and durable from here on. The hook is the
        // documented post-publication notification step, so its failure is a
        // *published* outcome, not a rollback: it is reported as
        // `Error::MatrixCommittedButHookFailed` carrying the committed event,
        // so a caller can retry the notification alone instead of repeating
        // the durable write and duplicating the hook's external work.
        hook((*event).clone()).map_err(|source| {
            *error_slot = source;
            Error::MatrixCommittedButHookFailed {
                event,
                source: error_slot,
            }
        })
    }

    /// Every written chunk as `(record offset, payload length)`, oldest first.
    ///
    /// The list is **sorted here**, by chunk index, which is what makes the
    /// binary search in `find` legal. It used to be left in file order and that
    /// order demanded to be ascending, on the reasoning that only the newest
    /// chunk is ever open — no longer true: a chunk that committed nothing is
    /// never written, so a later write to one of its rows appends its record
    /// after higher-indexed ones. File order is still what `ordinal` records,
    /// because that is what addresses a record for a rewrite.
    ///
    /// **`payload_len` is the point, not a convenience.** Every offset the chunk
    /// decode computes comes from bytes in the file, and without the record's
    /// own extent to bound them a crafted chunk reads whatever it names. The
    /// framing already established this length and already charged it against
    /// `RecordPayloadLen`; the decode below treats it as the wall.
    fn build_chunk_directory(&self) -> Result<ChunkDirectory> {
        let mut chunks = Vec::new();
        // **Through the retention gate, not straight at the field.** A handle
        // opened by `open_lazy` / `open_readonly_lazy` keeps no resident
        // directory: `self.index` is *empty*, not merely unbuilt. Reading it
        // directly made every written chunk invisible, which is not a read that
        // returns less — it is a writer that believes chunk N has no record and
        // appends a **second** one for it. That file no longer opens: the
        // duplicate refusal below fires, every chunked read answers
        // `InvalidMatrixChunk`, and the cells that were committed are gone.
        //
        // `NoResidentDirectory` is the same answer `blocks::<T>()` gives on such
        // a handle, and for the same reason: an empty answer here is
        // indistinguishable from "this file has no chunks", and that
        // indistinguishability is what destroys data rather than inconveniencing
        // a caller.
        let index = self.resident_directory("matrix chunk directory")?;
        for entry in index.iter() {
            let entry = entry?;
            if entry.block_id != MATRIX_CHUNK_BLOCK_ID {
                continue;
            }
            let prefix = self.read_chunk_prefix(entry.record_offset, entry.payload_len)?;
            // `rows` and `first_row` were decoded and thrown away by every
            // caller, and the row width was taken from the record's `cells`
            // divided by *this spec's* `rows_per_chunk` — so a file written
            // under a different `rows_per_chunk` was not refused, it was
            // reinterpreted, and a read returned another row's bytes.
            let rows_per_chunk = self
                .spec
                .growing_rows_per_chunk()
                .ok_or(Error::InvalidMatrixChunk)?;
            if prefix.rows != rows_per_chunk
                || prefix.first_row
                    != prefix
                        .index
                        .checked_mul(rows_per_chunk)
                        .ok_or(Error::InvalidMatrixChunk)?
                || u64::from(prefix.block_count) != self.spec.matrix_blocks.len() as u64
            {
                return Err(Error::InvalidMatrixChunk);
            }
            let cell_crc = !matches!(self.spec.integrity_policy, IntegrityPolicy::None);
            if prefix.cell_crc != cell_crc
                || prefix.compressed_slots != self.spec.chunk_compression.is_some()
            {
                return Err(Error::InvalidMatrixChunk);
            }
            chunks.try_reserve(1).map_err(|_| Error::AllocationFailed {
                resource: "matrix chunk directory",
                requested: chunks.len() as u64 + 1,
            })?;
            chunks.push(ChunkLocator {
                index: prefix.index,
                record_offset: entry.record_offset,
                payload_len: entry.payload_len,
                block_count: prefix.block_count,
                cell_crc: prefix.cell_crc,
                compressed_slots: prefix.compressed_slots,
                // File order, which is the order this loop walks and the order
                // `ReplacementTarget` counts in. Captured here because the sort
                // below is about to destroy it.
                ordinal: chunks.len(),
            });
        }
        // Chunk records are immutable versions. Within this handle's confirmed
        // EOF the record with the greatest offset is the current version.
        // Keep the original record count for the next append's ordinal.
        let next_ordinal = chunks.len();
        chunks.sort_unstable_by_key(|chunk| (chunk.index, std::cmp::Reverse(chunk.record_offset)));
        chunks.dedup_by_key(|chunk| chunk.index);
        Ok(ChunkDirectory {
            chunks,
            next_ordinal,
        })
    }

    /// The written-chunk directory, built at most once per handle.
    ///
    /// On failure nothing is cached, so a later call retries rather than
    /// caching a half-built answer.
    fn chunk_directory(&self) -> Result<&ChunkDirectory> {
        if let Some(directory) = self.chunk_directory.get() {
            return Ok(directory);
        }
        let built = self.build_chunk_directory()?;
        Ok(self.chunk_directory.get_or_init(|| built))
    }

    /// Reads one chunk record's prefix: its index, first row and row count.
    ///
    /// `MATRIX_CHUNK_PREFIX_LEN` bytes whatever the chunk holds. This is the
    /// read that keeps a cell lookup off the chunk's own size.
    fn read_chunk_prefix(&self, record_offset: u64, payload_len: u64) -> Result<ChunkPrefix> {
        if payload_len < MATRIX_CHUNK_PREFIX_LEN {
            return Err(Error::InvalidMatrixChunk);
        }
        let payload_offset = record_offset
            .checked_add(RECORD_HEADER_LEN)
            .ok_or(Error::InvalidMatrixChunk)?;
        let mut prefix = [0u8; MATRIX_CHUNK_PREFIX_LEN as usize];
        self.snapshot.read_exact_at(payload_offset, &mut prefix)?;
        note_chunk_bytes_read(MATRIX_CHUNK_PREFIX_LEN);
        if &prefix[..4] != MATRIX_CHUNK_MAGIC {
            return Err(Error::InvalidMatrixChunk);
        }
        if u16::from_le_bytes([prefix[4], prefix[5]]) != MATRIX_CHUNK_VERSION {
            return Err(Error::InvalidMatrixChunk);
        }
        let flags = u16::from_le_bytes([prefix[6], prefix[7]]);
        if flags & !MATRIX_CHUNK_KNOWN_FLAGS != 0 {
            return Err(Error::InvalidMatrixChunk);
        }
        let index = u64::from_le_bytes(prefix[8..16].try_into().expect("slice"));
        let first_row = u64::from_le_bytes(prefix[16..24].try_into().expect("slice"));
        let rows = u64::from_le_bytes(prefix[24..32].try_into().expect("slice"));
        let block_count = u32::from_le_bytes(prefix[32..36].try_into().expect("slice"));
        // The descriptor table has to fit in this record. Without this the field
        // is a bare `u32` from disk: `0xFFFF_FFFF` asked for a 137,438,953,440
        // byte reservation out of a 1 KB file, which `try_reserve` refused on
        // this host and a host with overcommit would have accepted and then
        // faulted in. No `ReadLimits` ceiling was charged, including under
        // `STANDARD`, which is the setting for untrusted input.
        let descriptors_len = MATRIX_CHUNK_BLOCK_DESC_LEN
            .checked_mul(u64::from(block_count))
            .ok_or(Error::InvalidMatrixChunk)?;
        if descriptors_len > payload_len - MATRIX_CHUNK_PREFIX_LEN {
            return Err(Error::InvalidMatrixChunk);
        }
        Ok(ChunkPrefix {
            index,
            first_row,
            rows,
            block_count,
            cell_crc: flags & MATRIX_CHUNK_FLAG_CELL_CRC != 0,
            compressed_slots: flags & MATRIX_CHUNK_FLAG_COMPRESSED_SLOTS != 0,
        })
    }

    /// Finds the written chunk with this index, by binary search over the chunk
    /// records — `O(log chunks)` prefix reads, and no state built at open.
    fn find_chunk_record(&self, chunk_index: u64) -> Result<Option<ChunkLocator>> {
        Ok(self.chunk_directory()?.find(chunk_index))
    }

    /// Where one block's commit map and slot region sit inside a chunk record.
    ///
    /// **Every offset here is derived from bytes in the file, so every one of
    /// them is bounded by `payload_len` — the record's own extent, which the
    /// framing established and already charged.** Without that wall a crafted
    /// `commit_len` moved a block's slot region onto a *neighbouring record* and
    /// a cell read returned that record's bytes decoded as a value: no error, no
    /// refusal, and `IntegrityPolicy::Crc32` did not catch it, because a
    /// positional cell read never verifies a footer under the default
    /// `IntegrityVerification::OnDemand`.
    fn chunk_block_location(
        &self,
        record_offset: u64,
        payload_len: u64,
        block_count: u32,
        cell_crc: bool,
        compressed_slots: bool,
        block_id: u32,
    ) -> Result<Option<ChunkBlockLocation>> {
        let payload_offset = record_offset
            .checked_add(RECORD_HEADER_LEN)
            .ok_or(Error::InvalidMatrixChunk)?;
        let payload_end = payload_offset
            .checked_add(payload_len)
            .ok_or(Error::InvalidMatrixChunk)?;
        // `read_chunk_prefix` already proved this fits; recomputed rather than
        // threaded so the bound and its use cannot drift apart.
        let descriptors_len = MATRIX_CHUNK_BLOCK_DESC_LEN
            .checked_mul(u64::from(block_count))
            .filter(|len| *len <= payload_len - MATRIX_CHUNK_PREFIX_LEN)
            .ok_or(Error::InvalidMatrixChunk)?;
        let descriptors_len_usize =
            usize::try_from(descriptors_len).map_err(|_| Error::InvalidMatrixChunk)?;
        // A stack buffer for every format anyone declares, so a cell read
        // allocates nothing. `MATRIX_CHUNK_INLINE_DESCRIPTORS` blocks is 18 at
        // 28 bytes each; past that the read is rare enough to take a heap
        // buffer, and a hostile `block_count` cannot force one because
        // `descriptors_len` is bounded by this record's own payload above.
        let mut inline = [0u8; MATRIX_CHUNK_INLINE_DESCRIPTOR_BYTES];
        let mut spilled;
        let descriptors: &mut [u8] = if descriptors_len_usize <= inline.len() {
            &mut inline[..descriptors_len_usize]
        } else {
            spilled = try_zeroed_vec(descriptors_len, "matrix chunk descriptors")?;
            &mut spilled[..descriptors_len_usize]
        };
        self.snapshot.read_exact_at(
            payload_offset
                .checked_add(MATRIX_CHUNK_PREFIX_LEN)
                .ok_or(Error::InvalidMatrixChunk)?,
            descriptors,
        )?;
        note_chunk_bytes_read(descriptors_len);
        let mut cursor = payload_offset
            .checked_add(MATRIX_CHUNK_PREFIX_LEN)
            .and_then(|offset| offset.checked_add(descriptors_len))
            .ok_or(Error::InvalidMatrixChunk)?;
        let mut found = None;
        for position in 0..block_count as usize {
            let base = position * MATRIX_CHUNK_BLOCK_DESC_LEN as usize;
            let id = u32::from_le_bytes(descriptors[base..base + 4].try_into().expect("slice"));
            let stride =
                u64::from_le_bytes(descriptors[base + 8..base + 16].try_into().expect("slice"));
            let cells =
                u64::from_le_bytes(descriptors[base + 16..base + 24].try_into().expect("slice"));
            let commit_len =
                u64::from_le_bytes(descriptors[base + 24..base + 32].try_into().expect("slice"));
            // The commit map, then the slots, then the next block — each must
            // land at or before the end of this record's payload.
            let crc_offset = cursor
                .checked_add(commit_len)
                .filter(|offset| *offset <= payload_end)
                .ok_or(Error::InvalidMatrixChunk)?;
            // A compressed block packs each checksum beside its cell inside the
            // sub-block, so there is no separate table to skip.
            let crc_len = if cell_crc && !compressed_slots {
                cells
                    .checked_mul(MATRIX_CHUNK_CRC_LEN)
                    .ok_or(Error::InvalidMatrixChunk)?
            } else {
                0
            };
            let slots_offset = crc_offset
                .checked_add(crc_len)
                .filter(|offset| *offset <= payload_end)
                .ok_or(Error::InvalidMatrixChunk)?;
            // A plain slot region's length is arithmetic. A compressed one's
            // is whatever its own index terminator says, which is a value from
            // the file and so is bounded by `payload_end` like every other.
            let slots_len = if compressed_slots {
                let count = sub_block_count(cells, compressed_cell_width(stride, cell_crc));
                let index_len = count
                    .checked_add(1)
                    .and_then(|entries| entries.checked_mul(MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN))
                    .filter(|len| {
                        slots_offset
                            .checked_add(*len)
                            .is_some_and(|end| end <= payload_end)
                    })
                    .ok_or(Error::InvalidMatrixChunk)?;
                let terminator = slots_offset
                    .checked_add(index_len)
                    .and_then(|end| end.checked_sub(MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN))
                    .ok_or(Error::InvalidMatrixChunk)?;
                let mut bytes = [0u8; MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN as usize];
                self.snapshot.read_exact_at(terminator, &mut bytes)?;
                note_chunk_bytes_read(MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN);
                index_len
                    .checked_add(u64::from(u32::from_le_bytes(bytes)))
                    .ok_or(Error::InvalidMatrixChunk)?
            } else {
                cells.checked_mul(stride).ok_or(Error::InvalidMatrixChunk)?
            };
            let next = slots_offset
                .checked_add(slots_len)
                .filter(|offset| *offset <= payload_end)
                .ok_or(Error::InvalidMatrixChunk)?;
            // Every descriptor must be the one this spec would have written.
            // `stride` and `cells` were previously taken from the record and
            // never compared, so a crafted or foreign `cells` widened the row
            // pitch and every key resolved to a different cell.
            let descriptor = self
                .spec
                .matrix_blocks
                .iter()
                .find(|block| block.block_id == id)
                .ok_or(Error::InvalidMatrixChunk)?;
            let expected_cells = self
                .spec
                .growing_rows_per_chunk()
                .and_then(|rows| rows.checked_mul(self.chunk_row_width(descriptor).ok()?))
                .ok_or(Error::InvalidMatrixChunk)?;
            if stride != descriptor.slot_stride || cells != expected_cells {
                return Err(Error::InvalidMatrixChunk);
            }
            if id == block_id {
                // The commit map must cover the cells it claims, or the bit read
                // for a high ordinal lands in the slot region.
                if commit_len < cells.div_ceil(8) {
                    return Err(Error::InvalidMatrixChunk);
                }
                found = Some(ChunkBlockLocation {
                    commit_offset: cursor,
                    crc_offset: (cell_crc && !compressed_slots).then_some(crc_offset),
                    slots_offset,
                    slots_end: next,
                    compressed_slots,
                    cell_crc,
                    stride,
                    cells,
                });
            }
            cursor = next;
        }
        Ok(found)
    }

    /// The chunk-local ordinal of `key`, and where its block's bytes are.
    ///
    /// `Ok(None)` means no chunk record holds that row — which is not an error:
    /// a chunk nothing committed is never written, so its rows read exactly as
    /// a written chunk's uncommitted rows do.
    fn locate_chunk_cell<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
        chunk_index: u64,
        local_row: u64,
    ) -> Result<Option<(ChunkBlockLocation, u64)>> {
        let Some(locator) = self.find_chunk_record(chunk_index)? else {
            return Ok(None);
        };
        // `block_count` comes from the directory, so finding the chunk and
        // locating a block inside it cost one prefix read between them rather
        // than one each.
        let Some(location) = self.chunk_block_location(
            locator.record_offset,
            locator.payload_len,
            locator.block_count,
            locator.cell_crc,
            locator.compressed_slots,
            T::ID,
        )?
        else {
            return Err(Error::MatrixBlockMissing(T::ID));
        };
        // The spec's `rows_per_chunk` is legitimate as the divisor only because
        // the directory build refused any chunk whose own `rows` disagreed with
        // it. Before that check existed this line was the defect.
        let width = location
            .cells
            .checked_div(
                self.spec
                    .growing_rows_per_chunk()
                    .ok_or(Error::InvalidMatrixChunk)?,
            )
            .ok_or(Error::InvalidMatrixChunk)?;
        if key.ch >= width {
            return Err(Error::MatrixKeyOutOfBounds {
                scan: key.scan,
                ch: key.ch,
            });
        }
        let ordinal = local_row
            .checked_mul(width)
            .and_then(|base| base.checked_add(key.ch))
            .filter(|ordinal| *ordinal < location.cells)
            .ok_or(Error::InvalidMatrixChunk)?;
        Ok(Some((location, ordinal)))
    }

    fn chunk_cell_is_committed(&self, location: ChunkBlockLocation, ordinal: u64) -> Result<bool> {
        let mut byte = [0u8; 1];
        self.snapshot.read_exact_at(
            location
                .commit_offset
                .checked_add(ordinal / 8)
                .ok_or(Error::InvalidMatrixChunk)?,
            &mut byte,
        )?;
        note_chunk_bytes_read(1);
        Ok(byte[0] & (1u8 << (ordinal % 8)) != 0)
    }

    /// One cell out of the chunk this handle is still filling, if that is where
    /// the row lives.
    ///
    /// **The open chunk is not on disk.** Without this, a writer could not read
    /// back a cell it had just written and committed — `read_matrix_cell` said
    /// `MatrixNotCommitted` until the next write, which is a write-then-read
    /// inconsistency and not a property anyone would want. Found by sweeping
    /// every matrix entry point against a chunked row; the tests that existed
    /// all read through a fresh reader after a flush and could not see it.
    /// The open chunk's block and cell ordinal for a key, or `None` when the row
    /// is not in the open chunk.
    ///
    /// Shared by the payload read and the status read so that answering "is it
    /// committed" costs no allocation.
    fn open_chunk_cell<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
        chunk_index: u64,
        local_row: u64,
    ) -> Result<Option<(&OpenChunkBlock, u64)>> {
        let Some(chunk) = self.open_chunk.as_ref() else {
            return Ok(None);
        };
        if chunk.index != chunk_index {
            return Ok(None);
        }
        let Some(position) = chunk.block_position(T::ID) else {
            return Err(Error::MatrixBlockMissing(T::ID));
        };
        let block = &chunk.blocks[position];
        let width = block
            .cells
            .checked_div(chunk.rows)
            .ok_or(Error::InvalidMatrixChunk)?;
        if key.ch >= width {
            return Err(Error::MatrixKeyOutOfBounds {
                scan: key.scan,
                ch: key.ch,
            });
        }
        let ordinal = local_row
            .checked_mul(width)
            .and_then(|base| base.checked_add(key.ch))
            .filter(|ordinal| *ordinal < block.cells)
            .ok_or(Error::InvalidMatrixChunk)?;
        Ok(Some((block, ordinal)))
    }

    fn read_open_chunk_cell_payload<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
        chunk_index: u64,
        local_row: u64,
    ) -> Result<Option<Vec<u8>>> {
        let Some((block, ordinal)) = self.open_chunk_cell::<T>(key, chunk_index, local_row)? else {
            return Ok(None);
        };
        let byte = usize::try_from(ordinal / 8).map_err(|_| Error::InvalidMatrixLayout)?;
        if block.commit[byte] & (1u8 << (ordinal % 8)) == 0 {
            return Err(Error::MatrixNotCommitted);
        }
        let start = usize::try_from(
            ordinal
                .checked_mul(block.stride)
                .ok_or(Error::InvalidMatrixChunk)?,
        )
        .map_err(|_| Error::InvalidMatrixLayout)?;
        let len = usize::try_from(block.stride).map_err(|_| Error::InvalidMatrixLayout)?;
        Ok(Some(u8::try_clone_slice(&block.slots[start..start + len])?))
    }

    /// Whether the open chunk holds a committed value for this cell.
    ///
    /// `Ok(None)` means the row is not in the open chunk, so the written records
    /// own the answer.
    fn open_chunk_cell_status<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
        chunk_index: u64,
        local_row: u64,
    ) -> Result<Option<MatrixCellStatus>> {
        // Reads the commit bit and stops. The first version answered this
        // boolean by calling `read_open_chunk_cell_payload`, which copies the
        // slot into a fresh `Vec` — a malloc, a memcpy and a free per status
        // call, for data sitting in memory two fields away.
        let Some((block, ordinal)) = self.open_chunk_cell::<T>(key, chunk_index, local_row)? else {
            return Ok(None);
        };
        let byte = usize::try_from(ordinal / 8).map_err(|_| Error::InvalidMatrixLayout)?;
        Ok(Some(if block.commit[byte] & (1u8 << (ordinal % 8)) == 0 {
            MatrixCellStatus::NotCommitted
        } else {
            MatrixCellStatus::Committed
        }))
    }

    /// One cell out of a written chunk, read positionally.
    ///
    /// Two small reads and one `stride`-byte read. The chunk itself is never
    /// materialised, whatever it holds.
    fn read_chunk_cell_payload<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
        chunk_index: u64,
        local_row: u64,
    ) -> Result<Vec<u8>> {
        self.ensure_chunk_block_access::<T>()?;
        if let Some(payload) =
            self.read_open_chunk_cell_payload::<T>(key, chunk_index, local_row)?
        {
            return Ok(payload);
        }
        let Some((location, ordinal)) = self.locate_chunk_cell::<T>(key, chunk_index, local_row)?
        else {
            return Err(Error::MatrixNotCommitted);
        };
        if !self.chunk_cell_is_committed(location, ordinal)? {
            return Err(Error::MatrixNotCommitted);
        }
        self.spec
            .read_limits
            .check(ReadLimitKey::RecordPayloadLen, location.stride)?;
        self.spec
            .read_limits
            .check(ReadLimitKey::MaterializedBytes, location.stride)?;
        let payload = if location.compressed_slots {
            let (payload, stored) = self.read_compressed_chunk_cell(location, ordinal)?;
            // The checksum came out of the same decode as the cell, so a
            // damaged sub-block cannot produce a matching pair.
            if let Some(expected) = stored {
                let actual = crc32_bytes(&payload)?;
                if actual != expected {
                    return Err(Error::MatrixChecksumMismatch {
                        offset: location.slots_offset,
                        expected,
                        actual,
                    });
                }
            }
            return Ok(payload);
        } else {
            let mut payload = try_zeroed_vec(location.stride, "matrix chunk slot payload")?;
            self.snapshot.read_exact_at(
                location
                    .slots_offset
                    .checked_add(
                        ordinal
                            .checked_mul(location.stride)
                            .ok_or(Error::InvalidMatrixChunk)?,
                    )
                    .ok_or(Error::InvalidMatrixChunk)?,
                &mut payload,
            )?;
            note_chunk_bytes_read(location.stride);
            payload
        };
        self.verify_chunk_cell(location, ordinal, &payload)?;
        Ok(payload)
    }

    /// One cell out of a compressed slot region.
    ///
    /// The sub-block is arithmetic — `ordinal / cells_per_sub_block(stride)` —
    /// so finding it costs two four-byte reads of the offset index and no
    /// search. What it costs over a plain chunk is exactly one sub-block
    /// decode, and that is the whole price of `with_chunk_compression`.
    ///
    /// The per-cell checksum still guards the result: it is computed over the
    /// *uncompressed* cell bytes and stored plain, so a corrupted sub-block
    /// decodes to something whose checksum does not match, and the caller sees
    /// the mismatch rather than the bytes.
    fn read_compressed_chunk_sub_block(
        &self,
        location: ChunkBlockLocation,
        ordinal: u64,
    ) -> Result<Vec<u8>> {
        let cell_crc = location.cell_crc;
        let width = compressed_cell_width(location.stride, cell_crc);
        let per = cells_per_sub_block(width);
        let count = sub_block_count(location.cells, width);
        let index = ordinal / per;
        if index >= count {
            return Err(Error::InvalidMatrixChunk);
        }
        let index_len = count
            .checked_add(1)
            .and_then(|entries| entries.checked_mul(MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN))
            .ok_or(Error::InvalidMatrixChunk)?;
        let entry_at = location
            .slots_offset
            .checked_add(
                index
                    .checked_mul(MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN)
                    .ok_or(Error::InvalidMatrixChunk)?,
            )
            .ok_or(Error::InvalidMatrixChunk)?;
        let mut pair = [0u8; 2 * MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN as usize];
        self.snapshot.read_exact_at(entry_at, &mut pair)?;
        note_chunk_bytes_read(2 * MATRIX_CHUNK_SUB_BLOCK_OFFSET_LEN);
        let start = u64::from(u32::from_le_bytes(pair[..4].try_into().expect("slice")));
        let end = u64::from(u32::from_le_bytes(pair[4..].try_into().expect("slice")));
        if end < start {
            return Err(Error::InvalidMatrixChunk);
        }
        let stored_len = end - start;
        let data_at = location
            .slots_offset
            .checked_add(index_len)
            .and_then(|base| base.checked_add(start))
            .filter(|at| {
                at.checked_add(stored_len)
                    .is_some_and(|end| end <= location.slots_end)
            })
            .ok_or(Error::InvalidMatrixChunk)?;

        // The uncompressed extent of this sub-block: a full one everywhere but
        // possibly the last.
        let cells_here = per.min(location.cells.saturating_sub(index * per));
        let raw_len = cells_here
            .checked_mul(width)
            .ok_or(Error::InvalidMatrixChunk)?;
        self.spec
            .read_limits
            .check(ReadLimitKey::MaterializedBytes, raw_len)?;

        // Writers store raw bytes when compression would not shrink them.
        // Refuse an oversized extent before allocating attacker-controlled bytes.
        if stored_len > raw_len {
            return Err(Error::InvalidMatrixChunk);
        }
        let mut stored = try_zeroed_vec(stored_len, "matrix chunk sub-block")?;
        self.snapshot.read_exact_at(data_at, &mut stored)?;
        note_chunk_bytes_read(stored_len);

        // Equal lengths mean the writer stored it raw, which it does whenever
        // compressing did not shrink it. The writer never emits a compressed
        // sub-block of exactly the uncompressed length, so this is unambiguous.
        let raw = if stored_len == raw_len {
            stored
        } else {
            let compression = self
                .spec
                .chunk_compression
                .ok_or(Error::InvalidMatrixChunk)?;
            let decoded = decompress_with_algorithm(compression.algorithm, &stored, raw_len)?;
            if decoded.len() as u64 != raw_len {
                return Err(Error::DecompressedLengthMismatch {
                    expected: raw_len,
                    actual: decoded.len() as u64,
                });
            }
            decoded
        };

        Ok(raw)
    }

    fn read_compressed_chunk_cell(
        &self,
        location: ChunkBlockLocation,
        ordinal: u64,
    ) -> Result<(Vec<u8>, Option<u32>)> {
        let cell_crc = location.cell_crc;
        let width = compressed_cell_width(location.stride, cell_crc);
        let per = cells_per_sub_block(width);
        let raw = self.read_compressed_chunk_sub_block(location, ordinal)?;
        let at = usize::try_from(
            (ordinal % per)
                .checked_mul(width)
                .ok_or(Error::InvalidMatrixChunk)?,
        )
        .map_err(|_| Error::InvalidMatrixChunk)?;
        let stride = usize::try_from(location.stride).map_err(|_| Error::InvalidMatrixChunk)?;
        let payload = raw
            .get(at..at + stride)
            .map(<[u8]>::to_vec)
            .ok_or(Error::InvalidMatrixChunk)?;
        let stored = if cell_crc {
            let bytes = raw
                .get(at + stride..at + stride + 4)
                .ok_or(Error::InvalidMatrixChunk)?;
            Some(u32::from_le_bytes(bytes.try_into().expect("slice")))
        } else {
            None
        };
        Ok((payload, stored))
    }

    /// Checks one chunked cell against the checksum stored beside it.
    ///
    /// **The record footer's crc does not cover this read.** It covers the
    /// record, and it is verified on a *record* read; a positional cell read is
    /// not one, so under the default `IntegrityVerification::OnDemand` a single
    /// flipped bit in a written chunk came back as data with no error, while the
    /// identical flip one row earlier — in the matrix region, which keeps
    /// per-cell checksums — was refused. A chunk keeps them now, for the same
    /// reason and in the same shape.
    fn verify_chunk_cell(
        &self,
        location: ChunkBlockLocation,
        ordinal: u64,
        payload: &[u8],
    ) -> Result<()> {
        let Some(crc_offset) = location.crc_offset else {
            return Ok(());
        };
        let at = crc_offset
            .checked_add(
                ordinal
                    .checked_mul(MATRIX_CHUNK_CRC_LEN)
                    .ok_or(Error::InvalidMatrixChunk)?,
            )
            .ok_or(Error::InvalidMatrixChunk)?;
        let mut stored = [0u8; MATRIX_CHUNK_CRC_LEN as usize];
        self.snapshot.read_exact_at(at, &mut stored)?;
        note_chunk_bytes_read(MATRIX_CHUNK_CRC_LEN);
        let expected = u32::from_le_bytes(stored);
        let actual = crc32_bytes(payload)?;
        if actual != expected {
            return Err(Error::MatrixChecksumMismatch {
                offset: location
                    .slots_offset
                    .checked_add(
                        ordinal
                            .checked_mul(location.stride)
                            .ok_or(Error::InvalidMatrixChunk)?,
                    )
                    .ok_or(Error::InvalidMatrixChunk)?,
                expected,
                actual,
            });
        }
        Ok(())
    }

    pub fn read_matrix_cell<T: VarlitMatrixBlock>(&self, key: MatrixKey) -> Result<T> {
        if let Some((chunk_index, local_row)) = self.chunk_for_row(key.scan) {
            let payload = self.read_chunk_cell_payload::<T>(key, chunk_index, local_row)?;
            // Bounded exactly as the region twin bounds it (`matrix::read_cell`):
            // the slot bytes are already charged against `MaterializedBytes`,
            // so what remains of that budget is what the decode may materialize
            // on top of them. Unbounded here, a decoder that expands past its
            // stride was capped on a region row and uncapped on a chunked one.
            let materialized_limit = self
                .spec
                .read_limits
                .require(ReadLimitKey::MaterializedBytes)?
                .unwrap_or(u64::MAX);
            let decode_limit = materialized_limit.checked_sub(payload.len() as u64).ok_or(
                Error::ResourceArithmeticOverflow {
                    resource: "materialized bytes",
                },
            )?;
            return crate::codec::Decoder::decode_from_slice_limited(
                &payload,
                T::ENDIAN.unwrap_or(self.spec.endian),
                decode_limit,
            );
        }
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::read_cell(self.spec, matrix, self.file.matrix_region_reader(), key)
    }

    /// Whether a chunked cell has a committed value.
    ///
    /// Answers for a chunked row the same way the region answers for a region
    /// row: a value that never arrived is `NotCommitted`, permanently and by
    /// design. Sealing asks no question about completeness.
    fn chunked_cell_status<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
        chunk_index: u64,
        local_row: u64,
    ) -> Result<MatrixCellStatus> {
        self.ensure_chunk_block_access::<T>()?;
        if let Some(status) = self.open_chunk_cell_status::<T>(key, chunk_index, local_row)? {
            return Ok(status);
        }
        match self.locate_chunk_cell::<T>(key, chunk_index, local_row)? {
            Some((location, ordinal)) if self.chunk_cell_is_committed(location, ordinal)? => {
                Ok(MatrixCellStatus::Committed)
            }
            _ => Ok(MatrixCellStatus::NotCommitted),
        }
    }

    pub fn matrix_cell_payload<T: VarlitMatrixBlock>(&self, key: MatrixKey) -> Result<Vec<u8>> {
        if let Some((chunk_index, local_row)) = self.chunk_for_row(key.scan) {
            return self.read_chunk_cell_payload::<T>(key, chunk_index, local_row);
        }
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::read_cell_payload::<T>(
            self.spec,
            matrix,
            self.file.matrix_region_reader(),
            key,
        )
    }

    pub fn matrix_aux_len(&self, name: &str) -> Result<u64> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::aux_len(matrix, name)
    }

    pub fn read_matrix_aux(&self, name: &str, offset: u64, len: u64) -> Result<Vec<u8>> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::read_aux_at_len(
            matrix,
            self.file.matrix_region_reader(),
            self.snapshot.len(),
            name,
            offset,
            len,
        )
    }

    pub fn write_matrix_aux(&mut self, name: &str, offset: u64, payload: &[u8]) -> Result<()> {
        let _permit = self.ensure_write()?;
        let result = {
            let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::write_aux_at_len(
                matrix,
                self.file.matrix_region(),
                self.snapshot.len(),
                name,
                offset,
                payload,
            )
        };
        self.finish_matrix_mutation(result)
    }

    pub fn matrix_cell_status<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
    ) -> Result<MatrixCellStatus> {
        if let Some((chunk_index, local_row)) = self.chunk_for_row(key.scan) {
            return self.chunked_cell_status::<T>(key, chunk_index, local_row);
        }
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::cell_status::<T>(
            self.spec,
            matrix,
            key,
            self.file.matrix_region_reader().bitmap_read(),
        )
    }

    pub fn commit_matrix_cell<T: VarlitMatrixBlock>(&mut self, key: MatrixKey) -> Result<()> {
        let _permit = self.ensure_write()?;
        if let Some((chunk_index, local_row)) = self.chunk_for_row(key.scan) {
            let (position, ordinal) = self.chunk_block_slice::<T>(chunk_index, local_row, key)?;
            let chunk = self.open_chunk.as_mut().ok_or(Error::InvalidMatrixChunk)?;
            let block = &mut chunk.blocks[position];
            let byte = usize::try_from(ordinal / 8).map_err(|_| Error::InvalidMatrixLayout)?;
            let bit = 1u8 << (ordinal % 8);
            // The region path refuses a commit of a cell that was never
            // written, and answers from its write bitmap. This asked the slot
            // bytes instead — "are they all zero" — which is not the same
            // question: a cell holding a legitimate zero could never be
            // committed.
            if block.commit[byte] & bit == 0 && block.written[byte] & bit == 0 {
                return Err(Error::MatrixCellNotWritten);
            }
            block.commit[byte] |= bit;
            chunk.dirty = true;
            return Ok(());
        }
        let result = {
            let matrix = self.matrix.as_mut().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::commit_cell::<T>(self.spec, matrix, self.file.matrix_region(), key)
        };
        self.finish_matrix_mutation(result)
    }

    /// Clears one chunked cell: its commit bit and its slot bytes.
    ///
    /// Opens the cell's chunk first, loading it back from its record when it has
    /// one. This used to refuse anything but the currently open chunk, which
    /// left the two halves of the same capability disagreeing: after
    /// [`Self::open_chunk_at`] learned to reload, a written cell could be
    /// *overwritten* but not *cleared*. A caller cannot act on that distinction
    /// — clearing is what `write` is for a cell that should go back to having no
    /// value — so it was a refusal with nothing behind it.
    ///
    /// The refusals that remain are the ones `open_chunk_at` reports, and they
    /// are about the record's shape rather than about the cell: a compressed
    /// chunk cannot be rewritten at its stored length. See
    /// [`Error::MatrixChunkNotReopenable`].
    fn clear_chunk_cell<T: VarlitMatrixBlock>(
        &mut self,
        key: MatrixKey,
        chunk_index: u64,
        local_row: u64,
    ) -> Result<()> {
        self.open_chunk_at(chunk_index)?;
        let (position, ordinal) = self.chunk_block_slice::<T>(chunk_index, local_row, key)?;
        let chunk = self.open_chunk.as_mut().ok_or(Error::InvalidMatrixChunk)?;
        let block = &mut chunk.blocks[position];
        let byte = usize::try_from(ordinal / 8).map_err(|_| Error::InvalidMatrixLayout)?;
        block.commit[byte] &= !(1u8 << (ordinal % 8));
        block.written[byte] &= !(1u8 << (ordinal % 8));
        let start = usize::try_from(
            ordinal
                .checked_mul(block.stride)
                .ok_or(Error::InvalidMatrixChunk)?,
        )
        .map_err(|_| Error::InvalidMatrixLayout)?;
        let len = usize::try_from(block.stride).map_err(|_| Error::InvalidMatrixLayout)?;
        block.slots[start..start + len].fill(0);
        // A chunk with a record on disk must be written out again, or the clear
        // lives in the buffer while the file keeps serving the old value —
        // silent loss of a mutation, reported as success. A chunk with no record
        // has nothing to contradict, so clearing it leaves an idle flush writing
        // nothing, which is what `dirty` is for.
        if chunk.backing.is_some() {
            chunk.dirty = true;
        }
        Ok(())
    }

    /// [`Self::clear_chunk_cell`] addressed by block id rather than by type, for
    /// [`Self::clear_matrix_cell_by_category`].
    ///
    /// **One cell, exactly as its typed twin clears one cell.** Only the way the
    /// block is named differs — a category string instead of a Rust type — and
    /// the two must therefore refuse and accept the same things. They briefly
    /// did not: `clear_chunk_cell` learned to reopen a written chunk and this
    /// did not, so the same cell cleared under one spelling and returned
    /// `MatrixChunkClosed` under the other. The comment justifying that claimed
    /// this entry point walks a whole category; it does not, and
    /// [`Self::clear_matrix_category`] is the one that does.
    fn clear_chunk_cell_by_id(
        &mut self,
        block_id: u32,
        key: MatrixKey,
        chunk_index: u64,
        local_row: u64,
    ) -> Result<()> {
        // Its typed twin gates through `chunk_block_slice`; this one addresses
        // the block by id and so went through nothing, leaving a quarantined
        // category clearable through any chunked row.
        self.ensure_chunk_access_by_block_id(block_id)?;
        self.open_chunk_at(chunk_index)?;
        let chunk = self.open_chunk.as_mut().ok_or(Error::InvalidMatrixChunk)?;
        let position = chunk
            .block_position(block_id)
            .ok_or(Error::MatrixBlockMissing(block_id))?;
        let rows = chunk.rows;
        let block = &mut chunk.blocks[position];
        let width = block
            .cells
            .checked_div(rows)
            .ok_or(Error::InvalidMatrixChunk)?;
        if key.ch >= width {
            return Err(Error::MatrixKeyOutOfBounds {
                scan: key.scan,
                ch: key.ch,
            });
        }
        let ordinal = local_row
            .checked_mul(width)
            .and_then(|base| base.checked_add(key.ch))
            .filter(|ordinal| *ordinal < block.cells)
            .ok_or(Error::InvalidMatrixChunk)?;
        let byte = usize::try_from(ordinal / 8).map_err(|_| Error::InvalidMatrixLayout)?;
        block.commit[byte] &= !(1u8 << (ordinal % 8));
        block.written[byte] &= !(1u8 << (ordinal % 8));
        let start = usize::try_from(
            ordinal
                .checked_mul(block.stride)
                .ok_or(Error::InvalidMatrixChunk)?,
        )
        .map_err(|_| Error::InvalidMatrixLayout)?;
        let len = usize::try_from(block.stride).map_err(|_| Error::InvalidMatrixLayout)?;
        block.slots[start..start + len].fill(0);
        // Same reason as in the typed twin: a chunk with a record on disk must
        // go out again, or the file keeps serving the value this just cleared.
        if chunk.backing.is_some() {
            chunk.dirty = true;
        }
        Ok(())
    }

    pub fn clear_matrix_cell<T: VarlitMatrixBlock>(&mut self, key: MatrixKey) -> Result<()> {
        let _permit = self.ensure_write()?;
        if let Some((chunk_index, local_row)) = self.chunk_for_row(key.scan) {
            return self.clear_chunk_cell::<T>(key, chunk_index, local_row);
        }
        let result = {
            let matrix = self.matrix.as_mut().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::clear_cell::<T>(self.spec, matrix, self.file.matrix_region(), key)
        };
        self.finish_matrix_mutation(result)
    }

    pub fn clear_matrix_cell_by_category(&mut self, category: &str, key: MatrixKey) -> Result<()> {
        let _permit = self.ensure_write()?;
        if let Some((chunk_index, local_row)) = self.chunk_for_row(key.scan) {
            let block_id = self
                .spec
                .matrix_blocks
                .iter()
                .find(|block| block.category == category)
                .map(|block| block.block_id)
                .ok_or_else(|| Error::MatrixCommitMissing(category.to_string()))?;
            return self.clear_chunk_cell_by_id(block_id, key, chunk_index, local_row);
        }
        let result = {
            let matrix = self.matrix.as_mut().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::clear_cell_by_category(
                self.spec,
                matrix,
                self.file.matrix_region(),
                category,
                key,
            )
        };
        self.finish_matrix_mutation(result)
    }

    /// Clears a category in the working generation, including stored chunks.
    /// Each affected chunk is loaded and appended as a new immutable version;
    /// memory holds one chunk at a time. Published readers remain unchanged
    /// until sync. A partial failure can leave partial working changes; reopen
    /// to discard them instead of publishing an incomplete operation.
    pub fn clear_matrix_category(&mut self, category: &str) -> Result<u64> {
        let _permit = self.ensure_write()?;
        let mut cleared = 0u64;
        if self.spec.growing_matrix.is_some() {
            // Refused before anything is touched. `clear_category` reaches its
            // own `ensure_fatal_access_allowed` only after the open chunk had
            // already been zeroed, so a refusal returned an error to a caller
            // entitled to believe nothing had happened.
            self.ensure_chunk_access_allowed(category)?;
            // The same discipline for the reopen refusals. A format whose
            // chunks cannot be rewritten at their stored length would fail on
            // the first written chunk — after the region had been cleared and
            // possibly after several chunks had been — so it is asked here,
            // where the answer is a property of the spec and nothing has moved.
            if let Some(oldest) = self.chunk_directory()?.chunks.first().map(|it| it.index) {
                if self.spec.chunk_compression.is_some() {
                    return Err(Error::MatrixChunkNotReopenable {
                        chunk: oldest,
                        reason: "chunk compression",
                    });
                }
                if self.spec.index_policy.segment_on_flush {
                    return Err(Error::MatrixChunkNotReopenable {
                        chunk: oldest,
                        reason: "segment_on_flush",
                    });
                }
            }
        }
        let result = {
            let matrix = self.matrix.as_mut().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::clear_category(self.spec, matrix, self.file.matrix_region(), category)
        };
        // The region first, as before: it is one write that either happens or
        // does not, so a failure there leaves the chunks untouched rather than
        // half-cleared behind an error.
        let region_cleared = self.finish_matrix_mutation(result)?;
        if self.spec.growing_matrix.is_some() {
            // The open chunk, whether or not it has a record yet. Doing it here
            // rather than inside the walk keeps the common case — a growing
            // matrix that has never written a chunk — exactly what it was: a
            // memset over a buffer, no I/O at all.
            if let Some(position) = self.open_chunk_block_for(category)? {
                cleared = cleared.saturating_add(self.clear_open_chunk_block(position));
            }
            cleared = cleared.saturating_add(self.clear_written_chunks_of(category)?);
        }
        Ok(cleared + region_cleared)
    }

    /// Clears the category out of every written chunk, one at a time.
    ///
    /// Walks the directory by position rather than over a collected list of
    /// indexes: the list would be one `u64` per chunk held for the length of
    /// the walk, which is the shape this file removes everywhere else, and the
    /// walk rewrites records in place so the directory neither grows nor
    /// reorders under it. The chunk already open is skipped — the caller
    /// cleared it in its buffer — and is written out by the first reload, which
    /// is what carries that clear to disk.
    fn clear_written_chunks_of(&mut self, category: &str) -> Result<u64> {
        let mut cleared = 0u64;
        let mut at = 0usize;
        loop {
            let Some(index) = self.chunk_directory()?.chunks.get(at).map(|it| it.index) else {
                return Ok(cleared);
            };
            at += 1;
            if self
                .open_chunk
                .as_ref()
                .is_some_and(|open| open.index == index)
            {
                continue;
            }
            self.open_chunk_at(index)?;
            if let Some(position) = self.open_chunk_block_for(category)? {
                cleared = cleared.saturating_add(self.clear_open_chunk_block(position));
            }
        }
    }

    /// Which block of the open chunk a category names, if any.
    ///
    /// The fallible half of clearing a chunk category, split out so the caller
    /// can resolve before it destroys: every `None` here is "nothing to clear",
    /// and the apply step that follows cannot fail at all.
    fn open_chunk_block_for(&self, category: &str) -> Result<Option<usize>> {
        let Some(block_id) = self
            .spec
            .matrix_blocks
            .iter()
            .find(|block| block.category == category)
            .map(|block| block.block_id)
        else {
            return Ok(None);
        };
        let Some(chunk) = self.open_chunk.as_ref() else {
            return Ok(None);
        };
        Ok(chunk.block_position(block_id))
    }

    /// Clears one already-resolved block of the open chunk, returning how many
    /// cells were committed in it. Infallible by construction — a memset over a
    /// buffer this handle owns.
    fn clear_open_chunk_block(&mut self, position: usize) -> u64 {
        let Some(chunk) = self.open_chunk.as_mut() else {
            return 0;
        };
        let block = &mut chunk.blocks[position];
        let cleared = block
            .commit
            .iter()
            .map(|byte| u64::from(byte.count_ones()))
            .sum();
        block.commit.fill(0);
        block.written.fill(0);
        block.slots.fill(0);
        block.crc.fill(0);
        // `dirty` is what makes the next flush write this chunk out, and the
        // answer differs by whether the chunk already has a record.
        //
        // **No record.** Leaving `dirty` set after clearing every bit wrote an
        // all-uncommitted record — a full-size record for rows that hold
        // nothing, which (before chunks could be reopened) then refused every
        // later write to those rows, permanently. So it is recomputed from
        // what is left, not cleared outright: another block of the same chunk
        // may still hold committed cells.
        //
        // **Has a record.** The opposite, and getting this wrong loses the
        // clear silently: the record on disk still holds the cells this just
        // zeroed, so a chunk that goes non-dirty is never written and the file
        // keeps serving them. It was unreachable while `clear_matrix_category`
        // refused a written chunk, and became reachable the moment that
        // refusal was lifted.
        chunk.dirty = chunk.backing.is_some()
            || chunk
                .blocks
                .iter()
                .any(|block| block.commit.iter().any(|byte| *byte != 0));
        cleared
    }

    pub fn apply_matrix_recovery_action(&mut self, action: &MatrixRecoveryAction) -> Result<()> {
        match action {
            MatrixRecoveryAction::ClearCell { category, key } => {
                self.clear_matrix_cell_by_category(category, *key)
            }
            MatrixRecoveryAction::ClearCategory { category } => {
                self.clear_matrix_category(category).map(|_| ())
            }
            MatrixRecoveryAction::RebuildCommitMap { .. } => Err(Error::InvalidFormatSpec(
                "typed rebuild requires rebuild_matrix_commit_from_crc",
            )),
            MatrixRecoveryAction::Resume
            | MatrixRecoveryAction::Restart
            | MatrixRecoveryAction::DiscardSidecar => Ok(()),
        }
    }

    /// Rebuilds a commit map from the per-cell checksum table.
    ///
    /// **Refused for a format with a growing dimension.** The table it reads is
    /// the matrix region's; a chunk carries no per-cell checksums of its own —
    /// its record footer crc covers the whole payload instead. Without this
    /// refusal the call returned `Ok(0)` on a file full of chunks, which reads
    /// as "the commit map was already right" rather than "this answered for the
    /// region and nothing else".
    pub fn rebuild_matrix_commit_from_crc<T: VarlitMatrixBlock>(&mut self) -> Result<u64> {
        let _permit = self.ensure_write()?;
        if self.spec.growing_matrix.is_some() {
            return Err(Error::InvalidFormatSpec(
                "rebuild_matrix_commit_from_crc covers the matrix region only; \
                 a growing matrix's chunks carry no per-cell checksum table",
            ));
        }
        let result = {
            let matrix = self.matrix.as_mut().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::rebuild_commit_map_from_crc::<T>(
                self.spec,
                matrix,
                self.file.matrix_region(),
            )
        };
        self.finish_matrix_mutation(result)
    }

    pub fn is_matrix_single_committed(&self, name: &str) -> Result<bool> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::is_single_committed(
            matrix,
            name,
            self.file.matrix_region_reader().bitmap_read(),
        )
    }

    pub fn set_matrix_single_committed(&mut self, name: &str, value: bool) -> Result<()> {
        let _permit = self.ensure_write()?;
        let result = {
            let matrix = self.matrix.as_mut().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::set_single_committed(matrix, self.file.matrix_region(), name, value)
        };
        self.finish_matrix_mutation(result)
    }

    pub fn is_matrix_channel_committed(&self, name: &str, channel: u64) -> Result<bool> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::is_channel_committed(
            matrix,
            name,
            channel,
            self.file.matrix_region_reader().bitmap_read(),
        )
    }

    pub fn set_matrix_channel_committed(
        &mut self,
        name: &str,
        channel: u64,
        value: bool,
    ) -> Result<()> {
        let _permit = self.ensure_write()?;
        let result = {
            let matrix = self.matrix.as_mut().ok_or(Error::MatrixLayoutMissing)?;
            crate::matrix::set_channel_committed(
                matrix,
                self.file.matrix_region(),
                name,
                channel,
                value,
            )
        };
        self.finish_matrix_mutation(result)
    }

    /// What a resumed writer should do with this category.
    ///
    /// A growing matrix holding a **dirty** chunk is never `Clean`: that chunk
    /// is live state this handle has and the next handle will not, so reporting
    /// a clean category over it told a caller the acquisition had finished when
    /// it had not.
    ///
    /// **Dirty, not merely open.** The test is `is_unwritten`, and it used to be
    /// `is_some`. A chunk stays open after its record is written now — that is
    /// what preserves the write bitmap across a flush, which is not on disk —
    /// so "a chunk is open" no longer implies "something is only in memory". A
    /// clean chunk's every byte is in its record; the next handle reads exactly
    /// what this one would.
    pub fn matrix_resume_signal(&self, category: &str) -> Result<MatrixResumeSignal> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        let signal = crate::matrix::resume_signal(
            matrix,
            category,
            self.file.matrix_region_reader().bitmap_read(),
        )?;
        if self.open_chunk_is_unwritten() && matches!(signal, MatrixResumeSignal::Clean) {
            return Ok(MatrixResumeSignal::Partial {
                committed: 0,
                total: 0,
            });
        }
        Ok(signal)
    }

    pub fn matrix_sidecar_resume_signal<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
    ) -> Result<MatrixResumeSignal> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::sidecar_resume_signal(
            matrix,
            category,
            sidecar_path.as_ref().exists(),
            self.file.matrix_region_reader().bitmap_read(),
        )
    }

    pub fn matrix_verified_sidecar_resume_signal<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
    ) -> Result<MatrixResumeSignal> {
        self.matrix_verified_sidecar_resume_signal_inner(category, sidecar_path.as_ref(), None)
    }

    pub fn matrix_verified_sidecar_resume_signal_with_generation<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
        expected_generation: u64,
    ) -> Result<MatrixResumeSignal> {
        self.matrix_verified_sidecar_resume_signal_inner(
            category,
            sidecar_path.as_ref(),
            Some(expected_generation),
        )
    }

    fn matrix_verified_sidecar_resume_signal_inner(
        &self,
        category: &str,
        path: &Path,
        expected_generation: Option<u64>,
    ) -> Result<MatrixResumeSignal> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        if !path.exists() {
            return crate::matrix::sidecar_resume_signal(
                matrix,
                category,
                false,
                self.file.matrix_region_reader().bitmap_read(),
            );
        }
        let identity = self.matrix_native_identity()?;
        match read_matrix_sidecar_file(self.spec, category, path, expected_generation, identity) {
            Ok(_) => crate::matrix::sidecar_resume_signal(
                matrix,
                category,
                true,
                self.file.matrix_region_reader().bitmap_read(),
            ),
            Err(Error::IntegrityFeatureDisabled) => Err(Error::IntegrityFeatureDisabled),
            Err(error @ Error::LimitExceeded { .. })
            | Err(error @ Error::MissingResourceLimit { .. })
            | Err(error @ Error::TrustedUnboundedRequiresExplicitApi { .. })
            | Err(error @ Error::ResourceArithmeticOverflow { .. })
            | Err(error @ Error::LengthOverflow { .. })
            | Err(error @ Error::AllocationFailed { .. }) => Err(error),
            Err(_) => Ok(MatrixResumeSignal::DiscardRecommended),
        }
    }

    /// Publishes a matrix resume sidecar bound to this native file.
    ///
    /// Ordering contract: the native matrix data this sidecar summarizes must
    /// already be durable (native -> sidecar). Callers write and sync native
    /// cells/commits first, then call this, so a sidecar can never advertise
    /// progress that is not yet present in the native file. Publication itself
    /// is a same-directory temp write + fsync + atomic replace + parent sync,
    /// so a crash mid-publish leaves the previous sidecar intact.
    pub fn write_matrix_sidecar<P: AsRef<Path>>(
        &mut self,
        category: &str,
        sidecar_path: P,
        generation: u64,
        payload: &[u8],
    ) -> Result<MatrixSidecarManifest> {
        let _permit = self.ensure_write()?;
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::resume_signal(
            matrix,
            category,
            self.file.matrix_region_reader().bitmap_read(),
        )?;
        let identity = self.matrix_native_identity()?;
        write_matrix_sidecar_file(
            self.spec,
            category,
            sidecar_path,
            generation,
            payload,
            identity,
        )
    }

    pub fn read_matrix_sidecar<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
    ) -> Result<(MatrixSidecarManifest, Vec<u8>)> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::resume_signal(
            matrix,
            category,
            self.file.matrix_region_reader().bitmap_read(),
        )?;
        let identity = self.matrix_native_identity()?;
        read_matrix_sidecar_file(self.spec, category, sidecar_path, None, identity)
    }

    pub fn read_matrix_sidecar_with_generation<P: AsRef<Path>>(
        &self,
        category: &str,
        sidecar_path: P,
        expected_generation: u64,
    ) -> Result<(MatrixSidecarManifest, Vec<u8>)> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        crate::matrix::resume_signal(
            matrix,
            category,
            self.file.matrix_region_reader().bitmap_read(),
        )?;
        let identity = self.matrix_native_identity()?;
        read_matrix_sidecar_file(
            self.spec,
            category,
            sidecar_path,
            Some(expected_generation),
            identity,
        )
    }

    /// Computes the native-file identity a matrix sidecar is bound to.
    ///
    /// Reuses the same OS-object identity bytes as the scalable sidecar identity
    /// machinery (volume + file ID on Windows, device + inode on Unix) and folds
    /// in the schema hash, then pairs it with the matrix layout generation.
    fn matrix_native_identity(&self) -> Result<MatrixNativeIdentity> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        let creation_nonce = self
            .matrix_creation_nonce
            .ok_or(Error::MatrixLayoutMissing)?;
        let file = self.snapshot.try_clone_file()?;
        let fingerprint = native_object_fingerprint(self.spec, &file)?;
        Ok(MatrixNativeIdentity {
            fingerprint,
            layout_generation: matrix.append_log_start(),
            creation_nonce,
        })
    }

    /// Per-file storage observations, without probing or changing any live cursor.
    pub fn matrix_storage_diagnostics(&self) -> Option<crate::MatrixStorageDiagnostics> {
        self.matrix
            .as_ref()
            .map(|layout| layout.storage_diagnostics())
    }

    pub fn matrix_recovery_report(&self) -> MatrixRecoveryReport {
        match self.matrix.as_ref() {
            Some(matrix) => crate::matrix::recovery_report(
                matrix,
                self.file.matrix_region_reader().bitmap_read(),
            ),
            None => MatrixRecoveryReport {
                findings: Vec::new(),
                recommended_actions: Vec::new(),
            },
        }
    }

    /// Verifies this matrix's commit metadata now, and reports what was found.
    ///
    /// The on-demand half of `MatrixMetadataVerification`. A matrix opened under
    /// `MatrixMetadataVerification::AtOpen` — the default — has already had this
    /// pass run, and its findings are in `matrix_recovery_report`; one opened
    /// under `OnDemand` has not, and this is how a caller asks. Running it twice
    /// is allowed and answers the same thing.
    ///
    /// What it does: reads every page of every commit map named by the persisted
    /// page index **unioned with** the platform allocation map — the second term
    /// is what sees stray bytes in a page nothing ever published — authenticates
    /// each against its stored digest, and reports the `Recoverable` commit-map
    /// findings and the `RebuildCommitMap` / `ClearCategory` recommendations that
    /// follow. Cost: `O(live pages + allocated pages)` bytes read, one 4096-byte
    /// buffer retained, no matter the matrix's size.
    ///
    /// What it does **not** do: arm the quarantine
    /// (`Error::MatrixCommitQuarantined`) or gate a writer. That gate is derived
    /// once, at open, from the findings the layout is assembled with; a caller who
    /// needs a damaged category failed closed reopens with `AtOpen`.
    ///
    /// `Err(Error::MatrixLayoutMissing)` when this file has no matrix.
    pub fn verify_matrix_metadata(&self) -> Result<MatrixRecoveryReport> {
        let matrix = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        // A private cursor borrows the current view, including pending writer
        // pages. Positional reads preserve `&self` without cloning the working
        // directory or sharing its mutation capability.
        let mut file = self
            .file
            .matrix_pages()
            .ok_or(Error::MatrixLayoutMissing)?
            .read_borrow();
        crate::matrix::verify_matrix_metadata(matrix, &mut file)
    }

    pub fn inspect_writer_lock<P: AsRef<Path>>(path: P) -> Result<Option<WriterLockInfo>> {
        read_writer_lock_info(path.as_ref())
    }

    /// OS-object identity bytes of this writer's native file.
    ///
    /// Diagnostic scaffolding captures this at creation time so cleanup can
    /// refuse to delete a file that another process has since swapped in at
    /// the same pathname (API2-02).
    pub(crate) fn native_object_identity(&self) -> Result<Vec<u8>> {
        self.file.object_identity()
    }

    /// Arms `count` injected post-publication parent-directory sync failures.
    ///
    /// Fault-testing hook only: each armed failure makes the next
    /// `replace.parent_sync` boundary return an error after a publication has
    /// already succeeded, which is otherwise hard to reproduce on demand.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn inject_parent_sync_failures(count: u64) {
        INJECTED_PARENT_SYNC_FAILURES.store(count, std::sync::atomic::Ordering::Release);
    }

    /// Arms `count` injected indeterminate replacement failures (DUR2-01).
    ///
    /// Fault-testing hook only: each armed failure makes the next atomic
    /// pathname publication fail with
    /// [`Error::ReplacePublicationIndeterminate`] before touching the target,
    /// which models an unreconciled Windows `ReplaceFileW` 1176/1177 outcome
    /// that cannot be produced on demand by a real filesystem.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn inject_replace_indeterminate_failures(count: u64) {
        INJECTED_REPLACE_INDETERMINATE_FAILURES.store(count, std::sync::atomic::Ordering::Release);
    }

    /// Arms `count` injected rewrite-temp preparation failures (STO4-P2).
    ///
    /// Fault-testing hook only: each armed failure makes the next internal
    /// merge/compact publication fail immediately after creating its rewrite
    /// temp and before the scope that used to be responsible for deleting it.
    /// The observable contract is that no `.rewrite.` artifact survives.
    /// Thread-local.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn inject_rewrite_temp_preparation_failures(count: u64) {
        INJECTED_REWRITE_TEMP_PREPARATION_FAILURES.with(|armed| armed.set(count));
    }

    /// Arms `count` injected generic keyed-tail reservation failures (API3-01).
    ///
    /// Fault-testing hook only: each armed failure makes the next generic
    /// keyed push/delete fail its pre-append tail-cache reservation with
    /// [`Error::AllocationFailed`]. The observable contract under this fault is
    /// that the append did **not** happen, which is exactly what the previous
    /// append-then-reserve ordering could not guarantee. Thread-local.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn inject_keyed_tail_reservation_failures(count: u64) {
        INJECTED_KEYED_TAIL_RESERVATION_FAILURES.with(|armed| armed.set(count));
    }

    /// Arms `count` injected post-append keyed-tail reservation losses
    /// (API3-01).
    ///
    /// Fault-testing hook only: each armed loss makes the next generic keyed
    /// push/delete behave as if the slot reserved before the append were no
    /// longer usable afterwards. The mutation still succeeds; the cached tail
    /// map for that block id must be discarded rather than left holding the
    /// superseded predecessor, so the following mutation still links to the
    /// record that succeeded. Thread-local.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn inject_keyed_tail_commit_losses(count: u64) {
        INJECTED_KEYED_TAIL_COMMIT_LOSSES.with(|armed| armed.set(count));
    }

    /// Arms `count` injected post-commit-marker durability failures (round 10).
    ///
    /// Fault-testing hook only: each armed failure makes the next
    /// [`Self::commit_durable`] fail its `flush`/`sync_all` *after* the commit
    /// marker has been appended. The observable contract under this fault is
    /// that the caller receives [`Error::CommittedButDurabilityUnproven`]
    /// rather than a bare `Err`, because the marker bytes are in the file and
    /// re-running the transaction would append a second marker for work that
    /// is already recorded. Thread-local.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn inject_commit_durability_failures(count: u64) {
        INJECTED_COMMIT_DURABILITY_FAILURES.with(|armed| armed.set(count));
    }

    /// Returns the cumulative number of resident index entries this thread's
    /// checkpoint flush-cadence machinery has examined (PERF2-02).
    ///
    /// Fault-testing hook only: regression tests delta-measure this around a
    /// flush-per-record workload to pin the cadence work at O(1) per flush
    /// (near-linear cumulative touches) instead of the historical O(N) rescan
    /// per flush. The counter is thread-local so concurrently running tests
    /// cannot pollute each other's measurements.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn checkpoint_cadence_index_touches() -> u64 {
        CHECKPOINT_CADENCE_INDEX_TOUCHES.with(|touches| touches.get())
    }

    /// Returns the cumulative number of resident index entries this thread's
    /// block-offset-chain predecessor machinery has examined (PERF2-05).
    ///
    /// Fault-testing hook only. The append path resolves predecessors from the
    /// maintained tail table and must never advance this counter, so a
    /// regression test can delta-measure an append window and assert zero for
    /// any record count; only wholesale index loads (open, recovery, rebind,
    /// rollback) pay one pass.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn block_tail_index_touches() -> u64 {
        BLOCK_TAIL_INDEX_TOUCHES.with(|touches| touches.get())
    }

    /// Returns the cumulative number of block-tail tuples this thread has
    /// displaced by inserting into the sorted tail vector (PERF3-03).
    ///
    /// Fault-testing hook only. Wholesale tail construction must not advance
    /// this counter at all: it orders the distinct block ids once instead of
    /// inserting each first-seen id, so a reverse-ordered index no longer pays
    /// the `Theta(B^2)` movement the index-visit counter above cannot see.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn block_tail_entries_moved() -> u64 {
        BLOCK_TAIL_ENTRIES_MOVED.with(|moved| moved.get())
    }

    /// Returns the cumulative number of records this thread has framed - read a
    /// header, an extent and a footer for - while building an index.
    ///
    /// Fault-testing hook only. This is the unit `IndexPolicy::segment_on_flush`
    /// exists to reduce: a scan frames every record in the file, and a segment
    /// chain frames one record per commit point and no data record at all, so a
    /// regression test can delta-measure an open and tell the two apart by the
    /// count rather than by the wall clock.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn records_framed() -> u64 {
        RECORDS_FRAMED.with(|framed| framed.get())
    }

    /// Reads and clears the number of index-entry comparisons this thread has
    /// made resolving a rewritten record's chain predecessor.
    ///
    /// Fault-testing hook only. `replace_block` validates every rewritten
    /// record's predecessor against the prefix it has already written; a
    /// front-to-back scan of that growing prefix costs `Theta(N^2)` and the
    /// sorted lookup that replaced it costs `O(N log N)`, which a regression
    /// test tells apart by this count rather than by the clock.
    #[cfg(any(test, feature = "scalable-fault-injection"))]
    #[doc(hidden)]
    pub fn take_replacement_predecessor_probes() -> u64 {
        REPLACEMENT_PREDECESSOR_PROBES.with(|probes| probes.replace(0))
    }

    /// Reads and clears the number of `fstat`s this thread has issued to bind
    /// a snapshot's length (`snapshot.rs`'s `checked_snapshot_bounds`).
    ///
    /// Fault-testing hook only. The append path rebinds through
    /// `SnapshotFile::with_written_len`, which proves `len <= physical_len`
    /// from the write that just returned, so an append window must leave this
    /// at zero for any record count. Open still pays one per snapshot bind,
    /// which is what tells a real fix apart from a neutered counter.
    #[cfg(any(test, feature = "scalable-fault-injection"))]
    #[doc(hidden)]
    pub fn take_snapshot_bounds_fstats() -> u64 {
        crate::snapshot::take_snapshot_bounds_fstats()
    }

    /// Record bytes this thread has walked while scanning, read and cleared.
    ///
    /// Fault-testing hook only. An open that follows the on-disk segment chain
    /// walks the chain; an open that scans walks the file. This is the number
    /// that tells them apart.
    #[cfg(any(test, feature = "scalable-fault-injection"))]
    #[doc(hidden)]
    pub fn take_open_scan_bytes() -> u64 {
        take_open_scan_bytes()
    }

    /// Reads and clears the number of `fstat`s this thread has issued through
    /// the writer's own record handle (`RecordFile::metadata`).
    ///
    /// Fault-testing hook only, and a sibling of the counter above rather than
    /// the same one: this is the `AppendSnapshot` end-of-file probe, which the
    /// writer now answers from the snapshot it maintains.
    #[cfg(any(test, feature = "scalable-fault-injection"))]
    #[doc(hidden)]
    pub fn take_record_file_metadata_calls() -> u64 {
        record_file::take_record_file_metadata_calls()
    }

    /// Reads and clears this thread's count of `lseek`s `RecordFile` issued on
    /// its own handle.
    ///
    /// The sibling the metadata counter did not have. The append path's
    /// `AppendSnapshot` took its rollback cursor with a per-record
    /// `stream_position`, which is an `lseek`, which
    /// `an_append_window_issues_no_metadata_syscall` could not see because it
    /// counts `metadata` only.
    #[cfg(any(test, feature = "scalable-fault-injection"))]
    #[doc(hidden)]
    pub fn take_record_file_seeks() -> u64 {
        record_file::take_record_file_seeks()
    }

    /// Reads and clears this thread's count of resident-index entries rebuilt
    /// from their record headers.
    ///
    /// The resident index stores an offset and a commit bit per record, not the
    /// entry — every read of an entry is one positional read of that record's
    /// header (`fault_record_entry`). So this counts what walking the directory
    /// actually costs, which no byte counter does: `take_open_scan_bytes`
    /// measures the open scan, and a directory walk after open is invisible to
    /// it.
    #[cfg(any(test, feature = "scalable-fault-injection"))]
    #[doc(hidden)]
    pub fn take_record_entry_faults() -> u64 {
        take_record_entry_faults()
    }

    /// Cumulative bytes this thread has read to answer chunked cell reads.
    ///
    /// Fault-testing hook only. This is the unit a growing matrix's read path
    /// exists to keep small: a chunk is one record, so "read the cell" and
    /// "read the chunk" differ by orders of magnitude and a regression test can
    /// tell them apart by an absolute byte count rather than a ratio.
    #[cfg(feature = "scalable-fault-injection")]
    #[doc(hidden)]
    pub fn chunk_bytes_read() -> u64 {
        CHUNK_BYTES_READ.with(|read| read.get())
    }

    /// Maps only the stored payload of a record from this captured generation.
    /// No resident record directory is required. The mapping limit applies to
    /// this payload, not to the file or the sum of its record lengths. Compressed
    /// records expose their stored encoding, not decompressed bytes.
    ///
    /// # Safety
    /// The caller must prevent mutation, truncation and backing-file invalidation
    /// of this record for the entire returned window's lifetime, through all
    /// handles, threads and processes. The same external immutability contract
    /// as `mmap_payloads` applies; this API adds no writer lock.
    #[cfg(feature = "mmap")]
    pub unsafe fn mmap_payload_window(
        &self,
        entry: &RecordIndexEntry,
    ) -> Result<MmapPayloadWindow> {
        if entry.record_offset < append_log_start_for_file(self)? {
            return Err(Error::MmapEntryNotInSnapshot);
        }
        validate_mmap_index_entry(entry, self.snapshot.len())?;
        let actual = fault_record_entry(
            &self.snapshot,
            self.spec,
            entry.record_offset,
            entry.committed,
        )?;
        if actual != *entry {
            return Err(Error::MmapEntryNotInSnapshot);
        }
        self.spec
            .read_limits
            .check(ReadLimitKey::MmapLen, entry.payload_len)?;
        let len = usize::try_from(entry.payload_len).map_err(|_| Error::LengthOverflow {
            value: entry.payload_len,
        })?;
        let file = self.snapshot.try_clone_file()?;
        validate_mmap_index_entry(entry, file.metadata()?.len())?;
        let mmap = if len == 0 {
            None
        } else {
            // SAFETY: caller promises external immutability; the checked extent
            // belongs to this pinned file and fits the captured generation.
            Some(unsafe {
                memmap2::MmapOptions::new()
                    .offset(entry.payload_offset)
                    .len(len)
                    .map(&file)?
            })
        };
        let window = MmapPayloadWindow {
            offset: entry.payload_offset,
            mmap,
        };
        entry.verify_snapshot_record(self.spec, &self.snapshot, window.as_bytes())?;
        Ok(window)
    }

    #[cfg(feature = "mmap")]
    /// Maps the file's indexed record payloads as a read-only snapshot.
    ///
    /// # Safety
    ///
    /// The caller must prevent mutation, truncation, replacement, backing-file
    /// invalidation, and any other modification through every handle, thread,
    /// and process for the full lifetime of the returned mapping. The mapping
    /// remains tied to this already-open backing object even if its path is
    /// renamed or replaced.
    ///
    /// Once that condition holds, Varlit keeps safe accessors sound by creating
    /// a read-only mapping from a clone of the existing handle, validating every
    /// indexed extent with checked arithmetic, rejecting entries outside the
    /// copied snapshot, and tying every returned slice to the mapping owner.
    /// Use owned reads instead when external immutability cannot be guaranteed.
    ///
    /// **The file header is not mapped.** The mapping begins at the start of
    /// the append log, so the bytes a commit can rewrite — the
    /// `IndexPolicy::header_tails` region among them — are outside every
    /// reference this type constructs. The condition above is therefore about
    /// the *records* — and a `replace_*` is **not** the only thing that rewrites
    /// one. On a format declaring `with_growing_matrix_dimension`, any
    /// `flush`, `commit`, `sync` or drop that writes an already-backed chunk
    /// goes through `rewrite_chunk_record`, which overwrites that record's
    /// header and payload where they sit — inside this mapping. A writer of
    /// such a format has to be excluded for the mapping's lifetime like any
    /// other; "I call no `replace_*`" is not enough.
    pub unsafe fn mmap_payloads(&self) -> Result<MmapPayloads> {
        // The index this maps is the *resident* one, and a lazily opened handle
        // deliberately has none. Without this the answer was `Ok` with zero
        // entries — `is_empty()` true, every window `None`, no error anywhere.
        // Measured on the fixture that pins it, which holds sixty-five records;
        // the count is not what makes it wrong, but it is what was measured.
        // Refusing by name is what every other directory-needing read does, and
        // it is the difference between "this handle cannot answer that" and
        // "there is nothing here".
        let _ = self.resident_directory("mmap_payloads")?;
        let mapped_len = self.snapshot.len();
        // `MmapLen` alone. `FileLen` was checked here too, against the same
        // value — the mapping's length is the snapshot's length — so it bounded
        // nothing the line below does not, and it made a caller who declared a
        // mapping ceiling also have to declare a file ceiling to use it.
        self.spec
            .read_limits
            .check(ReadLimitKey::MmapLen, mapped_len)?;
        let record_count =
            u64::try_from(self.index.len()).map_err(|_| Error::ResourceArithmeticOverflow {
                resource: "record count",
            })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::Records, record_count)?;
        let verify = self.spec.integrity_policy != IntegrityPolicy::None;
        let mmap_index_bytes = mmap_index_bytes_for_count(self.index.len(), verify)?;
        self.spec
            .read_limits
            .check(ReadLimitKey::IndexBytes, mmap_index_bytes)?;

        let file = self.snapshot.try_clone_file()?;
        let current_len = file.metadata()?.len();
        if mapped_len > current_len {
            return Err(Error::MmapPayloadOutOfBounds {
                offset: 0,
                len: mapped_len,
            });
        }
        // Start the mapping at the append log, not at byte 0: see
        // `MmapPayloads::base`. Every payload this type hands out lives at or
        // after this offset by construction, so nothing is lost.
        let (base, mapped_span) = match mapped_len.checked_sub(append_log_start_for_file(self)?) {
            Some(span) if span > 0 => (append_log_start_for_file(self)?, span),
            // The file holds no records. No accessor can produce a window, so
            // the mapping is never dereferenced and nothing constructs a
            // reference over the header — mapping it is sound, and it avoids
            // asking the OS for a zero-length mapping.
            _ => {
                debug_assert_eq!(self.index.len(), 0);
                (0, mapped_len)
            }
        };
        let map_len = usize::try_from(mapped_span)
            .map_err(|_| Error::LengthOverflow { value: mapped_span })?;
        // SAFETY: The caller guarantees that the cloned backing object remains
        // immutable and valid for the mapping's entire lifetime.
        let mmap = unsafe {
            memmap2::MmapOptions::new()
                .offset(base)
                .len(map_len)
                .map(&file)?
        };
        let mut index = Vec::new();
        index
            .try_reserve_exact(self.index.len())
            .map_err(|_| Error::AllocationFailed {
                resource: "mmap index",
                requested: mmap_index_bytes,
            })?;
        let mut by_block: HashMap<u32, Vec<usize>> = HashMap::new();
        let mut verified = Vec::new();
        if verify {
            verified
                .try_reserve_exact(self.index.len())
                .map_err(|_| Error::AllocationFailed {
                    resource: "mmap integrity cache",
                    requested: self.index.len() as u64,
                })?;
            verified.resize_with(self.index.len(), || {
                std::sync::atomic::AtomicBool::new(false)
            });
        }
        by_block
            .try_reserve(
                self.index
                    .len()
                    .min(self.spec.blocks.len().saturating_add(6)),
            )
            .map_err(|_| Error::AllocationFailed {
                resource: "mmap block lookup",
                requested: mmap_index_bytes,
            })?;
        // **One pass, and it is now the only one.** The bounds validation, the
        // copy, the per-block position lists and the ordering witness were four
        // separate walks of the same entries. The ordering check in particular
        // was a `windows(2)` over the finished copy, which is a whole extra
        // traversal in debug builds to learn something each step already knows.
        //
        // What moved, and what it costs: validation used to run before the
        // mapping was taken. It now runs after, so a file with an out-of-bounds
        // entry pays one `mmap`/`munmap` before its refusal — the mapping is
        // dropped by the `?` and nothing has read through it, since
        // `MmapPayloads` is not constructed until the loop finishes. That is
        // the whole price, and it buys one traversal instead of two on the
        // path that succeeds. `mapped_len <= current_len` is still checked
        // before the map, so the map itself is never oversized.
        //
        // Records occupy contiguous ascending physical extents, so the copied
        // index is strictly offset-ordered; `payload_window` relies on that for
        // its binary-search membership check (PERF2-07).
        let mut previous_offset: Option<u64> = None;
        for (position, entry) in self.index.iter().enumerate() {
            let entry = entry?;
            validate_mmap_index_entry(&entry, mapped_len)?;
            debug_assert!(
                previous_offset.is_none_or(|previous| previous < entry.record_offset),
                "resident index must be strictly ordered by record offset",
            );
            previous_offset = Some(entry.record_offset);
            let block_id = entry.block_id;
            index.push(entry);
            let positions = by_block.entry(block_id).or_default();
            positions
                .try_reserve(1)
                .map_err(|_| Error::AllocationFailed {
                    resource: "mmap block positions",
                    requested: mmap_index_bytes,
                })?;
            positions.push(position);
        }
        Ok(MmapPayloads {
            spec: self.spec,
            base,
            index,
            by_block,
            verified,
            mmap,
        })
    }

    #[cfg(feature = "mmap")]
    /// Maps one committed matrix cell from this handle's generation.
    ///
    /// Charges `MmapLen` for the cell, and `MaterializedBytes` for its COW
    /// pages only. Bitmap and optional CRC validation use the same generation
    /// as ordinary cell reads. No complete matrix mapping or copied layout is
    /// needed. COW payload pages are copied into this private mapping; this is
    /// not a zero-copy promise for modified cells.
    ///
    /// # Safety
    ///
    /// The caller must keep the underlying file object immutable and valid
    /// for the entire mapping lifetime, as for [`Self::mmap_matrix`].
    pub unsafe fn mmap_matrix_cell<T: VarlitMatrixBlock>(
        &self,
        key: MatrixKey,
    ) -> Result<MmapPayloadWindow> {
        let layout = self.matrix.as_ref().ok_or(Error::MatrixLayoutMissing)?;
        let pages = self.file.matrix_pages().ok_or(Error::MatrixLayoutMissing)?;
        let (offset, len, cell_crc) = crate::matrix::cell_payload_parts::<T>(
            self.spec,
            layout,
            key,
            crate::matrix::BitmapRead::new(pages),
        )?;
        self.spec.read_limits.check(ReadLimitKey::MmapLen, len)?;
        let changed = pages.mapped_window_pages(offset, len)?;
        self.spec.read_limits.check(
            ReadLimitKey::MaterializedBytes,
            changed
                .checked_mul(4096)
                .ok_or(Error::InvalidMatrixLayout)?,
        )?;
        let file = self.snapshot.try_clone_file()?;
        validate_mmap_range(offset, len, self.snapshot.len())?;
        validate_mmap_range(offset, len, file.metadata()?.len())?;
        let mmap = if len == 0 {
            None
        } else {
            let map_len = usize::try_from(len).map_err(|_| Error::LengthOverflow { value: len })?;
            // SAFETY: the caller guarantees the base file's immutability and
            // lifetime; all COW patches are applied before exposing any slice.
            let mut mapping = unsafe {
                memmap2::MmapOptions::new()
                    .offset(offset)
                    .len(map_len)
                    .map_copy(&file)?
            };
            pages.patch_mapping_window(offset, &mut mapping)?;
            Some(mapping.make_read_only()?)
        };
        let window = MmapPayloadWindow { offset, mmap };
        if let Some(cell_crc) = cell_crc {
            let mut crc = [0; 4];
            let mut source = pages.read_borrow();
            source.seek(SeekFrom::Start(cell_crc.offset))?;
            source.read_exact(&mut crc)?;
            cell_crc.verify(
                window.as_bytes(),
                u32::from_le_bytes(crc),
                crate::matrix::BitmapRead::new(pages),
            )?;
        }
        Ok(window)
    }

    #[cfg(feature = "mmap")]
    /// Maps the file's matrix regions as a read-only snapshot.
    ///
    /// # Safety
    ///
    /// The caller must prevent mutation, truncation, replacement, backing-file
    /// invalidation, and any other modification through every handle, thread,
    /// and process for the full lifetime of the returned mapping. The mapping
    /// remains tied to this already-open backing object even if its path is
    /// renamed or replaced.
    ///
    /// Once that condition holds, Varlit keeps safe accessors sound by creating
    /// a read-only mapping from a clone of the existing handle, validating the
    /// complete matrix extent, checking every requested slot, and tying every
    /// returned slice to the mapping owner. Use owned reads instead when
    /// external immutability cannot be guaranteed.
    pub unsafe fn mmap_matrix(&self) -> Result<MmapMatrix> {
        let layout = self
            .matrix
            .as_ref()
            .ok_or(Error::MatrixLayoutMissing)?
            .try_clone()?;
        let mapped_len = self.snapshot.len();
        // `MmapLen` alone. `FileLen` was checked here too, against the same
        // value — the mapping's length is the snapshot's length — so it bounded
        // nothing the line below does not, and it made a caller who declared a
        // mapping ceiling also have to declare a file ceiling to use it.
        self.spec
            .read_limits
            .check(ReadLimitKey::MmapLen, mapped_len)?;
        let record_count =
            u64::try_from(self.index.len()).map_err(|_| Error::ResourceArithmeticOverflow {
                resource: "record count",
            })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::Records, record_count)?;
        self.spec.read_limits.check(
            ReadLimitKey::IndexBytes,
            index_bytes_for_count(self.index.len())?,
        )?;
        let file = self.snapshot.try_clone_file()?;
        let current_len = file.metadata()?.len();
        if mapped_len > current_len {
            return Err(Error::MmapPayloadOutOfBounds {
                offset: 0,
                len: mapped_len,
            });
        }
        validate_mmap_range(0, layout.append_log_start(), current_len)?;
        let map_len =
            usize::try_from(mapped_len).map_err(|_| Error::LengthOverflow { value: mapped_len })?;
        // SAFETY: The caller guarantees that the cloned backing object remains
        // immutable and valid for the mapping's entire lifetime.
        let pages = self.file.matrix_pages().ok_or(Error::MatrixLayoutMissing)?;
        let changed = pages.mapped_page_count()?;
        self.spec.read_limits.check(
            ReadLimitKey::MaterializedBytes,
            changed
                .checked_mul(4096)
                .ok_or(Error::InvalidMatrixLayout)?,
        )?;
        let mut mapping = unsafe { memmap2::MmapOptions::new().len(map_len).map_copy(&file)? };
        pages.patch_mapping(&mut mapping)?;
        let mmap = mapping.make_read_only()?;
        validate_mmap_range(0, layout.append_log_start(), mapped_len)?;
        Ok(MmapMatrix {
            spec: self.spec,
            layout,
            mmap,
        })
    }

    /// The write-side guard: poison check plus open-mode check, returning the
    /// witness the guarded operations demand. See [`Self::ensure_not_poisoned`].
    fn check_write(&self) -> Result<()> {
        self.check_mutation(WRITER_POISON_CONTEXT)?;
        match self.mode {
            OpenMode::ReadWrite => Ok(()),
            OpenMode::ReadOnly => Err(Error::Io(std::io::Error::new(
                std::io::ErrorKind::PermissionDenied,
                "file was opened read-only",
            ))),
        }
    }
    fn ensure_write(&mut self) -> Result<FileMutationPermit<'_>> {
        self.check_write()?;
        self.writer_permit(WRITER_POISON_CONTEXT)
    }

    fn rebind_published_generation(
        &mut self,
        sequence: u64,
        new_index: RewriteDirectory,
    ) -> Result<u64> {
        let rebind = (|| -> Result<(File, SnapshotFile)> {
            #[cfg(test)]
            fail_rebind_after_publish_if_requested()?;
            let file = OpenOptions::new().read(true).write(true).open(&self.path)?;
            // The published generation is a new file object; the single-writer
            // object lock must move with the writer.
            if let Some(lock) = self._lock.as_mut() {
                lock.bind_native(&file, &self.path)?;
            }
            let snapshot = SnapshotFile::new(file.try_clone()?)?;
            Ok((file, snapshot))
        })();

        match rebind {
            Ok((file, snapshot)) => {
                self.file = RecordFile::new(file);
                self.snapshot = snapshot;
                let last_resident_block_id = new_index.last().map(|entry| entry.block_id);
                // Rebinding succeeded and the complete new directory is ready.
                // Release the old private rows before optional compaction; an
                // assignment alone would keep them alive throughout its RHS.
                self.index = ResidentIndex::empty(self.snapshot.clone(), self.spec);
                self.index = new_index.into_resident(self.snapshot.clone(), self.spec);
                // The resident index was replaced wholesale; recover the O(1)
                // flush-cadence state once for the new generation (PERF2-02)
                // and the O(1) block tails with it (PERF2-05). Record offsets
                // moved, so every cached generic keyed tail is stale (API2-05).
                let derived = derive_index_state(self.index.iter(), true)?;
                self.checkpoint_cadence = derived.checkpoint_cadence;
                self.block_tails = derived.block_tails.expect("tails were requested");
                self.segment_cursor = derived.segment_cursor;
                // The same wholesale replacement: the newest entry is a
                // different record now, so the append-path shortcut that names
                // its block id is stale too.
                self.last_resident_block_id = last_resident_block_id;
                self.keyed_tails.invalidate_all();
                // Both callers publish a generation whose mutable header blocks
                // are cold — `replace_rewrite` because it writes a fresh header
                // through `header_extensions_for_replacement`, `replace_fixed`
                // because it writes the cold region over its byte copy — so the
                // cached region has to say so too, exactly as
                // `rebind_replacement_generation` does. A cache left warm over
                // a cold file makes the next commit write generation `N + 1`
                // while a reader still prefers a warm slot claiming `N`.
                self.header_extensions =
                    header_extensions_for_replacement(self.spec, &self.header_extensions)?;
                self.publish_sequence(sequence);
                Ok(sequence)
            }
            Err(source) => {
                self.poison.poison();
                // F-07: the caller folds in a parent-directory sync failure it
                // already observed, via `Error::with_pending_parent_sync`.
                Err(crate::fallible::boxed_error(
                    source,
                    Error::ErrorContextAllocationFailed {
                        context: crate::AllocationFailureContext::PublishedRebind {
                            sequence,
                            parent_sync_pending: false,
                        },
                    },
                    |source| Error::PublishedButRebindFailed {
                        sequence,
                        source,
                        parent_sync: None,
                    },
                ))
            }
        }
    }

    fn rebind_replacement_generation(
        &mut self,
        info: ReplacementInfo,
        new_index: RewriteDirectory,
    ) -> Result<ReplacementInfo> {
        let rebind = (|| -> Result<(File, SnapshotFile)> {
            #[cfg(test)]
            fail_rebind_after_publish_if_requested()?;
            let file = OpenOptions::new().read(true).write(true).open(&self.path)?;
            // The published generation is a new file object; the single-writer
            // object lock must move with the writer.
            if let Some(lock) = self._lock.as_mut() {
                lock.bind_native(&file, &self.path)?;
            }
            let snapshot = SnapshotFile::new(file.try_clone()?)?;
            Ok((file, snapshot))
        })();

        match rebind {
            Ok((file, snapshot)) => {
                self.file = RecordFile::new(file);
                self.snapshot = snapshot;
                let last_resident_block_id = new_index.last().map(|entry| entry.block_id);
                // Rebinding succeeded and the complete new directory is ready.
                // Release the old private rows before optional compaction; an
                // assignment alone would keep them alive throughout its RHS.
                self.index = ResidentIndex::empty(self.snapshot.clone(), self.spec);
                self.index = new_index.into_resident(self.snapshot.clone(), self.spec);
                // The resident index was replaced wholesale; recover the O(1)
                // flush-cadence state once for the new generation (PERF2-02)
                // and the O(1) block tails with it (PERF2-05). Record offsets
                // moved, so every cached generic keyed tail is stale (API2-05).
                let derived = derive_index_state(self.index.iter(), true)?;
                self.checkpoint_cadence = derived.checkpoint_cadence;
                self.block_tails = derived.block_tails.expect("tails were requested");
                self.segment_cursor = derived.segment_cursor;
                // The same wholesale replacement: the newest entry is a
                // different record now, so the append-path shortcut that names
                // its block id is stale too.
                self.last_resident_block_id = last_resident_block_id;
                self.keyed_tails.invalidate_all();
                // The published file carries a *cold* mutable header block —
                // the rewrite could not carry the old offsets forward — so the
                // cached region has to say so too. Same length either way, which
                // is why nothing derived from `header_extensions.len()` moves.
                self.header_extensions =
                    header_extensions_for_replacement(self.spec, &self.header_extensions)?;
                // The published header's mutable blocks were reset to cold, and
                // one of them is the liveness bit. This handle still holds the
                // object, so leaving it clear would tell the *next* open that
                // the last writer released cleanly — and if this one then dies,
                // `mark_tail` would not run and `truncate_tail` would cut a tail
                // nobody was told about. Re-asserted rather than left to the
                // next open to notice, because by then it is the wrong answer.
                //
                // Not `mark_writer_open`: that re-reads the block for the
                // handle's own crash verdict, which would clobber the verdict
                // this handle already established at its open.
                self.write_liveness_flags(LIVENESS_FLAG_DIRTY)?;
                Ok(info)
            }
            Err(source) => {
                self.poison.poison();
                // F-07: the caller folds in a parent-directory sync failure it
                // already observed, via `Error::with_pending_parent_sync`.
                Err(crate::fallible::boxed_error(
                    source,
                    Error::ErrorContextAllocationFailed {
                        context: crate::AllocationFailureContext::PublishedRebind {
                            sequence: info.sequence,
                            parent_sync_pending: false,
                        },
                    },
                    |source| Error::PublishedButRebindFailed {
                        sequence: info.sequence,
                        source,
                        parent_sync: None,
                    },
                ))
            }
        }
    }

    fn validate_source_generation(&self) -> Result<()> {
        let current_len = self.file.metadata()?.len();
        if current_len != self.snapshot.len() {
            return Err(Error::InvalidCanonicalEncoding(
                "native file changed after it was indexed",
            ));
        }
        let mut file = self.snapshot.try_clone_file()?;
        validate_generation_index(
            self.spec,
            &mut file,
            append_log_start_for_file(self)?,
            &self.index,
        )
    }

    /// The one poison check for this writer, and the only source of the
    /// witness its guarded operations demand.
    ///
    /// Shape B, mechanical enforcement (round 12). `PoisonFlag` owns the state
    /// and lives in `crate::writer_permit`, so nothing in this ~12000-line file
    /// can read or assign it. Every function that puts bytes into an already
    /// published generation — the append core, and the one in-place record
    /// rewrite — takes the [`MutationPermit`] this returns, by reference, so a
    /// mutating method written later cannot reach the disk without having asked
    /// for one. See `crate::writer_permit` for what that makes impossible.
    fn ensure_not_poisoned(&mut self) -> Result<FileMutationPermit<'_>> {
        self.writer_permit(WRITER_POISON_CONTEXT)
    }

    /// Handles a failed atomic publication for a copy-on-write writer.
    ///
    /// Pre-publication failures leave the target untouched, so the temp file
    /// is deleted and the writer stays usable. An indeterminate outcome
    /// ([`Error::ReplacePublicationIndeterminate`]) means the pathname state
    /// is unknown: the temp file is preserved for out-of-band reconciliation
    /// and the writer is poisoned so a blind retry cannot publish over an
    /// unknown generation (DUR2-01).
    fn fail_publication(&mut self, temp_path: &Path, error: Error) -> Error {
        if matches!(error, Error::ReplacePublicationIndeterminate { .. }) {
            self.poison.poison();
        } else {
            let _ = remove_file(temp_path);
        }
        error
    }

    /// Classifies the outcome of a matrix mutation and poisons the writer when
    /// the failure could have left disk and memory disagreeing.
    ///
    /// INVARIANT 3. The narrow [`Error::Io`] predicate is **deliberate**, and
    /// round 10 re-derived it rather than inheriting it. The review's F-03
    /// offered two corrections — prepare the allocation before the disk write,
    /// or poison on every error raised after on-disk mutation begins — and the
    /// first was taken. That choice is what makes this predicate correct: every
    /// disk write in `crate::matrix` is now paired with an *infallible*
    /// in-memory install (`commit_byte_write`, `commit_current_write_bit`, the
    /// page-index mirror resynchronisation), so a matrix mutation is a sequence
    /// of individually atomic sub-steps. A typed refusal raised between two of
    /// them — `LimitExceeded` from a later page charge, `AllocationFailed` from
    /// a later first-touch page, `InvalidMatrixLayout` from later geometry —
    /// leaves the file and memory agreeing on everything the earlier sub-steps
    /// did, so the writer stays usable and the caller can retry. That contract
    /// is asserted by
    /// `matrix_integrity_scaling.rs::a_failed_page_allocation_cannot_leave_a_bit_on_disk`,
    /// which injects exactly such a failure at both first-touch boundaries and
    /// requires the same writer to keep working.
    ///
    /// Poisoning on *any* post-write error was implemented and rejected on that
    /// evidence: it converts those clean refusals into an unusable writer.
    /// `Error::Io` remains the right trigger because a failed write is the one
    /// case where what reached the file is unknown.
    ///
    /// The obligation this leaves on future work is therefore not "widen the
    /// predicate" but "keep the pairing": any new fallible step placed *between*
    /// a matrix disk write and its in-memory twin reopens F-03, and must be
    /// moved ahead of the write instead.
    fn finish_matrix_mutation<T>(&mut self, result: Result<T>) -> Result<T> {
        if matches!(&result, Err(Error::Io(_))) {
            self.poison.poison();
        }
        result
    }

    /// A failed durability operation leaves the writer unfit to continue.
    /// Barrier callbacks precede generation publication and propagate their
    /// original errors. Publication/hook outcomes are classified by the caller.
    fn poison_after_started_matrix_error<T>(&mut self, result: Result<T>) -> Result<T> {
        if result.is_err() {
            self.poison.poison();
        }
        result
    }

    fn ensure_user_block<T: VarlitBlock>(&self) -> Result<()> {
        if T::ID >= RESERVED_BLOCK_ID_START {
            return Err(Error::ReservedBlockId(T::ID));
        }
        Ok(())
    }

    fn publish_sequence(&mut self, sequence: u64) {
        debug_assert_eq!(self.sequence_state, SequenceState::Available(sequence));
        self.sequence_state = SequenceState::after_publishing(sequence);
    }

    #[cfg(test)]
    fn push_info_for_test(&mut self, block_id: u32, payload: &[u8]) -> Result<AppendInfo> {
        self.check_write()?;
        self.ensure_write()?
            .write_record_with_prev_key(block_id, 1, 0, 0, payload, None)
    }

    pub(crate) fn write_record(
        &mut self,
        block_id: u32,
        block_version: u16,
        flags: u16,
        payload: &[u8],
    ) -> Result<u64> {
        self.check_write()?;
        Ok(self
            .ensure_write()?
            .write_record_with_prev_key(block_id, block_version, flags, 0, payload, None)?
            .sequence)
    }

    fn rollback_append(&mut self, snapshot: AppendSnapshot, operation_error: Error) -> Error {
        // The tail states are advanced only after the record is fully written,
        // so this normally truncates nothing; rebuilding when it does keeps
        // the `BlockTails::from_index` invariant unconditional (PERF2-05).
        let truncated = self.index.len() > snapshot.index_len;
        self.index.truncate(snapshot.index_len);
        // Restore the one tail this append moved rather than rebuilding the
        // table from the resident index.
        //
        // **Unreachable today, and kept anyway.** Both rollback points are
        // above `block_tails.note_appended`, so a rollback always finds the
        // tail where it started and this restores it to itself — exactly as
        // the rebuild it replaces never actually ran, for the same reason.
        // What changed is which one is *correct if the ordering ever moves*:
        // rebuilding from the resident index drops a non-resident block's tail
        // entirely, and that tail is the only way back to its records. This is
        // also `O(1)` and allocation-free, which the rebuild was not
        // (PERF2-05).
        self.block_tails
            .restore(snapshot.block_id, snapshot.previous_block_tail);
        self.uncommitted_since_commit = snapshot.uncommitted_since_commit;
        self.appended_since_digest = snapshot.appended_since_digest;
        self.last_resident_block_id = snapshot.last_resident_block_id;
        if truncated {
            self.keyed_tails.invalidate_all();
        }
        self.sequence_state = snapshot.sequence_state;
        self.checkpoint_cadence = snapshot.checkpoint_cadence;
        self.segment_cursor = snapshot.segment_cursor;

        #[cfg(test)]
        let truncate_result =
            fail_rollback_if_requested().and_then(|()| self.file.set_len(snapshot.eof));
        #[cfg(not(test))]
        let truncate_result = self.file.set_len(snapshot.eof);
        // Back to the end of file this append started from — the offset the
        // truncate above just restored, and the one the next append's
        // `SEEK_END` would land on anyway. See `AppendSnapshot::eof`.
        let cursor_result = self.file.seek_to(snapshot.eof).map(|_| ());
        if let Some(source) = truncate_result.err().or_else(|| cursor_result.err()) {
            self.poison.poison();
            Error::WriteRollbackFailed {
                operation: "append record",
                source,
            }
        } else {
            operation_error
        }
    }

    /// The payload length a full checkpoint of the current index would need.
    fn index_checkpoint_payload_len(&self) -> Result<u64> {
        const CHECKPOINT_PREFIX_LEN: u64 = 4 + 2 + 8 + 8;
        let entry_count =
            u64::try_from(self.index.len()).map_err(|_| Error::ResourceArithmeticOverflow {
                resource: "checkpoint entry count",
            })?;
        entry_count
            .checked_mul(SEGMENT_ENTRY_LEN)
            .and_then(|bytes| bytes.checked_add(CHECKPOINT_PREFIX_LEN))
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "checkpoint payload length",
            })
    }

    /// Whether a full checkpoint of the current index would fit the format's
    /// own record ceilings.
    ///
    /// The index only grows, so once this is false it stays false and the
    /// answer costs one multiply per flush. Every way it can be false is a
    /// reason `write_index_checkpoint` would refuse, which is why the decision
    /// belongs here: a checkpoint is derived, and declining to write one costs
    /// the next open a scan it already knows how to do.
    fn index_checkpoint_fits(&self) -> bool {
        let Ok(payload_len) = self.index_checkpoint_payload_len() else {
            return false;
        };
        let limits = &self.spec.read_limits;
        u64::try_from(self.index.len())
            .is_ok_and(|count| limits.check(ReadLimitKey::Records, count).is_ok())
            && limits
                .check(ReadLimitKey::RecordPayloadLen, payload_len)
                .is_ok()
            && limits
                .check(ReadLimitKey::LogicalPayloadLen, payload_len)
                .is_ok()
    }

    fn write_index_checkpoint(&mut self) -> Result<u64> {
        const CHECKPOINT_PREFIX_LEN: u64 = 4 + 2 + 8 + 8;
        const CHECKPOINT_ENTRY_LEN: u64 = 4 + 2 + 2 + 8 + 8 + 8 + 8 + 4 + 4 + 8 + 8 + 8 + 1;
        let covered_offset = self.file.metadata()?.len();
        let entry_count =
            u64::try_from(self.index.len()).map_err(|_| Error::ResourceArithmeticOverflow {
                resource: "checkpoint entry count",
            })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::Records, entry_count)?;
        let payload_len = entry_count
            .checked_mul(CHECKPOINT_ENTRY_LEN)
            .and_then(|bytes| bytes.checked_add(CHECKPOINT_PREFIX_LEN))
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "checkpoint payload length",
            })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::RecordPayloadLen, payload_len)?;
        self.spec
            .read_limits
            .check(ReadLimitKey::LogicalPayloadLen, payload_len)?;
        let mut payload = Vec::new();
        let payload_capacity = usize::try_from(payload_len)
            .map_err(|_| Error::LengthOverflow { value: payload_len })?;
        payload
            .try_reserve_exact(payload_capacity)
            .map_err(|_| Error::AllocationFailed {
                resource: "checkpoint payload",
                requested: payload_len,
            })?;
        payload.extend_from_slice(INDEX_CHECKPOINT_MAGIC);
        payload.extend_from_slice(&INDEX_CHECKPOINT_VERSION.to_le_bytes());
        payload.extend_from_slice(&covered_offset.to_le_bytes());
        payload.extend_from_slice(&entry_count.to_le_bytes());
        for entry in self.index.iter() {
            let entry = entry?;
            push_index_entry_bytes(&mut payload, &entry, entry.committed);
        }
        self.write_record(INDEX_BLOCK_ID, 1, RECORD_FLAG_INTERNAL, &payload)
    }

    /// Appends the segment record that closes this commit point.
    ///
    /// It must be the last record the commit point writes. Open finds the
    /// chain by reading the last record footer in the file, so any record
    /// appended after this one hides it — which costs the next open a full
    /// scan, never correctness.
    fn write_segment_record(&mut self) -> Result<()> {
        let start = self.segment_cursor.next_position;
        debug_assert!(start <= self.index.len());
        let covered_start = match self.segment_cursor.covered_start {
            Some(offset) => offset,
            None => append_log_start_for_file(self)?,
        };
        let preceding_records =
            u64::try_from(start).map_err(|_| Error::ResourceArithmeticOverflow {
                resource: "segment entry count",
            })?;
        // The record lands at the current end of file, and the trailer has to
        // name that offset before the header that would state it exists. The
        // append core budgets the same value from the same source and refuses
        // to write anywhere else, so the two cannot disagree.
        let record_offset = self.file.metadata()?.len();
        let payload = encode_segment_payload(
            self.spec,
            self.index.iter().skip(start),
            covered_start,
            preceding_records,
            record_offset,
        )?;
        self.check_write()?;
        let info = self.ensure_write()?.write_record_with_prev_key(
            SEGMENT_BLOCK_ID,
            SEGMENT_VERSION,
            RECORD_FLAG_INTERNAL,
            0,
            &payload,
            None,
        )?;
        debug_assert_eq!(info.record_offset, record_offset);
        Ok(())
    }

    /// Whether this commit point should close a segment.
    ///
    /// Three conditions, and the third is the one that matters: a segment is
    /// only written once everything it would cover is committed. Under a
    /// transaction-marker policy that means the commit marker is already down.
    /// A segment that covered uncommitted records would outlive them — the next
    /// writer open truncates them — and would then describe a file that no
    /// longer exists.
    fn needs_index_segment(&self) -> bool {
        // The digest, when both options are on, is appended *after* the segment
        // and is itself a resident record — so it advances `index.len()` past
        // the cursor and would make the next idle flush think a commit point
        // was left uncovered. It would then write a segment, which makes the
        // digest stale, which writes another digest, and the file grows forever
        // on a handle nothing is appending to. Only a trailing digest can be in
        // this position, so subtracting it is the whole correction.
        let trailing_digest =
            usize::from(self.last_resident_block_id == Some(OPEN_DIGEST_BLOCK_ID));
        self.spec.index_policy.segment_on_flush
            && self.segment_cursor.next_position < self.index.len() - trailing_digest
            && !(self.spec.commit_policy.is_transaction_marker()
                && self.has_uncommitted_since_last_commit())
    }

    /// Writes the segment record if one is due, and reports nothing if it
    /// could not be written.
    ///
    /// INVARIANT 3. Every caller runs this *after* the record its operation is
    /// accountable for is in the file, and for a commit point that record is
    /// the commit marker. The segment is derived from records that are already
    /// durable, so its failure cannot make the operation not have happened; the
    /// next open answers a missing or torn segment with the full scan. Turning
    /// it into an error here would tell a caller to re-run a transaction that
    /// is already committed.
    ///
    /// A failed append rolls itself back, and a failed *rollback* poisons the
    /// writer, so a failure this swallows is still visible: the next operation
    /// on this handle refuses.
    fn write_index_segment_if_needed(&mut self) {
        if self.mode != OpenMode::ReadWrite || !self.needs_index_segment() {
            return;
        }
        let _ = self.write_segment_record();
    }

    /// Appends whatever this commit point owes the *next open*, in the order
    /// the next open looks for it.
    ///
    /// Both are found from the end of the file, so both are last and their
    /// order is the reverse of the order they are read: the digest goes after
    /// the segment because the digest is the one probed at `file_len`. A
    /// segment appended behind it would hide it, which is the same reason both
    /// come after the commit marker.
    ///
    /// INVARIANT 3, inherited from `write_index_segment_if_needed`: every
    /// caller runs this after the record its operation is accountable for is in
    /// the file, and neither of these can make that record not have happened.
    /// A missing or torn one is answered by the next open with the full scan.
    fn close_commit_point(&mut self) {
        self.write_index_segment_if_needed();
        self.write_open_digest_if_needed();
        // Last, and deliberately after both, so the slot's tails include the
        // records this commit point itself appended.
        //
        // Not for the reader's sake: the slot names a commit *offset*, not a
        // file length, so a reader corroborating it walks forward from the same
        // marker either way and still lands on the end of the file — that is
        // what the segment arm of the walk is for. What the order buys is the
        // slot's own `SEGMENT` entry. Written first, it would name the previous
        // commit point's segment, and corroboration cannot catch that: a stale
        // segment offset still frames as a segment record. It is only wrong as
        // a chain link, which is the same silent breakage a stale table causes
        // anywhere else.
        // `the_slot_names_the_segment_from_its_own_commit_point` in
        // `header_tails_segment_combo.rs` is the assertion that holds this.
        self.write_header_tails_if_needed();
    }

    /// Rewrites the header tail slot for the commit point just closed.
    ///
    /// Failure is swallowed for the same reason the segment's and the digest's
    /// are: the commit marker is already in the file, so the transaction has
    /// happened and reporting an error here would entitle the caller to re-run
    /// it. A slot that was not written is a slot a later open does not adopt —
    /// it names an older commit marker, the forward walk does not reach the end
    /// of the file, and the open falls back to the scan. Slow, never wrong.
    /// Writes the liveness block's flags in place.
    ///
    /// Two callers and two values: a writer open sets `DIRTY`, and a clean
    /// release clears it. Everything between is unchanged, which is the point —
    /// this is not a heartbeat, it is a bracket.
    fn write_liveness_flags(&mut self, flags: u16) -> Result<()> {
        if self.spec.liveness_policy != LivenessPolicy::FooterFlags {
            return Ok(());
        }
        let header_len = append_log_start_for_file(self)?;
        let Some(extent) =
            mutable_header_block_extent(header_len, &self.header_extensions, LIVENESS_MAGIC)?
        else {
            return Ok(());
        };
        let block = encode_liveness_block(flags);
        // The payload only: the framing this seeks past is the magic and the
        // declared length, which must not move.
        self.file
            .overwrite_header_region(extent.payload_offset, &block[8..])?;
        // Kept in step so a later read of this handle's own cached region does
        // not disagree with the file it just wrote.
        let start = extent.payload_in_extensions;
        if let Some(window) = self
            .header_extensions
            .get_mut(start..start + LIVENESS_PAYLOAD_LEN)
        {
            window.copy_from_slice(&block[8..]);
        }
        Ok(())
    }

    /// Takes the object: records whether the *previous* writer released it
    /// cleanly, then marks it held by this one.
    ///
    /// Order matters and is the whole content of the mechanism — the read has
    /// to happen before the write, or every open reports itself as the crash it
    /// is looking for. Called only from a read-write open, because the question
    /// "was this abandoned" is only answerable by somebody who could take the
    /// object: a reader that finds the bit set cannot tell an abandoned file
    /// from one a healthy writer is appending to right now.
    fn mark_writer_open(&mut self) -> Result<()> {
        if self.spec.liveness_policy != LivenessPolicy::FooterFlags {
            return Ok(());
        }
        let header_len = append_log_start_for_file(self)?;
        self.opened_after_crash = decode_liveness_flags(header_len, &self.header_extensions)?
            .is_some_and(|flags| flags & LIVENESS_FLAG_DIRTY != 0);
        self.write_liveness_flags(LIVENESS_FLAG_DIRTY)
    }

    /// Marks a crashed writer's uncommitted tail dead, then commits it.
    ///
    /// Called once, at the open that discovers the crash, and only under
    /// `RecoveryPolicy::MarkTail`. `from` is the end of the committed prefix —
    /// the point `TruncateTail` would have cut at.
    ///
    /// **The commit marker at the end is the load-bearing part.** Marking alone
    /// would leave the file ending past its last marker, and the next marker
    /// written would make `committed_prefix_len` treat this whole tail as
    /// committed — records the original writer never committed, becoming
    /// visible retroactively. Committing them *here*, flagged dead, is the
    /// honest statement: they arrived, they were never committed by their
    /// writer, they are kept, and a defragmenting rewrite may drop them.
    ///
    /// Costs two framing passes over the tail, four bytes per user record and
    /// one appended record. No prefix rescans or record-count-sized target list.
    fn recover_marked_tail(&mut self, from: u64) -> Result<usize> {
        // Walked directly rather than through `scan_records_range_at_len`, and that is
        // not a shortcut. Under a marker policy the scan applies
        // `committed_prefix_len` to whatever it framed and **clears the list**
        // when no marker is in range — which is exactly this range, by
        // definition. That behaviour is right for `follow`, whose question is
        // "what is committed"; here the question is the opposite one.
        let end = self.snapshot.len();
        let mut offset = from;
        let mut marked = 0usize;
        let mut framed_end = from;
        let mut highest: Option<u64> = None;
        while offset < end {
            let Ok(entry) = fault_record_entry(&self.snapshot, self.spec, offset, false) else {
                // A half-written record is the expected find in a crashed
                // writer's tail, not a surprise. Everything before it framed and
                // is kept; this and anything after it never became a record and
                // is cut below.
                break;
            };
            let Ok(next) = entry.checked_physical_end() else {
                break;
            };
            if next > end || next <= offset {
                break;
            }
            // The kept tail's sequences are *higher* than anything the handle
            // knows about: its high-water mark came from the committed prefix,
            // which the scan truncated at the marker. Without this the marker
            // appended below reuses a sequence a kept record already holds, and
            // the next open refuses the file with "duplicate native record
            // sequence" — measured, before this line existed.
            highest = highest.max(Some(entry.sequence));
            framed_end = next;
            offset = next;
        }
        if let Some(highest) = highest {
            let next = highest
                .checked_add(1)
                .map_or(SequenceState::Exhausted, SequenceState::Available);
            if let (SequenceState::Available(now), SequenceState::Available(want)) =
                (self.sequence_state, next)
                && want > now
            {
                self.sequence_state = next;
            } else if matches!(next, SequenceState::Exhausted) {
                self.sequence_state = next;
            }
        }
        // Cut whatever did not frame. Leaving it would put unframeable bytes
        // *before* the marker appended below, which every later scan would walk
        // into — worse than the truncation this policy exists to avoid, because
        // it would take the framed records with it.
        if framed_end < end {
            self.file.set_len(framed_end)?;
            self.snapshot = self.snapshot.with_len(framed_end)?;
            let snapshot = self.snapshot.clone();
            self.index.rebind(snapshot);
        }
        // The first walk established this exact contiguous extent. Reuse its
        // boundary witness in a second streaming pass, without an input-sized
        // target vector or one prefix scan per marked record.
        offset = from;
        while offset < framed_end {
            let entry =
                fault_record_entry_prefixed::<128>(&self.snapshot, self.spec, offset, false)?;
            let next = entry.checked_physical_end()?;
            if next <= offset || next > framed_end {
                return Err(Error::CorruptTail { offset });
            }
            validate_record_entry(&self.spec, &entry)?;
            if entry.block_id < RESERVED_BLOCK_ID_START {
                self.write_framed_record_flags(&entry, RECORD_MUTABLE_FLAG_DEAD)?;
                marked += 1;
            }
            offset = next;
        }
        // `write_commit_marker` directly, not `commit()`. `commit()` reuses the
        // existing marker when nothing has been appended since the last one —
        // and nothing has been, because marking rewrites footers rather than
        // appending. That short-circuit is right for an ordinary commit and
        // exactly wrong here: the file ends past its last marker precisely
        // because this handle appended nothing, and leaving it that way is the
        // retroactive-commit hazard the marker exists to close.
        //
        // Unconditional, including when zero records were marked: an empty tail
        // that framed nothing still moved the end past the marker.
        self.write_commit_marker()?;
        self.close_commit_point();
        Ok(marked)
    }

    /// Whether the writer that held this file before this handle died without
    /// releasing it.
    ///
    /// The durable half of a crash verdict, and the half varlit could not answer
    /// before:
    /// the other signal — "does the file end exactly at a commit point" — is
    /// positional, describes only a suffix, and is truncated away by this very
    /// open before anyone can ask.
    ///
    /// `false` for a read-only handle by construction: answering needs the
    /// object lock this handle does not hold, and a set bit on a file a healthy
    /// writer is appending to is not a crash.
    pub const fn opened_after_crash(&self) -> bool {
        self.opened_after_crash
    }

    /// Marks a clean release, and makes it durable before returning.
    ///
    /// The sync matters here and nowhere else in this pair: a cleared bit that
    /// never reaches the platter reads as a crash, which costs a recovery pass
    /// that had nothing to do. The *set* bit needs no such care, because the
    /// direction it errs in is the safe one.
    fn mark_writer_closed(&mut self) -> Result<()> {
        if self.spec.liveness_policy != LivenessPolicy::FooterFlags {
            return Ok(());
        }
        self.write_liveness_flags(0)?;
        self.file.sync_data()?;
        Ok(())
    }

    /// Where the `VBTT` region sits and the cold bytes that retire it, or
    /// `None` for a format that declares no region.
    ///
    /// # Why an in-place replacement has to retire it
    ///
    /// The region stores no high-water mark. `corroborate_header_tails`
    /// *derives* one — the commit marker the slot names, then the segment and
    /// digest that may follow it — and that derivation is sound only because a
    /// record's sequence rises with its offset, which holds for an append log.
    ///
    /// An in-place replacement is the one operation that breaks it: it takes a
    /// *fresh* sequence and writes it at an offset **before** the marker, so
    /// the file's true maximum is above every record the derivation looks at.
    /// A lazy open then seeds its writer with a mark that is already used, and
    /// the next append duplicates a sequence — measured on a `header_tails`
    /// file of 64 records, `replace_fixed` took sequence 65 while the marker
    /// still said 64, and the following scan refused the file with
    /// `InvalidCanonicalEncoding("duplicate native record sequence")`. The file
    /// stops opening, so this is data loss rather than a slow open.
    ///
    /// The offsets in the table stay perfectly valid — an in-place replacement
    /// moves no record, which is exactly why this path was allowed to carry the
    /// table forward where [`header_extensions_for_replacement`] resets it. But
    /// the region answers three facts as a package, and one of them has gone
    /// wrong, so it goes out of use whole.
    ///
    /// # Why this is retirement and not a refusal
    ///
    /// The digest hazard is the same shape and is refused instead
    /// (`ensure_in_place_replacement_allowed`). The difference is that a
    /// digest has no "claims nothing" state — it is a record, present and
    /// trusted or not there at all — while a cold region is a state the format
    /// already defines and every open already handles. Where an escape hatch
    /// exists, the capability survives: the replacement still happens, and the
    /// cost is that the next open scans once and the next commit rewarms the
    /// region.
    fn header_tails_invalidation(&self) -> Result<Option<(u64, Vec<u8>)>> {
        if !self.spec.index_policy.header_tails {
            return Ok(None);
        }
        let header_len = append_log_start_for_file(self)?;
        let Some(extent) =
            mutable_header_block_extent(header_len, &self.header_extensions, HEADER_TAILS_MAGIC)?
        else {
            return Ok(None);
        };
        let framed = encode_cold_header_tails_region(self.spec)?;
        let cold = u8::try_clone_slice(
            framed
                .get(HEADER_TAILS_BLOCK_FRAMING_LEN..)
                .ok_or(Error::InvalidCompressionHeader)?,
        )?;
        if extent.payload_len != cold.len() {
            // `write_header_tails` leaves a region of unknown geometry alone,
            // and for a *write* that is right: it cannot encode a slot it does
            // not understand. Retirement is the opposite case — leaving it
            // alone is precisely the outcome that must not happen, because the
            // stale table would go on answering. Unreachable in practice: open
            // refuses a file whose mutable block is a different length than
            // this build would write (`validate_file_header_extensions`), so
            // reaching here means the header changed under an open handle.
            return Err(Error::InvalidCompressionHeader);
        }
        Ok(Some((extent.payload_offset, cold)))
    }

    /// Retires the region in the live file, for the path that mutates bytes
    /// rather than publishing a new generation.
    ///
    /// Ordered before the record write by its caller, so a crash between the
    /// two leaves a file whose lazy route is already out of use. The reverse
    /// order would leave the window where the table outlives the invariant it
    /// was derived under, which is the whole defect.
    ///
    /// The cached region follows the file for the reason
    /// [`Self::write_header_tails`] states: it is what the next commit reads
    /// its generation from, so a cache left warm over a cold file would write
    /// generation `N + 1` while a reader still prefers the warm slot claiming
    /// `N`.
    fn retire_header_tails_in_place(&mut self) -> Result<()> {
        let Some((offset, cold)) = self.header_tails_invalidation()? else {
            return Ok(());
        };
        self.file.overwrite_header_region(offset, &cold)?;
        self.file.sync_data()?;
        self.header_extensions =
            header_extensions_for_replacement(self.spec, &self.header_extensions)?;
        Ok(())
    }

    /// How many bytes the editable header region holds in total.
    ///
    /// The declared capacity, which never changes for the life of the file:
    /// it is folded into the schema hash, so a file written under one capacity
    /// is not opened under another. Zero when the format declares no region.
    pub fn header_slots_capacity(&self) -> usize {
        self.spec.header_slots.capacity as usize
    }

    /// How many of those bytes the blocks currently written there occupy,
    /// framing included.
    pub fn header_slots_used(&self) -> Result<usize> {
        match self.header_slots_view()? {
            Some((view, _)) => Ok(view.used),
            None => Ok(0),
        }
    }

    /// How many bytes remain. A write needs its payload plus twelve bytes of
    /// entry framing to fit in this, unless it replaces a block already there.
    pub fn header_slots_free_bytes(&self) -> Result<usize> {
        Ok(self
            .header_slots_capacity()
            .saturating_sub(self.header_slots_used()?))
    }

    /// Whether the region has been sealed and accepts no further writes.
    ///
    /// Always `false` under [`HeaderSlotIntegrity::None`] and
    /// [`HeaderSlotIntegrity::Rolling`], which have no seal.
    pub fn header_slots_sealed(&self) -> Result<bool> {
        match self.header_slots_view()? {
            Some((view, _)) => Ok(view.is_sealed()),
            None => Ok(false),
        }
    }

    /// Reads a header-declared block out of the editable region.
    ///
    /// `Ok(None)` means no block with this id has been written — which is what
    /// a freshly created file answers for every declared id. Takes `&self` and
    /// performs no I/O: the region is part of the header this handle already
    /// holds, so this is a decode of bytes in memory.
    pub fn read_header_block<T: VarlitBlock>(&self) -> Result<Option<T>> {
        let Some((view, _)) = self.header_slots_view()? else {
            return Ok(None);
        };
        if !self.spec.header_slots.permits(T::ID) {
            return Err(Error::InvalidFormatSpec(
                "block is not declared in header_slots",
            ));
        }
        let mut found: Option<(u16, &[u8])> = None;
        walk_header_slot_entries(
            &self.spec,
            view.entries,
            view.used,
            |id, version, payload| {
                if id == T::ID {
                    found = Some((version, payload));
                }
                Ok(())
            },
        )?;
        let Some((version, payload)) = found else {
            return Ok(None);
        };
        if version != T::VERSION {
            return Err(Error::BlockVersionMismatch {
                block_id: T::ID,
                expected: T::VERSION,
                actual: version,
            });
        }
        MaterializationBudget::new(self.spec)
            .decode::<T>(payload, T::ENDIAN.unwrap_or(self.spec.endian))
            .map(Some)
    }

    /// Writes a header-declared block into the editable region, replacing any
    /// earlier value for the same block id.
    ///
    /// Replacement rather than append is what lets a fixed region take an
    /// unbounded number of edits: writing the same block a thousand times
    /// costs what writing it once costs. Two different blocks must both fit,
    /// and a write that would not is refused with
    /// [`Error::LimitExceeded`] *before* any byte is written — the region is
    /// never left half-updated by a rejected write.
    ///
    /// The region is rewritten in place at a fixed offset and length, so this
    /// moves nothing: the append log starts where it started, and every record
    /// offset already handed out stays valid.
    pub fn write_header_block<T: VarlitBlock>(&mut self, block: &T) -> Result<()> {
        let payload = encode_logical_payload_limited(
            self.spec,
            block,
            T::ENDIAN.unwrap_or(self.spec.endian),
        )?;
        self.write_header_slot_bytes(T::ID, T::VERSION, Some(&payload))
    }

    /// Removes a header-declared block from the editable region, freeing its
    /// bytes for another.
    ///
    /// `Ok(())` whether or not the block was there; the post-condition is that
    /// it is not.
    pub fn remove_header_block<T: VarlitBlock>(&mut self) -> Result<()> {
        self.write_header_slot_bytes(T::ID, T::VERSION, None)
    }

    /// Fixes the region's checksum and refuses every later write.
    ///
    /// This is the "compute and freeze" point of
    /// [`HeaderSlotIntegrity::Sealed`]: until it is called the region is
    /// editable and its checksum is advisory; after it, reads verify the
    /// checksum and writes fail with [`Error::InvalidFormatSpec`]. Sealing is
    /// one-way — nothing unseals a region, because a caller who could would
    /// have gained nothing over declaring [`HeaderSlotIntegrity::Rolling`].
    ///
    /// Refused on a format declaring any other integrity: `None` has no
    /// checksum to freeze and `Rolling` recomputes on every write, so a seal
    /// would mean something different in each and silently do nothing in one.
    pub fn seal_header_slots(&mut self) -> Result<()> {
        if self.spec.header_slots.integrity != HeaderSlotIntegrity::Sealed {
            return Err(Error::InvalidFormatSpec(
                "header_slots integrity is not `sealed`",
            ));
        }
        self.check_write()?;
        let Some((view, extent)) = self.header_slots_view()? else {
            return Err(Error::InvalidFormatSpec("format declares no header_slots"));
        };
        if view.is_sealed() {
            return Ok(());
        }
        walk_header_slot_entries(&self.spec, view.entries, view.used, |_, _, _| Ok(()))?;
        let used = view.used;
        let payload = encode_header_slots_payload(self.spec, used, view.entries, true)?;
        self.ensure_write()?
            .commit_header_slots_payload(extent, &payload)
    }

    /// The region's decoded view plus where it lives, or `None` when the
    /// format declares none.
    ///
    /// Verification happens here rather than at each entry, so every read path
    /// gets it: `Rolling` always checks, `Sealed` checks once sealed, `None`
    /// never does.
    fn header_slots_view(&self) -> Result<Option<(HeaderSlotsView<'_>, MutableHeaderExtent)>> {
        if !self.spec.header_slots.is_declared() {
            return Ok(None);
        }
        let header_len = append_log_start_for_file(self)?;
        let Some(extent) =
            mutable_header_block_extent(header_len, &self.header_extensions, HEADER_SLOTS_MAGIC)?
        else {
            return Ok(None);
        };
        let payload = self
            .header_extensions
            .get(extent.payload_in_extensions..extent.payload_in_extensions + extent.payload_len)
            .ok_or(Error::InvalidCompressionHeader)?;
        let view = decode_header_slots(self.spec, payload)?;
        let verify = match self.spec.header_slots.integrity {
            HeaderSlotIntegrity::None => false,
            HeaderSlotIntegrity::Rolling => true,
            HeaderSlotIntegrity::Sealed => view.is_sealed(),
        };
        if verify && view.checksum != view.expected_checksum(self.header_slots_capacity()) {
            return Err(Error::ChecksumMismatch {
                offset: extent.payload_offset,
            });
        }
        Ok(Some((view, extent)))
    }

    /// Rebuilds the entry region with `block_id` set to `payload` — or removed
    /// when it is `None` — and writes it back.
    fn write_header_slot_bytes(
        &mut self,
        block_id: u32,
        block_version: u16,
        payload: Option<&[u8]>,
    ) -> Result<()> {
        if !self.spec.header_slots.is_declared() {
            return Err(Error::InvalidFormatSpec("format declares no header_slots"));
        }
        if !self.spec.header_slots.permits(block_id) {
            return Err(Error::InvalidFormatSpec(
                "block is not declared in header_slots",
            ));
        }
        self.check_write()?;
        let capacity = self.header_slots_capacity();
        let Some((view, extent)) = self.header_slots_view()? else {
            return Err(Error::InvalidFormatSpec("format declares no header_slots"));
        };
        if view.is_sealed() {
            return Err(Error::InvalidFormatSpec("header_slots region is sealed"));
        }
        let sealed = view.is_sealed();

        // Measure before allocating/copying; an oversized value cannot make
        // temporary storage exceed the schema-pinned region capacity.
        let mut required = payload.map_or(0u64, |p| {
            p.len() as u64 + HEADER_SLOT_ENTRY_HEADER_LEN as u64
        });
        walk_header_slot_entries(&self.spec, view.entries, view.used, |id, _, existing| {
            if id != block_id {
                required += existing.len() as u64 + HEADER_SLOT_ENTRY_HEADER_LEN as u64;
            }
            Ok(())
        })?;
        if required > capacity as u64 {
            return Err(Error::LimitExceeded {
                resource: "header slots region",
                actual: required,
                limit: capacity as u64,
            });
        }
        let mut rebuilt: Vec<u8> = Vec::new();
        rebuilt
            .try_reserve_exact(capacity)
            .map_err(|_| Error::AllocationFailed {
                resource: "header slots region",
                requested: capacity as u64,
            })?;
        walk_header_slot_entries(
            &self.spec,
            view.entries,
            view.used,
            |id, version, existing| {
                if id == block_id {
                    return Ok(());
                }
                rebuilt.extend_from_slice(&id.to_le_bytes());
                rebuilt.extend_from_slice(&version.to_le_bytes());
                rebuilt.extend_from_slice(&0u16.to_le_bytes());
                rebuilt.extend_from_slice(&(existing.len() as u32).to_le_bytes());
                rebuilt.extend_from_slice(existing);
                Ok(())
            },
        )?;
        if let Some(payload) = payload {
            let len = u32::try_from(payload.len()).map_err(|_| Error::LimitExceeded {
                resource: "header slots block",
                actual: payload.len() as u64,
                limit: capacity as u64,
            })?;
            rebuilt.extend_from_slice(&block_id.to_le_bytes());
            rebuilt.extend_from_slice(&block_version.to_le_bytes());
            rebuilt.extend_from_slice(&0u16.to_le_bytes());
            rebuilt.extend_from_slice(&len.to_le_bytes());
            rebuilt.extend_from_slice(payload);
        }
        if rebuilt.len() > capacity {
            return Err(Error::LimitExceeded {
                resource: "header slots region",
                actual: rebuilt.len() as u64,
                limit: capacity as u64,
            });
        }
        let used = rebuilt.len();
        // Zero rather than leave: the padding is covered by the checksum, and
        // stale entry bytes past `used` would also be readable in a file dump
        // long after the block that wrote them was removed.
        rebuilt.resize(capacity, 0);
        self.ensure_write()?
            .commit_header_slots(extent, used, &rebuilt, sealed)
    }

    fn write_header_tails_if_needed(&mut self) {
        if self.mode != OpenMode::ReadWrite || !self.spec.index_policy.header_tails {
            return;
        }
        let Some(commit_offset) = self.block_tails.tail(COMMIT_BLOCK_ID) else {
            return;
        };
        let _ = self.write_header_tails(commit_offset);
    }

    fn write_header_tails(&mut self, commit_offset: u64) -> Result<()> {
        // `header_tails` refuses a format declaring matrix blocks, so the
        // append log starts exactly where the header ends and this *is* the
        // header length. The refusal is what makes the equality safe to rely
        // on; if it is ever lifted, this needs the real header length.
        debug_assert!(!self.spec.has_matrix_blocks());
        let header_len = append_log_start_for_file(self)?;
        let Some(extent) =
            mutable_header_block_extent(header_len, &self.header_extensions, HEADER_TAILS_MAGIC)?
        else {
            return Ok(());
        };
        let capacity = header_tails_capacity(self.spec);
        let slot_len = header_tails_slot_len(capacity).ok_or(Error::InvalidFormatSpec(
            "header_tails region length overflows",
        ))?;
        if extent.payload_len != slot_len.saturating_mul(HEADER_TAILS_SLOTS) {
            // A region this build did not write. Leaving it alone is the only
            // safe answer: its geometry is not the one encoded here.
            return Ok(());
        }
        let generation = {
            let payload = self
                .header_extensions
                .get(
                    extent.payload_in_extensions..extent.payload_in_extensions + extent.payload_len,
                )
                .ok_or(Error::InvalidCompressionHeader)?;
            decode_header_tails_slots(payload)
                .iter()
                .map(|slot| slot.generation)
                .max()
                .unwrap_or(0)
                .saturating_add(1)
        };
        let index = (generation % HEADER_TAILS_SLOTS as u64) as usize;
        let bytes = encode_header_tails_slot(
            capacity,
            generation,
            commit_offset,
            self.block_tails.as_slice(),
        )?;
        let offset = extent
            .payload_offset
            .checked_add((index * slot_len) as u64)
            .ok_or(Error::InvalidCompressionHeader)?;
        self.file.overwrite_header_region(offset, &bytes)?;
        // The cached region is what the *next* write reads its generation from,
        // and what a `replace_*` carries forward, so it has to follow the file.
        // Leaving it at the create-time bytes would make every commit write
        // generation 1 over the top of generation 1.
        let at = extent.payload_in_extensions + index * slot_len;
        self.header_extensions
            .get_mut(at..at + slot_len)
            .ok_or(Error::InvalidCompressionHeader)?
            .copy_from_slice(&bytes);
        Ok(())
    }

    /// Whether this commit point should write an open digest.
    ///
    /// The third condition is the one that took a bug to learn on the segment
    /// path: a digest is itself a record, so "is there anything to describe"
    /// has to mean "anything other than the digest I already wrote", or every
    /// idle flush appends another one and the file grows while nothing happens.
    fn needs_open_digest(&self) -> bool {
        if !self.spec.index_policy.open_digest_on_flush {
            return false;
        }
        if self.spec.commit_policy.is_transaction_marker()
            && self.has_uncommitted_since_last_commit()
        {
            return false;
        }
        // Two terms, and neither may look at the resident index.
        //
        // The first answers for this handle's own appends, resident or not.
        // The second carries the *open* case — a handle that has appended
        // nothing yet still needs a digest when the file it opened does not end
        // with one — and it must not fire when there is no last resident record
        // at all, which is both a freshly created file and a file whose every
        // block is non-resident.
        //
        // The guard this replaces was `self.index.is_empty()`, meaning "nothing
        // has been written yet". Right intent, wrong instrument: the resident
        // index is empty forever when every block is declared non-resident, so
        // such a file never got a first digest — and a non-resident block
        // reaches its records through the chain whose head the digest carries.
        // The option was inert for exactly the file it exists to serve.
        self.appended_since_digest
            || matches!(self.last_resident_block_id, Some(id) if id != OPEN_DIGEST_BLOCK_ID)
    }

    fn write_open_digest_if_needed(&mut self) {
        if self.mode != OpenMode::ReadWrite || !self.needs_open_digest() {
            return;
        }
        let _ = self.write_open_digest_record();
    }

    fn write_open_digest_record(&mut self) -> Result<()> {
        let record_offset = self.file.metadata()?.len();
        // The high-water mark as it will stand *once this record is down*: the
        // digest takes the next sequence itself, so reporting the state before
        // it would send the next writer back over a number this record used.
        let sequence_high_water = match self.sequence_state {
            // `Available(next)` means `next` is the number this digest record is
            // about to take, so once it is down the mark is `next` — not
            // `next - 1`, which is the state *before* it and is what this
            // computed for as long as the comment above forbade exactly that.
            // Latent while the digest route builds read-only handles; sequence
            // reuse the day a writer is seeded from one.
            SequenceState::Available(next) => Some(next),
            // Unreachable in practice — an exhausted writer cannot append the
            // digest either, `available()` refuses first — but representable
            // now, which it was not.
            SequenceState::Exhausted => Some(u64::MAX),
        };
        // Its own tail is not in the table it writes — it cannot be, the record
        // does not exist yet. From the second digest onward the table does
        // carry a digest tail: the *previous* one, because `block_tails` is
        // maintained for every block. So a digest open answers
        // `block_tail_offset(OPEN_DIGEST_BLOCK_ID)` with the previous digest
        // where a scan answers with this one. The id is internal and nothing
        // walks from it, so the two answers are equally usable — but they are
        // not the same answer, and the claim that this table omits the digest
        // entirely was true only of the first one. Nothing walks the digest
        // chain: the digest is found at the end of the file, not by following
        // one.
        let payload = encode_digest_payload(
            self.spec,
            sequence_high_water,
            self.block_tails.as_slice(),
            record_offset,
        )?;
        self.check_write()?;
        let info = self.ensure_write()?.write_record_with_prev_key(
            OPEN_DIGEST_BLOCK_ID,
            DIGEST_VERSION,
            RECORD_FLAG_INTERNAL,
            0,
            &payload,
            None,
        )?;
        debug_assert_eq!(info.record_offset, record_offset);
        Ok(())
    }

    fn write_embedded_manifest_if_needed(&mut self) -> Result<()> {
        if self.spec.manifest_policy != ManifestPolicy::Embedded
            || self.index.contains_block(MANIFEST_BLOCK_ID)?
        {
            return Ok(());
        }
        let payload = encode_schema_manifest(self.spec)?;
        self.write_record(
            MANIFEST_BLOCK_ID,
            MANIFEST_PAYLOAD_VERSION,
            RECORD_FLAG_INTERNAL,
            &payload,
        )?;
        Ok(())
    }

    fn write_commit_marker(&mut self) -> Result<AppendInfo> {
        self.check_write()?;
        self.ensure_write()?.write_record_with_prev_key(
            COMMIT_BLOCK_ID,
            1,
            RECORD_FLAG_INTERNAL,
            0,
            COMMIT_PAYLOAD_MAGIC,
            None,
        )
    }

    fn has_uncommitted_since_last_commit(&self) -> bool {
        self.uncommitted_since_commit
    }

    /// Decides whether `flush`/`commit` should serialize a fresh full index
    /// checkpoint.
    ///
    /// This throttles only the *checkpoint* serialization; native-record
    /// durability in `flush` is untouched. Two rules apply (PERF-02):
    ///
    /// (a) *Skip when unchanged.* If nothing but commit markers has been
    ///     appended since the last checkpoint, the checkpoint would be
    ///     byte-identical, so it is suppressed.
    ///
    /// (b) *Geometric spacing.* A new full checkpoint is written only once the
    ///     live tail has grown by at least
    ///     `max(INDEX_CHECKPOINT_MIN_RECORDS, records_at_last_checkpoint / 2)`
    ///     records. Because each checkpoint serializes the whole index, spacing
    ///     the checkpoints geometrically bounds the total checkpoint bytes to
    ///     O(N) with O(log N) checkpoints, instead of the O(N^2) bytes produced
    ///     by a full checkpoint on every flush.
    ///
    /// Open/recovery does not depend on this cadence: the scan reads every
    /// native record and merely validates whatever checkpoints it encounters,
    /// so sparse checkpoints and a checkpoint-less tail both recover correctly.
    ///
    /// The decision itself is O(1) (PERF2-02): [`CheckpointCadence`] carries
    /// the eligible-tail count and the geometric threshold that the original
    /// implementation recomputed by reverse-searching the resident index on
    /// every flush, which made cumulative flush CPU O(N^2) for
    /// flush-per-record workloads.
    /// (c) *Skip when it would not fit.* A full checkpoint serializes the whole
    ///     index into one record, so past `(max_record_payload_len - 22) / 73`
    ///     entries — 919,299 on the 64 MiB default — there is no record that
    ///     can hold it. `write_index_checkpoint` answered that with
    ///     `LimitExceeded`, and because `flush` propagates, a file simply
    ///     stopped being flushable at that record count. The checkpoint is
    ///     derived: not writing one costs the next open the scan it already
    ///     falls back to, so the ceiling belongs in the decision, not in the
    ///     write.
    fn needs_index_checkpoint(&self) -> bool {
        // Rule (a): commit markers never grow the eligible tail, so an
        // unchanged checkpoint is suppressed by `eligible_since_checkpoint`
        // staying at zero. Rule (b): the threshold was derived from the last
        // checkpoint's position, whose entry count is a faithful proxy for
        // that checkpoint's byte cost.
        let new_records = self.checkpoint_cadence.eligible_since_checkpoint;
        new_records != 0
            && new_records >= self.checkpoint_cadence.next_threshold
            && self.index_checkpoint_fits()
    }
}

/// Newest-first walk of one block's footer chain.
///
/// Each step is two positional reads — the record header, then its footer — and
/// yields the entry it just framed. Nothing is retained: the walk holds one
/// offset, so a block with more records than memory is still walkable.
#[derive(Debug)]
pub struct BlockChain<'a> {
    spec: FormatSpec,
    snapshot: &'a SnapshotFile,
    block_id: u32,
    next: Option<u64>,
    visited: u64,
}

impl Iterator for BlockChain<'_> {
    type Item = Result<RecordIndexEntry>;

    fn next(&mut self) -> Option<Self::Item> {
        let offset = self.next?;
        match self.step(offset) {
            Ok(entry) => Some(Ok(entry)),
            Err(error) => {
                // A failed step ends the walk rather than repeating itself.
                self.next = None;
                Some(Err(error))
            }
        }
    }
}

impl BlockChain<'_> {
    fn step(&mut self, offset: u64) -> Result<RecordIndexEntry> {
        self.visited = self
            .visited
            .checked_add(1)
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "record count",
            })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::Records, self.visited)?;
        let entry = read_record_entry_positional(self.spec, self.snapshot, offset)?;
        if entry.block_id != self.block_id {
            return Err(Error::InvalidCanonicalEncoding(
                "block offset chain left its block",
            ));
        }
        // Strictly decreasing, so a crafted or damaged chain cannot loop: the
        // walk is bounded by the file whatever the footers claim. Defence in
        // depth rather than the first line - `decode_native_record_footer`
        // already refuses a predecessor at or past its own record, so a whole
        // file carrying one is refused at open and never reaches here. This
        // walk frames records that scan never looked at, which is why it
        // carries the check itself.
        self.next = match entry.prev_same_block_offset {
            Some(previous) if previous >= offset => {
                return Err(Error::InvalidCanonicalEncoding(
                    "block offset chain does not decrease",
                ));
            }
            previous => previous,
        };
        Ok(entry)
    }
}

/// One key's records, newest first, from [`VarlitFile::keyed_chain`].
///
/// The keyed counterpart of [`BlockChain`], and it holds what that holds: one
/// offset. Nothing is retained, so a key with more generations than memory is
/// still walkable.
///
/// It differs from `BlockChain` in one way, and that is the reason it is a
/// separate type rather than a parameter: the keyed chain legitimately runs
/// through [`TOMBSTONE_BLOCK_ID`], so there is no "left its block" refusal to
/// make. The caller filters on `block_id`. Records under [`OP_BLOCK_ID`] are
/// *not* on the chain -- `push_op` writes no keyed predecessor and moves no
/// tail.
#[derive(Debug)]
pub struct KeyedChain<'a> {
    spec: FormatSpec,
    snapshot: &'a SnapshotFile,
    next: Option<u64>,
    visited: u64,
}

impl Iterator for KeyedChain<'_> {
    type Item = Result<RecordIndexEntry>;

    fn next(&mut self) -> Option<Self::Item> {
        let offset = self.next?;
        match self.step(offset) {
            Ok(entry) => Some(Ok(entry)),
            Err(error) => {
                // A failed step ends the walk rather than repeating itself,
                // identically to `BlockChain`.
                self.next = None;
                Some(Err(error))
            }
        }
    }
}

impl KeyedChain<'_> {
    fn step(&mut self, offset: u64) -> Result<RecordIndexEntry> {
        self.visited = self
            .visited
            .checked_add(1)
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "record count",
            })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::Records, self.visited)?;
        let entry = read_record_entry_positional(self.spec, self.snapshot, offset)?;
        // Strictly decreasing, so a crafted or damaged chain cannot loop. The
        // same defence in depth `BlockChain` carries, and for the same reason:
        // this walk frames records that scan never looked at.
        self.next = match entry.prev_same_key_offset {
            Some(previous) if previous >= offset => {
                return Err(Error::InvalidCanonicalEncoding(
                    "keyed offset chain does not decrease",
                ));
            }
            previous => previous,
        };
        Ok(entry)
    }
}

/// Frames one record through the snapshot, without touching the resident index.
pub(crate) fn read_record_entry_positional(
    spec: FormatSpec,
    snapshot: &SnapshotFile,
    record_offset: u64,
) -> Result<RecordIndexEntry> {
    let mut header = [0u8; RECORD_HEADER_LEN as usize];
    snapshot.read_exact_at(record_offset, &mut header)?;
    let decoded = read_native_record_header(&mut &header[..], record_offset)?;
    let fields = decoded.fields;
    let payload_offset =
        record_offset
            .checked_add(decoded.lead_in_len)
            .ok_or(Error::CorruptTail {
                offset: record_offset,
            })?;
    spec.read_limits
        .check(ReadLimitKey::RecordPayloadLen, fields.payload_len)?;
    let payload_end = payload_offset
        .checked_add(fields.payload_len)
        .ok_or(Error::CorruptTail {
            offset: record_offset,
        })?;
    let mut entry = RecordIndexEntry {
        block_id: fields.block_id,
        block_version: fields.block_version,
        flags: fields.flags,
        sequence: fields.sequence,
        record_offset,
        payload_offset,
        payload_len: fields.payload_len,
        checksum: fields.checksum,
        uncompressed_len_hint: fields.uncompressed_len_hint,
        footer_offset: None,
        prev_same_block_offset: None,
        prev_same_key_offset: None,
        mutable_flags: 0,
        committed: true,
    };
    validate_record_entry(&spec, &entry)?;
    if spec.spec_needs_record_footer() {
        let mut footer = [0u8; RECORD_FOOTER_LEN as usize];
        snapshot.read_exact_at(payload_end, &mut footer)?;
        let decoded = decode_record_footer(spec, &footer, payload_end, record_offset)?;
        entry.footer_offset = Some(payload_end);
        entry.prev_same_block_offset = decoded.prev_same_block_offset;
        entry.prev_same_key_offset = decoded.prev_same_key_offset;
        entry.mutable_flags = decoded.mutable_flags;
    }
    entry.validate_payload_extent(snapshot.len())?;
    Ok(entry)
}

fn append_log_start_for_file(file: &VarlitFile) -> Result<u64> {
    if let Some(matrix) = &file.matrix {
        return Ok(matrix.append_log_start());
    }
    // From the file's own region, not from `spec`: a block this build does not
    // know is skipped at open rather than refused, so a file can carry a longer
    // header than this build writes. Deriving the boundary from `spec` would
    // put the append log inside that block's bytes.
    let extension_len = u64::try_from(file.header_extensions.len()).map_err(|_| {
        Error::ResourceArithmeticOverflow {
            resource: "file-header length",
        }
    })?;
    Ok(native_file_header_len(file.spec, extension_len))
}

/// Checks a live file against the record directory that indexes it.
///
/// **What this can still prove, and what it no longer can.** The directory
/// holds each record's offset and nothing else; the entry it produces is
/// rebuilt from the record's own header. So `physical_record_headers_match`
/// below compares a header against itself here and cannot fail — the header
/// fields of an indexed record are no longer a fact the index could disagree
/// with the file about, because the index does not store them.
///
/// What the walk still establishes is everything that was ever load-bearing on
/// this path: the directory's offsets are contiguous from `append_start`, they
/// cover the file exactly (`offset != file_len` is the tail refusal), every
/// record's stored checksum verifies against its bytes, every checkpoint's
/// declared ceilings hold, and no sequence is reused. A file replaced or
/// truncated under the writer fails the first or the second of those.
fn validate_generation_index(
    spec: FormatSpec,
    file: &mut File,
    append_start: u64,
    index: &ResidentIndex,
) -> Result<()> {
    validate_generation_file_inner(spec, file, append_start, index, false)
}

/// The same walk against entries the caller is still holding — the rewrite
/// paths, which validate the generation they have just built before it is
/// published and so have no directory for it yet.
fn validate_generation_file(
    spec: FormatSpec,
    file: &mut File,
    append_start: u64,
    expected_entries: &dyn RecordDirectory,
) -> Result<()> {
    validate_generation_file_inner(spec, file, append_start, expected_entries, false)
}

fn validate_replacement_generation_file(
    spec: FormatSpec,
    file: &mut File,
    append_start: u64,
    expected_entries: &dyn RecordDirectory,
) -> Result<()> {
    validate_generation_file_inner(spec, file, append_start, expected_entries, true)
}

/// Strict replacement validation compares checkpoint rows incrementally with
/// the already validated prefix. Other callers screen only the fixed header.
fn validate_generation_file_inner(
    spec: FormatSpec,
    file: &mut File,
    append_start: u64,
    expected_entries: &dyn RecordDirectory,
    strict_prefix: bool,
) -> Result<()> {
    let file_len = check_open_file_len(spec, file)?;
    let header_len = read_file_header(spec, file)?;
    if append_start < header_len || append_start > file_len {
        return Err(Error::InvalidCanonicalEncoding(
            "invalid native append-log boundary",
        ));
    }
    let mut accounting = ScanAccounting::default();
    accounting.advance(spec, append_start)?;
    let mut offset = append_start;
    // Increasing runs with disjoint ranges prove uniqueness without scratch.
    // Overlapping ranges take the bounded external-sort fallback.
    let mut sequences = native_rewrite::SequenceRanges::default();
    let mut walked = 0usize;
    for (position, expected) in directory_records(expected_entries).enumerate() {
        let expected = expected?;
        let expected = &expected;
        walked += 1;
        if expected.record_offset != offset {
            return Err(Error::InvalidCanonicalEncoding(
                "native record offsets are not contiguous",
            ));
        }
        let actual = match read_record_entry_at(
            spec,
            file,
            file_len,
            offset,
            // Generation validation proves a just-published file matches what
            // was indexed; verifying is the point of this walk, so it does not
            // consult the open-time policy.
            ScanChecks {
                partial_boundary: None,
                checksum_boundary: None,
                verify_checksums: true,
            },
            &mut accounting,
        )? {
            RecordRead::Entry(entry) => entry,
            RecordRead::RecoverableTail(tail) => {
                return Err(Error::CorruptTail {
                    offset: tail.offset,
                });
            }
        };
        if !physical_record_headers_match(expected, &actual) {
            return Err(Error::InvalidCanonicalEncoding(
                "native record changed after it was indexed",
            ));
        }
        if actual.block_id == INDEX_BLOCK_ID
            && (1..=INDEX_CHECKPOINT_VERSION).contains(&actual.block_version)
        {
            if strict_prefix {
                native_rewrite::validate_checkpoint(
                    spec,
                    file,
                    &actual,
                    expected_entries,
                    position,
                    append_start,
                )?;
            } else {
                let prefix = actual.read_payload_prefix_file_with_len(
                    file,
                    file_len,
                    INDEX_CHECKPOINT_PREFIX_LEN,
                )?;
                check_index_checkpoint_limits_for(spec, &prefix, false)?;
            }
        }
        sequences.note(actual.sequence);
        offset = actual.checked_physical_end()?;
    }
    debug_assert_eq!(
        walked,
        expected_entries.record_count(),
        "declared entry count did not hold"
    );
    if offset != file_len {
        return Err(Error::CorruptTail { offset });
    }
    if sequences.proves_unique() {
        return Ok(());
    }
    native_rewrite::validate_sequences(expected_entries, resident_index::buffer_bytes(spec) / 2)
}

fn physical_record_headers_match(left: &RecordIndexEntry, right: &RecordIndexEntry) -> bool {
    left.block_id == right.block_id
        && left.block_version == right.block_version
        && left.flags == right.flags
        && left.sequence == right.sequence
        && left.record_offset == right.record_offset
        && left.payload_offset == right.payload_offset
        && left.payload_len == right.payload_len
        && left.checksum == right.checksum
        && left.uncompressed_len_hint == right.uncompressed_len_hint
        && left.footer_offset == right.footer_offset
        && left.prev_same_block_offset == right.prev_same_block_offset
        && left.prev_same_key_offset == right.prev_same_key_offset
}

#[derive(Clone, Copy)]
enum RewritePayload<'a> {
    Bytes(&'a [u8]),
    Snapshot { offset: u64, len: u64 },
    Index(IndexPayload<'a>),
}

fn rewrite_record_streaming(
    spec: FormatSpec,
    snapshot: &SnapshotFile,
    output: &mut File,
    mut entry: RecordIndexEntry,
    payload: RewritePayload<'_>,
) -> Result<RecordIndexEntry> {
    let payload_len = match payload {
        RewritePayload::Bytes(bytes) => {
            u64::try_from(bytes.len()).map_err(|_| Error::LengthOverflow { value: u64::MAX })?
        }
        RewritePayload::Snapshot { len, .. } => len,
        RewritePayload::Index(index) => index.len(spec)?,
    };
    spec.read_limits
        .check(ReadLimitKey::RecordPayloadLen, payload_len)?;
    let logical_len = match payload {
        RewritePayload::Bytes(bytes) => record_logical_len_from_parts(
            spec,
            entry.block_id,
            entry.flags,
            entry.uncompressed_len_hint,
            bytes,
        )?,
        RewritePayload::Snapshot { .. } => entry.logical_payload_len_snapshot(spec, snapshot)?,
        RewritePayload::Index(_) => payload_len,
    };
    spec.read_limits
        .check(ReadLimitKey::LogicalPayloadLen, logical_len)?;

    let record_offset = output.stream_position()?;
    let payload_offset =
        record_offset
            .checked_add(RECORD_HEADER_LEN)
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "rewrite file length",
            })?;
    let record_end =
        payload_offset
            .checked_add(payload_len)
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "rewrite file length",
            })?;
    let header = RecordHeaderFields {
        block_id: entry.block_id,
        block_version: entry.block_version,
        flags: entry.flags,
        sequence: entry.sequence,
        payload_len,
        checksum: 0,
        uncompressed_len_hint: entry.uncompressed_len_hint,
    };
    write_record_header(output, spec, record_offset, header)?;
    match payload {
        RewritePayload::Bytes(bytes) => output.write_all(bytes)?,
        RewritePayload::Index(index) => index.write(output)?,
        RewritePayload::Snapshot { offset, len } => {
            snapshot.copy_range_to(offset, len, output)?;
        }
    }

    entry.record_offset = record_offset;
    entry.payload_offset = payload_offset;
    entry.payload_len = payload_len;
    entry.footer_offset = None;
    entry.prev_same_block_offset = None;
    entry.prev_same_key_offset = None;
    entry.checksum = match spec.integrity_policy {
        IntegrityPolicy::None => 0,
        IntegrityPolicy::Crc32 | IntegrityPolicy::Crc32WithHeader => {
            checksum_record_file(spec, output, &entry, &[])?
        }
    };
    output.seek(SeekFrom::Start(record_offset))?;
    write_record_header(
        output,
        spec,
        record_offset,
        RecordHeaderFields {
            checksum: entry.checksum,
            ..header
        },
    )?;
    output.seek(SeekFrom::Start(record_end))?;
    Ok(entry)
}

/// Which backward chain a link belongs to.
#[derive(Clone, Copy, PartialEq, Eq)]
enum Chain {
    Block,
    Key,
}

/// How a whole-file rewrite maps an old record offset to a new one.
///
/// The two rewrites in this crate move records for different reasons, and the
/// arithmetic that is correct for one is silently wrong for the other.
///
/// `replace_block` resizes **exactly one** record and removes none, so every
/// record after the target moves by the same amount and every record before it
/// does not move at all. That is `Uniform`, and it is why
/// [`ReplacementInfo::translate_record_offset`] can be one subtraction.
///
/// A defragmenting rewrite drops records, so each survivor moves by a different
/// amount and some chain predecessors are not in the new file at all. A uniform
/// delta there points a link at a byte offset that is not where that record
/// went.
///
/// **How badly that fails was measured rather than assumed.** Substituting
/// `Uniform` into the defragmenting rewrite does not publish a corrupt file: it
/// is refused at write time with `InvalidRecordFooter { offset: 616 }`, because
/// `validate_replacement_predecessors` resolves every link against the prefix
/// already written and requires it to name an *earlier record of the same
/// block*. Two of the four defragment tests fail that way, and nothing reaches
/// the pathname. So the honest claim is that this type is required for the
/// operation to work at all, not that it is the last thing between a caller and
/// silent corruption — that guard is the predecessor check, and it is older
/// than this.
///
/// `Tables` stores both chain resolutions in one sorted, spillable row per
/// source record. Dropped records inherit their predecessor in each chain;
/// zero means that no predecessor in that chain survived.
enum ChainRemap<'a> {
    Uniform(ReplacementInfo),
    Tables(&'a OffsetRemap),
}

impl ChainRemap<'_> {
    fn translate(&self, chain: Chain, old: u64) -> Result<Option<u64>> {
        match self {
            Self::Uniform(info) => info.translate_record_offset(old).map(Some),
            Self::Tables(remap) => remap.get(old, chain),
        }
    }
}

fn rewrite_replacement_record_streaming(
    spec: FormatSpec,
    snapshot: &SnapshotFile,
    output: &mut File,
    mut entry: RecordIndexEntry,
    payload: RewritePayload<'_>,
    replacement: ChainRemap<'_>,
    rewritten_prefix: &RewriteDirectory,
) -> Result<RecordIndexEntry> {
    let source_entry = matches!(payload, RewritePayload::Snapshot { .. }).then(|| entry.clone());
    let payload_len = match payload {
        RewritePayload::Bytes(bytes) => {
            u64::try_from(bytes.len()).map_err(|_| Error::LengthOverflow { value: u64::MAX })?
        }
        RewritePayload::Snapshot { len, .. } => len,
        RewritePayload::Index(index) => index.len(spec)?,
    };
    spec.read_limits
        .check(ReadLimitKey::RecordPayloadLen, payload_len)?;
    let logical_len = match payload {
        RewritePayload::Bytes(bytes) => record_logical_len_from_parts(
            spec,
            entry.block_id,
            entry.flags,
            entry.uncompressed_len_hint,
            bytes,
        )?,
        RewritePayload::Snapshot { .. } => entry.logical_payload_len_snapshot(spec, snapshot)?,
        RewritePayload::Index(_) => payload_len,
    };
    spec.read_limits
        .check(ReadLimitKey::LogicalPayloadLen, logical_len)?;

    let record_offset = output.stream_position()?;
    let payload_offset =
        record_offset
            .checked_add(RECORD_HEADER_LEN)
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "replacement file length",
            })?;
    let payload_end =
        payload_offset
            .checked_add(payload_len)
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "replacement file length",
            })?;
    let record_end = payload_end.checked_add(record_footer_len(spec)).ok_or(
        Error::ResourceArithmeticOverflow {
            resource: "replacement file length",
        },
    )?;

    entry.record_offset = record_offset;
    entry.payload_offset = payload_offset;
    entry.payload_len = payload_len;
    entry.footer_offset = spec.spec_needs_record_footer().then_some(payload_end);
    entry.prev_same_block_offset = entry
        .prev_same_block_offset
        .map(|offset| replacement.translate(Chain::Block, offset))
        .transpose()?
        .flatten();
    entry.prev_same_key_offset = entry
        .prev_same_key_offset
        .map(|offset| replacement.translate(Chain::Key, offset))
        .transpose()?
        .flatten();

    let header = RecordHeaderFields {
        block_id: entry.block_id,
        block_version: entry.block_version,
        flags: entry.flags,
        sequence: entry.sequence,
        payload_len,
        checksum: 0,
        uncompressed_len_hint: entry.uncompressed_len_hint,
    };
    write_record_header(output, spec, record_offset, header)?;
    let mut copied_crc = None;
    match payload {
        RewritePayload::Bytes(bytes) => output.write_all(bytes)?,
        RewritePayload::Index(index) => index.write(output)?,
        RewritePayload::Snapshot { offset, len } => {
            if spec.integrity_policy == IntegrityPolicy::None {
                snapshot.copy_range_to(offset, len, output)?;
            } else {
                copied_crc = Some(copy_verified_snapshot_record(
                    spec,
                    snapshot,
                    output,
                    source_entry.as_ref().unwrap(),
                    offset,
                    len,
                )?);
            }
        }
    }
    let encoded_footer = if spec.spec_needs_record_footer() {
        let footer = encode_record_footer(RecordFooterFields {
            prev_same_block_offset: entry.prev_same_block_offset,
            prev_same_key_offset: entry.prev_same_key_offset,
            // Carried, not reset: a republish moves a record, it does not bring
            // it back to life.
            mutable_flags: entry.mutable_flags,
        })?;
        output.write_all(&footer)?;
        Some(footer)
    } else {
        None
    };
    let footer = encoded_footer.as_ref().map_or(&[][..], |bytes| &bytes[..]);
    validate_replacement_predecessors(output, &entry, rewritten_prefix)?;

    entry.checksum = match spec.integrity_policy {
        IntegrityPolicy::None => 0,
        IntegrityPolicy::Crc32 | IntegrityPolicy::Crc32WithHeader => {
            if let Some(mut hash) = copied_crc {
                hash.update(checksummed_footer(spec, footer));
                hash.finalize()
            } else {
                checksum_record_file(spec, output, &entry, footer)?
            }
        }
    };
    output.seek(SeekFrom::Start(record_offset))?;
    write_record_header(
        output,
        spec,
        record_offset,
        RecordHeaderFields {
            checksum: entry.checksum,
            ..header
        },
    )?;
    output.seek(SeekFrom::Start(record_end))?;
    Ok(entry)
}

/// Validate the copied source and checksum the replacement in one payload pass.
/// Snapshot copies keep the header fields intact. Forking the CRC state before
/// the changed footer avoids a second read or hash of the payload.
#[cfg(feature = "integrity")]
fn copy_verified_snapshot_record(
    spec: FormatSpec,
    snapshot: &SnapshotFile,
    output: &mut File,
    source: &RecordIndexEntry,
    offset: u64,
    len: u64,
) -> Result<crc32fast::Hasher> {
    if offset != source.payload_offset || len != source.payload_len {
        return Err(Error::InvalidCanonicalEncoding(
            "rewrite source payload changed",
        ));
    }
    // Snapshot copies preserve all header fields covered by the CRC. Only
    // physical offsets (not stored in the header) and footer links change.
    let mut payload = crc32fast::Hasher::new();
    if spec.integrity_policy == IntegrityPolicy::Crc32WithHeader {
        payload.update(&encode_native_record_header(
            RecordHeaderFields {
                block_id: source.block_id,
                block_version: source.block_version,
                flags: source.flags,
                sequence: source.sequence,
                payload_len: source.payload_len,
                checksum: 0,
                uncompressed_len_hint: source.uncompressed_len_hint,
            },
            source.record_offset,
            record_footer_len(spec),
        )?);
    }
    if len <= 1024 {
        copy_snapshot_payload_crc::<1024>(&mut payload, snapshot, output, offset, len)?;
    } else {
        copy_snapshot_payload_crc::<STREAM_BUFFER_LEN>(
            &mut payload,
            snapshot,
            output,
            offset,
            len,
        )?;
    }
    let checksum = |footer: &[u8]| {
        let mut hash = payload.clone();
        hash.update(checksummed_footer(spec, footer));
        hash.finalize()
    };
    let source_footer = if spec.spec_needs_record_footer() {
        Some(encode_record_footer(RecordFooterFields {
            prev_same_block_offset: source.prev_same_block_offset,
            prev_same_key_offset: source.prev_same_key_offset,
            mutable_flags: source.mutable_flags,
        })?)
    } else {
        None
    };
    let actual = checksum(source_footer.as_ref().map_or(&[][..], |bytes| &bytes[..]));
    if actual != source.checksum {
        return Err(Error::ChecksumMismatch {
            offset: source.record_offset,
        });
    }
    Ok(payload)
}

// Keeping each sized array in its own call frame avoids reserving the wide
// frame when a small record is copied. Source CRC and footer validation remain
// in the caller and still precede publication.
#[cfg(feature = "integrity")]
#[inline(never)]
fn copy_snapshot_payload_crc<const BUFFER: usize>(
    payload: &mut crc32fast::Hasher,
    snapshot: &SnapshotFile,
    output: &mut File,
    offset: u64,
    len: u64,
) -> Result<()> {
    const {
        assert!(BUFFER > 0);
    }
    let mut remaining = len;
    let mut at = offset;
    let mut buffer = [0; BUFFER];
    while remaining != 0 {
        let count = remaining.min(buffer.len() as u64) as usize;
        snapshot.read_exact_at(at, &mut buffer[..count])?;
        output.write_all(&buffer[..count])?;
        payload.update(&buffer[..count]);
        remaining -= count as u64;
        at = at
            .checked_add(count as u64)
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "rewrite payload offset",
            })?;
    }
    Ok(())
}

#[cfg(not(feature = "integrity"))]
fn copy_verified_snapshot_record(
    _spec: FormatSpec,
    _snapshot: &SnapshotFile,
    _output: &mut File,
    _source: &RecordIndexEntry,
    _offset: u64,
    _len: u64,
) -> Result<crc32fast::Hasher> {
    Err(Error::IntegrityFeatureDisabled)
}

fn validate_replacement_predecessors(
    output: &mut File,
    entry: &RecordIndexEntry,
    rewritten_prefix: &RewriteDirectory,
) -> Result<()> {
    if let Some(offset) = entry.prev_same_block_offset {
        let Some(previous) = rewritten_prefix.find_offset(offset)? else {
            return Err(Error::InvalidRecordFooter { offset });
        };
        if offset >= entry.record_offset || previous.block_id != entry.block_id {
            return Err(Error::InvalidRecordFooter { offset });
        }
    }
    if let Some(offset) = entry.prev_same_key_offset {
        let Some(previous) = rewritten_prefix.find_offset(offset)? else {
            return Err(Error::InvalidRecordFooter { offset });
        };
        if offset >= entry.record_offset
            || replacement_chain_block_id(output, &previous)?
                != replacement_chain_block_id(output, entry)?
        {
            return Err(Error::InvalidRecordFooter { offset });
        }
    }
    Ok(())
}

fn replacement_chain_block_id(file: &mut File, entry: &RecordIndexEntry) -> Result<u32> {
    if !matches!(entry.block_id, TOMBSTONE_BLOCK_ID | OP_BLOCK_ID) {
        return Ok(entry.block_id);
    }
    if entry.payload_len < 4 {
        return Err(Error::InvalidRecordFooter {
            offset: entry.record_offset,
        });
    }
    file.seek(SeekFrom::Start(entry.payload_offset))?;
    let mut block_id = [0; 4];
    file.read_exact(&mut block_id)?;
    Ok(u32::from_le_bytes(block_id))
}

/// Record counts and a hypothetical fully resident merge size.
///
/// Merge/compact now use temporary disk indexes. The count fields still size
/// logical work and bound distinct keys. The byte fields retain the historical
/// `count * size_of` model for an equivalent fully resident implementation;
/// they do **not** estimate the external implementation's RAM or scratch disk.
/// They exclude heap-owned payloads and allocator overhead.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
#[non_exhaustive]
pub struct KeyedMergeEstimate {
    /// Records across all inputs. An exact count.
    pub input_records: u64,
    /// Records that can introduce a distinct key: values of `T`, tombstones,
    /// and merge ops. An exact count.
    pub key_bearing_records: u64,
    /// Upper bound on `K-ever`, the number of distinct keys the merge state
    /// retains. Tombstoned keys count: the collector keeps their entries.
    pub max_distinct_keys: u64,
    /// Resident index bytes for the largest single input, which is opened
    /// whole while its records are applied:
    /// `records * size_of::<RecordIndexEntry>()`.
    pub largest_input_index_bytes: u64,
    /// Transient bytes the largest single input's open can allocate *on top of*
    /// its resident index, and which are live at the same time as that index:
    /// the sequence-uniqueness witness copies one `u64` per record when the
    /// file's sequences are not already ascending in offset order (PERF3-05).
    pub largest_input_open_transient_bytes: u64,
    /// Structural bytes of the merge-state map's entries at
    /// [`Self::max_distinct_keys`] keys:
    /// `max_distinct_keys * size_of::<(Key, (MergeOrder, Option<T>))>()`.
    ///
    /// This is not a bound on the map: it excludes hash-table load-factor
    /// slack, control bytes and bucket rounding, and all heap owned by
    /// individual keys and values.
    pub max_state_bytes: u64,
    /// Structural bytes of the output vector, which is reserved for the
    /// surviving entries while the merge state and its values are still alive
    /// (PERF4-04): `max_distinct_keys * size_of::<(MergeOrder, T)>()`.
    ///
    /// Like [`Self::max_state_bytes`] this counts inline storage only.
    pub max_output_values_bytes: u64,
}

impl KeyedMergeEstimate {
    /// Sum of the hypothetical fully resident implementation's structural
    /// terms. This is neither current merge memory usage nor an upper bound.
    #[must_use]
    pub fn peak_resident_structural_bytes(&self) -> u64 {
        self.max_state_bytes
            .saturating_add(self.max_output_values_bytes)
            .saturating_add(self.largest_input_index_bytes)
            .saturating_add(self.largest_input_open_transient_bytes)
    }
}

/// Counts merge inputs without decoding values. Directory buffers are bounded;
/// large inputs use temporary storage. Byte fields describe a hypothetical
/// fully resident implementation; see [`KeyedMergeEstimate`].
pub fn estimate_keyed_merge<T, P>(
    spec: FormatSpec,
    base: P,
    deltas: &[P],
) -> Result<KeyedMergeEstimate>
where
    T: VarlitMerge,
    T::Key: Eq + Hash,
    P: AsRef<Path>,
{
    let spec = spec.ordinary_read();
    spec.validate()?;
    crate::collections::ensure_registered_block::<T>(spec)?;
    let mut estimate = KeyedMergeEstimate::default();
    accumulate_keyed_merge_estimate::<T, _>(spec, base, &mut estimate)?;
    for delta in deltas {
        accumulate_keyed_merge_estimate::<T, _>(spec, delta, &mut estimate)?;
    }
    estimate.max_distinct_keys = estimate.key_bearing_records;
    let keys = usize::try_from(estimate.max_distinct_keys).unwrap_or(usize::MAX);
    estimate.max_state_bytes =
        allocation_bytes::<(T::Key, (MergeOrder, Option<T>))>(keys, "merge state")?;
    // Historical fully resident model, retained independently of execution.
    estimate.max_output_values_bytes = allocation_bytes::<(MergeOrder, T)>(keys, "merged values")?;
    Ok(estimate)
}

fn accumulate_keyed_merge_estimate<T, P>(
    spec: FormatSpec,
    path: P,
    estimate: &mut KeyedMergeEstimate,
) -> Result<()>
where
    T: VarlitMerge,
    T::Key: Eq + Hash,
    P: AsRef<Path>,
{
    let file = VarlitFile::open_readonly(spec, path)?;
    let records =
        u64::try_from(file.index.len()).map_err(|_| Error::ResourceArithmeticOverflow {
            resource: "record count",
        })?;
    let mut key_bearing = 0usize;
    for entry in file.index.iter() {
        let block_id = entry?.block_id;
        if block_id == T::ID || block_id == TOMBSTONE_BLOCK_ID || block_id == OP_BLOCK_ID {
            key_bearing += 1;
        }
    }
    let key_bearing =
        u64::try_from(key_bearing).map_err(|_| Error::ResourceArithmeticOverflow {
            resource: "record count",
        })?;
    estimate.input_records = estimate.input_records.saturating_add(records);
    estimate.key_bearing_records = estimate.key_bearing_records.saturating_add(key_bearing);
    estimate.largest_input_index_bytes = estimate
        .largest_input_index_bytes
        .max(index_bytes_for_count(file.index.len())?);
    // PERF3-05: the open that produced `file` also validates sequence
    // uniqueness, which can copy every sequence into an `8N` temporary held
    // alongside the resident index. Charging it here keeps
    // `peak_resident_structural_bytes` from ignoring a live allocation it can
    // actually see.
    estimate.largest_input_open_transient_bytes = estimate
        .largest_input_open_transient_bytes
        .max(sequence_uniqueness_transient_bytes(file.index.len())?);
    Ok(())
}

/// Merges `base` with `deltas` into `output`, keeping the last write per key.
///
/// Inputs are processed in shard, sequence and physical-ordinal order. Per-key
/// state, values and output ordering stay in bounded RAM buffers and spill to
/// private files only when full. Explicit finite `max_index_bytes` is honored;
/// the unbounded default uses 2 MiB per buffer. Per-operation
/// decoding uses `max_materialized_bytes`. One record/key and fixed tree-page
/// workspace remain minimum working storage. Buffers are capped independently;
/// they do not grow without bound with the total key count.
///
/// Scratch disk grows with history and must have free space. Output replacement
/// happens only after the complete result has been written and synced. Spilling
/// does not publish intermediate output. Custom key equality/hash semantics are
/// preserved, including hash collisions. Individual oversized records still
/// fail their decode/encode limits. Explicit key-count guards remain available.
pub fn merge_keyed_files<T, P>(spec: FormatSpec, base: P, deltas: &[P], output: P) -> Result<()>
where
    T: VarlitMerge,
    T::Key: Eq + Hash,
    P: AsRef<Path>,
{
    merge_keyed_files_with_key_limit::<T, P>(spec, base, deltas, output, u64::MAX)
}

/// [`merge_keyed_files`] with an explicit ceiling on distinct retained keys.
///
/// The collector checks `max_distinct_keys` before it admits each new key, so
/// an input whose cardinality exceeds the declared work limit fails with
/// [`Error::LimitExceeded`] (`resource = "merge distinct keys"`) at the
/// boundary instead of being discovered by the allocator. The ceiling counts
/// tombstoned keys, matching what the state actually retains.
pub fn merge_keyed_files_with_key_limit<T, P>(
    spec: FormatSpec,
    base: P,
    deltas: &[P],
    output: P,
    max_distinct_keys: u64,
) -> Result<()>
where
    T: VarlitMerge,
    T::Key: Eq + Hash,
    P: AsRef<Path>,
{
    let spec = spec.ordinary_read();
    spec.validate()?;
    let merged =
        external_merge::ExternalMerge::<T>::collect(spec, base, deltas, max_distinct_keys)?;
    write_keyed_values_atomically(spec, output.as_ref(), |out| merged.write(out))
}

/// Compacts `base` plus `deltas` into `output`, dropping superseded records.
/// Uses the bounded buffers and temporary files described by [`merge_keyed_files`].
/// [`compact_keyed_files_with_key_limit`] additionally bounds distinct keys.
pub fn compact_keyed_files<T, P>(spec: FormatSpec, base: P, deltas: &[P], output: P) -> Result<()>
where
    T: VarlitMerge,
    T::Key: Eq + Hash,
    P: AsRef<Path>,
{
    compact_keyed_files_with_key_limit::<T, P>(spec, base, deltas, output, u64::MAX)
}

/// [`compact_keyed_files`] with an explicit ceiling on distinct retained keys.
///
/// See [`merge_keyed_files_with_key_limit`] for the guard semantics.
pub fn compact_keyed_files_with_key_limit<T, P>(
    spec: FormatSpec,
    base: P,
    deltas: &[P],
    output: P,
    max_distinct_keys: u64,
) -> Result<()>
where
    T: VarlitMerge,
    T::Key: Eq + Hash,
    P: AsRef<Path>,
{
    let spec = spec.ordinary_read();
    spec.validate()?;
    let merged =
        external_merge::ExternalMerge::<T>::collect(spec, base, deltas, max_distinct_keys)?;
    write_keyed_values_atomically(spec, output.as_ref(), |out| merged.write(out))
}

fn write_keyed_values_atomically(
    spec: FormatSpec,
    output: &Path,
    populate: impl FnOnce(&mut VarlitFile) -> Result<()>,
) -> Result<()> {
    let _lock = WriterLock::acquire(output)?;
    // STO4-P2: the permission copy below is fallible and used to sit between
    // the temp's creation and the first scope that cleaned it up, so its `?`
    // could leave an empty temp behind. The guard owns the temp from creation,
    // so *every* early return from here on unlinks it; the deliberate
    // retentions below disarm it explicitly.
    let mut temp = RewriteTemp::create(output)?;
    take_injected_rewrite_temp_preparation_failure()?;
    if let Ok(metadata) = std::fs::metadata(output) {
        temp.file().set_permissions(metadata.permissions())?;
    }
    temp.close();
    let temp_path = temp.path().to_path_buf();

    let result = (|| {
        let mut out = VarlitFile::create(spec, &temp_path)?;
        populate(&mut out)?;
        out.flush()?;
        out.sync()
    })();
    if let Err(error) = result {
        // Delete eagerly rather than at drop: the marker cleanup below is only
        // correct once the temp itself is gone.
        temp.cleanup_now();
        remove_rewrite_temp_lock_marker(&temp_path);
        return Err(error);
    }

    let published = match replace_path_atomically(&temp_path, output) {
        // The rename consumed the temp pathname; there is nothing left to
        // unlink and the guard must not try.
        Ok(ReplaceDurability::Durable) => {
            temp.retain();
            Ok(())
        }
        // Publication already happened; the temp file no longer exists and the
        // target pathname resolves to the merged generation, so the caller
        // must not treat this as "target unchanged".
        Ok(ReplaceDurability::ParentSyncPending(sync_error)) => {
            temp.retain();
            Err(crate::fallible::boxed_path_error(
                sync_error,
                output,
                Error::ErrorContextAllocationFailed {
                    context: crate::AllocationFailureContext::ParentSyncPending,
                },
                |path, source| Error::PublishedButParentSyncPending { path, source },
            ))
        }
        Err(error) => {
            if matches!(error, Error::ReplacePublicationIndeterminate { .. }) {
                // DUR2-01: the temp may be the only surviving copy of the new
                // generation. Preserving it is the whole point of this arm, so
                // the guard is disarmed rather than allowed to unlink it.
                temp.retain();
            } else {
                temp.cleanup_now();
            }
            Err(error)
        }
    };
    remove_rewrite_temp_lock_marker(&temp_path);
    published
}

/// Removes the writer-lock marker that an internal rewrite temp left behind
/// (STO3-01).
///
/// Opening the temp through [`VarlitFile::create`] creates `<temp>.lock`.
/// Dropping that writer clears the marker's *contents* but deliberately keeps
/// the file: for a real user path the marker is a stable identity, and
/// unlinking it while another process may already hold the OS lock on that
/// inode would let a third process create a fresh marker at the same pathname
/// and "acquire" a lock on a different inode - exactly the race the persistent
/// marker exists to prevent. None of that applies to this pathname:
///
/// - it was generated by [`create_rewrite_temp_file`] with `create_new`, so
///   this operation exclusively owns it;
/// - the only way to regenerate the same name is another rewrite of the same
///   output in the same process, and the caller holds the output's writer lock
///   across the whole publication, so no such rewrite can be in flight;
/// - by the time this runs the temp has been published or deleted, so the
///   marker names a file that no longer exists.
///
/// The caller must therefore have dropped the temp's `VarlitFile` (releasing its
/// [`WriterLock`]) and must still hold the target's writer lock. If the temp is
/// still present - the indeterminate-publication case, where it is preserved
/// for out-of-band reconciliation - its marker is left with it.
fn remove_rewrite_temp_lock_marker(temp_path: &Path) {
    if temp_path.exists() {
        return;
    }
    let _ = remove_file(lock_path(temp_path));
}

/// Deletes a publication temp file after a pre-publication failure, but
/// preserves it after [`Error::ReplacePublicationIndeterminate`]: in that
/// state the temp may be the only surviving copy of the new generation and is
/// required for out-of-band reconciliation (DUR2-01).
fn preserve_temp_on_indeterminate(temp_path: &Path, error: Error) -> Error {
    if !matches!(error, Error::ReplacePublicationIndeterminate { .. }) {
        let _ = remove_file(temp_path);
    }
    error
}

/// Refuses a key the merge state has not seen once the caller's `K-ever`
/// ceiling is reached (PERF2-03), so a cardinality the caller cannot afford
/// fails typed at the boundary instead of in the allocator.
fn admit_merge_key<T>(
    state: &HashMap<T::Key, (MergeOrder, Option<T>)>,
    key: &T::Key,
    max_distinct_keys: u64,
) -> Result<()>
where
    T: VarlitMerge,
    T::Key: Eq + Hash,
{
    if state.contains_key(key) {
        return Ok(());
    }
    let admitted = u64::try_from(state.len()).map_err(|_| Error::ResourceArithmeticOverflow {
        resource: "merge distinct keys",
    })?;
    if admitted >= max_distinct_keys {
        return Err(Error::LimitExceeded {
            resource: "merge distinct keys",
            actual: admitted.saturating_add(1),
            limit: max_distinct_keys,
        });
    }
    Ok(())
}

fn apply_merge_entries<T, D: RecordDirectory + ?Sized>(
    spec: FormatSpec,
    snapshot: &SnapshotFile,
    entries: &D,
    shard: MergeShard,
    state: &mut HashMap<T::Key, (MergeOrder, Option<T>)>,
    budget: &mut MaterializationBudget,
    max_distinct_keys: u64,
) -> Result<()>
where
    T: VarlitMerge,
    T::Key: Eq + Hash,
{
    // One payload buffer for the whole merge walk, not one per record.
    let mut payload = Vec::new();
    for (record_ordinal, entry) in directory_records(entries).enumerate() {
        let entry = entry?;
        let order = MergeOrder::for_record(shard.ordinal, entry.sequence, record_ordinal);
        match entry.block_id {
            id if id == T::ID => {
                if entry.block_version != T::VERSION {
                    return Err(Error::BlockVersionMismatch {
                        block_id: T::ID,
                        expected: T::VERSION,
                        actual: entry.block_version,
                    });
                }
                let logical_len = entry.logical_payload_len_snapshot(spec, snapshot)?;
                budget.consume(logical_len)?;
                entry.read_logical_payload_snapshot_into(spec, snapshot, &mut payload)?;
                let block: T = budget.decode(&payload, T::ENDIAN.unwrap_or(spec.endian))?;
                let key = block.key();
                if should_apply(state.get(&key), order) {
                    admit_merge_key::<T>(state, &key, max_distinct_keys)?;
                    state.try_reserve(1).map_err(|_| Error::AllocationFailed {
                        resource: "merge state",
                        requested: logical_len,
                    })?;
                    state.insert(key, (order, Some(block)));
                }
            }
            TOMBSTONE_BLOCK_ID => {
                let logical_len = entry.logical_payload_len_snapshot(spec, snapshot)?;
                budget.consume(logical_len)?;
                entry.read_payload_snapshot_into(spec, snapshot, &mut payload)?;
                let Some(key) = decode_internal_key_payload::<T>(spec.endian, &payload, budget)?
                else {
                    continue;
                };
                if should_apply(state.get(&key), order) {
                    admit_merge_key::<T>(state, &key, max_distinct_keys)?;
                    state.try_reserve(1).map_err(|_| Error::AllocationFailed {
                        resource: "merge state",
                        requested: logical_len,
                    })?;
                    state.insert(key, (order, None));
                }
            }
            OP_BLOCK_ID => {
                let logical_len = entry.logical_payload_len_snapshot(spec, snapshot)?;
                budget.consume(logical_len)?;
                entry.read_payload_snapshot_into(spec, snapshot, &mut payload)?;
                let Some((key, op)) =
                    decode_internal_op_payload::<T>(spec.endian, &payload, budget)?
                else {
                    continue;
                };
                if !should_apply(state.get(&key), order) {
                    continue;
                }
                let Some((_, Some(mut value))) = state.remove(&key) else {
                    return Err(Error::MissingMergeTarget);
                };
                value.apply_op(op)?;
                state.insert(key, (order, Some(value)));
            }
            _ => {}
        }
    }
    Ok(())
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct MergeShard {
    ordinal: usize,
}

impl MergeShard {
    fn single_file() -> Self {
        Self { ordinal: 0 }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
struct MergeOrder {
    shard_ordinal: usize,
    sequence: u64,
    record_ordinal: usize,
}

impl MergeOrder {
    const fn for_record(shard_ordinal: usize, sequence: u64, record_ordinal: usize) -> Self {
        Self {
            shard_ordinal,
            sequence,
            record_ordinal,
        }
    }
}

fn should_apply<T>(current: Option<&(MergeOrder, Option<T>)>, order: MergeOrder) -> bool {
    current.is_none_or(|(old_order, _)| order >= *old_order)
}

/// Frames a metadata record's payload as `(key, value)` without copying either.
///
/// [`VarlitFile::write_metadata`] encodes `(String, Vec<u8>)` through the tuple
/// codec, which is exactly `u64 key_len | key | u64 value_len | value`, and
/// metadata goes through `write_record` rather than `write_user_record`, so it
/// is never compressed. That framing is what the borrowed pair reads back.
///
/// It exists so a lookup can compare the key *before* deciding to materialize
/// the value: the decoder allocates a `String` and a `Vec<u8>` per record,
/// which for a lookup is one copy per record that is thrown away. The errors
/// are the ones `decode_complete` raises on the same bytes —
/// [`Error::UnexpectedEof`], [`Error::LengthOverflow`], [`Error::InvalidUtf8`]
/// and [`Error::TrailingBytes`] — because the byte-for-byte answer must not
/// depend on which of the two readers looked.
///
/// The `0` materialization allowance is not a limit being enforced: nothing is
/// materialized here, so nothing is charged. Callers charge the record they
/// then decode.
fn split_metadata_payload(payload: &[u8], endian: Endian) -> Result<(&str, &[u8])> {
    let mut decoder = crate::Decoder::new_limited(payload, endian, 0);
    let key_len = decoder.read_len()?;
    if key_len > decoder.remaining() {
        return Err(Error::UnexpectedEof);
    }
    let key = decoder.read_exact(key_len)?;
    let key = std::str::from_utf8(key).map_err(|_| Error::InvalidUtf8)?;
    let value_len = decoder.read_len()?;
    if value_len > decoder.remaining() {
        return Err(Error::UnexpectedEof);
    }
    let value = decoder.read_exact(value_len)?;
    if decoder.remaining() != 0 {
        return Err(Error::TrailingBytes {
            remaining: decoder.remaining(),
        });
    }
    Ok((key, value))
}

/// Encodes a writer-supplied value with the format's logical-payload limit as
/// the encode hard bound (DEF-02).
///
/// Every resident writer entry point routes its value encoding through this
/// bound so an oversized value fails with the typed limit error while the
/// encoder stops buffering at the limit, instead of materializing an
/// arbitrarily large encoding first and only then failing the limit check.
fn encode_logical_payload_limited<T: VarlitEncode>(
    spec: FormatSpec,
    value: &T,
    endian: Endian,
) -> Result<Vec<u8>> {
    let logical_limit = spec
        .read_limits
        .require(ReadLimitKey::LogicalPayloadLen)?
        .unwrap_or(u64::MAX);
    encode_to_vec_limited(
        value,
        endian,
        logical_limit,
        ReadLimitKey::LogicalPayloadLen.resource(),
    )
}

/// [`encode_logical_payload_limited`] into a caller-owned buffer.
fn encode_logical_payload_limited_into<T: VarlitEncode>(
    spec: FormatSpec,
    value: &T,
    endian: Endian,
    buffer: &mut Vec<u8>,
) -> Result<()> {
    let logical_limit = spec
        .read_limits
        .require(ReadLimitKey::LogicalPayloadLen)?
        .unwrap_or(u64::MAX);
    crate::codec::encode_into_limited(
        value,
        endian,
        logical_limit,
        ReadLimitKey::LogicalPayloadLen.resource(),
        buffer,
    )
}

fn encode_internal_key_payload<T>(spec: FormatSpec, key: &T::Key) -> Result<Vec<u8>>
where
    T: VarlitKeyedBlock,
{
    const ENVELOPE_LEN: u64 = 12;
    let logical_limit = spec
        .read_limits
        .require(ReadLimitKey::LogicalPayloadLen)?
        .unwrap_or(u64::MAX);
    let key_limit = logical_limit
        .checked_sub(ENVELOPE_LEN)
        .ok_or(Error::LimitExceeded {
            resource: ReadLimitKey::LogicalPayloadLen.resource(),
            actual: ENVELOPE_LEN,
            limit: logical_limit,
        })?;
    let key_payload = encode_to_vec_limited(
        key,
        spec.endian,
        key_limit,
        ReadLimitKey::LogicalPayloadLen.resource(),
    )?;
    let total_len = ENVELOPE_LEN.checked_add(key_payload.len() as u64).ok_or(
        Error::ResourceArithmeticOverflow {
            resource: "internal key payload length",
        },
    )?;
    spec.read_limits
        .check(ReadLimitKey::LogicalPayloadLen, total_len)?;
    let total_len_usize =
        usize::try_from(total_len).map_err(|_| Error::LengthOverflow { value: total_len })?;
    let mut payload = Vec::new();
    payload
        .try_reserve_exact(total_len_usize)
        .map_err(|_| Error::AllocationFailed {
            resource: "internal key payload",
            requested: total_len,
        })?;
    payload.extend_from_slice(&T::ID.to_le_bytes());
    payload.extend_from_slice(&(key_payload.len() as u64).to_le_bytes());
    payload.extend_from_slice(&key_payload);
    Ok(payload)
}

fn decode_internal_key_payload<T>(
    endian: Endian,
    payload: &[u8],
    budget: &mut MaterializationBudget,
) -> Result<Option<T::Key>>
where
    T: VarlitKeyedBlock,
{
    let Some(key) = decode_native_internal_key_envelope(payload, T::ID)? else {
        return Ok(None);
    };
    Ok(Some(budget.decode(key, endian)?))
}

pub(crate) fn decode_stream_tombstone_key<T: VarlitKeyedBlock>(
    spec: FormatSpec,
    snapshot: &SnapshotFile,
    entry: &RecordIndexEntry,
) -> Result<Option<T::Key>> {
    if entry.block_id != TOMBSTONE_BLOCK_ID {
        return Ok(None);
    }
    if entry.block_version != 1 || entry.flags != RECORD_FLAG_INTERNAL {
        return Err(Error::CorruptTail {
            offset: entry.record_offset,
        });
    }
    let logical_len = entry.logical_payload_len_snapshot(spec, snapshot)?;
    let mut budget = MaterializationBudget::new(spec);
    budget.consume(logical_len)?;
    let payload = entry.read_logical_payload_snapshot(spec, snapshot)?;
    decode_internal_key_payload::<T>(spec.endian, &payload, &mut budget)
}

fn encode_internal_op_payload<T>(spec: FormatSpec, key: &T::Key, op: &T::Op) -> Result<Vec<u8>>
where
    T: VarlitMerge,
{
    const ENVELOPE_LEN: u64 = 20;
    let logical_limit = spec
        .read_limits
        .require(ReadLimitKey::LogicalPayloadLen)?
        .unwrap_or(u64::MAX);
    let key_limit = logical_limit
        .checked_sub(ENVELOPE_LEN)
        .ok_or(Error::LimitExceeded {
            resource: ReadLimitKey::LogicalPayloadLen.resource(),
            actual: ENVELOPE_LEN,
            limit: logical_limit,
        })?;
    let key_payload = encode_to_vec_limited(
        key,
        spec.endian,
        key_limit,
        ReadLimitKey::LogicalPayloadLen.resource(),
    )?;
    // DEF-02: the op encoder inherits whatever budget the key left over, so
    // the combined encoding can never buffer past the logical payload limit.
    let op_limit = key_limit - key_payload.len() as u64;
    let op_payload = encode_to_vec_limited(
        op,
        spec.endian,
        op_limit,
        ReadLimitKey::LogicalPayloadLen.resource(),
    )?;
    let total_len = ENVELOPE_LEN
        .checked_add(key_payload.len() as u64)
        .and_then(|len| len.checked_add(op_payload.len() as u64))
        .ok_or(Error::ResourceArithmeticOverflow {
            resource: "internal op payload length",
        })?;
    spec.read_limits
        .check(ReadLimitKey::LogicalPayloadLen, total_len)?;
    let total_len_usize =
        usize::try_from(total_len).map_err(|_| Error::LengthOverflow { value: total_len })?;
    let mut payload = Vec::new();
    payload
        .try_reserve_exact(total_len_usize)
        .map_err(|_| Error::AllocationFailed {
            resource: "internal op payload",
            requested: total_len,
        })?;
    payload.extend_from_slice(&T::ID.to_le_bytes());
    payload.extend_from_slice(&(key_payload.len() as u64).to_le_bytes());
    payload.extend_from_slice(&key_payload);
    payload.extend_from_slice(&(op_payload.len() as u64).to_le_bytes());
    payload.extend_from_slice(&op_payload);
    Ok(payload)
}

fn decode_internal_op_payload<T>(
    endian: Endian,
    payload: &[u8],
    budget: &mut MaterializationBudget,
) -> Result<Option<(T::Key, T::Op)>>
where
    T: VarlitMerge,
{
    let Some((key, op)) = decode_native_internal_op_envelope(payload, T::ID)? else {
        return Ok(None);
    };
    let key = budget.decode(key, endian)?;
    let op = budget.decode(op, endian)?;
    Ok(Some((key, op)))
}

/// Write the header this spec describes, and hand back the extension region it
/// put there so the caller can record what this file actually carries.
pub(crate) fn write_file_header(spec: FormatSpec, file: &mut File) -> Result<Vec<u8>> {
    let extensions = file_header_extensions(spec)?;
    write_native_file_header(file, spec, &extensions)?;
    Ok(extensions)
}

pub(crate) fn read_file_header(spec: FormatSpec, file: &mut (impl Read + Seek)) -> Result<u64> {
    Ok(read_file_header_parts(spec, file)?.0)
}

/// The header length *and* the extension region the file carries.
///
/// The two are not interchangeable with what `spec` would produce: once an
/// unknown block is skippable rather than refused, a file's region can be
/// longer than this build would write, and every offset derived from the header
/// has to come from the file rather than from the spec.
pub(crate) fn read_file_header_parts(
    spec: FormatSpec,
    file: &mut (impl Read + Seek),
) -> Result<(u64, Vec<u8>)> {
    file.seek(SeekFrom::Start(0))?;
    let header = read_native_file_header(file, spec)?;
    let hash = header.schema_hash;
    if spec.schema_hash != 0 && hash != spec.schema_hash {
        return Err(Error::SchemaHashMismatch {
            expected: spec.schema_hash,
            actual: hash,
        });
    }
    if uses_format_contract_compression(spec) {
        let computed = spec.computed_schema_hash();
        if hash != computed {
            return Err(Error::SchemaHashMismatch {
                expected: computed,
                actual: hash,
            });
        }
    }
    if header.has_extension_len {
        validate_file_header_extensions(spec, &header.extensions)?;
        Ok((header.header_len, header.extensions))
    } else {
        if uses_file_explicit_compression(spec) {
            return Err(Error::InvalidCompressionHeader);
        }
        Ok((native_file_header_len(spec, 0), Vec::new()))
    }
}

fn matrix_pending_limit(spec: FormatSpec) -> usize {
    // Charge a conservative 128 bytes of directory metadata per dirty page.
    spec.read_limits
        .require(ReadLimitKey::MaterializedBytes)
        .ok()
        .flatten()
        .map_or(65_536, |n| {
            usize::try_from(n / 128).unwrap_or(usize::MAX).max(1)
        })
}
fn read_matrix_layout_if_needed(
    path: &Path,
    writable: bool,
    spec: FormatSpec,
    file: &mut File,
    header_len: u64,
    _captured_len: u64,
) -> Result<
    Option<(
        crate::matrix::MatrixLayout,
        [u8; MATRIX_CREATION_NONCE_LEN],
        crate::matrix_generation::MatrixFile,
    )>,
> {
    if !spec.has_matrix_blocks() {
        return Ok(None);
    }
    let nonce = read_matrix_creation_nonce_region(file, header_len)?;
    let mut pages = crate::matrix_generation::MatrixFile::open(
        path,
        file,
        nonce,
        writable,
        matrix_pending_limit(spec),
    )?;
    pages.set_cache_bytes(spec.read_limits.matrix_generation_cache_budget());
    pages.set_traversal_bytes(limit_or_max(
        spec.read_limits.require(ReadLimitKey::ScanBytes)?,
    ));
    if pages.head().native_eof > file.metadata()?.len() {
        return Err(Error::InvalidMatrixLayout);
    }
    let layout_start = header_len
        .checked_add(MATRIX_CREATION_NONCE_REGION_LEN as u64)
        .ok_or(Error::InvalidMatrixLayout)?;
    let confirmed_len = pages.head().native_eof;
    let layout = crate::matrix::read_layout_at_len(spec, &mut pages, layout_start, confirmed_len)?;
    if writable {
        file.set_len(pages.head().native_eof)?;
    }
    Ok(Some((layout, nonce, pages)))
}
#[allow(clippy::type_complexity)]
fn split_matrix_state(
    state: Option<(
        crate::matrix::MatrixLayout,
        [u8; MATRIX_CREATION_NONCE_LEN],
        crate::matrix_generation::MatrixFile,
    )>,
) -> (
    Option<crate::matrix::MatrixLayout>,
    Option<[u8; MATRIX_CREATION_NONCE_LEN]>,
    Option<crate::matrix_generation::MatrixFile>,
) {
    match state {
        Some((layout, nonce, pages)) => (Some(layout), Some(nonce), Some(pages)),
        None => (None, None, None),
    }
}

fn append_log_start(header_len: u64, matrix: Option<&crate::matrix::MatrixLayout>) -> u64 {
    matrix.map_or(header_len, crate::matrix::MatrixLayout::append_log_start)
}

/// Produces a fresh 128-bit matrix creation nonce (DUR2-03).
///
/// This is a uniqueness value, not a cryptographic secret: it only has to
/// differ between two `create_with_dims` calls that reuse the same OS file
/// object. Wall-clock nanoseconds, the process id and a per-process counter
/// are mixed through FNV-1a into two independent 64-bit lanes.
fn fresh_matrix_creation_nonce() -> [u8; MATRIX_CREATION_NONCE_LEN] {
    use std::sync::atomic::{AtomicU64, Ordering};

    static CREATION_COUNTER: AtomicU64 = AtomicU64::new(0);
    let counter = CREATION_COUNTER.fetch_add(1, Ordering::Relaxed);
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|elapsed| elapsed.as_nanos())
        .unwrap_or(0);
    let pid = u64::from(std::process::id());

    const FNV_PRIME: u64 = 0x0000_0100_0000_01B3;
    const FNV_OFFSET_BASIS: u64 = 0xCBF2_9CE4_8422_2325;
    let mut nonce = [0u8; MATRIX_CREATION_NONCE_LEN];
    for lane in 0u64..2 {
        let mut hash = FNV_OFFSET_BASIS;
        for word in [lane, nanos as u64, (nanos >> 64) as u64, pid, counter] {
            for byte in word.to_le_bytes() {
                hash ^= u64::from(byte);
                hash = hash.wrapping_mul(FNV_PRIME);
            }
        }
        let lane = lane as usize;
        nonce[lane * 8..(lane + 1) * 8].copy_from_slice(&hash.to_le_bytes());
    }
    // The raw entropy words survive the mix: XOR them back in so even a
    // degenerate clock (nanos == 0 on every call) cannot collapse two creates
    // in the same process to the same nonce (the counter still differs).
    for (index, byte) in nanos
        .to_le_bytes()
        .iter()
        .chain(counter.to_le_bytes().iter())
        .take(MATRIX_CREATION_NONCE_LEN)
        .enumerate()
    {
        nonce[index] ^= byte.rotate_left((index % 7) as u32);
    }
    nonce
}

fn write_matrix_creation_nonce_region(
    file: &mut File,
    creation_id: [u8; MATRIX_CREATION_NONCE_LEN],
) -> Result<()> {
    let mut region = [0u8; MATRIX_CREATION_NONCE_REGION_LEN];
    region[0..4].copy_from_slice(MATRIX_CREATION_NONCE_MAGIC);
    region[4..6].copy_from_slice(&MATRIX_CREATION_NONCE_VERSION.to_le_bytes());
    // region[6..8] stays zero (reserved).
    region[8..].copy_from_slice(&creation_id);
    file.write_all(&region)?;
    Ok(())
}

fn read_matrix_creation_nonce_region(
    file: &mut File,
    offset: u64,
) -> Result<[u8; MATRIX_CREATION_NONCE_LEN]> {
    file.seek(SeekFrom::Start(offset))?;
    let mut region = [0u8; MATRIX_CREATION_NONCE_REGION_LEN];
    file.read_exact(&mut region)?;
    if &region[0..4] != MATRIX_CREATION_NONCE_MAGIC
        || region[4..6] != MATRIX_CREATION_NONCE_VERSION.to_le_bytes()
        || region[6..8] != [0; 2]
    {
        return Err(Error::InvalidMatrixLayout);
    }
    let mut nonce = [0u8; MATRIX_CREATION_NONCE_LEN];
    nonce.copy_from_slice(&region[8..]);
    Ok(nonce)
}

/// The limits a native format must declare before it may be written or opened.
///
/// **`FileLen` is not among them, and that is the point.** Requiring a
/// declaration for a ceiling that nothing enforces is ceremony: the twenty-one
/// enforcement sites were removed in this round, and a required declaration
/// that no check consults refuses a format for a number that could not have
/// changed any outcome. `max_file_len` remains on `FormatSpec` and the DSL
/// still accepts `limits { file_len: .. }`, so no format definition breaks —
/// the value is simply inert.
///
/// The four that remain each bound a real allocation, and each has a check that
/// consults it.
pub(crate) fn ensure_native_write_limits(spec: FormatSpec) -> Result<()> {
    for key in [
        ReadLimitKey::Records,
        ReadLimitKey::IndexBytes,
        ReadLimitKey::RecordPayloadLen,
        ReadLimitKey::LogicalPayloadLen,
    ] {
        spec.read_limits.require(key)?;
    }
    Ok(())
}

pub(crate) fn ensure_native_open_limits(spec: FormatSpec) -> Result<()> {
    ensure_native_write_limits(spec)?;
    spec.read_limits.require(ReadLimitKey::ScanBytes)?;
    Ok(())
}

pub(crate) fn check_open_file_len(_spec: FormatSpec, file: &File) -> Result<u64> {
    Ok(file.metadata()?.len())
}

fn ensure_matrix_byte_copy_compatible<From, To>() -> Result<()>
where
    From: VarlitMatrixBlock,
    To: VarlitMatrixBlock,
{
    if From::DIMENSIONS != To::DIMENSIONS || From::SLOT_STRIDE != To::SLOT_STRIDE {
        return Err(Error::InvalidFormatSpec(
            "matrix byte-copy requires matching dimensions and slot_stride",
        ));
    }
    Ok(())
}

fn record_footer_len(spec: FormatSpec) -> u64 {
    if spec.spec_needs_record_footer() {
        native_record_footer_len()
    } else {
        0
    }
}

fn nonzero_offset(offset: u64) -> Option<u64> {
    if offset == 0 { None } else { Some(offset) }
}

const fn limit_or_max(limit: Option<u64>) -> u64 {
    match limit {
        Some(limit) => limit,
        None => u64::MAX,
    }
}

fn ensure_payload_limit(resource: &'static str, actual: u64, limit: u64) -> Result<()> {
    if actual > limit {
        Err(Error::LimitExceeded {
            resource,
            actual,
            limit,
        })
    } else {
        Ok(())
    }
}

fn index_bytes_for_count(count: usize) -> Result<u64> {
    let count = u64::try_from(count).map_err(|_| Error::ResourceArithmeticOverflow {
        resource: "index bytes",
    })?;
    let entry_size = u64::try_from(size_of::<RecordIndexEntry>()).map_err(|_| {
        Error::ResourceArithmeticOverflow {
            resource: "index bytes",
        }
    })?;
    count
        .checked_mul(entry_size)
        .ok_or(Error::ResourceArithmeticOverflow {
            resource: "index bytes",
        })
}

fn allocation_bytes<T>(count: usize, resource: &'static str) -> Result<u64> {
    u64::try_from(count)
        .map_err(|_| Error::ResourceArithmeticOverflow { resource })?
        .checked_mul(size_of::<T>() as u64)
        .ok_or(Error::ResourceArithmeticOverflow { resource })
}

#[cfg(feature = "mmap")]
fn mmap_index_bytes_for_count(count: usize, verify: bool) -> Result<u64> {
    let count = u64::try_from(count).map_err(|_| Error::ResourceArithmeticOverflow {
        resource: "mmap index bytes",
    })?;
    // One index entry copy plus one `by_block` position per record; the
    // former second full entry copy for the membership hash set is gone
    // (PERF2-07).
    let entry_bytes = u64::try_from(size_of::<RecordIndexEntry>())
        .map_err(|_| Error::ResourceArithmeticOverflow {
            resource: "mmap index bytes",
        })?
        .checked_add(size_of::<usize>() as u64)
        .and_then(|bytes| bytes.checked_add(u64::from(verify)))
        .ok_or(Error::ResourceArithmeticOverflow {
            resource: "mmap index bytes",
        })?;
    count
        .checked_mul(entry_bytes)
        .ok_or(Error::ResourceArithmeticOverflow {
            resource: "mmap index bytes",
        })
}

/// Bytes the sequence-uniqueness witness allocates for `records` entries.
///
/// This is the transient every resident input open can pay on top of its
/// resident index, so [`KeyedMergeEstimate`] has to charge it (PERF3-05).
fn sequence_uniqueness_transient_bytes(records: usize) -> Result<u64> {
    u64::try_from(records)
        .map_err(|_| Error::ResourceArithmeticOverflow {
            resource: "sequence uniqueness index",
        })?
        .checked_mul(size_of::<u64>() as u64)
        .ok_or(Error::ResourceArithmeticOverflow {
            resource: "sequence uniqueness index",
        })
}

/// Rejects a native file that reuses a record sequence.
///
/// Fast path (PERF3-05): the writer hands out sequences from a monotonically
/// increasing counter, so an ordinary append-only file scanned in offset order
/// is strictly increasing. Verifying that costs one allocation-free pass and
/// proves uniqueness outright. Only an input whose records are *not* in
/// ascending sequence order - a rewritten or externally reordered generation -
/// falls back to the sorted copy, which costs `O(N log N)` time and an explicit
/// `8N` temporary. The fallback is still the published worst case, so the
/// resident merge estimate charges it unconditionally rather than assuming the
/// fast path.
fn validate_unique_sequences(entries: &[RecordIndexEntry]) -> Result<()> {
    if entries
        .windows(2)
        .all(|pair| pair[0].sequence < pair[1].sequence)
    {
        return Ok(());
    }
    let requested = sequence_uniqueness_transient_bytes(entries.len())?;
    let mut sequences = Vec::new();
    sequences
        .try_reserve_exact(entries.len())
        .map_err(|_| Error::AllocationFailed {
            resource: "sequence uniqueness index",
            requested,
        })?;
    sequences.extend(entries.iter().map(|entry| entry.sequence));
    sequences.sort_unstable();
    if sequences.windows(2).any(|pair| pair[0] == pair[1]) {
        return Err(Error::InvalidCanonicalEncoding(
            "duplicate native record sequence",
        ));
    }
    Ok(())
}

/// The three per-handle structures every open and every generation rebind
/// derives from the resident index.
struct DerivedIndexState {
    checkpoint_cadence: CheckpointCadence,
    segment_cursor: SegmentCursor,
    /// `None` when the caller did not ask for tails, which an open does not:
    /// it already has them from the scan or the chain walk, and building the
    /// newest-per-block map here would be work thrown away.
    block_tails: Option<BlockTails>,
}

/// Derives all three in ONE forward pass.
///
/// They used to be three separate walks of the same entries — one forward
/// (`BlockTails`) and two reverse (`CheckpointCadence`, `SegmentCursor`) — run
/// back to back at every open and at both generation rebinds. The two reverse
/// walks stop at the newest checkpoint and the newest segment respectively, so
/// on a file that carries neither they each walk the whole index; the forward
/// one has no early exit at all. Three traversals, and a single forward pass
/// answers all of them, because "the last entry with this block id" is just the
/// last one a forward pass saw.
///
/// Each field is still computed by exactly the rule its own `from_index`
/// states, so the invariants those doc comments assert are unchanged. The unit
/// tests below compare this against all three.
fn derive_index_state(
    entries: impl Iterator<Item = Result<RecordIndexEntry>>,
    with_tails: bool,
) -> Result<DerivedIndexState> {
    let mut touched: u64 = 0;
    let mut newest: HashMap<u32, u64> = HashMap::new();
    // Position of, and entry at, the newest record of each kind the derived
    // structures key on.
    let mut newest_checkpoint: Option<usize> = None;
    let mut newest_segment: Option<(usize, u64)> = None;
    // Eligible records since the newest checkpoint, counted forward: reset each
    // time a checkpoint is seen, which leaves exactly the tail the reverse walk
    // used to accumulate.
    let mut eligible: usize = 0;
    for (position, entry) in entries.enumerate() {
        let entry = entry?;
        touched = touched.saturating_add(1);
        if with_tails {
            if newest.len() == newest.capacity() && !newest.contains_key(&entry.block_id) {
                newest.try_reserve(1).map_err(|_| Error::AllocationFailed {
                    resource: "derived block tails",
                    requested: (newest.len() as u64 + 1).saturating_mul(32),
                })?;
            }
            newest.insert(entry.block_id, entry.record_offset);
        }
        match entry.block_id {
            INDEX_BLOCK_ID => {
                newest_checkpoint = Some(position);
                eligible = 0;
            }
            SEGMENT_BLOCK_ID => newest_segment = Some((position, entry.physical_end())),
            COMMIT_BLOCK_ID => {}
            _ => eligible = eligible.saturating_add(1),
        }
    }
    let state = DerivedIndexState {
        checkpoint_cadence: CheckpointCadence {
            eligible_since_checkpoint: eligible,
            next_threshold: match newest_checkpoint {
                Some(position) => core::cmp::max(INDEX_CHECKPOINT_MIN_RECORDS, position / 2),
                None => INDEX_CHECKPOINT_MIN_RECORDS,
            },
        },
        segment_cursor: match newest_segment {
            Some((position, physical_end)) => SegmentCursor {
                next_position: position + 1,
                covered_start: Some(physical_end),
            },
            None => SegmentCursor::new_empty(),
        },
        block_tails: with_tails
            .then(|| BlockTails::from_newest(&newest))
            .transpose()?,
    };
    if with_tails {
        note_block_tail_index_touches(touched);
    }
    note_checkpoint_cadence_index_touches(touched);
    Ok(state)
}

/// Borrowed entries as the fallible stream [`derive_index_state`] consumes.
///
/// The open paths still hold a plain `Vec` at the point they derive from it —
/// they built it moments earlier — so their entries cannot fail to be produced.
/// This says that in one place instead of at each call site.
#[cfg(test)]
fn infallible_entries(
    entries: &[RecordIndexEntry],
) -> impl DoubleEndedIterator<Item = Result<RecordIndexEntry>> + ExactSizeIterator + '_ {
    entries.iter().cloned().map(Ok)
}

fn read_record_header(
    file: &mut (impl Read + Seek),
    _spec: FormatSpec,
    offset: u64,
) -> Result<RecordIndexEntry> {
    let decoded = read_native_record_header(file, offset)?;
    debug_assert_eq!(decoded.lead_in_len, RECORD_HEADER_LEN);
    let header = decoded.fields;
    Ok(RecordIndexEntry {
        block_id: header.block_id,
        block_version: header.block_version,
        flags: header.flags,
        sequence: header.sequence,
        record_offset: offset,
        payload_offset: offset
            .checked_add(decoded.lead_in_len)
            .ok_or(Error::CorruptTail { offset })?,
        payload_len: header.payload_len,
        checksum: header.checksum,
        uncompressed_len_hint: header.uncompressed_len_hint,
        footer_offset: None,
        prev_same_block_offset: None,
        prev_same_key_offset: None,
        mutable_flags: 0,
        committed: true,
    })
}

fn write_record_header(
    file: &mut File,
    spec: FormatSpec,
    record_offset: u64,
    header: RecordHeaderFields,
) -> Result<()> {
    let footer_len = record_footer_len(spec);
    debug_assert_eq!(native_record_header_len(), RECORD_HEADER_LEN);
    write_native_record_header(file, header, record_offset, footer_len)
}

fn encode_record_footer(footer: RecordFooterFields) -> Result<[u8; RECORD_FOOTER_LEN as usize]> {
    encode_native_record_footer(footer)
}

/// Rebuilds a record's index entry from the record itself, positionally.
///
/// **`&self` throughout, which is the whole point.** `read_record_entry_at`
/// takes `&mut File` and seeks, so it cannot serve an `&self` read path.
/// A demand-filled index uses that path: every read of an entry the index no
/// longer holds has to come
/// from the file, under `&self`. This reads the two fixed-size regions through
/// `SnapshotFile::read_exact_at` and hands them to the same decoders the
/// scanning reader uses, so there is one decode of a record header in the
/// crate and not two.
///
/// `committed` is the caller's, because it is writer state with no
/// representation in the record — proved, not assumed, by
/// `every_index_entry_can_be_rebuilt_from_its_own_record`.
///
/// This is what `ResidentIndex` calls for every entry it produces.
/// `every_index_entry_can_be_rebuilt_from_its_own_record` is the proof that
/// what comes back matches what the scanning reader would have built.
/// Whether the record header actually at an offset is the record an entry
/// claims is there.
///
/// Two callers ask exactly this, under opposite conditions, which is why the
/// seven fields are listed once rather than twice.
/// [`RecordIndexEntry::verify_snapshot_record`] asks it as part of integrity
/// verification and returns early when no checksum is declared;
/// [`VarlitFile::check_directory_describes_this_file`] asks it of a
/// caller-supplied directory and exists *above all* for the no-checksum case,
/// where nothing else would notice. A field added to the record header has to
/// arrive here or both of them silently stop covering it.
fn record_header_describes(actual: &RecordHeaderFields, stated: &RecordIndexEntry) -> bool {
    actual.block_id == stated.block_id
        && actual.block_version == stated.block_version
        && actual.flags == stated.flags
        && actual.sequence == stated.sequence
        && actual.payload_len == stated.payload_len
        && actual.checksum == stated.checksum
        && actual.uncompressed_len_hint == stated.uncompressed_len_hint
}

pub(crate) fn fault_record_entry(
    snapshot: &SnapshotFile,
    spec: FormatSpec,
    record_offset: u64,
    committed: bool,
) -> Result<RecordIndexEntry> {
    fault_record_entry_prefixed::<{ RECORD_HEADER_LEN as usize }>(
        snapshot,
        spec,
        record_offset,
        committed,
    )
}

/// A mutation's small fixed prefix can frame the header and footer with one
/// positional read. Ordinary directory reads retain their header-only I/O;
/// large records use the existing separate footer read. No heap buffer or
/// persistent cache is added, and every prefix stays inside the snapshot.
fn fault_record_entry_prefixed<const PREFIX: usize>(
    snapshot: &SnapshotFile,
    spec: FormatSpec,
    record_offset: u64,
    committed: bool,
) -> Result<RecordIndexEntry> {
    const {
        assert!(PREFIX >= RECORD_HEADER_LEN as usize);
    }
    fault_record_entry_with::<PREFIX>(
        snapshot.len(),
        spec,
        record_offset,
        committed,
        |at, bytes| snapshot.read_exact_at(at, bytes),
    )
}

#[inline]
fn mark_prefers_header_only(snapshot_len: u64, records: usize) -> bool {
    // An I/O hint, never a boundary witness. Avoid copying an unused payload
    // prefix when observed file geometry is dominated by larger records.
    // Small directories keep the prefix because container metadata can dominate
    // their average. Saturation only selects the existing wider read route.
    records >= 32 && snapshot_len > (records as u64).saturating_mul(512)
}

fn fault_record_entry_for_mark_with(
    snapshot_len: u64,
    records: usize,
    spec: FormatSpec,
    record_offset: u64,
    read: impl FnMut(u64, &mut [u8]) -> Result<()>,
) -> Result<RecordIndexEntry> {
    if mark_prefers_header_only(snapshot_len, records) {
        fault_record_entry_with::<{ RECORD_HEADER_LEN as usize }>(
            snapshot_len,
            spec,
            record_offset,
            false,
            read,
        )
    } else {
        fault_record_entry_with::<512>(snapshot_len, spec, record_offset, false, read)
    }
}

fn fault_record_entry_with<const PREFIX: usize>(
    snapshot_len: u64,
    spec: FormatSpec,
    record_offset: u64,
    committed: bool,
    mut read: impl FnMut(u64, &mut [u8]) -> Result<()>,
) -> Result<RecordIndexEntry> {
    count_record_entry_fault();
    let mut header_bytes = [0; PREFIX];
    let prefix_len = if PREFIX == RECORD_HEADER_LEN as usize {
        RECORD_HEADER_LEN as usize
    } else {
        snapshot_len
            .saturating_sub(record_offset)
            .min(PREFIX as u64)
            .max(RECORD_HEADER_LEN) as usize
    };
    read(record_offset, &mut header_bytes[..prefix_len])?;
    let decoded = read_native_record_header(
        &mut &header_bytes[..RECORD_HEADER_LEN as usize],
        record_offset,
    )?;
    debug_assert_eq!(decoded.lead_in_len, RECORD_HEADER_LEN);
    let header = decoded.fields;
    let Some(payload_offset) = record_offset.checked_add(RECORD_HEADER_LEN) else {
        return Err(Error::ResourceArithmeticOverflow {
            resource: "record payload offset",
        });
    };
    let mut entry = RecordIndexEntry {
        block_id: header.block_id,
        block_version: header.block_version,
        flags: header.flags,
        sequence: header.sequence,
        record_offset,
        payload_offset,
        payload_len: header.payload_len,
        checksum: header.checksum,
        uncompressed_len_hint: header.uncompressed_len_hint,
        footer_offset: None,
        prev_same_block_offset: None,
        prev_same_key_offset: None,
        mutable_flags: 0,
        committed,
    };
    if spec.spec_needs_record_footer() {
        let Some(footer_offset) = payload_offset.checked_add(entry.payload_len) else {
            return Err(Error::ResourceArithmeticOverflow {
                resource: "record footer offset",
            });
        };
        let mut footer_bytes = [0; RECORD_FOOTER_LEN as usize];
        let within_prefix = if PREFIX > RECORD_HEADER_LEN as usize {
            usize::try_from(footer_offset - record_offset)
                .ok()
                .and_then(|start| {
                    start
                        .checked_add(RECORD_FOOTER_LEN as usize)
                        .filter(|&end| end <= prefix_len)
                        .map(|end| (start, end))
                })
        } else {
            None
        };
        let bytes = match within_prefix {
            Some((start, end)) => &header_bytes[start..end],
            None => {
                read(footer_offset, &mut footer_bytes)?;
                &footer_bytes[..]
            }
        };
        let footer = decode_record_footer(spec, bytes, footer_offset, record_offset)?;
        entry.footer_offset = Some(footer_offset);
        entry.prev_same_block_offset = footer.prev_same_block_offset;
        entry.prev_same_key_offset = footer.prev_same_key_offset;
        entry.mutable_flags = footer.mutable_flags;
    }
    Ok(entry)
}

fn read_record_footer_bytes(
    file: &mut (impl Read + Seek),
    offset: u64,
) -> Result<[u8; RECORD_FOOTER_LEN as usize]> {
    file.seek(SeekFrom::Start(offset))?;
    let mut footer = [0; RECORD_FOOTER_LEN as usize];
    file.read_exact(&mut footer)?;
    Ok(footer)
}

/// Decodes a footer and holds its trailing word to the spec's policy.
///
/// The native decoder hands the word back rather than judging it, because
/// whether a non-zero value is legitimate is a property of the *spec* and not
/// of the bytes. Under [`LivenessPolicy::None`] it is the reserved field it has
/// always been and a non-zero value is a corrupt footer — refusing it here is
/// what keeps a format that did not opt in exactly as strict as it was before
/// the policy existed, which matters because these four bytes are the ones the
/// checksum does not cover under the other policy.
fn decode_record_footer(
    spec: FormatSpec,
    bytes: &[u8],
    footer_offset: u64,
    record_offset: u64,
) -> Result<RecordFooterFields> {
    let footer = decode_native_record_footer(bytes, footer_offset, record_offset)?;
    if spec.liveness_policy == LivenessPolicy::None && footer.mutable_flags != 0 {
        return Err(Error::InvalidRecordFooter {
            offset: footer_offset,
        });
    }
    Ok(footer)
}

fn checksum_record_fields(
    spec: FormatSpec,
    record_offset: u64,
    mut header: RecordHeaderFields,
    payload: &[u8],
    footer: &[u8],
) -> Result<u32> {
    header.checksum = 0;
    let header_bytes = if spec.integrity_policy == IntegrityPolicy::Crc32WithHeader {
        Some(encode_native_record_header(
            header,
            record_offset,
            record_footer_len(spec),
        )?)
    } else {
        None
    };
    checksum_record_bytes(
        spec,
        header_bytes.as_ref().map(|bytes| &bytes[..]).unwrap_or(&[]),
        payload,
        footer,
    )
}

fn checksum_record_file(
    spec: FormatSpec,
    file: &mut (impl Read + Seek),
    entry: &RecordIndexEntry,
    footer: &[u8],
) -> Result<u32> {
    let header = RecordHeaderFields {
        block_id: entry.block_id,
        block_version: entry.block_version,
        flags: entry.flags,
        sequence: entry.sequence,
        payload_len: entry.payload_len,
        checksum: 0,
        uncompressed_len_hint: entry.uncompressed_len_hint,
    };
    let header_bytes = if spec.integrity_policy == IntegrityPolicy::Crc32WithHeader {
        Some(encode_native_record_header(
            header,
            entry.record_offset,
            record_footer_len(spec),
        )?)
    } else {
        None
    };
    crc32_record_file(
        file,
        entry.payload_offset,
        entry.payload_len,
        header_bytes.as_ref().map(|bytes| &bytes[..]).unwrap_or(&[]),
        checksummed_footer(spec, footer),
    )
}

#[cfg(feature = "integrity")]
fn crc32_record_file(
    file: &mut (impl Read + Seek),
    payload_offset: u64,
    payload_len: u64,
    header: &[u8],
    footer: &[u8],
) -> Result<u32> {
    if payload_len <= 1024 {
        crc32_record_file_buffered::<1024>(file, payload_offset, payload_len, header, footer)
    } else {
        crc32_record_file_buffered::<STREAM_BUFFER_LEN>(
            file,
            payload_offset,
            payload_len,
            header,
            footer,
        )
    }
}

#[cfg(feature = "integrity")]
#[inline(never)]
fn crc32_record_file_buffered<const BUFFER: usize>(
    file: &mut (impl Read + Seek),
    payload_offset: u64,
    payload_len: u64,
    header: &[u8],
    footer: &[u8],
) -> Result<u32> {
    const {
        assert!(BUFFER > 0);
    }
    let mut hasher = crc32fast::Hasher::new();
    hasher.update(header);
    file.seek(SeekFrom::Start(payload_offset))?;
    let mut remaining = payload_len;
    let mut buffer = [0; BUFFER];
    while remaining != 0 {
        let chunk_len = usize::try_from(remaining.min(BUFFER as u64)).map_err(|_| {
            Error::ResourceArithmeticOverflow {
                resource: "checksum buffer length",
            }
        })?;
        file.read_exact(&mut buffer[..chunk_len])?;
        hasher.update(&buffer[..chunk_len]);
        remaining -= chunk_len as u64;
    }
    hasher.update(footer);
    Ok(hasher.finalize())
}

#[cfg(not(feature = "integrity"))]
fn crc32_record_file(
    _file: &mut (impl Read + Seek),
    _payload_offset: u64,
    _payload_len: u64,
    _header: &[u8],
    _footer: &[u8],
) -> Result<u32> {
    Err(Error::IntegrityFeatureDisabled)
}

/// How much of a record footer the checksum covers.
///
/// The whole thing under [`LivenessPolicy::None`], which is what every file
/// written before that policy existed carries. Under
/// [`LivenessPolicy::FooterFlags`] the trailing word is excluded, and that
/// exclusion is the entire mechanism: it is what lets a writer set a flag there
/// afterwards without re-reading the payload to recompute a CRC, and without
/// making every reader that already framed the record disagree with the disk.
///
/// The price, stated once: those four bytes are unauthenticated. A flipped bit
/// in them is not detected by anything, so the flags are advisory — a set flag
/// says "the writer marked this", never "these bytes are sound".
fn checksummed_footer(spec: FormatSpec, footer: &[u8]) -> &[u8] {
    match spec.liveness_policy {
        LivenessPolicy::None => footer,
        LivenessPolicy::FooterFlags => footer
            .len()
            .checked_sub(RECORD_FOOTER_MUTABLE_LEN as usize)
            .map_or(footer, |end| &footer[..end]),
    }
}

fn checksum_record_bytes(
    spec: FormatSpec,
    header: &[u8],
    payload: &[u8],
    footer: &[u8],
) -> Result<u32> {
    match spec.integrity_policy {
        IntegrityPolicy::None => Ok(0),
        IntegrityPolicy::Crc32 => {
            crc32_record_bytes(&[], payload, checksummed_footer(spec, footer))
        }
        IntegrityPolicy::Crc32WithHeader => {
            crc32_record_bytes(header, payload, checksummed_footer(spec, footer))
        }
    }
}

fn write_matrix_sidecar_file<P: AsRef<Path>>(
    spec: FormatSpec,
    category: &str,
    sidecar_path: P,
    generation: u64,
    payload: &[u8],
    identity: MatrixNativeIdentity,
) -> Result<MatrixSidecarManifest> {
    let payload_len =
        u64::try_from(payload.len()).map_err(|_| Error::LengthOverflow { value: u64::MAX })?;
    let format_magic_len =
        u64::try_from(spec.magic.len()).map_err(|_| Error::ResourceArithmeticOverflow {
            resource: "matrix sidecar",
        })?;
    let category_len_u64 =
        u64::try_from(category.len()).map_err(|_| Error::ResourceArithmeticOverflow {
            resource: "matrix sidecar",
        })?;
    crate::matrix::matrix_sidecar_write_len(
        spec,
        MATRIX_SIDECAR_FIXED_LEN as u64,
        format_magic_len,
        category_len_u64,
        payload_len,
    )?;
    let manifest = matrix_sidecar_manifest_for(spec, category, generation, payload, identity)?;
    let magic_len =
        u16::try_from(manifest.format_magic.len()).map_err(|_| Error::InvalidMatrixSidecar)?;
    let category_len =
        u16::try_from(manifest.category.len()).map_err(|_| Error::InvalidMatrixSidecar)?;
    let header_len = MATRIX_SIDECAR_FIXED_LEN
        .checked_add(magic_len as usize)
        .and_then(|len| len.checked_add(category_len as usize))
        .ok_or(Error::ResourceArithmeticOverflow {
            resource: "sidecar header length",
        })?;
    let mut bytes = Vec::new();
    bytes
        .try_reserve_exact(header_len)
        .map_err(|_| Error::AllocationFailed {
            resource: "sidecar header",
            requested: header_len as u64,
        })?;
    bytes.extend_from_slice(MATRIX_SIDECAR_MAGIC);
    bytes.extend_from_slice(&MATRIX_SIDECAR_VERSION.to_le_bytes());
    bytes.extend_from_slice(&0u16.to_le_bytes());
    bytes.extend_from_slice(&manifest.format_version.to_le_bytes());
    bytes.extend_from_slice(&magic_len.to_le_bytes());
    bytes.extend_from_slice(&category_len.to_le_bytes());
    bytes.extend_from_slice(&0u16.to_le_bytes());
    bytes.extend_from_slice(&manifest.schema_hash.to_le_bytes());
    bytes.extend_from_slice(&manifest.generation.to_le_bytes());
    bytes.extend_from_slice(&manifest.payload_len.to_le_bytes());
    bytes.extend_from_slice(&manifest.payload_crc32.to_le_bytes());
    bytes.extend_from_slice(&0u32.to_le_bytes());
    bytes.extend_from_slice(&manifest.native_fingerprint);
    bytes.extend_from_slice(&manifest.matrix_layout_generation.to_le_bytes());
    bytes.extend_from_slice(&manifest.matrix_creation_nonce);
    debug_assert_eq!(bytes.len(), MATRIX_SIDECAR_FIXED_LEN);
    bytes.extend_from_slice(&manifest.format_magic);
    bytes.extend_from_slice(manifest.category.as_bytes());

    // Publish atomically via a same-directory RAII temp: write the full sidecar
    // into a private temp, fsync it, then atomically replace the destination and
    // sync the parent directory. A crash before the replace leaves the previous
    // sidecar untouched; the old in-place `File::create` truncated it eagerly
    // and could expose a partial sidecar (DUR-05).
    let sidecar_path = sidecar_path.as_ref();
    let (temp_path, mut temp_file) = create_rewrite_temp_file(sidecar_path)?;
    let write_result = (|| -> Result<()> {
        temp_file.write_all(&bytes)?;
        temp_file.write_all(payload)?;
        temp_file.flush()?;
        temp_file.sync_all()?;
        Ok(())
    })();
    if let Err(error) = write_result {
        drop(temp_file);
        let _ = remove_file(&temp_path);
        return Err(error);
    }
    drop(temp_file);

    match replace_path_atomically(&temp_path, sidecar_path) {
        Ok(ReplaceDurability::Durable) => Ok(manifest),
        Ok(ReplaceDurability::ParentSyncPending(sync_error)) => {
            // The replacement is already visible at `sidecar_path`; only the
            // parent-directory entry's durability is pending. Do not delete the
            // now-published file, and surface the durability gap so a caller
            // that needs a hard guarantee can react (a regenerable sidecar may
            // simply be rewritten).
            Err(crate::fallible::boxed_path_error(
                sync_error,
                sidecar_path,
                Error::ErrorContextAllocationFailed {
                    context: crate::AllocationFailureContext::ParentSyncPending,
                },
                |path, source| Error::PublishedButParentSyncPending { path, source },
            ))
        }
        Err(error) => Err(preserve_temp_on_indeterminate(&temp_path, error)),
    }
}

fn read_matrix_sidecar_file<P: AsRef<Path>>(
    spec: FormatSpec,
    category: &str,
    sidecar_path: P,
    expected_generation: Option<u64>,
    identity: MatrixNativeIdentity,
) -> Result<(MatrixSidecarManifest, Vec<u8>)> {
    let mut file = File::open(sidecar_path)?;
    let file_len = file.metadata()?.len();
    crate::matrix::check_matrix_sidecar_file_len(spec, file_len)?;
    if file_len < MATRIX_SIDECAR_FIXED_LEN as u64 {
        return Err(Error::InvalidMatrixSidecar);
    }
    let mut fixed = [0; MATRIX_SIDECAR_FIXED_LEN];
    file.read_exact(&mut fixed)?;
    if &fixed[0..4] != MATRIX_SIDECAR_MAGIC {
        return Err(Error::InvalidMatrixSidecar);
    }
    let version = u16::from_le_bytes(fixed[4..6].try_into().expect("slice"));
    if version != MATRIX_SIDECAR_VERSION {
        // A different envelope version (legacy v1 lacked native identity,
        // legacy v2 lacked the matrix creation nonce) is refused as stale and
        // regenerable rather than trusted.
        return Err(Error::MatrixSidecarMismatch("sidecar version"));
    }
    let format_version = u16::from_le_bytes(fixed[8..10].try_into().expect("slice"));
    let flags = u16::from_le_bytes(fixed[6..8].try_into().expect("slice"));
    let magic_len = u64::from(u16::from_le_bytes(fixed[10..12].try_into().expect("slice")));
    let category_len = u64::from(u16::from_le_bytes(fixed[12..14].try_into().expect("slice")));
    let reserved = u16::from_le_bytes(fixed[14..16].try_into().expect("slice"));
    let schema_hash = u64::from_le_bytes(fixed[16..24].try_into().expect("slice"));
    let generation = u64::from_le_bytes(fixed[24..32].try_into().expect("slice"));
    let payload_len = u64::from_le_bytes(fixed[32..40].try_into().expect("slice"));
    let payload_crc32 = u32::from_le_bytes(fixed[40..44].try_into().expect("slice"));
    let trailing_reserved = u32::from_le_bytes(fixed[44..48].try_into().expect("slice"));
    let mut native_fingerprint = [0u8; 32];
    native_fingerprint.copy_from_slice(
        &fixed[MATRIX_SIDECAR_FINGERPRINT_OFFSET..MATRIX_SIDECAR_LAYOUT_GENERATION_OFFSET],
    );
    let matrix_layout_generation = u64::from_le_bytes(
        fixed[MATRIX_SIDECAR_LAYOUT_GENERATION_OFFSET..MATRIX_SIDECAR_CREATION_NONCE_OFFSET]
            .try_into()
            .expect("slice"),
    );
    let mut matrix_creation_nonce = [0u8; MATRIX_CREATION_NONCE_LEN];
    matrix_creation_nonce
        .copy_from_slice(&fixed[MATRIX_SIDECAR_CREATION_NONCE_OFFSET..MATRIX_SIDECAR_FIXED_LEN]);
    let plan = crate::matrix::matrix_sidecar_read_plan(
        spec,
        file_len,
        MATRIX_SIDECAR_FIXED_LEN as u64,
        magic_len,
        category_len,
        payload_len,
        flags,
        reserved,
        trailing_reserved,
    )?;
    // DEF-03: only the small fixed header and the bounded magic/category
    // prefix are read before identity validation. A sidecar that belongs to a
    // different native file, schema, category or generation is rejected here,
    // before the payload is ever allocated, read or hashed.
    file.seek(SeekFrom::Start(plan.format_magic_offset))?;
    let mut format_magic = try_alloc_bytes(magic_len, "sidecar format magic")?;
    file.read_exact(&mut format_magic)?;
    file.seek(SeekFrom::Start(plan.category_offset))?;
    let mut category_bytes = try_alloc_bytes(category_len, "sidecar category")?;
    file.read_exact(&mut category_bytes)?;
    let category_text =
        String::from_utf8(category_bytes).map_err(|_| Error::InvalidMatrixSidecar)?;
    let manifest = MatrixSidecarManifest {
        format_magic,
        format_version,
        schema_hash,
        category: category_text,
        generation,
        payload_len,
        payload_crc32,
        native_fingerprint,
        matrix_layout_generation,
        matrix_creation_nonce,
    };
    validate_matrix_sidecar_manifest(spec, category, expected_generation, identity, &manifest)?;
    file.seek(SeekFrom::Start(plan.payload_offset))?;
    let mut payload = try_alloc_bytes(plan.payload_len, "sidecar payload")?;
    file.read_exact(&mut payload)?;
    let actual = crc32_bytes(&payload)?;
    if actual != payload_crc32 {
        return Err(Error::MatrixSidecarChecksumMismatch {
            expected: payload_crc32,
            actual,
        });
    }
    Ok((manifest, payload))
}

fn try_alloc_bytes(len: u64, resource: &'static str) -> Result<Vec<u8>> {
    let len = usize::try_from(len).map_err(|_| Error::LengthOverflow { value: len })?;
    let mut bytes = Vec::new();
    bytes
        .try_reserve_exact(len)
        .map_err(|_| Error::AllocationFailed {
            resource,
            requested: u64::try_from(len).unwrap_or(u64::MAX),
        })?;
    bytes.resize(len, 0);
    Ok(bytes)
}

fn matrix_sidecar_manifest_for(
    spec: FormatSpec,
    category: &str,
    generation: u64,
    payload: &[u8],
    identity: MatrixNativeIdentity,
) -> Result<MatrixSidecarManifest> {
    if category.is_empty() {
        return Err(Error::InvalidMatrixSidecar);
    }
    let mut format_magic = try_alloc_bytes(
        u64::try_from(spec.magic.len()).map_err(|_| Error::ResourceArithmeticOverflow {
            resource: "matrix sidecar",
        })?,
        "sidecar format magic",
    )?;
    format_magic.copy_from_slice(spec.magic);
    let category_len =
        u64::try_from(category.len()).map_err(|_| Error::ResourceArithmeticOverflow {
            resource: "matrix sidecar",
        })?;
    let mut category_text = String::new();
    category_text
        .try_reserve_exact(category.len())
        .map_err(|_| Error::AllocationFailed {
            resource: "sidecar category",
            requested: category_len,
        })?;
    category_text.push_str(category);
    Ok(MatrixSidecarManifest {
        format_magic,
        format_version: spec.version,
        schema_hash: spec.computed_schema_hash(),
        category: category_text,
        generation,
        payload_len: payload
            .len()
            .try_into()
            .map_err(|_| Error::InvalidMatrixSidecar)?,
        payload_crc32: crc32_bytes(payload)?,
        native_fingerprint: identity.fingerprint,
        matrix_layout_generation: identity.layout_generation,
        matrix_creation_nonce: identity.creation_nonce,
    })
}

fn validate_matrix_sidecar_manifest(
    spec: FormatSpec,
    category: &str,
    expected_generation: Option<u64>,
    identity: MatrixNativeIdentity,
    manifest: &MatrixSidecarManifest,
) -> Result<()> {
    if manifest.format_magic != spec.magic {
        return Err(Error::MatrixSidecarMismatch("format magic"));
    }
    if manifest.format_version != spec.version {
        return Err(Error::MatrixSidecarMismatch("format version"));
    }
    if manifest.schema_hash != spec.computed_schema_hash() {
        return Err(Error::MatrixSidecarMismatch("schema hash"));
    }
    if manifest.category != category {
        return Err(Error::MatrixSidecarMismatch("category"));
    }
    // Bind to a specific native file and its matrix layout: a same-spec,
    // same-generation sibling produces a different OS-object fingerprint and is
    // rejected (DUR-04).
    if manifest.native_fingerprint != identity.fingerprint {
        return Err(Error::MatrixSidecarMismatch("native identity"));
    }
    if manifest.matrix_layout_generation != identity.layout_generation {
        return Err(Error::MatrixSidecarMismatch("matrix layout generation"));
    }
    // Same OS object, schema and layout offsets are not enough: a matrix
    // recreated in the same file object gets a fresh creation nonce, so every
    // sidecar published against the previous logical matrix is refused as
    // stale and regenerable (DUR2-03).
    if manifest.matrix_creation_nonce != identity.creation_nonce {
        return Err(Error::MatrixSidecarMismatch("creation nonce"));
    }
    if let Some(expected_generation) = expected_generation
        && manifest.generation != expected_generation
    {
        return Err(Error::MatrixSidecarMismatch("generation"));
    }
    Ok(())
}

#[cfg(feature = "integrity")]
fn crc32_bytes(payload: &[u8]) -> Result<u32> {
    Ok(crc32fast::hash(payload))
}

#[cfg(not(feature = "integrity"))]
fn crc32_bytes(_payload: &[u8]) -> Result<u32> {
    Err(Error::IntegrityFeatureDisabled)
}

#[cfg(feature = "integrity")]
fn crc32_record_bytes(header: &[u8], payload: &[u8], footer: &[u8]) -> Result<u32> {
    let mut hasher = crc32fast::Hasher::new();
    hasher.update(header);
    hasher.update(payload);
    hasher.update(footer);
    Ok(hasher.finalize())
}

#[cfg(not(feature = "integrity"))]
fn crc32_record_bytes(_header: &[u8], _payload: &[u8], _footer: &[u8]) -> Result<u32> {
    Err(Error::IntegrityFeatureDisabled)
}

#[cfg(test)]
mod tests {
    /// One forward pass must answer exactly what the three walks it replaced
    /// answered, on every shape that tells them apart.
    ///
    /// `derive_index_state` folds `CheckpointCadence::from_index` (a reverse
    /// walk stopping at the newest checkpoint), `SegmentCursor::from_index` (an
    /// `rposition` for the newest segment) and `BlockTails::from_index` (a full
    /// forward pass) into one traversal. The three rules are kept beside it as
    /// `#[cfg(test)]` specifications precisely so this can compare against
    /// them rather than against a restatement of the new code.
    ///
    /// The shapes matter more than the count. An index with no checkpoint and
    /// no segment is the case where both reverse walks degenerate to full
    /// walks; a checkpoint at the very end and one at the very start bracket
    /// the `position / 2` threshold; interleaved commit and segment records are
    /// what separate "eligible" from "seen", since those two ids are the ones
    /// the cadence does not count.
    #[test]
    fn derived_state_matches_the_three_rules_it_replaced() {
        fn entry(block_id: u32, sequence: u64) -> RecordIndexEntry {
            RecordIndexEntry {
                block_id,
                block_version: 1,
                flags: 0,
                sequence,
                record_offset: sequence * 16,
                payload_offset: sequence * 16 + 8,
                payload_len: 8,
                checksum: 0,
                uncompressed_len_hint: 0,
                footer_offset: None,
                prev_same_block_offset: None,
                prev_same_key_offset: None,
                mutable_flags: 0,
                committed: false,
            }
        }
        fn build(ids: &[u32]) -> Vec<RecordIndexEntry> {
            ids.iter()
                .enumerate()
                .map(|(position, id)| entry(*id, position as u64))
                .collect()
        }

        const USER: u32 = 7;
        let shapes: Vec<(&str, Vec<RecordIndexEntry>)> = vec![
            ("empty", build(&[])),
            (
                "no checkpoint, no segment",
                build(&[USER, USER, USER, USER]),
            ),
            ("checkpoint last", build(&[USER, USER, INDEX_BLOCK_ID])),
            (
                "checkpoint first",
                build(&[INDEX_BLOCK_ID, USER, USER, USER]),
            ),
            (
                "two checkpoints, newest wins",
                build(&[INDEX_BLOCK_ID, USER, INDEX_BLOCK_ID, USER, USER]),
            ),
            ("segment only", build(&[USER, SEGMENT_BLOCK_ID, USER])),
            (
                "segment last, so the cursor sits past the end",
                build(&[USER, USER, SEGMENT_BLOCK_ID]),
            ),
            (
                "commit and segment interleaved, neither is eligible",
                build(&[
                    USER,
                    COMMIT_BLOCK_ID,
                    SEGMENT_BLOCK_ID,
                    USER,
                    COMMIT_BLOCK_ID,
                    INDEX_BLOCK_ID,
                    USER,
                    SEGMENT_BLOCK_ID,
                    USER,
                ]),
            ),
        ];

        for (name, index) in shapes {
            let derived = derive_index_state(infallible_entries(&index), true)
                .expect("borrowed entries cannot fail");
            let cadence = CheckpointCadence::from_index(&index);
            assert_eq!(
                derived.checkpoint_cadence.eligible_since_checkpoint,
                cadence.eligible_since_checkpoint,
                "{name}: eligible count diverged from the reverse walk"
            );
            assert_eq!(
                derived.checkpoint_cadence.next_threshold, cadence.next_threshold,
                "{name}: next threshold diverged from the reverse walk"
            );
            let cursor = SegmentCursor::from_index(&index);
            assert_eq!(
                derived.segment_cursor.next_position, cursor.next_position,
                "{name}: segment cursor position diverged from the rposition"
            );
            assert_eq!(
                derived.segment_cursor.covered_start, cursor.covered_start,
                "{name}: segment coverage diverged from the rposition"
            );
            // `BlockTails` is `PartialEq`, so this compares the whole
            // structure — the ordered table as well as the tails — rather than
            // spot-checking ids the fused pass happens to get right.
            assert_eq!(
                derived.block_tails.as_ref().expect("tails were requested"),
                &BlockTails::from_index(&index),
                "{name}: block tails diverged from the forward walk"
            );
        }
    }

    /// What the two sidecar identity windows must stop covering, and what they
    /// must keep covering.
    ///
    /// Both windows hash the file's leading bytes to bind a derived artefact to
    /// the primary. That was sound while the header was written once; the
    /// header tail region makes it false, and without this blanking one commit
    /// would permanently invalidate every published sidecar for the file.
    ///
    /// The relaxation has to be exactly as narrow as that. This asserts three
    /// things a looser version would get wrong: the magic and the declared
    /// length stay in the window (they are what move `append_log_start`, so a
    /// change to either has to keep failing); a block that is *not* mutable is
    /// untouched even when it sits beside one that is; and a caller whose
    /// window ends inside the region blanks what it holds rather than
    /// overrunning or refusing.
    #[test]
    fn blanking_covers_the_mutable_payload_and_nothing_else() {
        const PAYLOAD_LEN: usize = 40;
        const HEADER_PREAMBLE: usize = 20;
        let mut extensions = Vec::new();
        // `VCHD` first: it predates the framing and carries no length prefix,
        // so it also checks that the walk's offsets survive a block of a
        // different shape sitting in front of the mutable one.
        extensions.extend_from_slice(FILE_COMPRESSION_MAGIC);
        extensions.extend_from_slice(&[0x11; FILE_COMPRESSION_PAYLOAD_LEN]);
        let vchd_len = extensions.len();
        extensions.extend_from_slice(HEADER_TAILS_MAGIC);
        extensions.extend_from_slice(&(PAYLOAD_LEN as u32).to_le_bytes());
        extensions.extend_from_slice(&[0x22; PAYLOAD_LEN]);
        // And a block *after* the mutable one, which the walk skips because it
        // does not know the magic. Without it the mutable payload runs to the
        // end of the region and "everything after it is untouched" asserts over
        // an empty slice — true of any implementation, including one that
        // blanked to the end.
        const TRAILING_LEN: usize = 12;
        extensions.extend_from_slice(b"VZZZ");
        extensions.extend_from_slice(&(TRAILING_LEN as u32).to_le_bytes());
        extensions.extend_from_slice(&[0x33; TRAILING_LEN]);

        let header_len = (HEADER_PREAMBLE + extensions.len()) as u64;
        let payload_start = HEADER_PREAMBLE + vchd_len + 8;
        assert!(
            payload_start + PAYLOAD_LEN < header_len as usize,
            "the assertion below has to have bytes to be about",
        );

        let mut prefix = vec![0xAAu8; header_len as usize];
        let blanked = blank_mutable_header_bytes(&mut prefix, header_len, &extensions)
            .expect("a well-framed region blanks");
        assert_eq!(blanked, PAYLOAD_LEN as u64);
        assert!(
            prefix[payload_start..payload_start + PAYLOAD_LEN]
                .iter()
                .all(|byte| *byte == 0),
            "the mutable payload is blanked",
        );
        assert!(
            prefix[..payload_start].iter().all(|byte| *byte == 0xAA),
            "everything before it — including `VBTT`'s own magic and declared \
             length — stays in the window",
        );
        assert!(
            prefix[payload_start + PAYLOAD_LEN..]
                .iter()
                .all(|byte| *byte == 0xAA),
            "and everything after it",
        );

        // A window that stops inside the region blanks its own tail and no more.
        let short = payload_start + 5;
        let mut clipped = vec![0xAAu8; short];
        let blanked = blank_mutable_header_bytes(&mut clipped, header_len, &extensions)
            .expect("a clipped window is not an error");
        assert_eq!(blanked, 5);
        assert!(clipped[payload_start..].iter().all(|byte| *byte == 0));

        // A window that ends before the region touches nothing.
        let mut early = vec![0xAAu8; HEADER_PREAMBLE];
        assert_eq!(
            blank_mutable_header_bytes(&mut early, header_len, &extensions).expect("no overrun"),
            0,
        );
        assert!(early.iter().all(|byte| *byte == 0xAA));

        // A region with no mutable block is left exactly as it is.
        let immutable = &extensions[..vchd_len];
        assert!(!immutable.is_empty());
        let header_len = (HEADER_PREAMBLE + immutable.len()) as u64;
        let mut untouched = vec![0xAAu8; header_len as usize];
        assert_eq!(
            blank_mutable_header_bytes(&mut untouched, header_len, immutable).expect("no block"),
            0,
        );
        assert!(untouched.iter().all(|byte| *byte == 0xAA));
    }

    use super::*;
    // Only the fixtures below need it, so importing it at module scope
    // would be an unused import in the non-test build — which is what it
    // became when `_descriptor_for` was deleted as dead.
    use crate::format::BlockDescriptor;
    use crate::{VarlitDecode, VarlitEncode};

    /// One index entry for a record of `payload_len` bytes at `record_offset`,
    /// with no footer, as a checkpoint would hold it.
    fn checkpoint_test_entry(record_offset: u64, payload_len: u64) -> RecordIndexEntry {
        RecordIndexEntry {
            block_id: 7,
            block_version: 1,
            flags: 0,
            sequence: record_offset,
            record_offset,
            payload_offset: record_offset + RECORD_HEADER_LEN,
            payload_len,
            checksum: 0,
            uncompressed_len_hint: 0,
            footer_offset: None,
            prev_same_block_offset: None,
            prev_same_key_offset: None,
            mutable_flags: 0,
            committed: true,
        }
    }

    fn checkpoint_record_at(record_offset: u64) -> RecordIndexEntry {
        let mut entry = checkpoint_test_entry(record_offset, 0);
        entry.block_id = INDEX_BLOCK_ID;
        entry
    }

    // The records a checkpoint covers are contiguous, and the predicate used to
    // compare `record_offset < previous_offset`. That accepts a *gap*: a
    // one-entry checkpoint could name `covered_offset` far past the record it
    // listed, and every record in between is on disk, absent from the
    // checkpoint, and therefore absent from `index_entries()` and from every
    // typed read.
    #[test]
    fn a_checkpoint_that_skips_records_is_refused() {
        let header_len = 32;
        let first = checkpoint_test_entry(header_len, 8);
        let skipped = checkpoint_test_entry(first.physical_end(), 8);
        let record = checkpoint_record_at(skipped.physical_end());

        let contiguous = IndexCheckpoint {
            covered_offset: record.record_offset,
            entries: vec![first.clone(), skipped.clone()],
        };
        assert!(
            validate_index_checkpoint(
                header_len,
                record.physical_end(),
                &record,
                &contiguous,
                contiguous.entries.len(),
                contiguous.entries.iter(),
            )
            .is_ok(),
            "a checkpoint that tiles its coverage must still validate",
        );

        // The same file, with the middle record simply left out. The observed
        // prefix is what the scan saw, so it agrees with the checkpoint - the
        // hole is only visible as an offset gap.
        let with_gap = IndexCheckpoint {
            covered_offset: record.record_offset,
            entries: vec![first.clone()],
        };
        assert!(matches!(
            validate_index_checkpoint(
                header_len,
                record.physical_end(),
                &record,
                &with_gap,
                with_gap.entries.len(),
                with_gap.entries.iter(),
            ),
            Err(Error::InvalidIndexCheckpoint),
        ));
    }

    // The same hole, moved to the far end: every entry is contiguous, and the
    // checkpoint simply stops before its own record. Only the terminal
    // `previous_offset == covered_offset` catches this one.
    #[test]
    fn a_checkpoint_that_stops_short_of_its_coverage_is_refused() {
        let header_len = 32;
        let first = checkpoint_test_entry(header_len, 8);
        let trailing = checkpoint_test_entry(first.physical_end(), 8);
        let record = checkpoint_record_at(trailing.physical_end());

        let short = IndexCheckpoint {
            covered_offset: record.record_offset,
            entries: vec![first.clone()],
        };
        assert!(matches!(
            validate_index_checkpoint(
                header_len,
                record.physical_end(),
                &record,
                &short,
                short.entries.len(),
                short.entries.iter(),
            ),
            Err(Error::InvalidIndexCheckpoint),
        ));
    }

    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    struct MatrixTestCell {
        value: u32,
    }

    impl VarlitEncode for MatrixTestCell {
        const WIRE_TYPE: crate::WireType = crate::WireType::U32;

        fn encode_varlit(&self, encoder: &mut crate::Encoder) -> Result<()> {
            self.value.encode_varlit(encoder)
        }
    }

    impl VarlitDecode for MatrixTestCell {
        const WIRE_TYPE: crate::WireType = crate::WireType::U32;

        fn decode_varlit(decoder: &mut crate::Decoder<'_>) -> Result<Self> {
            Ok(Self {
                value: u32::decode_varlit(decoder)?,
            })
        }
    }

    impl VarlitBlock for MatrixTestCell {
        const ID: u32 = 41;
        const VERSION: u16 = 1;
        const KIND: BlockKind = BlockKind::Matrix;
        const ENDIAN: Option<Endian> = None;
        const IS_KEYED: bool = false;
        const SCHEMA_FINGERPRINT: u64 = 0x4649_4C45_0000_0029;
    }

    impl VarlitMatrixBlock for MatrixTestCell {
        const DIMENSIONS: [&'static str; 2] = ["scan", "ch"];
        const CATEGORY: &'static str = "cells";
        const SLOT_STRIDE: u64 = 4;
    }

    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    struct ReplaceTestBlock {
        value: u64,
    }

    impl VarlitEncode for ReplaceTestBlock {
        const WIRE_TYPE: crate::WireType = crate::WireType::U64;

        fn encode_varlit(&self, encoder: &mut crate::Encoder) -> Result<()> {
            self.value.encode_varlit(encoder)
        }
    }

    impl VarlitDecode for ReplaceTestBlock {
        const WIRE_TYPE: crate::WireType = crate::WireType::U64;

        fn decode_varlit(decoder: &mut crate::Decoder<'_>) -> Result<Self> {
            Ok(Self {
                value: u64::decode_varlit(decoder)?,
            })
        }
    }

    impl VarlitBlock for ReplaceTestBlock {
        const ID: u32 = 42;
        const VERSION: u16 = 1;
        const KIND: BlockKind = BlockKind::Fixed;
        const ENDIAN: Option<Endian> = None;
        const IS_KEYED: bool = false;
        const SCHEMA_FINGERPRINT: u64 = 0x4649_4C45_0000_002A;
    }

    impl VarlitReplaceBlock for ReplaceTestBlock {
        fn validate_replacement(_old: &Self, _new: &Self) -> Result<()> {
            Ok(())
        }
    }

    /// The digest's sequence mark counts the digest record itself.
    ///
    /// `Available(next)` means `next` is the number the digest is about to
    /// take, so the mark once it is down is `next`. Storing `next - 1` reported
    /// the digest's own sequence as unused, and a writer seeded from that
    /// digest would hand it out a second time. The encode/decode pair is the
    /// whole of what can be checked here without a writer, and it is where the
    /// off-by-one lived.
    #[test]
    fn a_digest_sequence_mark_survives_the_round_trip_including_the_last_number() {
        for mark in [
            None,
            Some(0u64),
            Some(1),
            Some(u64::MAX - 1),
            Some(u64::MAX),
        ] {
            let payload =
                encode_digest_payload(test_spec(), mark, &[(7, 128)], 4096).expect("encode digest");
            let decoded = decode_digest_payload(&payload, 64, 4096, 4200).expect("decode digest");
            assert_eq!(
                decoded.sequence_high_water, mark,
                "a mark of {mark:?} did not survive the round trip"
            );
        }
    }

    /// `u64::MAX` is a real mark, not the absence of one.
    ///
    /// It used to be the sentinel for "no mark", which made the two
    /// indistinguishable on the wire and left `SequenceState::Exhausted`
    /// unrepresentable — the decode arm that maps it was unreachable.
    #[test]
    fn the_last_sequence_number_is_not_the_absence_of_one() {
        let spec = test_spec();
        let present =
            encode_digest_payload(spec, Some(u64::MAX), &[(7, 128)], 4096).expect("encode present");
        let absent = encode_digest_payload(spec, None, &[(7, 128)], 4096).expect("encode absent");
        assert_ne!(present, absent, "a real u64::MAX mark encodes as no mark");
        assert_eq!(
            decode_digest_payload(&present, 64, 4096, 4200)
                .expect("decode")
                .sequence_high_water,
            Some(u64::MAX)
        );
        assert_eq!(
            decode_digest_payload(&absent, 64, 4096, 4200)
                .expect("decode")
                .sequence_high_water,
            None
        );
    }

    /// A flag this build does not define means the writer meant more by this
    /// record than this build knows, so it is answered with the scan rather
    /// than half-understood. The field was written as zero and never read,
    /// which foreclosed exactly this evolution path.
    #[test]
    fn a_digest_with_an_unknown_flag_is_refused() {
        let mut payload =
            encode_digest_payload(test_spec(), Some(9), &[(7, 128)], 4096).expect("encode digest");
        payload[6..8].copy_from_slice(&(DIGEST_FLAGS_KNOWN | 0x0002).to_le_bytes());
        assert!(matches!(
            decode_digest_payload(&payload, 64, 4096, 4200),
            Err(Error::InvalidIndexSegment)
        ));
    }

    #[derive(Clone, Debug, PartialEq, Eq)]
    struct ReplaceString(String);

    impl VarlitEncode for ReplaceString {
        const WIRE_TYPE: crate::WireType = crate::WireType::String;

        fn encode_varlit(&self, encoder: &mut crate::Encoder) -> Result<()> {
            self.0.encode_varlit(encoder)
        }
    }

    impl VarlitDecode for ReplaceString {
        const WIRE_TYPE: crate::WireType = crate::WireType::String;

        fn decode_varlit(decoder: &mut crate::Decoder<'_>) -> Result<Self> {
            Ok(Self(String::decode_varlit(decoder)?))
        }
    }

    impl VarlitBlock for ReplaceString {
        const ID: u32 = 43;
        const VERSION: u16 = 1;
        const KIND: BlockKind = BlockKind::Variable;
        const ENDIAN: Option<Endian> = None;
        const IS_KEYED: bool = false;
        const SCHEMA_FINGERPRINT: u64 = 0x4649_4C45_0000_002B;
    }

    impl VarlitReplaceBlock for ReplaceString {
        fn validate_replacement(_old: &Self, _new: &Self) -> Result<()> {
            Ok(())
        }
    }

    #[derive(Clone, Debug, PartialEq, Eq)]
    struct ReplaceKeyed {
        key: u64,
        value: String,
    }

    impl VarlitEncode for ReplaceKeyed {
        const WIRE_TYPE: crate::WireType = <(u64, String) as VarlitEncode>::WIRE_TYPE;

        fn encode_varlit(&self, encoder: &mut crate::Encoder) -> Result<()> {
            (self.key, self.value.clone()).encode_varlit(encoder)
        }
    }

    impl VarlitDecode for ReplaceKeyed {
        const WIRE_TYPE: crate::WireType = <(u64, String) as VarlitDecode>::WIRE_TYPE;

        fn decode_varlit(decoder: &mut crate::Decoder<'_>) -> Result<Self> {
            let (key, value) = <(u64, String)>::decode_varlit(decoder)?;
            Ok(Self { key, value })
        }
    }

    impl VarlitBlock for ReplaceKeyed {
        const ID: u32 = 44;
        const VERSION: u16 = 1;
        const KIND: BlockKind = BlockKind::Variable;
        const ENDIAN: Option<Endian> = None;
        const IS_KEYED: bool = true;
        const SCHEMA_FINGERPRINT: u64 = 0x4649_4C45_0000_002C;
    }

    impl VarlitKeyedBlock for ReplaceKeyed {
        type Key = u64;

        fn key(&self) -> Self::Key {
            self.key
        }
    }

    impl VarlitReplaceBlock for ReplaceKeyed {
        fn validate_replacement(old: &Self, new: &Self) -> Result<()> {
            if old.key == new.key {
                Ok(())
            } else {
                Err(Error::ReplacementKeyMismatch)
            }
        }
    }

    /// A format with one declared block kept out of the resident index, and the
    /// footer chain that makes it reachable.
    /// A failed write must leave the chunk where it was.
    ///
    /// `write_open_chunk_record` `take()`d the chunk and *then* ran three fallible
    /// steps, so any failure destroyed the data and emptied `open_chunk` — and
    /// the retry a caller would naturally make returned `Ok(())` for a chunk
    /// that no longer existed anywhere. Silent loss reported as success.
    ///
    /// **The state is constructed rather than reached through the API, and the
    /// reason is worth stating.** The reachable way to make a write fail was a
    /// record payload ceiling below the chunk's written size, and `create` now
    /// refuses that pairing outright — fixing a different defect closed the
    /// public route to this one. `a_chunk_that_could_never_be_written_is_refused_at_create`
    /// covers the refusal; this covers what happens if a write fails anyway,
    /// which an I/O error still can.
    #[test]
    fn a_failed_chunk_write_keeps_the_chunk() {
        let spec = residency_test_spec();
        let dir = tempfile::tempdir().expect("temp dir");
        let path = dir.path().join("chunk-write.varlit");
        let mut file = VarlitFile::create(spec, &path).expect("create");

        file.open_chunk = Some(OpenChunk {
            index: 1,
            first_row: 4,
            rows: 4,
            compression: None,
            blocks: vec![OpenChunkBlock {
                block_id: 900,
                stride: 4,
                cells: 32,
                written: vec![0xFF; 4],
                commit: vec![0xFF; 4],
                crc: Vec::new(),
                slots: vec![7; 128],
            }],
            dirty: true,
            backing: None,
        });

        // A ceiling the encoded chunk cannot fit under.
        file.spec = file
            .spec
            .with_read_limits(file.spec.read_limits.with_max_record_payload_len(16));

        assert!(matches!(
            file.write_open_chunk_record(),
            Err(Error::LimitExceeded { .. })
        ));
        assert!(
            file.open_chunk.is_some(),
            "a failed chunk write must leave the chunk where it was",
        );
        // The retry reports the same failure rather than Ok.
        assert!(matches!(
            file.write_open_chunk_record(),
            Err(Error::LimitExceeded { .. })
        ));

        // Let it succeed, and confirm the chunk is released exactly once.
        //
        // Released, even though a written chunk is normally *retained* now —
        // retention is what preserves the write bitmap across a flush. This
        // fixture builds an `OpenChunk` by hand on a spec that declares no
        // growing matrix, so no chunk directory exists and the record it just
        // wrote has no ordinal to be addressed by later. A retained chunk with
        // no `backing` would append a *second* record for its index on the next
        // edit, so the no-ordinal case releases instead: the write bitmap is
        // worth less than the guarantee that a duplicate cannot be produced.
        file.spec = file
            .spec
            .with_read_limits(file.spec.read_limits.with_max_record_payload_len(u64::MAX));
        file.write_open_chunk_record().expect("write the chunk");
        assert!(file.open_chunk.is_none());
    }

    fn digest_test_spec() -> FormatSpec {
        const BLOCKS: &[BlockDescriptor] = &[BlockDescriptor {
            id: 12,
            name: "line",
            version: 1,
            kind: BlockKind::Variable,
            fields: &[],
        }];
        let spec = FormatSpec::new(
            b"VSDIG",
            1,
            Endian::Little,
            0,
            IndexPolicy::BlockOffsetChain,
            IntegrityPolicy::None,
            RecoveryPolicy::Strict,
            ManifestPolicy::None,
            BLOCKS,
        )
        .with_read_limits(crate::ReadLimits::finite_all(u64::MAX));
        spec.with_index_policy(spec.index_policy.with_open_digest_on_flush(true))
    }

    /// The two open routes must agree on what sequence the next append takes.
    ///
    /// This is the assertion the encode/decode round trip cannot make, and it
    /// is where the off-by-one actually lived: the digest stored the high-water
    /// mark as it stood *before* its own record, so a digest open reported the
    /// digest's own sequence as still unused. The scan open frames that record
    /// like any other and counts it.
    ///
    /// Latent today only because the digest route builds read-only handles;
    /// the day a writer is seeded from a digest it is a sequence handed out
    /// twice. Pinned here rather than left to that day.
    #[test]
    fn the_digest_route_and_the_scan_route_agree_on_the_next_sequence() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("digest-sequence.varlit");
        let mut file = VarlitFile::create(digest_test_spec(), &path)?;
        for _ in 0..4 {
            file.push_info_for_test(12, b"row")?;
        }
        file.flush()?;
        drop(file);

        let scanned = VarlitFile::open_readonly(digest_test_spec(), &path)?;
        let (lazy, source) = VarlitFile::open_readonly_lazy_with_report(digest_test_spec(), &path)?;
        assert_eq!(
            source,
            LazyOpenSource::Digest,
            "the fixture fell back to the scan, so this case compares nothing",
        );
        assert_eq!(
            lazy.sequence_state, scanned.sequence_state,
            "the digest open disagrees with the scan on the next sequence",
        );
        Ok(())
    }

    /// The append path issues no `lseek` per record either.
    ///
    /// `an_append_window_issues_no_metadata_syscall` pins the `fstat` half and
    /// counts `metadata` only, so the `stream_position` the `AppendSnapshot`
    /// took for its rollback cursor — an `lseek`, once per record — was
    /// invisible to it. Nothing takes it now: the rollback restores
    /// `AppendSnapshot::eof`, which the append already holds.
    ///
    /// Measured at 1,000 records: **2,000 seeks before, 1,000 after.** The one
    /// that remains is `append_record_at_end`'s own `seek(SeekFrom::End(0))`,
    /// which is the check that refuses an append at any offset but the end and
    /// is deliberately kept — removing it is the positional-write redesign, as
    /// the comment there says. What went is the second one.
    ///
    /// It first went by being *cached* rather than dropped, and this doc
    /// carried the reason: the cursor and `eof` are not always the same number,
    /// because a reopen's scan leaves the handle where it stopped reading
    /// (measured 5493) while `eof` is the committed end (9143). That reason was
    /// sound and the cache was not — the offset belongs to a file description
    /// `VarlitFile::snapshot` shares and seeks (see `RecordFile`). What the
    /// difference actually costs is one cold-path behaviour: a rollback of the
    /// *first* append after an open now leaves the handle at the end of file
    /// instead of at 5493. Nothing reads this handle sequentially — every
    /// append seeks `SEEK_END`, every rewrite seeks its own offset, every read
    /// is positional — so the restored offset is a tidiness property, and the
    /// end of file is the tidier of the two.
    #[cfg(feature = "scalable-fault-injection")]
    #[test]
    fn an_append_window_issues_no_seek_per_record() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("append-seeks.varlit");
        let mut file = VarlitFile::create(test_spec(), &path)?;

        file.push_info_for_test(12, b"warm")?;
        let _ = VarlitFile::take_record_file_seeks();

        const RECORDS: u64 = 1_000;
        for _ in 0..RECORDS {
            file.push_info_for_test(12, b"row")?;
        }
        let seeks = VarlitFile::take_record_file_seeks();
        assert!(
            seeks <= RECORDS,
            "the append window issued {seeks} seeks for {RECORDS} records; the per-record \
             `stream_position` is back",
        );
        Ok(())
    }

    /// The writer half of the lazy open: no scan, and it can still append.
    ///
    /// Every other writer open calls `load_index` with `ScanIntent::Writer`, so
    /// it frames every record in the file — at any size. The framing count is
    /// the assertion because it is the cost: `records_framed` counts what the
    /// scan does and the digest route does not.
    #[cfg(feature = "scalable-fault-injection")]
    #[test]
    fn a_lazy_writer_open_frames_no_record_and_still_appends() -> Result<()> {
        let spec = digest_test_spec();
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("lazy-writer.varlit");
        let mut file = VarlitFile::create(spec, &path)?;
        for _ in 0..200 {
            file.push_info_for_test(12, b"row")?;
        }
        file.flush()?;
        drop(file);

        let before = VarlitFile::records_framed();
        let scanned = VarlitFile::open(spec, &path)?;
        let scan_frames = VarlitFile::records_framed() - before;
        drop(scanned);
        assert!(
            scan_frames >= 200,
            "the scanning writer open framed {scan_frames} records, so this case measures nothing",
        );

        let before = VarlitFile::records_framed();
        let (mut lazy, source) = VarlitFile::open_lazy_with_report(spec, &path)?;
        let lazy_frames = VarlitFile::records_framed() - before;
        assert_eq!(source, LazyOpenSource::Digest);
        assert_eq!(
            lazy_frames, 1,
            "the lazy writer open frames the digest record and nothing else",
        );

        // And it is a writer: the append path takes the sequence and the tail
        // the digest supplied, so the record lands where the scan says it does.
        let info = lazy.push_info_for_test(12, b"appended")?;
        lazy.flush()?;
        drop(lazy);

        let after = VarlitFile::open_readonly(spec, &path)?;
        assert_eq!(
            after.block_tail_offset(12),
            Some(info.record_offset),
            "the record appended through the lazy writer is not the block's newest",
        );
        // 200 records took 0..=199 and the digest took 200 — counting its own
        // sequence is what F1 fixed. A lazy writer seeded from a digest that
        // still reported 199 would hand out 200 a second time, which is the
        // reuse that fix was latent for until this open existed.
        assert_eq!(
            info.sequence, 201,
            "the lazy writer did not continue the digest's sequence"
        );
        Ok(())
    }

    /// The two index policies a lazy writer cannot serve are refused at open.
    ///
    /// Both records serialize the resident index this handle does not keep, so
    /// writing nothing would leave a file that opens slower than its spec says.
    #[test]
    fn a_lazy_writer_refuses_the_policies_it_cannot_serve() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("lazy-writer-policy.varlit");
        let base = digest_test_spec();
        VarlitFile::create(base, &path)?.flush()?;

        let checkpointing =
            base.with_index_policy(base.index_policy.with_checkpoint_on_flush(true));
        assert!(matches!(
            VarlitFile::open_lazy(checkpointing, &path),
            Err(Error::LazyWriterIndexPolicy {
                policy: "checkpoint_on_flush"
            })
        ));

        // `segment_on_flush` needs crc32, and the base spec here declares no
        // integrity — without this the spec is refused by `validate` before the
        // check under test is reached, which is how the first version of this
        // case passed for the wrong reason.
        let segmenting = base
            .with_integrity_policy(IntegrityPolicy::Crc32)
            .with_index_policy(base.index_policy.with_segment_on_flush(true));
        assert!(matches!(
            VarlitFile::open_lazy(segmenting, &path),
            Err(Error::LazyWriterIndexPolicy {
                policy: "segment_on_flush"
            })
        ));
        Ok(())
    }

    /// A file whose every block is non-resident gets a digest at all.
    ///
    /// The guard was `self.index.is_empty()` — "nothing written yet", measured
    /// on the resident index. Declare every block non-resident and that index
    /// is empty forever, so the file never got a *first* digest however much
    /// was appended to it. The irony is exact: a non-resident block gives up
    /// the resident directory and reaches its records through the block offset
    /// chain instead, and the head of that chain is what the digest carries.
    /// The option was inert for the one file it exists to serve.
    ///
    /// Asserted through `_with_report` rather than by counting bytes, because
    /// the symptom is silent — the fallback scan returns exactly the right
    /// answer, just after framing every record in the file.
    #[test]
    fn an_all_non_resident_file_still_gets_a_digest() -> Result<()> {
        const RESIDENCY: &[crate::BlockResidencyDescriptor] = &[crate::BlockResidencyDescriptor {
            block_id: 12,
            resident: false,
        }];
        let spec = digest_test_spec().with_block_residency(RESIDENCY);

        let directory = tempfile::tempdir()?;
        let path = directory.path().join("digest-all-non-resident.varlit");
        let mut file = VarlitFile::create(spec, &path)?;
        for _ in 0..4 {
            file.push_info_for_test(12, b"row")?;
        }
        file.flush()?;
        drop(file);

        let (lazy, source) = VarlitFile::open_readonly_lazy_with_report(spec, &path)?;
        assert_eq!(
            source,
            LazyOpenSource::Digest,
            "a file with no resident block never wrote a digest",
        );
        // And the digest is worth having here: the tail is the only way in.
        assert!(
            lazy.block_tail_offset(12).is_some(),
            "the digest carried no tail for the only block in the file",
        );
        Ok(())
    }

    /// A non-resident append still earns a fresh digest.
    ///
    /// `needs_open_digest` answered "is the last thing in this file already a
    /// digest" with `last_resident_block_id`, which a non-resident append does
    /// not move. So after one digest, appending only non-resident records wrote
    /// no further digest — and those records put the old digest out of last
    /// place, which is the one thing that makes it unusable. Every
    /// `open_readonly_lazy` from then on silently took the full scan.
    ///
    /// Silent is the operative word: the answer stays correct, the cost does
    /// not, and the tail table the digest carries exists precisely to reach
    /// non-resident blocks. `_with_report` is what makes it assertable.
    ///
    /// The fixture is deliberately *mixed* — one resident block, one not —
    /// because an all-non-resident file exposes a second, separate gap this
    /// case is not about: `needs_open_digest` also returns early on
    /// `self.index.is_empty()`, and a file whose every block is non-resident
    /// has an empty resident index, so it never gets a first digest at all.
    /// That one is recorded, not fixed here.
    #[test]
    fn a_non_resident_append_still_earns_a_new_digest() -> Result<()> {
        const BLOCKS: &[BlockDescriptor] = &[
            BlockDescriptor {
                id: 12,
                name: "line",
                version: 1,
                kind: BlockKind::Variable,
                fields: &[],
            },
            BlockDescriptor {
                id: 13,
                name: "mark",
                version: 1,
                kind: BlockKind::Variable,
                fields: &[],
            },
        ];
        const RESIDENCY: &[crate::BlockResidencyDescriptor] = &[crate::BlockResidencyDescriptor {
            block_id: 12,
            resident: false,
        }];
        let spec = FormatSpec::new(
            b"VSDGN",
            1,
            Endian::Little,
            0,
            IndexPolicy::BlockOffsetChain,
            IntegrityPolicy::None,
            RecoveryPolicy::Strict,
            ManifestPolicy::None,
            BLOCKS,
        )
        .with_read_limits(crate::ReadLimits::finite_all(u64::MAX))
        .with_block_residency(RESIDENCY);
        let spec = spec.with_index_policy(spec.index_policy.with_open_digest_on_flush(true));

        let directory = tempfile::tempdir()?;
        let path = directory.path().join("digest-non-resident.varlit");
        let mut file = VarlitFile::create(spec, &path)?;
        // A resident record first, so there is a digest for the non-resident
        // appends to leave behind.
        file.push_info_for_test(13, b"resident")?;
        file.flush()?;

        for _ in 0..3 {
            file.push_info_for_test(12, b"more")?;
        }
        file.flush()?;
        drop(file);

        let (_lazy, source) = VarlitFile::open_readonly_lazy_with_report(spec, &path)?;
        assert_eq!(
            source,
            LazyOpenSource::Digest,
            "the second flush wrote no digest, so the lazy open fell back to the scan",
        );
        Ok(())
    }

    fn residency_test_spec() -> FormatSpec {
        const BLOCKS: &[BlockDescriptor] = &[BlockDescriptor {
            id: 12,
            name: "line",
            version: 1,
            kind: BlockKind::Variable,
            fields: &[],
        }];
        const RESIDENCY: &[crate::BlockResidencyDescriptor] = &[crate::BlockResidencyDescriptor {
            block_id: 12,
            resident: false,
        }];
        FormatSpec::new(
            b"VSRES",
            1,
            Endian::Little,
            0,
            IndexPolicy::BlockOffsetChain,
            IntegrityPolicy::None,
            RecoveryPolicy::Strict,
            ManifestPolicy::None,
            BLOCKS,
        )
        .with_block_residency(RESIDENCY)
        .with_read_limits(crate::ReadLimits::finite_all(u64::MAX))
    }

    // §5.4. A rolled-back append of a non-resident record must leave nothing
    // behind: the file length, the sequence and - the part residency makes
    // load-bearing - the block tail, which is the only way back to that block's
    // records.
    //
    // This does *not* exercise `BlockTails::restore`. Both rollback points sit
    // above `block_tails.note_appended`, so a rollback always finds the tail
    // where it started; the restore is unreachable and is kept for the ordering
    // rather than for today. Reverting it to the old rebuild-from-index, or
    // deleting it outright, leaves this test green, and that is recorded rather
    // than papered over.
    #[test]
    fn a_rolled_back_non_resident_append_leaves_the_tail_alone() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("residency-rollback.varlit");
        let mut file = VarlitFile::create(residency_test_spec(), &path)?;

        file.write_record(12, 1, 0, b"first")?;
        let tail_before = file.block_tails.tail(12);
        assert!(
            tail_before.is_some(),
            "the tail is published for a non-resident block"
        );
        assert!(file.index.is_empty(), "and nothing is resident");
        let len_before = file.file.metadata()?.len();
        let sequence_before = file.sequence_state;

        inject_write_fault(WriteFault::AppendAfterHeader);
        assert!(matches!(
            file.write_record(12, 1, 0, b"rolled back"),
            Err(Error::Io(_))
        ));

        assert_eq!(
            file.block_tails.tail(12),
            tail_before,
            "the rolled-back record must not stay reachable through the tail",
        );
        assert_eq!(file.file.metadata()?.len(), len_before);
        assert_eq!(file.sequence_state, sequence_before);
        assert!(!file.poison.is_refusing());

        // The next append chains onto the surviving record, not the ghost.
        let info = file.push_info_for_test(12, b"second")?;
        assert_eq!(info.prev_same_block_offset, tail_before);
        Ok(())
    }

    // The first append of a block publishes no tail if it rolls back, so the
    // next surviving record is still the head of the chain.
    #[test]
    fn a_rolled_back_first_append_leaves_no_tail() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("residency-first.varlit");
        let mut file = VarlitFile::create(residency_test_spec(), &path)?;
        assert_eq!(file.block_tails.tail(12), None);

        inject_write_fault(WriteFault::AppendAfterHeader);
        assert!(matches!(
            file.write_record(12, 1, 0, b"x"),
            Err(Error::Io(_))
        ));
        assert_eq!(
            file.block_tails.tail(12),
            None,
            "a rollback of the first append must leave no tail behind",
        );

        let info = file.push_info_for_test(12, b"real")?;
        assert_eq!(
            info.prev_same_block_offset, None,
            "the first surviving record names no predecessor",
        );
        Ok(())
    }

    #[test]
    fn serialized_directory_cannot_authorize_marking_an_embedded_record() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let spec = test_spec()
            .with_index_policy(IndexPolicy::BlockOffsetChain)
            .with_liveness_policy(LivenessPolicy::FooterFlags);
        let donor_path = directory.path().join("donor");
        let mut donor = VarlitFile::create(spec, &donor_path)?;
        let embedded = donor.push_info_for_test(10, b"value")?;
        let bytes = std::fs::read(&donor_path)?;
        let bytes = &bytes[embedded.record_offset as usize..];
        let path = directory.path().join("outer");
        let mut writer = VarlitFile::create(spec, &path)?;
        let outer = writer.push_info_for_test(10, bytes)?;
        let fake = fault_record_entry(&writer.snapshot, spec, outer.payload_offset, false)?;
        // Model a serialized segment claiming the embedded header is a record.
        writer.index = ResidentIndex::adopt_generation(
            &vec![fake],
            writer.snapshot.clone(),
            spec,
            false,
        )?;
        let before = std::fs::read(&path)?;
        assert!(matches!(
            writer.mark_record_dead(outer.payload_offset),
            Err(Error::InvalidCanonicalEncoding(_))
        ));
        assert_eq!(std::fs::read(&path)?, before);
        assert!(matches!(
            writer.defragment(),
            Err(Error::InvalidCanonicalEncoding(_))
        ));
        assert_eq!(std::fs::read(&path)?, before);
        writer.mark_record_dead(outer.record_offset)?;
        assert!(writer.record_is_dead(outer.record_offset)?);
        Ok(())
    }

    fn test_spec() -> FormatSpec {
        FormatSpec::new(
            b"VSTEST",
            1,
            Endian::Little,
            0,
            IndexPolicy::ScanOnOpen,
            IntegrityPolicy::None,
            RecoveryPolicy::Strict,
            ManifestPolicy::None,
            &[],
        )
        .with_read_limits(crate::ReadLimits::finite_all(u64::MAX))
    }

    fn matrix_test_spec() -> FormatSpec {
        static BLOCKS: &[BlockDescriptor] = &[BlockDescriptor {
            id: MatrixTestCell::ID,
            name: "MatrixTestCell",
            version: MatrixTestCell::VERSION,
            kind: BlockKind::Matrix,
            fields: MatrixTestCell::FIELDS,
        }];
        static DIMENSIONS: &[crate::MatrixDimensionDescriptor] = &[
            crate::MatrixDimensionDescriptor { name: "scan" },
            crate::MatrixDimensionDescriptor { name: "ch" },
        ];
        static COMMITS: &[crate::MatrixCommitDescriptor] = &[crate::MatrixCommitDescriptor {
            name: "cells",
            kind: crate::MatrixCommitKind::Cell,
        }];
        static MATRIX_BLOCKS: &[crate::MatrixBlockDescriptor] = &[crate::MatrixBlockDescriptor {
            block_id: MatrixTestCell::ID,
            dimensions: MatrixTestCell::DIMENSIONS,
            category: MatrixTestCell::CATEGORY,
            slot_stride: MatrixTestCell::SLOT_STRIDE,
        }];

        FormatSpec::new(
            b"VSMTX",
            1,
            Endian::Little,
            0,
            IndexPolicy::ScanOnOpen,
            IntegrityPolicy::None,
            RecoveryPolicy::Strict,
            ManifestPolicy::None,
            BLOCKS,
        )
        .with_block_identities(&[MatrixTestCell::IDENTITY])
        .with_matrix_spec(DIMENSIONS, COMMITS, MATRIX_BLOCKS)
        .with_read_limits(crate::ReadLimits::finite_all(u64::MAX))
    }

    fn replace_test_spec() -> FormatSpec {
        static BLOCKS: &[BlockDescriptor] = &[
            BlockDescriptor {
                id: ReplaceTestBlock::ID,
                name: "ReplaceTestBlock",
                version: ReplaceTestBlock::VERSION,
                kind: BlockKind::Fixed,
                fields: ReplaceTestBlock::FIELDS,
            },
            BlockDescriptor {
                id: ReplaceString::ID,
                name: "ReplaceString",
                version: ReplaceString::VERSION,
                kind: BlockKind::Variable,
                fields: ReplaceString::FIELDS,
            },
            BlockDescriptor {
                id: ReplaceKeyed::ID,
                name: "ReplaceKeyed",
                version: ReplaceKeyed::VERSION,
                kind: BlockKind::Variable,
                fields: ReplaceKeyed::FIELDS,
            },
        ];

        FormatSpec::new(
            b"VSRPL",
            1,
            Endian::Little,
            0,
            IndexPolicy::ScanOnOpen,
            IntegrityPolicy::None,
            RecoveryPolicy::Strict,
            ManifestPolicy::None,
            BLOCKS,
        )
        .with_block_identities(&[
            ReplaceTestBlock::IDENTITY,
            ReplaceString::IDENTITY,
            ReplaceKeyed::IDENTITY,
        ])
        .with_read_limits(crate::ReadLimits::finite_all(u64::MAX))
    }

    fn replacement_policy_spec() -> FormatSpec {
        let spec = replace_test_spec()
            .with_index_policy(IndexPolicy::new(true, true, true, false))
            .with_commit_policy(CommitPolicy::RecordFooter);
        #[cfg(feature = "integrity")]
        {
            spec.with_integrity_policy(IntegrityPolicy::Crc32WithHeader)
        }
        #[cfg(not(feature = "integrity"))]
        {
            spec
        }
    }

    #[test]
    fn replacement_info_translates_grow_and_shrink_offsets() -> Result<()> {
        let grow = ReplacementInfo {
            sequence: 7,
            record_offset: 100,
            old_payload_len: 8,
            new_payload_len: 18,
            old_physical_len: 40,
            new_physical_len: 50,
        };
        assert_eq!(grow.translate_record_offset(99)?, 99);
        assert_eq!(grow.translate_record_offset(100)?, 100);
        assert_eq!(grow.translate_record_offset(140)?, 150);

        let shrink = ReplacementInfo {
            old_payload_len: 18,
            new_payload_len: 8,
            old_physical_len: 50,
            new_physical_len: 40,
            ..grow
        };
        assert_eq!(shrink.translate_record_offset(150)?, 140);
        Ok(())
    }

    #[test]
    fn replace_block_grows_shrinks_and_preserves_sequence_chains_and_snapshot() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("resized.varlit");
        let spec = replacement_policy_spec();
        let mut writer = VarlitFile::create(spec, &path)?;
        writer.push(&ReplaceString("a".into()))?;
        writer.flush()?;
        writer.push(&ReplaceTestBlock { value: 9 })?;
        writer.push(&ReplaceString("tail".into()))?;
        writer.flush()?;

        let old_reader = VarlitFile::open_readonly(spec, &path)?;
        let old_values = old_reader.blocks::<ReplaceString>()?;
        let old_tail_offset = writer
            .index_entries()
            .iter()
            .filter(|entry| entry.block_id == ReplaceString::ID)
            .nth(1)
            .expect("tail record")
            .record_offset;
        let sequence = writer
            .index_entries()
            .iter()
            .find(|entry| entry.block_id == ReplaceString::ID)
            .expect("target record")
            .sequence;

        let grown = writer.replace_block(
            0,
            &ReplaceString("a replacement that is substantially longer".into()),
        )?;
        assert_eq!(grown.sequence, sequence);
        assert!(grown.new_physical_len > grown.old_physical_len);
        let translated_tail = grown.translate_record_offset(old_tail_offset)?;
        let entries = writer.index_entries();
        let tail = entries
            .iter()
            .filter(|entry| entry.block_id == ReplaceString::ID)
            .nth(1)
            .expect("rewritten tail");
        assert_eq!(tail.record_offset, translated_tail);
        assert_eq!(tail.prev_same_block_offset, Some(grown.record_offset));
        assert_eq!(old_values.get(0)?, Some(ReplaceString("a".into())));

        let shrunk = writer.replace_block(0, &ReplaceString(String::new()))?;
        assert_eq!(shrunk.sequence, sequence);
        assert!(shrunk.new_physical_len < shrunk.old_physical_len);
        let equal = writer.replace_block(0, &ReplaceString("x".into()))?;
        let equal_again = writer.replace_block(0, &ReplaceString("y".into()))?;
        assert_eq!(equal.new_physical_len, equal_again.new_physical_len);

        let reopened = VarlitFile::open_readonly(spec, &path)?;
        assert_eq!(
            reopened.blocks::<ReplaceString>()?.get(0)?,
            Some(ReplaceString("y".into()))
        );
        assert_eq!(
            reopened.blocks::<ReplaceString>()?.get(1)?,
            Some(ReplaceString("tail".into()))
        );
        assert_no_rewrite_temps(directory.path())?;
        Ok(())
    }

    #[test]
    fn replace_block_validates_key_before_publication() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("keyed.varlit");
        let spec = replace_test_spec();
        let mut writer = VarlitFile::create(spec, &path)?;
        writer.push(&ReplaceKeyed {
            key: 1,
            value: "old".into(),
        })?;
        let original = std::fs::read(&path)?;

        assert!(matches!(
            writer.replace_block(
                0,
                &ReplaceKeyed {
                    key: 2,
                    value: "new".into(),
                },
            ),
            Err(Error::ReplacementKeyMismatch)
        ));
        assert_eq!(std::fs::read(&path)?, original);
        assert_no_rewrite_temps(directory.path())?;
        Ok(())
    }

    #[test]
    fn replace_block_translates_keyed_predecessors_after_target() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("keyed-chain.varlit");
        let spec =
            replacement_policy_spec().with_index_policy(IndexPolicy::new(true, true, true, true));
        let mut writer = VarlitFile::create(spec, &path)?;
        // API2-05: the generic push refuses keyed blocks on a keyed-chaining
        // format; the maintaining path is the equivalent entry point.
        let first = writer.push_keyed_info(&ReplaceKeyed {
            key: 1,
            value: "a".into(),
        })?;
        let second = writer.push_with_prev_key_info(
            &ReplaceKeyed {
                key: 1,
                value: "b".into(),
            },
            Some(first.record_offset),
        )?;
        writer.push_with_prev_key_info(
            &ReplaceKeyed {
                key: 1,
                value: "c".into(),
            },
            Some(second.record_offset),
        )?;
        writer.flush()?;

        let info = writer.replace_block(
            0,
            &ReplaceKeyed {
                key: 1,
                value: "a much longer first value".into(),
            },
        )?;
        let snapshot = writer.index_entries();
        let keyed: Vec<_> = snapshot
            .iter()
            .filter(|entry| entry.block_id == ReplaceKeyed::ID)
            .collect();
        assert_eq!(
            keyed[2].prev_same_key_offset,
            Some(info.translate_record_offset(second.record_offset)?)
        );
        VarlitFile::open_readonly(spec, &path)?;
        Ok(())
    }

    #[test]
    fn replace_block_preserves_transaction_visibility_and_next_sequence() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("transaction.varlit");
        let spec = replace_test_spec()
            .with_index_policy(IndexPolicy::new(true, true, true, false))
            .with_commit_policy(CommitPolicy::TransactionMarker(
                crate::TransactionMarkerMode::Explicit,
            ));
        let mut writer = VarlitFile::create(spec, &path)?;
        writer.push(&ReplaceString("committed-old".into()))?;
        writer.commit()?;
        let old_reader = VarlitFile::open_readonly(spec, &path)?;
        writer.push(&ReplaceString("uncommitted".into()))?;
        let next_sequence = writer.sequence_state.available()?;

        let info = writer.replace_block(0, &ReplaceString("committed-new".into()))?;
        assert_eq!(info.sequence, 0);
        assert_eq!(writer.sequence_state.available()?, next_sequence);
        assert_eq!(
            old_reader.blocks::<ReplaceString>()?.get(0)?,
            Some(ReplaceString("committed-old".into()))
        );
        let new_reader = VarlitFile::open_readonly(spec, &path)?;
        let visible = new_reader.blocks::<ReplaceString>()?;
        assert_eq!(visible.len(), 1);
        assert_eq!(visible.get(0)?, Some(ReplaceString("committed-new".into())));
        assert_eq!(writer.push(&ReplaceTestBlock { value: 11 })?, next_sequence);
        Ok(())
    }

    #[test]
    fn replacement_publish_rebind_failure_is_explicit_and_poisoned() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("replacement-rebind.varlit");
        let spec = replace_test_spec();
        let mut writer = VarlitFile::create(spec, &path)?;
        writer.push(&ReplaceString("old".into()))?;
        let old_reader = VarlitFile::open_readonly(spec, &path)?;
        inject_write_fault(WriteFault::RebindAfterPublish);

        assert!(matches!(
            writer.replace_block(0, &ReplaceString("new and longer".into())),
            Err(Error::PublishedButRebindFailed { sequence: 0, .. })
        ));
        assert_eq!(
            old_reader.blocks::<ReplaceString>()?.get(0)?,
            Some(ReplaceString("old".into()))
        );
        assert_eq!(
            VarlitFile::open_readonly(spec, &path)?
                .blocks::<ReplaceString>()?
                .get(0)?,
            Some(ReplaceString("new and longer".into()))
        );
        assert!(matches!(writer.flush(), Err(Error::WriterPoisoned("file"))));
        assert_no_rewrite_temps(directory.path())?;
        Ok(())
    }

    #[test]
    fn max_sequence_publishes_once_then_reopens_exhausted() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("max.varlit");
        let mut file = VarlitFile::create(test_spec(), &path)?;
        file.sequence_state = SequenceState::Available(u64::MAX);

        assert_eq!(
            file.write_record(METADATA_BLOCK_ID, 1, RECORD_FLAG_INTERNAL, b"max")?,
            u64::MAX
        );
        assert_eq!(file.sequence_state, SequenceState::Exhausted);
        let original_len = file.file.metadata()?.len();
        let original_cursor = file.file.stream_position()?;
        let original_index_len = file.index.len();
        assert!(matches!(
            file.write_record(METADATA_BLOCK_ID, 1, RECORD_FLAG_INTERNAL, b"again"),
            Err(Error::SequenceExhausted)
        ));
        assert_eq!(file.file.metadata()?.len(), original_len);
        assert_eq!(file.file.stream_position()?, original_cursor);
        assert_eq!(file.index.len(), original_index_len);
        drop(file);

        let mut reopened = VarlitFile::open(test_spec(), &path)?;
        assert_eq!(reopened.sequence_state, SequenceState::Exhausted);
        assert!(matches!(
            reopened.write_record(METADATA_BLOCK_ID, 1, RECORD_FLAG_INTERNAL, b"again"),
            Err(Error::SequenceExhausted)
        ));
        Ok(())
    }

    #[test]
    fn append_failure_rolls_back_and_preserves_sequence() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("rollback.varlit");
        let mut file = VarlitFile::create(test_spec(), &path)?;
        // Somewhere no append would have left it, so that "restored the end of
        // file" and "left it where it found it" are different answers.
        file.file.seek_to(0)?;
        let original_len = file.file.metadata()?.len();
        inject_write_fault(WriteFault::AppendAfterHeader);

        assert!(matches!(
            file.write_record(METADATA_BLOCK_ID, 1, RECORD_FLAG_INTERNAL, b"failed"),
            Err(Error::Io(_))
        ));
        assert_eq!(file.file.metadata()?.len(), original_len);
        // The truncate put the file back; this is the handle put back with it.
        // Not the offset the append found — that was 0, and it is a number this
        // writer no longer has any way to know. See `AppendSnapshot::eof`.
        assert_eq!(file.file.stream_position()?, original_len);
        assert!(file.index.is_empty());
        assert_eq!(file.sequence_state, SequenceState::Available(0));
        assert!(!file.poison.is_refusing());
        assert_eq!(
            file.write_record(METADATA_BLOCK_ID, 1, RECORD_FLAG_INTERNAL, b"ok")?,
            0
        );
        Ok(())
    }

    /// A read through the snapshot moves the writer's own file offset.
    ///
    /// `VarlitFile::snapshot` is a `try_clone` of `VarlitFile::file`, and
    /// `try_clone` shares the open file description — so the two share one
    /// offset. `cursor_at` is the plainest way to show it (it is what the
    /// layout scan uses), but it is not the only one: every `replace_*` seeks
    /// this description through `validate_generation_index`, and on Windows so
    /// does every positional read, `read_exact_at` being `seek_read` there.
    ///
    /// This is a property of the design, not a defect — reads are supposed to
    /// be free of the writer. What was a defect is anything believing it knows
    /// where the offset is: `RecordFile` cached it, and after the `cursor_at`
    /// below the cache said `eof` while the kernel said `0`, with nothing able
    /// to tell the writer otherwise. The cache is gone; every write here seeks
    /// first, so a displaced offset costs nothing.
    #[test]
    fn a_snapshot_read_moves_the_writers_offset_and_the_writer_survives_it() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("shared-description.varlit");
        let mut file = VarlitFile::create(test_spec(), &path)?;
        file.push_info_for_test(12, b"first")?;
        let after_first = file.snapshot.len();
        assert_eq!(file.file.stream_position()?, after_first);

        // What a layout scan does, on the description the writer appends to.
        let _scan = file.snapshot.cursor_at(0)?;
        assert_eq!(
            file.file.stream_position()?,
            0,
            "the snapshot and the writer share one file offset",
        );

        // The append still lands at the end, because it seeks there itself.
        let info = file.push_info_for_test(12, b"second")?;
        assert_eq!(info.record_offset, after_first);
        assert_eq!(file.file.stream_position()?, file.snapshot.len());
        assert!(file.snapshot.len() > after_first);
        Ok(())
    }

    #[test]
    fn rollback_failure_poisons_mutation_flush_and_sync() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("poison.varlit");
        let mut file = VarlitFile::create(test_spec(), &path)?;
        inject_write_fault(WriteFault::AppendAfterHeaderWithRollbackFailure);

        assert!(matches!(
            file.write_record(METADATA_BLOCK_ID, 1, RECORD_FLAG_INTERNAL, b"failed"),
            Err(Error::WriteRollbackFailed {
                operation: "append record",
                ..
            })
        ));
        assert!(matches!(
            file.write_record(METADATA_BLOCK_ID, 1, RECORD_FLAG_INTERNAL, b"again"),
            Err(Error::WriterPoisoned("file"))
        ));
        assert!(matches!(file.flush(), Err(Error::WriterPoisoned("file"))));
        assert!(matches!(file.sync(), Err(Error::WriterPoisoned("file"))));
        Ok(())
    }

    /// A-3. A whole-category clear does its fallible region half first, so a
    /// failure there leaves every chunk exactly as it was.
    ///
    /// **The ordering was fixed on 2026-08-08 and went unpinned until now,
    /// because nothing could make the region half fail.** The clear writes
    /// through `zero_range`; the two injectors that existed sat on
    /// `write_slot_payload` and `write_bitmap_byte`, neither of which a
    /// category clear ever calls. So the fix was a reordering nobody could
    /// observe, which is the same as no fix at all against the next edit — and
    /// the defect it corrected is silent: the chunk half used to run first as
    /// an infallible memset, so a region clear that then failed on I/O returned
    /// an error to a caller entitled to believe nothing had happened, with the
    /// chunk's committed cells already destroyed.
    ///
    /// Both kinds of chunk are present, because the halves are separate code
    /// now: chunk 1 has a record and is reached by the directory walk, chunk 2
    /// is the open buffer. Neither may be touched.
    #[test]
    fn a_failed_region_clear_leaves_every_chunk_alone() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("clear-order.varlit");
        let spec = matrix_test_spec().with_growing_matrix_dimension("scan", 4);
        let mut file = VarlitFile::create_with_dims(
            spec,
            &path,
            MatrixDimensions::from_pairs([("scan", 4), ("ch", 1)]),
        )?;
        let region = MatrixKey::new(0, 0);
        let written = MatrixKey::new(4, 0);
        let open = MatrixKey::new(8, 0);
        for (key, value) in [(region, 1), (written, 2), (open, 3)] {
            file.write_matrix_cell(key, &MatrixTestCell { value })?;
            file.commit_matrix_cell::<MatrixTestCell>(key)?;
        }
        // Opening chunk 2 wrote chunk 1 out, so `written` lives in a record and
        // `open` lives in the buffer.
        file.flush()?;
        let length_before = file.file.metadata()?.len();

        crate::matrix::inject_zero_range_failure();
        assert!(matches!(
            file.clear_matrix_category(MatrixTestCell::CATEGORY),
            Err(Error::Io(_))
        ));

        for key in [region, written, open] {
            assert_eq!(
                file.matrix_cell_status::<MatrixTestCell>(key)?,
                MatrixCellStatus::Committed,
                "a clear that failed on the region reported an error and destroyed a cell",
            );
        }
        assert_eq!(
            file.file.metadata()?.len(),
            length_before,
            "a clear that failed before its first write must not have rewritten a chunk record",
        );
        Ok(())
    }

    #[test]
    fn partial_matrix_overwrite_is_withdrawn_and_poisons_writer() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("matrix-partial.varlit");
        let spec = matrix_test_spec();
        let key = MatrixKey::new(0, 0);
        let mut file = VarlitFile::create_with_dims(
            spec,
            &path,
            MatrixDimensions::from_pairs([("scan", 1), ("ch", 1)]),
        )?;
        file.write_matrix_cell(key, &MatrixTestCell { value: 11 })?;
        file.commit_matrix_cell::<MatrixTestCell>(key)?;
        let original_len = file.file.metadata()?.len();

        crate::matrix::inject_partial_slot_write_failure();
        assert!(matches!(
            file.write_matrix_cell(key, &MatrixTestCell { value: 22 }),
            Err(Error::Io(_))
        ));
        assert_eq!(file.file.metadata()?.len(), original_len);
        assert_eq!(
            file.matrix_cell_status::<MatrixTestCell>(key)?,
            MatrixCellStatus::NotCommitted
        );
        assert!(matches!(
            file.write_matrix_cell(key, &MatrixTestCell { value: 33 }),
            Err(Error::WriterPoisoned("file"))
        ));
        assert!(matches!(file.flush(), Err(Error::WriterPoisoned("file"))));
        assert!(matches!(file.sync(), Err(Error::WriterPoisoned("file"))));
        drop(file);

        let reopened = VarlitFile::open_readonly(spec, &path)?;
        assert_eq!(
            reopened.matrix_cell_status::<MatrixTestCell>(key)?,
            MatrixCellStatus::NotCommitted
        );
        assert!(matches!(
            reopened.read_matrix_cell::<MatrixTestCell>(key),
            Err(Error::MatrixNotCommitted)
        ));
        Ok(())
    }

    #[test]
    fn fixed_publish_rebind_failure_is_explicit_and_poisoned() -> Result<()> {
        assert_publish_rebind_failure(false)
    }

    #[test]
    fn rewrite_publish_rebind_failure_is_explicit_and_poisoned() -> Result<()> {
        assert_publish_rebind_failure(true)
    }

    fn assert_publish_rebind_failure(rewrite: bool) -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join(if rewrite {
            "rewrite-rebind.varlit"
        } else {
            "fixed-rebind.varlit"
        });
        let spec = replace_test_spec();
        {
            let mut initial = VarlitFile::create(spec, &path)?;
            initial.push(&ReplaceTestBlock { value: 1 })?;
            initial.flush()?;
        }

        let old_reader = VarlitFile::open_readonly(spec, &path)?;
        let old_blocks = old_reader.blocks::<ReplaceTestBlock>()?;
        let mut writer = VarlitFile::open(spec, &path)?;
        inject_write_fault(WriteFault::RebindAfterPublish);
        let error = if rewrite {
            writer
                .replace_rewrite(0, &ReplaceTestBlock { value: 2 })
                .expect_err("injected rewrite rebind failure must be returned")
        } else {
            writer
                .replace_fixed(0, &ReplaceTestBlock { value: 2 })
                .expect_err("injected fixed rebind failure must be returned")
        };
        match error {
            Error::PublishedButRebindFailed {
                sequence,
                source,
                parent_sync,
            } => {
                assert_eq!(sequence, 1);
                assert!(matches!(*source, Error::Io(_)));
                // F-07: no parent-directory sync failure happened here, so the
                // second durability fact is absent rather than fabricated.
                assert!(parent_sync.is_none());
            }
            other => panic!("unexpected publication error: {other:?}"),
        }

        assert_eq!(old_blocks.get(0)?, Some(ReplaceTestBlock { value: 1 }));
        assert_eq!(
            VarlitFile::open_readonly(spec, &path)?
                .blocks::<ReplaceTestBlock>()?
                .get(0)?,
            Some(ReplaceTestBlock { value: 2 })
        );
        assert!(matches!(
            writer.push(&ReplaceTestBlock { value: 3 }),
            Err(Error::WriterPoisoned("file"))
        ));
        assert_no_rewrite_temps(directory.path())?;

        drop(writer);
        let mut reopened = VarlitFile::open(spec, &path)?;
        assert_eq!(reopened.push(&ReplaceTestBlock { value: 3 })?, 2);
        Ok(())
    }

    /// F-07 double fault, one per replacement API.
    ///
    /// A replacement publication learns two independent durability facts in a
    /// fixed order: whether the parent-directory sync succeeded, and whether
    /// the writer could rebind to the published generation. Only the second
    /// had a path out, so the pre-fix code called rebind with `?` and, when
    /// both failed, returned `PublishedButRebindFailed` alone - silently
    /// dropping the already-known fact that the published pathname may not
    /// survive power loss. Both facts must now arrive together.
    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    enum ReplacementApi {
        Block,
        Fixed,
        Rewrite,
    }

    fn assert_double_publication_fault_reports_both_facts(api: ReplacementApi) -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join(match api {
            ReplacementApi::Block => "double-block.varlit",
            ReplacementApi::Fixed => "double-fixed.varlit",
            ReplacementApi::Rewrite => "double-rewrite.varlit",
        });
        let spec = replace_test_spec();
        {
            let mut initial = VarlitFile::create(spec, &path)?;
            initial.push(&ReplaceTestBlock { value: 1 })?;
            initial.flush()?;
        }

        let mut writer = VarlitFile::open(spec, &path)?;
        // One arming produces both failures in the order the code sees them:
        // the parent-directory sync inside `replace_path_atomically`, then the
        // rebind that follows it.
        inject_write_fault(WriteFault::ParentSyncThenRebindAfterPublish);
        let error = match api {
            ReplacementApi::Block => writer
                .replace_block(0, &ReplaceTestBlock { value: 2 })
                .map(|info| info.sequence)
                .expect_err("injected double publication fault must be returned"),
            ReplacementApi::Fixed => writer
                .replace_fixed(0, &ReplaceTestBlock { value: 2 })
                .expect_err("injected double publication fault must be returned"),
            ReplacementApi::Rewrite => writer
                .replace_rewrite(0, &ReplaceTestBlock { value: 2 })
                .expect_err("injected double publication fault must be returned"),
        };
        inject_write_fault(WriteFault::None);

        match error {
            Error::PublishedButRebindFailed {
                source,
                parent_sync,
                ..
            } => {
                assert!(matches!(*source, Error::Io(_)), "rebind fact: {source:?}");
                let parent_sync = parent_sync.expect(
                    "the parent-directory sync failure observed before the rebind must survive",
                );
                assert!(
                    matches!(*parent_sync, Error::Io(_)),
                    "parent-sync fact: {parent_sync:?}",
                );
                // The rendered message must carry both facts, because that is
                // what an operator reads out of a log line.
                let rendered = Error::PublishedButRebindFailed {
                    sequence: 0,
                    source,
                    parent_sync: Some(parent_sync),
                }
                .to_string();
                assert!(
                    rendered.contains("could not rebind"),
                    "message lost the rebind fact: {rendered}"
                );
                assert!(
                    rendered.contains("parent-directory sync"),
                    "message lost the parent-sync fact: {rendered}"
                );
            }
            other => panic!("unexpected double-fault outcome: {other:?}"),
        }

        // Everything the single-fault contract already promised still holds:
        // publication happened, and the writer is poisoned.
        assert_eq!(
            VarlitFile::open_readonly(spec, &path)?
                .blocks::<ReplaceTestBlock>()?
                .get(0)?,
            Some(ReplaceTestBlock { value: 2 })
        );
        assert!(matches!(
            writer.push(&ReplaceTestBlock { value: 3 }),
            Err(Error::WriterPoisoned("file"))
        ));
        assert_no_rewrite_temps(directory.path())?;
        Ok(())
    }

    #[test]
    fn block_replacement_double_publication_fault_reports_both_facts() -> Result<()> {
        assert_double_publication_fault_reports_both_facts(ReplacementApi::Block)
    }

    #[test]
    fn fixed_replacement_double_publication_fault_reports_both_facts() -> Result<()> {
        assert_double_publication_fault_reports_both_facts(ReplacementApi::Fixed)
    }

    #[test]
    fn rewrite_replacement_double_publication_fault_reports_both_facts() -> Result<()> {
        assert_double_publication_fault_reports_both_facts(ReplacementApi::Rewrite)
    }

    #[cfg(windows)]
    #[test]
    fn windows_sharing_violation_preserves_generation_and_allows_retry() -> Result<()> {
        use std::os::windows::fs::OpenOptionsExt;
        use windows_sys::Win32::Storage::FileSystem::{FILE_SHARE_READ, FILE_SHARE_WRITE};

        let directory = tempfile::tempdir()?;
        let path = directory.path().join("sharing.varlit");
        let spec = replace_test_spec();
        {
            let mut initial = VarlitFile::create(spec, &path)?;
            initial.push(&ReplaceTestBlock { value: 1 })?;
            initial.flush()?;
        }

        let old_reader = VarlitFile::open_readonly(spec, &path)?;
        let old_blocks = old_reader.blocks::<ReplaceTestBlock>()?;
        let mut writer = VarlitFile::open(spec, &path)?;
        let blocker = OpenOptions::new()
            .read(true)
            .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
            .open(&path)?;

        assert!(matches!(
            writer.replace_fixed(0, &ReplaceTestBlock { value: 2 }),
            Err(Error::Io(_))
        ));
        assert_eq!(
            writer.blocks::<ReplaceTestBlock>()?.get(0)?,
            Some(ReplaceTestBlock { value: 1 })
        );
        assert_eq!(old_blocks.get(0)?, Some(ReplaceTestBlock { value: 1 }));
        assert_no_rewrite_temps(directory.path())?;

        drop(blocker);
        writer.replace_fixed(0, &ReplaceTestBlock { value: 2 })?;
        assert_eq!(old_blocks.get(0)?, Some(ReplaceTestBlock { value: 1 }));
        assert_eq!(
            VarlitFile::open_readonly(spec, &path)?
                .blocks::<ReplaceTestBlock>()?
                .get(0)?,
            Some(ReplaceTestBlock { value: 2 })
        );
        assert_no_rewrite_temps(directory.path())?;
        Ok(())
    }

    #[cfg(windows)]
    #[test]
    fn windows_open_generation_rename_handles_every_utf16_alignment() -> Result<()> {
        let directory = tempfile::tempdir()?;
        // Four adjacent ASCII lengths cover every UTF-16 tail alignment in the
        // u64-backed FILE_RENAME_INFO allocation, including no padding at all.
        for suffix_len in 0..4 {
            let target = directory
                .path()
                .join(format!("generation{}", "x".repeat(suffix_len)));
            std::fs::write(&target, b"old")?;
            let mut old = File::open(&target)?;
            let mut temporary = tempfile::NamedTempFile::new_in(directory.path())?;
            std::io::Write::write_all(temporary.as_file_mut(), b"new")?;
            temporary.as_file().sync_all()?;
            let mut new = temporary.as_file().try_clone()?;
            std::io::Seek::seek(&mut new, std::io::SeekFrom::Start(0))?;
            let _durability = crate::file::publish_open_temp_path_atomically(
                temporary.into_temp_path(),
                &target,
            )?;
            assert_eq!(std::fs::read(&target)?, b"new");
            let mut bytes = [0; 3];
            std::io::Read::read_exact(&mut old, &mut bytes)?;
            assert_eq!(&bytes, b"old");
            std::io::Read::read_exact(&mut new, &mut bytes)?;
            assert_eq!(&bytes, b"new");
        }
        Ok(())
    }

    #[cfg(windows)]
    #[test]
    fn windows_concurrent_replacefilew_keeps_whole_generations_and_old_handle() -> Result<()> {
        use std::sync::{Arc, Barrier};

        for round in 0..64u32 {
            let directory = tempfile::tempdir()?;
            let target = directory.path().join("target.bin");
            let replacement_a = directory.path().join("a.bin");
            let replacement_b = directory.path().join("b.bin");
            let old = vec![0x11; 16 * 1024];
            let a = vec![0xA5; 16 * 1024];
            let b = vec![0x5A; 16 * 1024];
            std::fs::write(&target, &old)?;
            std::fs::write(&replacement_a, &a)?;
            std::fs::write(&replacement_b, &b)?;
            let mut old_handle = File::open(&target)?;

            let barrier = Arc::new(Barrier::new(3));
            let first_barrier = Arc::clone(&barrier);
            let first_target = target.clone();
            let first = std::thread::spawn(move || {
                first_barrier.wait();
                replace_path_atomically(&replacement_a, &first_target)
            });
            let second_barrier = Arc::clone(&barrier);
            let second_target = target.clone();
            let second = std::thread::spawn(move || {
                second_barrier.wait();
                replace_path_atomically(&replacement_b, &second_target)
            });
            barrier.wait();
            let first = first.join().expect("first ReplaceFileW thread panicked");
            let second = second.join().expect("second ReplaceFileW thread panicked");

            assert!(
                first.is_ok() || second.is_ok(),
                "round {round}: both replacements failed"
            );
            let unreconciled_indeterminate_loser = [&first, &second]
                .into_iter()
                .any(|result| matches!(result, Err(Error::ReplacePublicationIndeterminate { .. })));
            match std::fs::read(&target) {
                Ok(published) => {
                    assert!(
                        published == old || published == a || published == b,
                        "round {round}: target was a partial or mixed generation (len={}, first={:?}, first_result={first:?}, second_result={second:?})",
                        published.len(),
                        published.first()
                    );
                }
                Err(error)
                    if error.kind() == std::io::ErrorKind::NotFound
                        && unreconciled_indeterminate_loser =>
                {
                    // Documented ReplaceFileW outcome: on 1176 with no backup
                    // name, the losing replace can unlink the target name. The
                    // loser must have reported the unreconciled
                    // ReplacePublicationIndeterminate error (DUR2-01) so its
                    // caller preserves the temp file and poisons the writer.
                }
                Err(error) => panic!(
                    "round {round}: reading target failed without an indeterminate loser \
                     (error={error:?}, first_result={first:?}, second_result={second:?})"
                ),
            }
            let mut retained = Vec::new();
            old_handle.seek(SeekFrom::Start(0))?;
            old_handle.read_to_end(&mut retained)?;
            assert_eq!(retained, old, "round {round}: old handle was rebound");
        }
        Ok(())
    }

    #[cfg(windows)]
    #[test]
    fn windows_replacefilew_rejects_retained_replacement_handle() -> Result<()> {
        use std::os::windows::fs::OpenOptionsExt;
        use windows_sys::Win32::Storage::FileSystem::{
            FILE_SHARE_DELETE, FILE_SHARE_READ, FILE_SHARE_WRITE,
        };

        let directory = tempfile::tempdir()?;
        let target = directory.path().join("target.bin");
        let replacement = directory.path().join("replacement.bin");
        let old = vec![0x11; 4 * 1024];
        let new = vec![0xA5; 4 * 1024];
        std::fs::write(&target, &old)?;
        std::fs::write(&replacement, &new)?;
        let mut retained = OpenOptions::new()
            .read(true)
            .write(true)
            .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE)
            .open(&replacement)?;

        assert!(matches!(
            replace_path_atomically(&replacement, &target),
            Err(Error::Io(_))
        ));
        assert_eq!(std::fs::read(&target)?, old);
        retained.seek(SeekFrom::Start(0))?;
        let mut retained_bytes = Vec::new();
        retained.read_to_end(&mut retained_bytes)?;
        assert_eq!(retained_bytes, new);
        drop(retained);
        replace_path_atomically(&replacement, &target)?;
        assert_eq!(std::fs::read(&target)?, new);
        Ok(())
    }

    #[cfg(windows)]
    #[test]
    fn windows_external_truncate_returns_error_without_rebinding_or_panicking() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("truncate.varlit");
        let spec = replace_test_spec();
        {
            let mut writer = VarlitFile::create(spec, &path)?;
            writer.push(&ReplaceTestBlock { value: 7 })?;
            writer.flush()?;
        }

        let reader = VarlitFile::open_readonly(spec, &path)?;
        let blocks = reader.blocks::<ReplaceTestBlock>()?;
        OpenOptions::new().write(true).open(&path)?.set_len(0)?;
        assert!(blocks.get(0).is_err());
        Ok(())
    }

    fn assert_no_rewrite_temps(directory: &Path) -> Result<()> {
        for entry in std::fs::read_dir(directory)? {
            let name = entry?.file_name();
            assert!(
                !name.to_string_lossy().contains(".rewrite."),
                "rewrite temp leaked after failed publication"
            );
        }
        Ok(())
    }

    #[test]
    fn failed_matrix_commit_publish_keeps_memory_uncommitted_and_poisons_writer() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("matrix-commit-failure.varlit");
        let spec = matrix_test_spec();
        let key = MatrixKey::new(0, 0);
        let mut file = VarlitFile::create_with_dims(
            spec,
            &path,
            MatrixDimensions::from_pairs([("scan", 1), ("ch", 1)]),
        )?;
        file.write_matrix_cell(key, &MatrixTestCell { value: 44 })?;

        crate::matrix::inject_bitmap_write_failure();
        assert!(matches!(
            file.commit_matrix_cell::<MatrixTestCell>(key),
            Err(Error::Io(_))
        ));
        assert_eq!(
            file.matrix_cell_status::<MatrixTestCell>(key)?,
            MatrixCellStatus::NotCommitted
        );
        assert!(matches!(file.sync(), Err(Error::WriterPoisoned("file"))));
        drop(file);

        let reopened = VarlitFile::open_readonly(spec, &path)?;
        assert_eq!(
            reopened.matrix_cell_status::<MatrixTestCell>(key)?,
            MatrixCellStatus::NotCommitted
        );
        Ok(())
    }

    #[test]
    fn schema_manifest_rejects_huge_and_truncated_counts_before_iteration() {
        let mut prefix = Vec::new();
        prefix.extend_from_slice(&1u16.to_le_bytes());
        prefix.extend_from_slice(&1u16.to_le_bytes());
        prefix.push(Endian::Little.to_byte());
        prefix.extend_from_slice(&0u64.to_le_bytes());
        prefix.extend_from_slice(&[0, 0, 0, 0]);

        let mut huge = prefix.clone();
        huge.extend_from_slice(&u32::MAX.to_le_bytes());
        let mut budget = MaterializationBudget::new(test_spec());
        assert!(matches!(
            decode_schema_manifest(&huge, &mut budget),
            Err(Error::InvalidSchemaManifest)
        ));

        let mut truncated = prefix;
        truncated.extend_from_slice(&1u32.to_le_bytes());
        truncated.extend_from_slice(&[0; 8]);
        let mut budget = MaterializationBudget::new(test_spec());
        assert!(matches!(
            decode_schema_manifest(&truncated, &mut budget),
            Err(Error::InvalidSchemaManifest)
        ));
    }

    #[test]
    fn checkpoint_rejects_oversized_extent_before_index_allocation() -> Result<()> {
        let entry = RecordIndexEntry {
            block_id: ReplaceTestBlock::ID,
            block_version: ReplaceTestBlock::VERSION,
            flags: 0,
            sequence: 0,
            record_offset: 32,
            payload_offset: u64::MAX - 1,
            payload_len: 4,
            checksum: 0,
            uncompressed_len_hint: 0,
            footer_offset: None,
            prev_same_block_offset: None,
            prev_same_key_offset: None,
            mutable_flags: 0,
            committed: true,
        };
        let payload = encode_index_checkpoint_payload(test_spec(), &[entry], 128)?;

        let decoded =
            std::panic::catch_unwind(|| decode_index_checkpoint(test_spec(), &payload, 128));
        assert!(
            decoded.is_ok(),
            "oversized checkpoint extent caused a panic"
        );
        assert!(matches!(
            decoded.expect("checked above"),
            Err(Error::LengthOverflow { .. }) | Err(Error::InvalidIndexCheckpoint)
        ));
        Ok(())
    }

    /// DUR3-01: `sync` on a file this handle created must make the pathname
    /// durable, not only its contents - and must do so exactly once, never per
    /// sync and never on the append path.
    #[test]
    fn create_then_sync_makes_the_new_pathname_durable_once() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("create-parent-sync.varlit");
        let spec = replace_test_spec();

        reset_parent_directory_sync_calls();
        let mut writer = VarlitFile::create(spec, &path)?;
        writer.push(&ReplaceTestBlock { value: 1 })?;
        writer.push(&ReplaceTestBlock { value: 2 })?;
        writer.flush()?;
        assert_eq!(
            parent_directory_sync_calls(),
            0,
            "creating and appending must not sync the parent directory"
        );

        writer.sync()?;
        assert_eq!(
            parent_directory_sync_calls(),
            1,
            "the first sync must make the created pathname durable"
        );

        writer.sync()?;
        writer.push(&ReplaceTestBlock { value: 3 })?;
        writer.flush()?;
        writer.sync()?;
        assert_eq!(
            parent_directory_sync_calls(),
            1,
            "the pathname is durable already; later syncs must not repeat it"
        );
        drop(writer);

        // A handle that merely opens an existing pathname created nothing, so
        // it owes no directory entry.
        reset_parent_directory_sync_calls();
        let mut reopened = VarlitFile::open(spec, &path)?;
        reopened.sync()?;
        assert_eq!(
            parent_directory_sync_calls(),
            0,
            "opening an existing pathname must not sync the parent directory"
        );
        Ok(())
    }

    /// PERF3-03: wholesale tail construction must have no quadratic term. The
    /// worst case is an index whose first appearances descend by block id,
    /// which made every first-seen id shift the whole sorted vector.
    #[test]
    fn block_tail_construction_moves_nothing_for_reverse_ordered_block_ids() {
        const BLOCKS: u32 = 1_024;

        fn entry(block_id: u32, sequence: u64) -> RecordIndexEntry {
            RecordIndexEntry {
                block_id,
                block_version: 1,
                flags: 0,
                sequence,
                record_offset: sequence * 16,
                payload_offset: sequence * 16 + 8,
                payload_len: 8,
                checksum: 0,
                uncompressed_len_hint: 0,
                footer_offset: None,
                prev_same_block_offset: None,
                prev_same_key_offset: None,
                mutable_flags: 0,
                committed: false,
            }
        }

        let mut index = Vec::new();
        for (sequence, block_id) in (0..BLOCKS).rev().enumerate() {
            index.push(entry(block_id, sequence as u64));
        }
        // A second descending round proves the tails track the *newest* record
        // per block id, not the first.
        for (offset, block_id) in (0..BLOCKS).rev().enumerate() {
            index.push(entry(block_id, (BLOCKS as usize + offset) as u64));
        }

        let tails = BlockTails::from_index(&index);
        assert_eq!(tails.tails.len(), BLOCKS as usize);
        for (position, (block_id, _)) in tails.tails.iter().enumerate() {
            assert_eq!(*block_id, position as u32, "tails must stay sorted by id");
        }
        for entry in &index[BLOCKS as usize..] {
            assert_eq!(
                tails.tail(entry.block_id),
                Some(entry.record_offset),
                "tail must be the newest record for its block id"
            );
        }

        // Identical result to the incremental path, which is the maintained
        // invariant; the difference is only how much movement it costs.
        let mut incremental = BlockTails::new_empty();
        for entry in &index {
            incremental.note_appended(entry.block_id, entry.record_offset);
        }
        assert_eq!(incremental, tails);
    }

    #[test]
    fn atomic_replace_invokes_parent_directory_sync() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let target = directory.path().join("parent-sync-target.bin");
        let replacement = directory.path().join("parent-sync-replacement.bin");
        std::fs::write(&target, b"old")?;
        std::fs::write(&replacement, b"new")?;
        OpenOptions::new()
            .write(true)
            .open(&replacement)?
            .sync_all()?;

        reset_parent_directory_sync_calls();
        replace_path_atomically(&replacement, &target)?;

        assert_eq!(parent_directory_sync_calls(), 1);
        assert_eq!(std::fs::read(target)?, b"new");

        let new_target = directory.path().join("parent-sync-new-target.bin");
        let new_replacement = directory.path().join("parent-sync-new-replacement.bin");
        std::fs::write(&new_replacement, b"first")?;
        OpenOptions::new()
            .write(true)
            .open(&new_replacement)?
            .sync_all()?;
        reset_parent_directory_sync_calls();
        replace_path_atomically(&new_replacement, &new_target)?;

        assert_eq!(parent_directory_sync_calls(), 1);
        assert_eq!(std::fs::read(new_target)?, b"first");
        Ok(())
    }

    /// PERF: an append must ask the kernel for nothing it already knows.
    ///
    /// Two distinct per-record metadata syscalls used to sit on
    /// `write_record_with_prev_key`: `self.file.metadata()?.len()` for the
    /// `AppendSnapshot`'s end of file, and a second one inside
    /// `checked_snapshot_bounds` reached through `self.snapshot.with_len(..)`.
    /// Both facts are now taken from state the writer maintains and from the
    /// write that just returned, so both counters must stay at zero across the
    /// whole append window whatever the record count.
    ///
    /// The open at the top is not incidental: it pins the snapshot counter
    /// *nonzero* where the fstat is still correct, so a "fix" that simply
    /// stopped incrementing the counter fails here rather than passing.
    #[test]
    fn an_append_window_issues_no_metadata_syscall() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("append-syscalls.varlit");

        let _ = VarlitFile::take_snapshot_bounds_fstats();
        let mut file = VarlitFile::create(test_spec(), &path)?;
        assert!(
            VarlitFile::take_snapshot_bounds_fstats() > 0,
            "binding a snapshot at open must still cost the fstat that proves the length",
        );

        let _ = VarlitFile::take_record_file_metadata_calls();
        for index in 0..1_000u32 {
            file.push_info_for_test(METADATA_BLOCK_ID, &index.to_le_bytes())?;
        }

        assert_eq!(
            VarlitFile::take_record_file_metadata_calls(),
            0,
            "the append took the end of file from the snapshot it maintains, not from an fstat",
        );
        assert_eq!(
            VarlitFile::take_snapshot_bounds_fstats(),
            0,
            "the snapshot rebind took the completed write as its proof, not an fstat",
        );

        // The records really are there and really are readable through the
        // rebound snapshot, so this is not "no syscalls because no work".
        assert_eq!(file.index_entries().len(), 1_000);
        let last = file
            .index_entries()
            .last()
            .expect("appended record")
            .clone();
        assert_eq!(file.snapshot.len(), last.checked_physical_end()?);
        Ok(())
    }

    /// The witness must not be usable to shorten a snapshot past bytes it has
    /// not proven: `with_written_len` is growth-only, which is what keeps it
    /// safe to hand a value the filesystem was never asked about.
    #[test]
    fn a_written_witness_cannot_shrink_a_snapshot() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("witness-shrink.varlit");
        let mut file = VarlitFile::create(test_spec(), &path)?;
        file.push_info_for_test(METADATA_BLOCK_ID, b"payload")?;

        let len = file.snapshot.len();
        assert!(
            file.snapshot
                .with_written_len(crate::snapshot::WrittenThrough::after_write(len))
                .is_ok()
        );
        assert!(matches!(
            file.snapshot
                .with_written_len(crate::snapshot::WrittenThrough::after_write(len - 1)),
            Err(Error::SnapshotRangeOutOfBounds { .. }),
        ));
        Ok(())
    }

    /// PERF: `replace_block` must not rescan the prefix it has already written.
    ///
    /// Every rewritten record validates its chain predecessor against the
    /// prefix already in the new generation. That prefix is built in strictly
    /// increasing `record_offset` order, so the lookup is a binary search; it
    /// used to be `iter().find(..)`, which made the whole call `Theta(N^2)` for
    /// any spec carrying a predecessor offset in its footer.
    ///
    /// The assertion is a comparison count, not a wall clock. At N = 4096 the
    /// two are ~50k against ~8.4M, and the gap grows by 2x per doubling.
    /// **Can an index entry be rebuilt from its record?** Every field but one.
    ///
    /// This is the precondition for a demand-filled index: if the entry the
    /// file already holds can be reconstructed from the record it describes,
    /// then the index does not have to keep the entry — only where to find it.
    /// If it cannot, no amount of call-site refactoring makes the store lazy,
    /// and finding that out by trying is cheaper than finding it out after the
    /// swap.
    ///
    /// The one field that cannot come back is `committed`. It is writer state
    /// with no representation in the record, so a rebuild reports the record as
    /// framed rather than as committed. That is why the directory a lazy store
    /// would keep is `(record_offset, committed)` and not `record_offset`
    /// alone — and this test is what says so, rather than a comment guessing it.
    #[test]
    fn every_index_entry_can_be_rebuilt_from_its_own_record() -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("rebuild.varlit");
        let spec = replacement_policy_spec();
        assert!(
            spec.spec_needs_record_footer(),
            "a format without footers cannot exercise the footer half of a rebuild",
        );
        let mut writer = VarlitFile::create(spec, &path)?;
        for index in 0..64u64 {
            writer.push(&ReplaceString(format!("v{index}")))?;
            if index % 8 == 7 {
                writer.flush()?;
            }
        }
        writer.flush()?;
        drop(writer);

        let opened = VarlitFile::open_readonly(spec, &path)?;
        let resident = opened.index_entries();
        assert!(resident.len() >= 64, "fixture is too small to say anything");

        let mut file = OpenOptions::new().read(true).open(&path)?;
        let file_len = file.metadata()?.len();
        let mut accounting = ScanAccounting::default();
        let mut committed_differed = 0usize;
        for entry in resident.iter() {
            let rebuilt = match read_record_entry_at(
                spec,
                &mut file,
                file_len,
                entry.record_offset,
                ScanChecks {
                    partial_boundary: None,
                    checksum_boundary: None,
                    verify_checksums: true,
                },
                &mut accounting,
            )? {
                RecordRead::Entry(rebuilt) => rebuilt,
                RecordRead::RecoverableTail(_) => {
                    panic!("record at {} did not rebuild", entry.record_offset)
                }
            };
            if rebuilt.committed != entry.committed {
                committed_differed += 1;
            }
            // Everything else has to match exactly, field for field. Comparing
            // the whole struct with `committed` normalised is what makes this a
            // proof rather than a spot check.
            let normalised = RecordIndexEntry {
                committed: entry.committed,
                ..rebuilt
            };
            assert_eq!(
                &normalised, entry,
                "record at {} rebuilt into a different entry",
                entry.record_offset
            );
        }
        // And the same again through the positional `&self` reader, which is
        // the one a demand-filled index would actually use: `read_record_entry_at`
        // above takes `&mut File` and seeks, which no shared read path can do.
        let snapshot = SnapshotFile::new(OpenOptions::new().read(true).open(&path)?)?;
        for entry in resident.iter() {
            let faulted =
                fault_record_entry(&snapshot, spec, entry.record_offset, entry.committed)?;
            assert_eq!(
                &faulted, entry,
                "positional fault of the record at {} produced a different entry",
                entry.record_offset
            );
        }
        println!(
            "(rebuild) {} entries rebuilt from their records, {committed_differed} differed only \
             in `committed`; all {} also matched through the positional &self reader",
            resident.len(),
            resident.len()
        );
        Ok(())
    }

    #[test]
    fn replace_block_finds_predecessors_without_rescanning_the_prefix() -> Result<()> {
        const RECORDS: u64 = 4096;

        let directory = tempfile::tempdir()?;
        let path = directory.path().join("replace-probes.varlit");
        let spec = replacement_policy_spec();
        assert!(
            spec.index_policy.block_offset_chain,
            "without a predecessor offset in the footer both lookup arms are skipped and there \
             is nothing to measure",
        );
        let mut writer = VarlitFile::create(spec, &path)?;
        for index in 0..RECORDS {
            writer.push(&ReplaceString(format!("v{index}")))?;
        }
        writer.flush()?;
        let entries = writer.index_entries().len() as u64;

        let _ = VarlitFile::take_replacement_predecessor_probes();
        writer.replace_block(0, &ReplaceString("replaced".into()))?;
        let probes = VarlitFile::take_replacement_predecessor_probes();

        // At most ceil(log2 N) = 12 probes per chained record; 32 leaves room
        // for the internal records the rewrite also carries.
        let ceiling = 32 * entries;
        assert!(
            probes <= ceiling,
            "predecessor lookup cost {probes} probes over {entries} entries, ceiling {ceiling}; \
             a front-to-back scan of the growing prefix costs ~N^2/2",
        );

        // And the replacement actually happened, so this is not "cheap because
        // the validation was deleted".
        let replaced = VarlitFile::open_readonly(spec, &path)?;
        let values = replaced.blocks::<ReplaceString>()?;
        assert_eq!(values.len() as u64, RECORDS);
        assert_eq!(values.get(0)?.expect("record 0").0, "replaced");
        assert_eq!(
            values.get(RECORDS as usize - 1)?.expect("last record").0,
            format!("v{}", RECORDS - 1),
        );
        Ok(())
    }
}

/// **The in-crate bypass catalogue for `file.rs`** (round 15).
///
/// The companion of `matrix.rs::bypass_catalogue`, and it exists for the same
/// reason: the round-14 proofs were `trybuild` fixtures compiled from an
/// outside crate, which say nothing about the file the defects live in. Every
/// line below was compiled from this module — a sibling of `mod
/// resident_index`, `mod replacement_target` and `mod record_file`, with every
/// privilege a future defect in this file would have — and observed to fail
/// with the quoted diagnostic.
///
/// ```text
/// // (1) mint the append path's reservation token without reserving
/// let _ = ReservedIndexSlot(());
/// //  error[E0423]: cannot initialize a tuple struct which contains private
/// //               fields  (`pub struct ReservedIndexSlot(());`)
///
/// // (2) grow the resident mirror around the token
/// index.entries.push(entry);
/// //  error[E0616]: field `entries` of struct `resident_index::ResidentIndex`
/// //               is private
///
/// // (3) rebuild the mirror by literal to get at the `Vec`
/// let _ = ResidentIndex { entries: Vec::new() };
/// //  error[E0451]: field `entries` of struct `resident_index::ResidentIndex`
/// //               is private
///
/// // (4) mint a version-checked replacement target without the version check
/// let _ = ReplacementTarget { position: 0 };
/// //  error[E0451]: field `position` of struct
/// //               `replacement_target::ReplacementTarget` is private
///
/// // (5) mint the in-place write permission without dropping the keyed tails
/// let _ = RecordOverwrite { record_offset: 0, payload_offset: 0 };
/// //  error[E0451]: fields `record_offset` and `payload_offset` of struct
/// //               `replacement_target::RecordOverwrite` are private
///
/// // (6) fabricate the poison-check witness
/// let _ = MutationPermit { writer, context: "forged" };
/// //  error[E0451]: fields `writer` and `context` are private
///
/// // (7) launder one out of a throwaway flag (round 14's closed hole,
/// //     re-checked here from a different module than the one that closed it)
/// let _ = PoisonFlag::issue(writer, "x")?;
/// //  error[E0624]: associated function `issue` is private
/// ```
///
/// Retained on purpose, with the reason at the declaration: `ResidentIndex::
/// adopt_generation` (open and the rewrite paths hand over a `Vec` that already
/// describes records on disk), `ResidentIndex::truncate` (the append rollback)
/// and `ResidentIndex::rebind` (pointing the directory at the file as it now
/// is). None of them can add an entry the disk does not have, which is the
/// property the token protects.
#[cfg(test)]
mod bypass_catalogue {
    use super::*;

    /// A directory over an empty file. The token tests never produce an entry,
    /// so what backs it never has to hold a record.
    fn empty_index() -> (tempfile::TempDir, ResidentIndex) {
        let directory = tempfile::tempdir().expect("temp dir");
        let path = directory.path().join("empty.varlit");
        std::fs::write(&path, b"").expect("create");
        let snapshot = SnapshotFile::new(File::open(&path).expect("open")).expect("snapshot");
        let spec = FormatSpec::new(
            b"VSBYPS",
            1,
            Endian::Little,
            0,
            IndexPolicy::ScanOnOpen,
            IntegrityPolicy::None,
            RecoveryPolicy::Strict,
            ManifestPolicy::None,
            &[],
        );
        let index = ResidentIndex::empty(snapshot, spec);
        (directory, index)
    }

    /// The legitimate route still works, and still costs the reservation: the
    /// only producer of the token is the fallible half of the append.
    #[test]
    fn the_checked_route_still_produces_the_reservation_it_should() {
        let (_directory, mut index) = empty_index();
        let slot = index.reserve(|| Ok(64)).expect("reservation");
        index.install(slot, &sample_index_entry());
        assert_eq!(index.len(), 1);
    }

    /// And a charge that refuses yields no token at all, so the append that
    /// would have followed it cannot be spelled.
    #[test]
    fn a_refused_charge_yields_no_reservation() {
        let (_directory, mut index) = empty_index();
        assert!(
            index
                .reserve(|| Err(Error::AllocationFailed {
                    resource: "record index",
                    requested: 1,
                }))
                .is_err()
        );
        assert!(index.is_empty());
    }

    fn sample_index_entry() -> RecordIndexEntry {
        RecordIndexEntry {
            block_id: 1,
            block_version: 1,
            flags: 0,
            sequence: 1,
            record_offset: 0,
            payload_offset: 0,
            payload_len: 0,
            checksum: 0,
            uncompressed_len_hint: 0,
            footer_offset: None,
            prev_same_block_offset: None,
            prev_same_key_offset: None,
            mutable_flags: 0,
            committed: true,
        }
    }
}

impl FileMutationPermit<'_> {
    /// Overwrites an already-indexed record's header and payload in place.
    ///
    /// F-01 and F-02, mechanical enforcement. This function holds no addressing
    /// and no invalidation of its own: it takes a [`ReplacementTarget`], whose
    /// only constructor performed the `T::VERSION` refusal, and turns it into a
    /// [`RecordOverwrite`], whose only constructor drops the target block's
    /// resident keyed-tail map. The write is then performed by
    /// `RecordFile::overwrite_indexed_record`, which consumes the
    /// [`RecordOverwrite`] by value and is the only route to those bytes,
    /// because the raw handle is unnameable outside `mod record_file`.
    ///
    /// So the two properties below are not properties of this function that a
    /// sibling could fail to repeat; they are properties of *addressing an
    /// already-indexed record at all*:
    ///
    /// * The invalidation runs **before** the first byte reaches disk, so it
    ///   also covers a write that fails half-way, a poisoned writer that is
    ///   later inspected, and a caller that violates the same-key contract.
    /// * It is infallible and allocation-free (a `HashMap::remove`), so it
    ///   introduces no fallible step of its own, in either direction of
    ///   invariant 3.
    ///
    /// Round 12 stated the same guarantee for a function that a new seek/write
    /// pair elsewhere in this file could simply bypass, and re-verification
    /// compiled exactly that bypass. The bypass no longer builds.
    fn overwrite_record_bytes_in_place(
        &mut self,
        target: ReplacementTarget,
        header_bytes: &[u8],
        payload: &[u8],
    ) -> Result<()> {
        self.check()?;
        // Both preconditions are discharged by constructing the permission:
        // the version refusal happened in `ReplacementTarget::resolve`, and
        // `prepare` drops the keyed-tail map before the write below.
        let writer: &mut VarlitFile = self;
        let write = RecordOverwrite::prepare(target, &writer.index, &mut writer.keyed_tails)?;
        writer
            .file
            .overwrite_indexed_record(write, header_bytes, payload)
    }
    fn write_user_record(
        &mut self,
        block_id: u32,
        block_version: u16,
        kind: BlockKind,
        payload: &[u8],
        prev_same_key_offset: Option<u64>,
    ) -> Result<AppendInfo> {
        self.check()?;
        let payload = prepare_user_record_payload(self.spec, block_id, kind, payload)?;
        self.write_record_with_prev_key(
            block_id,
            block_version,
            payload.flags,
            payload.uncompressed_len_hint,
            &payload.bytes,
            prev_same_key_offset,
        )
    }
    /// The crate's single record-append core.
    ///
    /// Shape B, mechanical enforcement (round 12). It used to call
    /// [`VarlitFile::ensure_write`] itself, which is a convention: a sibling append
    /// helper written next month could seek and `write_all` without one, which
    /// is precisely the defect F-05 was in `stream.rs`. It now demands the
    /// [`MutationPermit`] instead, so the check is the caller's precondition
    /// and the compiler enforces that every route to an append has made it.
    fn write_record_with_prev_key(
        &mut self,
        block_id: u32,
        block_version: u16,
        flags: u16,
        uncompressed_len_hint: u32,
        payload: &[u8],
        prev_same_key_offset: Option<u64>,
    ) -> Result<AppendInfo> {
        self.check()?;
        let payload_len =
            u64::try_from(payload.len()).map_err(|_| Error::LengthOverflow { value: u64::MAX })?;
        self.spec
            .read_limits
            .check(ReadLimitKey::RecordPayloadLen, payload_len)?;
        let logical_len = record_logical_len_from_parts(
            self.spec,
            block_id,
            flags,
            uncompressed_len_hint,
            payload,
        )?;
        self.spec
            .read_limits
            .check(ReadLimitKey::LogicalPayloadLen, logical_len)?;

        let record_count =
            self.index
                .len()
                .checked_add(1)
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "record count",
                })?;
        self.spec.read_limits.check(
            ReadLimitKey::Records,
            u64::try_from(record_count).map_err(|_| Error::ResourceArithmeticOverflow {
                resource: "record count",
            })?,
        )?;
        // Shape A, mechanical enforcement (round 12). The limit charge and the
        // mirror reservation are a precondition of the write below, and the
        // token they produce is the only thing that can install the entry
        // afterwards. See `mod reserved_index_slot`.
        let spec = self.spec;
        // H1, and the only per-block branch the index append has ever had.
        // Internal records are always resident: the manifest, commit markers,
        // checkpoints and segments are varlit's own bookkeeping and every open
        // path expects to find them.
        let resident = block_id >= RESERVED_BLOCK_ID_START || spec.block_is_resident(block_id);
        let index_slot = self.index.reserve(|| index_bytes_for_count(record_count))?;

        let sequence = self.sequence_state.available()?;
        let snapshot = AppendSnapshot {
            // PERF: the end of file is state this writer already maintains, so
            // asking the kernel for it once per record bought nothing. Every
            // construction of `self.snapshot` seeds it from the PHYSICAL length
            // (`SnapshotFile::new` at create, at `open_locked`, at
            // `open_recover_locked` and at both rebind sites) and every
            // successful append rewrites it from the witness the write itself
            // produced; `rollback_append` truncates back to the same `eof` it
            // started from and leaves `self.snapshot` alone.
            //
            // This is not blind trust. `RecordFile::append_record_at_end` still
            // performs its own `seek(SeekFrom::End(0))` and refuses any offset
            // that is not the one budgeted here, so a value that ever drifted
            // yields the existing typed refusal and a rollback — never a write
            // over live data. Removing that check along with the syscall is the
            // positional-write redesign, and is deliberately not what this is.
            eof: self.snapshot.len(),
            sequence_state: self.sequence_state,
            index_len: self.index.len(),
            checkpoint_cadence: self.checkpoint_cadence,
            segment_cursor: self.segment_cursor,
            block_id,
            previous_block_tail: self.block_tails.tail(block_id),
            uncommitted_since_commit: self.uncommitted_since_commit,
            appended_since_digest: self.appended_since_digest,
            last_resident_block_id: self.last_resident_block_id,
        };
        let record_offset = snapshot.eof;
        let payload_offset = record_offset.checked_add(RECORD_HEADER_LEN).ok_or(
            Error::ResourceArithmeticOverflow {
                resource: "file length",
            },
        )?;
        let payload_end =
            payload_offset
                .checked_add(payload_len)
                .ok_or(Error::ResourceArithmeticOverflow {
                    resource: "file length",
                })?;
        let prospective_len = payload_end
            .checked_add(record_footer_len(self.spec))
            .ok_or(Error::ResourceArithmeticOverflow {
                resource: "file length",
            })?;
        // No file-length ceiling here. `max_file_len` refuses on a number
        // rather than on a resource: the scan is bounded incrementally by
        // `ScanBytes`, the index by `Records` and `IndexBytes`, and a mapping
        // by `MmapLen`, each against the thing it actually consumes. A length
        // check on top of those refuses to touch a file whose data is already
        // there, and on the append path it bounds nothing at all — appending to
        // a 1 TB file costs exactly what appending to a 1 GB file costs.
        // PERF2-05: the predecessor comes from the maintained tail table, not
        // from a reverse scan of the resident index.
        let prev_same_block_offset = if self.spec.index_policy.block_offset_chain {
            self.block_tails.tail(block_id)
        } else {
            None
        };
        let prev_same_key_offset = if self.spec.index_policy.keyed_offset_chain {
            prev_same_key_offset
        } else {
            None
        };
        let footer = if self.spec.spec_needs_record_footer() {
            Some(encode_record_footer(RecordFooterFields {
                prev_same_block_offset,
                prev_same_key_offset,
                // A record being appended is alive by construction.
                mutable_flags: 0,
            })?)
        } else {
            None
        };
        let header = RecordHeaderFields {
            block_id,
            block_version,
            flags,
            sequence,
            payload_len,
            checksum: 0,
            uncompressed_len_hint,
        };
        let footer_bytes = footer.as_ref().map_or(&[][..], |bytes| &bytes[..]);
        let checksum =
            checksum_record_fields(self.spec, record_offset, header, payload, footer_bytes)?;
        let header_bytes = encode_native_record_header(
            RecordHeaderFields { checksum, ..header },
            record_offset,
            record_footer_len(self.spec),
        )?;
        let footer_offset = if footer.is_some() {
            payload_end
                .checked_add(RECORD_FOOTER_LEN)
                .ok_or(Error::LengthOverflow { value: payload_len })?;
            Some(payload_end)
        } else {
            None
        };
        // The append is the second and last route to record bytes on disk
        // (`mod record_file`). It seeks to the end itself and refuses an
        // offset that is not the one budgeted above, so this path cannot land
        // inside an already-indexed record even if `record_offset` were wrong.
        let write_result = self.file.append_record_at_end(
            &index_slot,
            record_offset,
            &header_bytes,
            payload,
            footer.as_ref().map(|bytes| &bytes[..]),
            || {
                #[cfg(test)]
                fail_append_after_header_if_requested()?;
                Ok(())
            },
        );
        let written = match write_result {
            Ok(written) => written,
            Err(error) => return Err(self.rollback_append(snapshot, error)),
        };

        // The budgeted extent and the extent actually written are computed
        // independently — one from the header/payload/footer lengths above, the
        // other from the offset `SEEK_END` returned plus the bytes `write_all`
        // took — so they agreeing is a real check on both.
        debug_assert_eq!(written.end_offset(), prospective_len);
        // The write above is the proof that the file reaches this offset, so
        // the rebind needs no `fstat` of its own — that was the second
        // per-record metadata syscall on this path. `with_written_len` is still
        // fallible and still growth-only, so the rollback arm is unchanged.
        let new_snapshot = match self.snapshot.with_written_len(written) {
            Ok(snapshot) => snapshot,
            Err(error) => return Err(self.rollback_append(snapshot, error)),
        };

        let committed =
            !self.spec.commit_policy.is_transaction_marker() || block_id == COMMIT_BLOCK_ID;
        let entry = RecordIndexEntry {
            block_id,
            block_version,
            flags,
            sequence,
            record_offset,
            payload_offset,
            payload_len,
            checksum,
            uncompressed_len_hint,
            footer_offset,
            prev_same_block_offset,
            prev_same_key_offset,
            // Appended, therefore alive.
            mutable_flags: 0,
            committed,
        };
        let info = AppendInfo::from(&entry);
        // A non-resident block's record is written, sequenced, chained and
        // recoverable exactly as any other; it is simply not mirrored in
        // memory, which is what stops resident cost tracking record count.
        //
        // Three things are deliberately *not* skipped with it. Sequences are
        // file-global and gapless, so `publish_sequence` below runs either way.
        // `BlockTails` is what makes the footer chain walkable and is
        // `O(blocks)`, not `O(records)` - it is the only way back to a
        // non-resident record, so it is maintained for every block. And the
        // record's own footer chain went to disk above, not to memory.
        if resident {
            self.last_resident_block_id = Some(block_id);
            self.index.install(index_slot, &entry);
            // Single index append site: keep the O(1) flush-cadence state in
            // lockstep with the resident index (PERF2-02). It counts resident
            // entries, so a non-resident record must not advance it.
            let ordinal = self.index.len() - 1;
            self.checkpoint_cadence.note_appended(ordinal, block_id);
            self.segment_cursor
                .note_appended(ordinal, block_id, prospective_len);
        } else {
            drop(index_slot);
        }
        self.block_tails.note_appended(block_id, record_offset);
        // The marker itself clears the flag; a segment record is written after
        // the marker it certifies and must not set it again, or a repeated idle
        // flush would write marker, segment, marker, segment forever.
        self.uncommitted_since_commit = match block_id {
            COMMIT_BLOCK_ID => false,
            // A digest is written after the marker it describes, for the same
            // reason a segment is, so it needs the same exemption. Without it
            // the digest sets the flag, the next idle flush writes a marker
            // because the flag is set, and the file grows forever on a handle
            // nothing is appending to.
            SEGMENT_BLOCK_ID | OPEN_DIGEST_BLOCK_ID => self.uncommitted_since_commit,
            _ => true,
        };
        // Maintained for every record, resident or not — that is the whole
        // point of it. The digest is the one record that clears it: it is
        // written last and describes everything before it, including itself.
        self.appended_since_digest = block_id != OPEN_DIGEST_BLOCK_ID;
        self.snapshot = new_snapshot;
        // The directory's entries are rebuilt from the file, and the record
        // just installed is past the end of the snapshot this handle held a
        // moment ago — `SnapshotFile` refuses a read beyond its logical length
        // rather than serving it, so without this the entry for the newest
        // record would be unreadable until something else rebound. One `Arc`
        // refcount bump and a `u64` copy: no allocation and no syscall, which
        // is what lets it sit here.
        let snapshot = self.snapshot.clone();
        self.index.rebind(snapshot);
        self.publish_sequence(sequence);
        Ok(info)
    }
    /// The one place the region reaches the disk.
    ///
    /// Writes the payload at its fixed offset and syncs before updating the
    /// cached copy, so a crash mid-write leaves the file and this handle
    /// agreeing about which generation of the region is on disk.
    fn commit_header_slots(
        &mut self,
        extent: MutableHeaderExtent,
        used: usize,
        entries: &[u8],
        sealed: bool,
    ) -> Result<()> {
        self.check()?;
        let payload = encode_header_slots_payload(self.spec, used, entries, sealed)?;
        self.commit_header_slots_payload(extent, &payload)
    }

    fn commit_header_slots_payload(
        &mut self,
        extent: MutableHeaderExtent,
        payload: &[u8],
    ) -> Result<()> {
        self.check()?;
        if payload.len() != extent.payload_len {
            // A region this build did not write: its geometry is not the one
            // encoded here, and overwriting it would corrupt whatever it is.
            return Err(Error::InvalidFormatSpec(
                "header_slots region length disagrees with the declaration",
            ));
        }
        self.file
            .overwrite_header_region(extent.payload_offset, payload)?;
        self.file.sync_data()?;
        self.header_extensions
            [extent.payload_in_extensions..extent.payload_in_extensions + extent.payload_len]
            .copy_from_slice(payload);
        Ok(())
    }
}

#[cfg(test)]
#[path = "file/validation_tests.rs"]
mod validation_tests;

#[path = "file/header_codec.rs"]
mod header_codec;
use header_codec::*;

pub(crate) use header_codec::file_header_extensions;

pub(crate) use header_codec::header_tails_region_len;

pub(crate) use header_codec::blank_mutable_header_bytes;

#[path = "file/scan.rs"]
mod scan;
#[cfg(any(test, feature = "scalable-fault-injection"))]
pub(crate) use scan::take_open_scan_bytes;
#[cfg(any(test, feature = "scalable-fault-injection"))]
pub(crate) use scan::take_record_entry_faults;
use scan::*;

pub(crate) use scan::NativeStreamScanner;
#[cfg(test)]
pub(crate) use scan::reset_stream_io_counters;
#[cfg(test)]
pub(crate) use scan::stream_io_counters;

pub(crate) use scan::read_stream_entry_at;

pub(crate) use scan::PreparedStreamRecord;

pub(crate) use scan::PreparedRecordParts;

#[cfg(test)]
pub(crate) use scan::prepare_stream_user_record;
pub(crate) use scan::prepare_stream_user_record_into;

pub(crate) use scan::prepare_stream_tombstone_record;

pub(crate) use scan::prepare_stream_manifest_record;

pub(crate) use scan::fresh_stream_creation_nonce;

pub(crate) use scan::prepare_stream_creation_nonce_record;

pub(crate) use scan::read_stream_creation_nonce;

#[path = "file/publication.rs"]
mod publication;
#[cfg(unix)]
pub(crate) use publication::opened_file_identity;
#[cfg(windows)]
pub(crate) use publication::opened_file_identity;
use publication::*;

pub(crate) use publication::PinnedObject;

pub(crate) use publication::create_rewrite_temp_file;

pub use publication::ReplacePublicationFailure;

pub use publication::classify_replace_publication_error;

pub(crate) use publication::ReplaceDurability;

pub(crate) use publication::publish_temp_path_atomically;

pub(crate) use publication::publish_open_temp_path_atomically;
#[cfg(not(windows))]
pub(crate) use publication::replace_path_atomically;
#[cfg(windows)]
pub(crate) use publication::replace_path_atomically;
#[cfg(unix)]
pub(crate) use publication::sync_parent_directory;
#[cfg(windows)]
pub(crate) use publication::sync_parent_directory;

#[path = "file/locks.rs"]
mod locks;
#[cfg(unix)]
#[cfg(feature = "experimental-matrix-reuse")]
pub(crate) use locks::verify_dedicated_lock_marker;
#[cfg(windows)]
#[cfg(feature = "experimental-matrix-reuse")]
pub(crate) use locks::verify_dedicated_lock_marker;
#[cfg(not(any(unix, windows)))]
#[cfg(feature = "experimental-matrix-reuse")]
pub(crate) use locks::verify_dedicated_lock_marker;
use locks::*;

pub(crate) use locks::WriterLock;

pub(crate) use locks::WriterGuardLockError;
#[cfg(not(windows))]
pub(crate) use locks::try_lock_native_guard;
#[cfg(windows)]
pub(crate) use locks::try_lock_native_guard;
#[cfg(not(windows))]
pub(crate) use locks::unlock_native_guard;
#[cfg(windows)]
pub(crate) use locks::unlock_native_guard;

pub use locks::clear_stale_writer_lock;

pub(crate) use locks::with_writer_lock_value;

#[cfg(feature = "mmap")]
#[path = "file/mmap_views.rs"]
mod mmap_views;
#[cfg(feature = "mmap")]
use mmap_views::*;
#[cfg(feature = "mmap")]
pub use mmap_views::{MmapMatrix, MmapPayloadWindow, MmapPayloads};

impl crate::TryClone for RecordIndexEntry {
    fn try_clone(&self) -> Result<Self> {
        // All fields are integers, booleans, or Option<u64>; no owned heap data.
        Ok(self.clone())
    }
}
