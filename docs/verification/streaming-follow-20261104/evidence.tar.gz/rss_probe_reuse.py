import json,subprocess,resource,time,os
from pathlib import Path
r=Path('/workspace/scratch/stream-cache');out=r/'rss-probes-reuse';out.mkdir(exist_ok=True)
args=['pending',str(256<<20),'4096','64','8','8','4','0','resident','varying']
bins={label:r/folder/'native_follow_load' for label,folder in [('before','before-bin'),('follow-reuse','reuse-follow-bin'),('after-v1','after-bin'),('after-reuse','reuse-after-bin')]}
for group in range(3):
 for label in bins:
  proc=subprocess.Popen([str(bins[label]),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env={**os.environ,'TMPDIR':str(r/'disk-data')})
  peak=0;snapshot='';samples=0
  while proc.poll() is None:
   try:
    raw=Path(f'/proc/{proc.pid}/smaps_rollup').read_text();rss=int(next(s.split()[1] for s in raw.splitlines() if s.startswith('Rss:')))
    if rss>peak:peak=rss;snapshot=raw
    samples+=1
   except (OSError,StopIteration):pass
   time.sleep(.005)
  stdout,stderr=proc.communicate();row={'label':label,'group':group,'command':[str(bins[label]),*args],'returncode':proc.returncode,'stdout':stdout,'stderr':stderr,'sampled_rss_kib':peak,'rollup_at_sampled_peak':snapshot,'samples':samples}
  (out/f'{label}-{group}.json').write_text(json.dumps(row,indent=2));print(label,group,peak,snapshot,flush=True);assert proc.returncode==0
