from pathlib import Path
import hashlib,json,random,statistics,subprocess,os
r=Path('/workspace/scratch/stream-cache');out=r/'sequence-inline-diagnostic';out.mkdir(exist_ok=True)
bins={'original':Path('/workspace/varlit-pre-boundary/target/release/examples/record_mutation_load'),'before':r/'sequence-direct-before-inline/record_mutation_load','after':r/'sequence-bin/record_mutation_load'}
cases=[('variable',['writer','variable','random','200000','20000']),('mixed',['writer','mixed','random','131072','8192'])]
plan={'purpose':'A fixed six-group diagnostic of direct13-byte row reads after rejecting64KiB page reads; not pooled with the different binary. Not final qualification.','seed':961021,'groups':6,'cases':cases,'sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in bins.items()},'metrics':'mark operation seconds, whole-child CPU/RSS/writes, final private logical bytes; same exact harness source/work in each binary'}
(out/'plan.json').write_text(json.dumps(plan,indent=2))
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});rng=random.Random(plan['seed']);rows=[]
import itertools
for name,args in cases:
 orders=list(itertools.permutations(bins));rng.shuffle(orders)
 for group,order in enumerate(orders):
  for label in order:
   usage=out/'usage.json';p=subprocess.run(['/workspace/scratch/perf-recovery/initial/measure',str(usage),str(bins[label]),*args],capture_output=True,text=True,check=True,timeout=600,env={**os.environ,'TMPDIR':str(r/'disk-data')})
   row={'case':name,'group':group,'label':label,'result':json.loads(p.stdout),'usage':json.loads(usage.read_text())};rows.append(row)
   with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(name,group,label,row['result']['seconds'],row['usage']['cpu'],row['usage']['rss'],flush=True)
 selected=[x for x in rows if x['case']==name];keys=['mode','layout','order','count','marks','source_bytes'];work=[{k:x['result'][k] for k in keys} for x in selected];assert all(w==work[0] for w in work)
 med={label:statistics.median(x['result']['seconds'] for x in selected if x['label']==label) for label in bins};print('SUMMARY',name,med,{k:100*(v/med['original']-1) for k,v in med.items()},flush=True)
print('FINISHED',flush=True)
