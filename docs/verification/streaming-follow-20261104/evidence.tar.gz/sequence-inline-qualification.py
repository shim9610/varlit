from pathlib import Path
import hashlib,itertools,json,os,random,statistics,subprocess
r=Path('/workspace/scratch/stream-cache');out=r/'sequence-inline-qualification';out.mkdir(exist_ok=True)
old=Path('/workspace/varlit-pre-boundary/target/release/examples/record_mutation_load')
bins={'original-a':old,'original-b':old,'before':r/'sequence-before-bin/record_mutation_load','after':r/'sequence-bin/record_mutation_load'}
cases=[('variable',['writer','variable','random','200000','20000'],12),('short-mixed',['writer','mixed','random','131072','8192'],24),('epochs',['epochs','fixed','random','200000','20000'],12),('rewritten',['rewrite','variable','random','200000','20000'],12)]
plan={'seed':961022,'cases':cases,'gate':1.05,'groups':'Fixed in advance, no optional extension. All observations retained.','metrics':['median operation seconds','median whole-child CPU seconds','maximum RSS KiB','median written bytes','maximum final private logical bytes'],'affinity':'one allowed logical CPU, matching prior original-reference record_mutation_load experiments','sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in bins.items()},'source_patch_sha256':hashlib.sha256((r/'sequence-inline-source.patch').read_bytes()).hexdigest(),'cpu_quota':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'memory_limit_bytes':Path('/sys/fs/cgroup/memory.max').read_text().strip()}
p=out/'plan.json'
if p.exists():assert json.loads(p.read_text())==json.loads(json.dumps(plan))
else:p.write_text(json.dumps(plan,indent=2))
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
orders=[['original-a','original-b','after','before'],['original-b','before','original-a','after'],['before','after','original-b','original-a'],['after','original-a','before','original-b']];random.Random(plan['seed']).shuffle(orders)
rows=[json.loads(x) for x in (out/'samples.jsonl').read_text().splitlines()] if (out/'samples.jsonl').exists() else [];done={(x['case'],x['group'],x['label']) for x in rows};summaries=[]
for name,args,groups in cases:
 for group in range(groups):
  for label in orders[group%4]:
   if (name,group,label) in done:continue
   usage=out/'usage.json';p=subprocess.run(['/workspace/scratch/perf-recovery/initial/measure',str(usage),str(bins[label]),*args],capture_output=True,text=True,timeout=600,env={**os.environ,'TMPDIR':str(r/'disk-data')})
   if p.returncode:
    (out/'failure.json').write_text(json.dumps({'command':[str(bins[label]),*args],'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2));raise RuntimeError('measurement failed')
   row={'case':name,'group':group,'label':label,'result':json.loads(p.stdout),'usage':json.loads(usage.read_text())};rows.append(row)
   with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(name,group,label,row['result']['seconds'],row['usage']['cpu'],row['usage']['rss'],flush=True)
 selected=[x for x in rows if x['case']==name];keys=['mode','layout','order','count','marks','source_bytes'];work=[{k:x['result'][k] for k in keys} for x in selected];assert all(w==work[0] for w in work)
 getters={'seconds':lambda x:x['result']['seconds'],'cpu':lambda x:x['usage']['cpu'],'rss_kib':lambda x:x['usage']['rss'],'write_bytes':lambda x:x['usage']['write_blocks']*512,'private_bytes':lambda x:x['result']['temporary_bytes']}
 values={k:{label:(max if k in ['rss_kib','private_bytes'] else statistics.median)(fn(x) for x in selected if x['label']==label) for label in bins} for k,fn in getters.items()}
 comparisons={before:{k:{'percent':100*(v['after']/v[before]-1) if v[before] else (0 if v['after']==0 else None),'passed':v['after']<=1.05*v[before]} for k,v in values.items()} for before in ['original-a','original-b','before']}
 aa=100*(values['seconds']['original-b']/values['seconds']['original-a']-1);summary={'case':name,'groups':groups,'work':work[0],'values':values,'comparisons':comparisons,'same_binary_median_percent':aa,'calibration_passed':abs(aa)<=5,'passed':abs(aa)<=5 and all(m['passed'] for b in comparisons.values() for m in b.values())};summaries.append(summary);(out/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',name,json.dumps(summary),flush=True)
print('FINISHED',flush=True)
