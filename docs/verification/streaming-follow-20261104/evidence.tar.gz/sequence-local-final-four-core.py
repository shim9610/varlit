from pathlib import Path
import hashlib,itertools,json,os,random,statistics,subprocess
r=Path('/workspace/scratch/stream-cache');out=r/'sequence-local-final-four-core';out.mkdir(exist_ok=True)
affinity=sorted(os.sched_getaffinity(0))[:4];assert len(affinity)==4
cases=[('independent-1g-r8','native_streaming_load',[1<<30,65536,16<<20,8,16,0,'resident']),('independent-4g-r8','native_streaming_load',[4<<30,65536,16<<20,8,16,0,'resident']),('complex-varying','native_follow_load',['pending',256<<20,4096,64,8,8,4,0,'resident','varying']),('independent-1g-r1','native_streaming_load',[1<<30,65536,16<<20,1,16,0,'resident'])]
bins={label:{exe:r/folder/exe for exe in ['native_streaming_load','native_follow_load']} for label,folder in [('before-a','budget-bin'),('before-b','budget-bin'),('after','sequence-bin')]}
plan={'seed':961023,'groups_per_case':12,'cases':cases,'affinity':affinity,'cpu_quota':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'memory_limit_bytes':Path('/sys/fs/cgroup/memory.max').read_text().strip(),'gate':1.05,'reason':'Separate comparison restricted to four logical CPUs as well as the existing four-CPU quota; it does not identify the cause of earlier variability. This does not replace or pool the prior unrestricted-affinity failures. Same4CPU quota and16GiB memory, same calls/work, no writer acknowledgment waits.','before':'Frozen98692fa runtime, identical to67a8939 product code','after':'2e68aa9 plus sequence-local-final-source.patch (mark-only borrow, original generic get_direct unchanged)','sha256':{label:{exe:hashlib.sha256(p.read_bytes()).hexdigest() for exe,p in exes.items()} for label,exes in bins.items()}}
p=out/'plan.json'
if p.exists():assert json.loads(p.read_text())==json.loads(json.dumps(plan))
else:p.write_text(json.dumps(plan,indent=2))
os.sched_setaffinity(0,set(affinity));rows=[json.loads(x) for x in (out/'samples.jsonl').read_text().splitlines()] if (out/'samples.jsonl').exists() else [];done={(x['case'],x['group'],x['label']) for x in rows};summaries=[]
for number,(name,exe,args) in enumerate(cases):
 rng=random.Random(plan['seed']+number);orders=[]
 for _ in range(2):
  block=list(itertools.permutations(bins));rng.shuffle(block);orders+=block
 for group,order in enumerate(orders):
  for label in order:
   if (name,group,label) in done:continue
   usage=out/'usage.json';cmd=['/workspace/scratch/perf-recovery/initial/measure',str(usage),str(bins[label][exe]),*map(str,args)];p=subprocess.run(cmd,capture_output=True,text=True,timeout=600,env={**os.environ,'TMPDIR':str(r/'disk-data')})
   if p.returncode:(out/'failure.json').write_text(json.dumps({'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2));raise RuntimeError(cmd)
   row={'case':name,'group':group,'label':label,'result':json.loads(p.stdout),'usage':json.loads(usage.read_text())};rows.append(row)
   with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(name,group,label,row['result']['seconds'],row['result'].get('writer_seconds'),row['usage']['cpu'],row['usage']['rss'],flush=True)
 selected=[x for x in rows if x['case']==name];keys=(['bytes','payload','epoch_bytes','readers','follows','records','read_bytes','trace','source_bytes','residency'] if exe=='native_streaming_load' else ['mode','residency','shape','bytes','payload','epochs','readers','polls','records','read_bytes','trace','source_bytes']);work=[{k:x['result'][k] for k in keys} for x in selected];assert all(w==work[0] for w in work)
 getters={'seconds':lambda x:x['result']['seconds'],'cpu':lambda x:x['usage']['cpu'],'rss_kib':lambda x:x['usage']['rss'],'write_bytes':lambda x:x['usage']['write_blocks']*512}
 if exe=='native_streaming_load':getters['writer_seconds']=lambda x:x['result']['writer_seconds']
 else:getters['private_bytes']=lambda x:x['result']['temporary_bytes']
 values={k:{label:(max if k in ['rss_kib','private_bytes'] else statistics.median)(fn(x) for x in selected if x['label']==label) for label in bins} for k,fn in getters.items()}
 comparisons={before:{k:{'percent':100*(v['after']/v[before]-1) if v[before] else (0 if not v['after'] else None),'passed':v['after']<=v[before]*1.05} for k,v in values.items()} for before in ['before-a','before-b']}
 calibration={k:100*(values[k]['before-b']/values[k]['before-a']-1) for k in ['seconds','writer_seconds'] if k in values};summary={'case':name,'groups':12,'work':work[0],'values':values,'comparisons':comparisons,'same_binary_median_percent':calibration,'passed':all(abs(v)<=5 for v in calibration.values()) and all(m['passed'] for c in comparisons.values() for m in c.values())};summaries.append(summary);(out/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',name,json.dumps(summary),flush=True)
print('FINISHED',flush=True)
