from pathlib import Path
import hashlib,json,os,random,statistics,subprocess
r=Path('/workspace/scratch/stream-cache');out=r/'sequence-local-final-replication';out.mkdir(exist_ok=True)
marks=r/'sequence-local-final-qualification';native=r/'sequence-local-final-four-core';initial={'marks':[json.loads(x) for x in (marks/'samples.jsonl').read_text().splitlines()],'native':[json.loads(x) for x in (native/'samples.jsonl').read_text().splitlines()]}
old=Path('/workspace/varlit-pre-boundary/target/release/examples/record_mutation_load');mb={'original-a':old,'original-b':old,'before':r/'sequence-before-bin/record_mutation_load','after':r/'sequence-bin/record_mutation_load'};nb={'before-a':r/'budget-bin/native_streaming_load','before-b':r/'budget-bin/native_streaming_load','after':r/'sequence-bin/native_streaming_load'}
all_affinity=sorted(os.sched_getaffinity(0));cases=[('marks','short-mixed',24,24,['writer','mixed','random',131072,8192]),('marks','epochs',12,12,['epochs','fixed','random',200000,20000]),('native','independent-1g-r8',12,12,[1<<30,65536,16<<20,8,16,0,'resident']),('native','independent-4g-r8',12,12,[4<<30,65536,16<<20,8,16,0,'resident'])]
for folder,bins in [(marks,mb)]:assert json.loads((folder/'plan.json').read_text())['sha256']=={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in bins.items()}
np=json.loads((native/'plan.json').read_text());assert all(np['sha256'][label]['native_streaming_load']==hashlib.sha256(p.read_bytes()).hexdigest() for label,p in nb.items())
plan={'purpose':'One fixed replication after the completed initial series. Retain all initial failures and pool every initial+new observation; never select a subset or extend again for this unchanged candidate.','seed':961025,'cases':cases,'gate':1.05,'initial_samples_sha256':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [marks/'samples.jsonl',native/'samples.jsonl']},'sha256':{'marks':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in mb.items()},'native':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in nb.items()}},'affinity':{'marks':[all_affinity[0]],'native':np['affinity']},'cpu_quota':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'memory_limit_bytes':Path('/sys/fs/cgroup/memory.max').read_text().strip()}
p=out/'plan.json'
if p.exists():assert json.loads(p.read_text())==json.loads(json.dumps(plan))
else:p.write_text(json.dumps(plan,indent=2))
extra=[json.loads(x) for x in (out/'samples.jsonl').read_text().splitlines()] if (out/'samples.jsonl').exists() else [];done={(x['series'],x['case'],x['group'],x['label']) for x in extra};summaries={}
for number,(series,name,initial_groups,groups,args) in enumerate(cases):
 bins=mb if series=='marks' else nb;os.sched_setaffinity(0,set(plan['affinity'][series]));rng=random.Random(plan['seed']+number)
 if series=='marks':
  orders=[['original-a','original-b','after','before'],['original-b','before','original-a','after'],['before','after','original-b','original-a'],['after','original-a','before','original-b']];rng.shuffle(orders);orders=[orders[g%4] for g in range(groups)]
 else:
  import itertools
  orders=[]
  for _ in range(2):
   block=list(itertools.permutations(bins));rng.shuffle(block);orders+=block
 for n,order in enumerate(orders):
  group=initial_groups+n
  for label in order:
   if (series,name,group,label) in done:continue
   usage=out/'usage.json';cmd=['/workspace/scratch/perf-recovery/initial/measure',str(usage),str(bins[label]),*map(str,args)];p=subprocess.run(cmd,capture_output=True,text=True,timeout=600,env={**os.environ,'TMPDIR':str(r/'disk-data')})
   if p.returncode:(out/'failure.json').write_text(json.dumps({'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2));raise RuntimeError(cmd)
   row={'series':series,'case':name,'group':group,'label':label,'result':json.loads(p.stdout),'usage':json.loads(usage.read_text())};extra.append(row)
   with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(series,name,group,label,row['result']['seconds'],row['result'].get('writer_seconds'),row['usage']['cpu'],row['usage']['rss'],flush=True)
 chosen=[x for x in initial[series]+[x for x in extra if x['series']==series] if x['case']==name];workkeys=['mode','layout','order','count','marks','source_bytes'] if series=='marks' else ['bytes','payload','epoch_bytes','readers','follows','records','read_bytes','trace','source_bytes','residency'];work=[{k:x['result'][k] for k in workkeys} for x in chosen];assert all(w==work[0] for w in work)
 getters={'seconds':lambda x:x['result']['seconds'],'cpu':lambda x:x['usage']['cpu'],'rss_kib':lambda x:x['usage']['rss'],'write_bytes':lambda x:x['usage']['write_blocks']*512}
 if series=='marks':getters['private_bytes']=lambda x:x['result']['temporary_bytes']
 else:getters['writer_seconds']=lambda x:x['result']['writer_seconds']
 values={k:{label:(max if k in ['rss_kib','private_bytes'] else statistics.median)(fn(x) for x in chosen if x['label']==label) for label in bins} for k,fn in getters.items()};befores=[x for x in bins if x!='after'];comparisons={before:{k:{'percent':100*(v['after']/v[before]-1) if v[before] else (0 if not v['after'] else None),'passed':v['after']<=v[before]*1.05} for k,v in values.items()} for before in befores}
 aa_keys=['seconds'] if series=='marks' else ['seconds','writer_seconds'];a,b=('original-a','original-b') if series=='marks' else ('before-a','before-b');calibration={k:100*(values[k][b]/values[k][a]-1) for k in aa_keys};summary={'case':name,'groups':initial_groups+groups,'work':work[0],'values':values,'comparisons':comparisons,'same_binary_median_percent':calibration,'passed':all(abs(v)<=5 for v in calibration.values()) and all(m['passed'] for c in comparisons.values() for m in c.values())};summaries[(series,name)]=summary
 output=json.loads(((marks if series=='marks' else native)/'summary.json').read_text());output=[summaries.get((series,x['case']),x) for x in output];(out/('pooled-'+series+'.json')).write_text(json.dumps(output,indent=2));print('POOLED',series,name,json.dumps(summary),flush=True)
print('FINISHED',flush=True)
