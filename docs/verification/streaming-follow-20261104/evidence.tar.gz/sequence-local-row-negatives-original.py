from pathlib import Path
import hashlib,json,subprocess
r=Path('/workspace/scratch/stream-cache');p=Path('/workspace/varlit/crates/varlit-core/src/native_directory.rs');original=p.read_bytes()
mutations={
 'buffered':(b'return Ok(u64::from_le_bytes(row[..8].try_into().unwrap()) == offset);',b'return Ok({ let _ = row; true });'),
 'spilled':(b'.is_some_and(|row| u64::from_le_bytes(row[..8].try_into().unwrap()) == offset)',b'.is_some_and(|row| { let _ = row; true })')}
results=[]
for name,(needle,replacement) in mutations.items():
 assert original.count(needle)==1
 try:
  p.write_bytes(original.replace(needle,replacement));x=subprocess.run(['cargo','test','--locked','-p','varlit-core','--all-features','--lib','serialized_directory_cannot_authorize_marking_an_embedded_record'],cwd='/workspace/varlit',capture_output=True,text=True)
  (r/f'sequence-local-row-negative-{name}.log').write_text(x.stdout+x.stderr)
  assert x.returncode!=0 and 'test result: FAILED' in x.stdout and 'assertion failed' in x.stdout,(name,x.returncode,x.stdout,x.stderr)
  results.append({'control':name+' actual-offset comparison removed','detected':True,'exit':x.returncode})
 finally:p.write_bytes(original)
assert p.read_bytes()==original
(r/'sequence-local-row-negatives.json').write_text(json.dumps({'source_sha256':hashlib.sha256(original).hexdigest(),'results':results,'restored':True},indent=2))
x=subprocess.run(['cargo','test','--locked','-p','varlit-core','--all-features','--lib','serialized_directory_cannot_authorize_marking_an_embedded_record'],cwd='/workspace/varlit',capture_output=True,text=True);(r/'sequence-local-row-restored.log').write_text(x.stdout+x.stderr);assert x.returncode==0
print('Both buffered and spilled spoofing controls killed; restored test passes.',flush=True)
