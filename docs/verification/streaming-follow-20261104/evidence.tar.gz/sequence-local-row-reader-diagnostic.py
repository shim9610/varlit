from pathlib import Path
import hashlib,json,os,random,statistics,subprocess
r=Path('/workspace/scratch/stream-cache');out=r/'sequence-local-row-reader-diagnostic';out.mkdir(exist_ok=True)
bins={'base':r/'budget-bin','direct':r/'sequence-direct-before-inline','global':r/'sequence-global-inline-bin','local':r/'sequence-bin'}
cases=[('independent','native_streaming_load',[1<<30,65536,16<<20,8,16,0,'resident']),('complex','native_follow_load',['pending',256<<20,4096,64,8,8,4,0,'resident','varying'])]
affinity=sorted(os.sched_getaffinity(0))[:4]
plan={'purpose':'Four-version diagnostic of global point-read inlining versus a mark-only resident-row borrow. Not qualification and does not replace prior failed data.','seed':961024,'groups':4,'affinity':affinity,'cases':cases,'sha256':{label:{exe:hashlib.sha256((folder/exe).read_bytes()).hexdigest() for exe in ['native_streaming_load','native_follow_load']} for label,folder in bins.items()}}
(out/'plan.json').write_text(json.dumps(plan,indent=2));os.sched_setaffinity(0,set(affinity));orders=[['base','direct','local','global'],['direct','global','base','local'],['global','local','direct','base'],['local','base','global','direct']];random.Random(plan['seed']).shuffle(orders);rows=[];summaries=[]
for name,exe,args in cases:
 for group,order in enumerate(orders):
  for label in order:
   usage=out/'usage.json';p=subprocess.run(['/workspace/scratch/perf-recovery/initial/measure',str(usage),str(bins[label]/exe),*map(str,args)],capture_output=True,text=True,timeout=600,check=True,env={**os.environ,'TMPDIR':str(r/'disk-data')})
   row={'case':name,'group':group,'label':label,'result':json.loads(p.stdout),'usage':json.loads(usage.read_text())};rows.append(row)
   with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(name,group,label,row['result']['seconds'],row['usage']['cpu'],row['usage']['rss'],row['result']['frames'],flush=True)
 chosen=[x for x in rows if x['case']==name];getters={'seconds':lambda x:x['result']['seconds'],'cpu':lambda x:x['usage']['cpu'],'rss':lambda x:x['usage']['rss'],'frames':lambda x:x['result']['frames']}
 values={key:{label:(max if key=='rss' else statistics.median)(fn(x) for x in chosen if x['label']==label) for label in bins} for key,fn in getters.items()};summaries.append({'case':name,'values':values});(out/'summary.json').write_text(json.dumps(summaries,indent=2));print('SUMMARY',name,values,flush=True)
print('FINISHED',flush=True)
