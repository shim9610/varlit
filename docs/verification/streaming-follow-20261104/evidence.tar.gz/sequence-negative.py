from pathlib import Path
import os,subprocess,json,hashlib
r=Path('/workspace/scratch/stream-cache');p=Path('/workspace/varlit/crates/varlit-core/src/native_directory.rs');original=p.read_bytes()
needle=b'.is_some_and(|row| u64::from_le_bytes(row[..8].try_into().unwrap()) == offset)'
assert original.count(needle)==1
mutated=original.replace(needle,b'.is_some_and(|row| { let _ = row; true })')
try:
 p.write_bytes(mutated)
 result=subprocess.run(['cargo','test','--locked','-p','varlit-core','--all-features','--lib','serialized_directory_cannot_authorize_marking_an_embedded_record'],capture_output=True,text=True,cwd='/workspace/varlit')
 (r/'sequence-negative.log').write_text(result.stdout+result.stderr)
 assert result.returncode!=0
 assert 'test result: FAILED' in result.stdout and 'assertion failed' in result.stdout
finally:p.write_bytes(original)
assert p.read_bytes()==original
(r/'sequence-negative.json').write_text(json.dumps({'control':'accept the sequence-selected private row without comparing its actual offset','exit':result.returncode,'detected':True,'restored_sha256':hashlib.sha256(original).hexdigest()},indent=2))
result=subprocess.run(['cargo','test','--locked','-p','varlit-core','--all-features','--lib','serialized_directory_cannot_authorize_marking_an_embedded_record'],capture_output=True,text=True,cwd='/workspace/varlit')
(r/'sequence-restored.log').write_text(result.stdout+result.stderr)
assert result.returncode==0
print('Killed missing-offset-equality mutation; restored contract passes.',flush=True)
