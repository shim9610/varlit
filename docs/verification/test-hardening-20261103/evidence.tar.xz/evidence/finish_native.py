from pathlib import Path
import json,time,subprocess
root=Path('/workspace/scratch/test-hardening');host=root/'after-perf/host.json'
while not host.exists() or 'memory.events_after' not in json.loads(host.read_text()): time.sleep(2)
repo=Path('/workspace/varlit');script=repo/'docs/performance/audit-followup-20261102/bench.py'
cmd=['python3',str(script),'--before',str(root/'before-bin'),'--after',str(root/'after-bin'),'--repo',str(repo),'--phase','native','--native-cases','0','4','7','9','10']
with (root/'native-final.log').open('w') as f: subprocess.run(cmd+['--pairs','5','--output',str(root/'native-final')],stdout=f,stderr=subprocess.STDOUT,check=True)
flagged=[r['case'] for r in json.loads((root/'native-final/native-summary.json').read_text()) if any((m['change_percent'] or 0)>5 for m in r['metrics'].values())]
if flagged:
 cmd=['python3',str(script),'--before',str(root/'before-bin'),'--after',str(root/'after-bin'),'--repo',str(repo),'--phase','native','--native-cases',*map(str,flagged),'--pairs','15','--output',str(root/'native-final-confirmation')]
 with (root/'native-final-confirmation.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
print('FINAL_NATIVE_COMPLETE',flush=True)
