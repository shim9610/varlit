import json,statistics,hashlib,struct
from pathlib import Path
root=Path('/workspace/scratch/test-hardening')
def sections(path):
 b=path.read_bytes();off=struct.unpack_from('<Q',b,40)[0];size,n,strings=struct.unpack_from('<HHH',b,58)
 headers=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size) for i in range(n)]
 sh=headers[strings];names=b[sh[4]:sh[4]+sh[5]]
 return {names[h[0]:].split(b'\0',1)[0].decode():hashlib.sha256(b[h[4]:h[4]+h[5]] if h[1]!=8 else str(h[5]).encode()).hexdigest() for h in headers if h[2]&2}
comparisons=[]
for p in (root/'before-bin').iterdir():
 q=root/'after-bin'/p.name;a=sections(p);b=sections(q);comparisons.append(dict(name=p.name,before_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),after_sha256=hashlib.sha256(q.read_bytes()).hexdigest(),different_allocated_sections=[k for k in sorted(a.keys()|b.keys()) if a.get(k)!=b.get(k)]))
(root/'binary-comparison-final.json').write_text(json.dumps(comparisons,indent=2)+'\n')
samples=json.loads((root/'native-final/native-samples.json').read_text())
for row in json.loads((root/'native-final-confirmation/native-samples.json').read_text()):row['pair']+=5;samples.append(row)
native=[]
for case in sorted({r['case'] for r in samples}):
 rows=[r for r in samples if r['case']==case];metrics={}
 for key,fn,agg in [('elapsed',lambda r:r['result']['seconds'],statistics.median),('cpu',lambda r:r['usage']['cpu'],statistics.median),('rss',lambda r:r['usage']['rss'],max),('writes',lambda r:r['usage']['write_blocks']*512,statistics.median)]:
  a,b=[agg(fn(r) for r in rows if r['side']==s) for s in ['before','after']];metrics[key]=dict(before=a,after=b,change_percent=100*(b/a-1) if a else None)
 native.append(dict(case=case,pairs=len(rows)//2,metrics=metrics))
report=dict(baseline='cd7b0446da3e731fba867802bef5f4b7b3fc328d',runtime_source='e9537e9d4770dc61dc7c55680ee387b008b18db0',native=native,clone=json.loads((root/'after-perf/summary.json').read_text()),swmr={str(n):json.loads((root/'after-perf/swmr'/f'swmr-{n}-comparison.json').read_text()) for n in [1,4]},resources={p.stem:json.loads(p.read_text()) for p in (root/'after-perf').glob('resources-*.json')},host=json.loads((root/'after-perf/host.json').read_text()),binaries=comparisons,qualified_timing_observations=len(samples)+len(json.loads((root/'after-perf/samples.json').read_text()))+12,unqualified_native_observations=50)
(root/'results.json').write_text(json.dumps(report,indent=2)+'\n')
for r in native: print(r['case'],r['pairs'],{k:round(v['change_percent'] or 0,2) for k,v in r['metrics'].items()})
for n,s in report['swmr'].items():print('SWMR',n,{k:round(v['change_percent'],2) for k,v in s['metrics'].items()})
print('Binaries',comparisons)
print('observations',report['qualified_timing_observations'])
